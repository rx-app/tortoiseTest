﻿module.exports = {
  NODE_ENV: '"production"',
  APP_API_ROOT: '"https://pptsappwebapi.ppts.xueda.com/PPTSApp/PPTS.Api"',
  APP_STAFF_HUBS: '"https://pptsappwebapi.ppts.xueda.com/PPTSApp/PPTS.Api"',
}