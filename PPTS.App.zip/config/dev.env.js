var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  IMPERSONATE_USER: {
    LOGIN_ACCOUNT: '"slcd"',
    LOGIN_PASSWORD: '"password"'
  }, //是否为模拟账户登录http://pptsappwebapi-uat.chinacloudapp.cn/PPTSApp/PPTS.Api
  //http://10.1.55.88/PPTSApp/PPTS.Api/
  // APP_API_ROOT: '"http://10.1.55.88/PPTSApp/PPTS.Api/"',
  APP_API_ROOT: '"http://pptsappwebapi-uat.ppts.xueda.com/PPTSApp/PPTS.Api"',
  IS_ACCOUNT_VIEW: true,
})
