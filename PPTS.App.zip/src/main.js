﻿import Vue from 'vue';
import App from './App';
import router from './router';
import store from './store';
import MintUI from 'mint-ui'
import 'mint-ui/lib/style.css'
import '../static/js/vueTouch.js'
import SignalR from './public/util/signalr.util'
import aiSDK from './public/util/ai.util'

Vue.use(MintUI)
Vue.use(SignalR, process.env)
Vue.use(aiSDK, process.env)

window.ajaxList || (window.ajaxList=[])
router.beforeEach((to, from, next) => {
    while (window.ajaxList.length > 0) {
      window.ajaxList.shift()('cancel');
    }
    next();
})

window.$vue = new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
});
