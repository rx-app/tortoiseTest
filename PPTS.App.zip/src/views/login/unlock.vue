﻿<template>
	<finger-psd :type="$route.params.type"></finger-psd>
</template>

<script>
	import FingerPsd from '@/components/fingerPsd/'
	export default {
		// created () {
		// 	console.log(this.$route.params.type)
		// },
		components: {
			FingerPsd
		}
	}
</script>