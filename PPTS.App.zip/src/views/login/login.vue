<template>
	<div class="xd-login">
		<h3 class="xd-regist-title">登录</h3>
		<div id="slider" class="mui-slider" data-slider="4">
			<div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<a class="mui-control-item mui-active nth_child" href="#item1mobile">
					OA账号登录
				</a>
			</div>
			<div id="item1mobile" class="mui-slider-item mui-control-content mui-active">
				<div id="scroll1" class="mui-scroll-wrapper" data-scroll="1">
					<div class="mui-scroll" style="transform: translate3d(0px, 0px, 0px) translateZ(0px);">
						<div class="befor_psd">
							<p class="xd-regist-inp">
								<img :src="crUser?require('@/public/asset/img/login/phone-on.png'):require('@/public/asset/img/login/phone-off.png')" alt="" class="xd-regist-icon" />
								<input ref="refPhone" type="text" placeholder="输入学大OA" v-model="criteria.username" maxlength="20" @click="toggleCrUser()" @focus="isShowInputSelect(criteria.username, 'isshow', true)" @blur="hideInput('isshow')" />

								<!-- <input type="text" placeholder="输入学大OA" v-model="criteria.username" 
								maxlength="20" @click="toggleCrUser()" /> -->
								<i class="line" :class="crUser?'inp-lineOn':'inp-lineOff'"></i>
								<i class="iconfont icon-error" v-show="criteria.username" @click="delText(1)"></i>
								<div class="input-associate" v-show="isshow">
									<ul>
										<li v-for="(item, i) in selectAccounts" :key="i" @click="setInputUserName('criteria', item, 'isshow')">{{item.username}}</li>
									</ul>
								</div>
							</p>
							<p class="xd-regist-inp">
								<img :src="crPsd?require('@/public/asset/img/login/psd-on.png'):require('@/public/asset/img/login/psd-off.png')" alt="" class="xd-regist-icon" />
								<input :type="inpType" placeholder="输入OA密码" v-model="criteria.password" maxlength="20" @click="toggleCrPsd()" />
								<i class="iconfont eye" :class="iconStatus" @click="toggleInpType()"></i>
								<i class="line" :class="crPsd?'inp-lineOn':'inp-lineOff'"></i>
								<i class="iconfont icon-error" v-show="criteria.password" @click="delText(2)"></i>
							</p>
							<div v-show="showValid" style="margin:0 0 20px 0;padding:0 40px;">
								<!-- <SliderVerificationCode v-model="slideCheck" /> -->
								<va v-if="reset" @success="passValid=true" ></va>
								<!-- <va v-if="reset" @success="passValid=true" :confirm="passValid"></va> -->
							</div>

							<!--<button type="button" class="mui-btn mui-btn-block xd-regist-btn" :disabled="criteria.username && criteria.password?false:true" :class="criteria.username && criteria.password? 'xd-regist-btnOn':'xd-regist-btnOff'" @click="userLogin()">
								登录</button>-->
							<div class="mui-btn mui-btn-block xd-regist-btn" :class="criteria.username && criteria.password? 'xd-regist-btnOn':'xd-regist-btnOff'" @click="userLogin()">登录</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<p class='server'>登录即代表阅读并同意
			<router-link :to="{name:'privacy'}" tag='span'>服务条款</router-link>
		</p>
	</div>
</template>

<script>
	import { login } from '@/api/ids/ids-api';
	import { sendLogOnCode } from '@/api/user/user-api';
	import { loadUserInfo } from '@/api/common/common-api';
	import { fingerPsdStatus } from '@/api/common/common-api';
	import store from '@/store';
	import va from './partial/va'
	import * as types from "@/store/mutation-types";
	import { CACHE_KEYS } from '@/constants';
	function resize2() {//*12*点击输入框时，小键盘挡住了输入框
		if (document.activeElement.tagName == 'INPUT' || document.activeElement.tagName == 'TEXTAREA') {
			window.setTimeout(function () {
				document.activeElement.scrollIntoViewIfNeeded();
			}, 0);
		}
  	}
	export default {
		data() {
			return {
				reset:true,
				showValid:true,
				passValid:false,
				slideCheck:false,
				valid:false,
				count: 60,
				dis: false,
				btnCon: "获取验证码",
				crUser: false,
				inpType: 'password',
				iconStatus: 'icon-close-eyes',
				/*普通登录 手机号输入框触发*/
				crPsd: false,
				/*普通登录 密码输入框触发*/
				phoneReg: /^1[34578]\d{9}$/,
				criteria: {
					// username: 'liyycd',
					// password: '123qwe!@#',
					username: '',
					password: '',
					...m2.util.getDevice()
				},
				accountList: [],
				selectAccounts: [],
				isshow: false,
				isVercriteriaShow: false,
				isDel: false
			}
		},
		beforeCreate() {
			mui.plusReady(function () {
				if (mui.os.ios) {
					plus.webview.currentWebview().setStyle({ 'softinputMode': 'adjustPan' });
				}
			});
			let loginStatus = fingerPsdStatus()
			if(loginStatus && typeof loginStatus !== 'undefiend') {
				$vue.$router.push({
					name: 'unlock'
				})
			}
		},
		activated() {
			this.init();
			this.clearMess();
			
		},
		created(){
			if (/Android/gi.test(navigator.userAgent)) {
				window.addEventListener('resize', resize2)
			}
		},
		destroyed(){
			if (/Android/gi.test(navigator.userAgent)) {
				window.removeEventListener('resize', resize2)
			}
		},
		mounted() {
			this.$nextTick( ()=>{
				this.showValid = false
				this.passValid = false
				this.isNeedSlideCheck();
			})
			this.init();
			this.clearMess();
			// this.isNeedSlideCheck();
			
		},
		watch: {
			'criteria.username': function(val, oldVal) {
				if(val === '') {
					this.criteria.password = '';
					this.selectAccounts = this.accountList;
				}
				if(val !== "") {
					var reg = new RegExp(val, 'i');
					this.selectAccounts = [];
					this.accountList.forEach((item, index) => {
						if(reg.test(item.username)) {
							this.accountList.slice(index, index + 1).forEach(item => {
								this.selectAccounts.push(item);
							})
						}
					})
				}
				this.isShowInputSelect(val, 'isshow')
			}
		},
		components: {va},
		methods: {
			isNeedSlideCheck(){
				let validRecords = m2.cache.get('invalid');
				if(validRecords.length>4){
					let v1 = ( new Date().getTime() - Number(validRecords[0]) )/3600000;
					if( ( new Date().getTime() - Number(validRecords[0]) )/3600000 < 1 ){
					this.showValid = true;
					return
					}
				}
				this.showValid = false;
			},
			clearMess(){
				let accountList = m2.cache.get("accountList");
				let pptsUserIcons = m2.cache.get("ppts-user-icons");
				let invalid = m2.cache.get("invalid");
				m2.cache.clear();
				m2.cache.set("accountList", accountList);
				m2.cache.set("ppts-user-icons", pptsUserIcons);
				m2.cache.set("invalid", invalid);

				store.commit(types.CURRENT_USER_GDENDER, 1);
				store.commit(types.CURRENT_USER_HEAD, {});

			},
			init() {
				this.accountList = this.getCacheAccounts()
				if(this.accountList.length) {
					this.criteria.username = this.accountList[0].username
				}
			},
			isShowInputSelect(val, showName, flag) {
				if(this.isDel && typeof flag === 'undefined') {
					return
				}
				if(typeof val === 'undefined' || val.length == 0) {
					this[showName] = true;
					this.selectAccounts = this.accountList
				} else {
					if(val !== '') {
						this[showName] = false;
					} else {
						this[showName] = true;
						let arr = []
						this.accountList.forEach((item, index) => {
							if(item.username.indexOf(val) >= 0) {
								arr.unshift(item)
							}
						})
						this.selectAccounts = arr;
					}
				}
			},
			hideInput(showName) {
				setTimeout(() => {
					this[showName] = false;
				}, 100);
				
			},
			setInputUserName(typeCriteria, val, showName) {
				this[typeCriteria].username = val.username;
				this[showName] = false;
			},
			getCacheAccounts() {
				let accounts = window.localStorage.getItem('accountList')
				if(accounts === 'null' || accounts === null || typeof accounts === 'undefined') {
					return []
				} else {
					return JSON.parse(accounts)
				}
			},
			setCacheAccounts(account) {
				let set = new Set()
				let accounts = window.localStorage.getItem('accountList')
				if(accounts === 'null' || accounts === null || typeof accounts === 'undefined') {
					accounts = []
				} else {
					accounts = JSON.parse(window.localStorage.getItem('accountList'))
				}
				// 去重，并将优选级提升到队列最后，然后反转
				accounts.map((one, i) => {
					if(one.username === account.username) {
						accounts.splice(i, 1);
					}
				})
				accounts.push({
					username: account.username,
					password: account.password
				})
				accounts.reverse()
				console.log(JSON.stringify(accounts, null, 2))
				// 去重
				window.localStorage.setItem('accountList', JSON.stringify([...new Set(accounts)]));
			},
			userLogin() { /*OA账号登录*///
				if(this.showValid && !this.passValid){
					mui.alert('本次登录需要滑动验证')
					return false
				}
				this.criteria.username = this.criteria.username.toLocaleLowerCase().replace(/\s+/g,"");
				this.criteria.password = this.criteria.password.replace(/\s+/g,"");
				//输入账号之后 登陆之前
				xdapp.util.aiUtil.seting(this.criteria.username);
				console.log(this.criteria.username,1)
				if(this.criteria.username && this.criteria.password) {
					login(this.criteria,async res => {
						m2.cache.set('invalid','');
						this.isNeedSlideCheck();
						this.reset=false;
						this.$nextTick( ()=>{
							this.reset=true;
							// mui.alert('bbb'+this.test)
						})
						await loadUserInfo("upd");
						//登陆之后
						xdapp.util.aiUtil.seting();
						console.log("login",2)
						this.setCacheAccounts(this.criteria);
	                    this.$router.push("home");
					},e=>{
						let invalidRecords = m2.cache.get('invalid')
						let err = new Date().getTime();
						if(invalidRecords){
							if(invalidRecords.length>4){
								invalidRecords.shift()
							}
							invalidRecords.push(err)
						}else{
							invalidRecords=[err]
						}
						m2.cache.set('invalid',invalidRecords)
						this.isNeedSlideCheck()
						if(this.showValid){
							this.reset=false;
							this.$nextTick( ()=>{
								this.reset=true;
								this.passValid = false;
							})
						}
						// console.log(e)
					});
				} 
			},
			toggleCrUser() {
				this.crUser = true;
				this.crPsd = false;
			},
			toggleCrPsd() {
				this.crUser = false;
				this.crPsd = true;
			},
			toggleVrUser() {
				this.vrUser = true;
				this.vrPsd = false;
			},
			toggleVrPsd() {
				this.vrUser = false;
				this.vrPsd = true;
			},
			toggleInpType() {
				if(this.inpType == 'text') {
					this.inpType = 'password';
					this.iconStatus = 'icon-close-eyes'
				} else {
					this.inpType = 'text';
					this.iconStatus = 'icon-eyes'

				}

			},
			delText(num) {
				this.isDel = true
				switch(num) {
					case 1:
						this.isDel = true
						this.criteria.username = '';
						break;
					case 2:
						this.criteria.password = '';
						break;
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.showValid{
		margin-top: 0px;
	}
	.mui-btn {
		height: 44px;
		border-radius: 100px;
		-webkit-border-radius: 100px;
		border: none;
		width: torem(314);
		font-size: torem(16);
		line-height: torem(16);
		color: #fff;
	}
	
	.xd-login {
		position: absolute;
		width: 100%;
		height: 100%;
		background: url(~@/public/asset/img/bg/bj-pic.png) repeat-x;
		background-size: 100% torem(238);
		display: table-cell;
		background-color: #fff;
	}
	
	#slider {
		margin-top: torem(140);
	}
	
	.mui-control-item {
		color: #666!important;
	}
	
	.mui-active {
		color: #FFA713!important;
	}
	
	#item1mobile,
	#item2mobile {
		height: torem(285);
		margin-top: 30px;
	}
	
	.forget {
		text-align: right;
		font-size: torem(16);
		padding-left: 34px;
		display: inline-block;
		color: #FFA713;
	}
	
	.xd-home-error {
		position: absolute;
		top: 0;
		bottom: 0;
		right: torem(20);
		margin: auto 0;
		border-radius: 100%;
		width: torem(16);
		height: torem(16);
		text-align: center;
		line-height: torem(16);
		background: orange;
	}
	
	.eye {
		color: #ccc;
		font-size: torem(24);
		position: absolute!important;
		right: torem(60)!important;
		top: torem(16)!important;
	}
	
	.server {
		text-align: center;
		margin-bottom: 0;
		span {
			color: orange;
		}
	}
	
	.input-associate {
		position: absolute;
		background: #fff;
		z-index: 999;
		margin-left: torem(65);
		margin-top: -12px;
		width: calc(100% - 95px);
		line-height: torem(35);
		box-sizing: border-box;
	}
	
	.input-associate li {
		width: 100%;
		color: #000;
		padding: 0 torem(15);
		border-bottom: 1px solid rgb(238, 241, 245);
	}
</style>
