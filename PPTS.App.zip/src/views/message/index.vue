<template>
  <div class="wrap">
    <ul class="mui-table-view rx-message-main">
      <!--家长申请-->
      <router-link
        class="mui-table-view-cell mui-media"
        tag="li"
        :to="{name:'message-lesson-notify'}"
        v-power="['睿学-家长申请']"
      >
        <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/04@3x.png" />
        <div class="pointer" v-if="ParentApplyNotify && ParentApplyNotify.unReadedCount"></div>
        <div class="mui-media-body">
          <p class="tit">
            <span class="tit-name">家长申请</span>
            <span
              class="tit-time"
              v-if="ParentApplyNotify && ParentApplyNotify.messages"
            >{{ParentApplyNotify.messages.createTime | dateTimeFormat}}</span>
          </p>
          <p class="mt" v-if="ParentApplyNotify && ParentApplyNotify.messages">
            <span
              class="num"
              v-if="ParentApplyNotify.unReadedCount"
            >[{{ParentApplyNotify.unReadedCount}}条]</span>
            <span class="parentCon" v-if="ParentApplyNotify.messages.content">
              <p v-html="ParentApplyNotify.messages.content"></p>
            </span>
          </p>
          <p class="mui-ellipsis txt" v-show="showParent">
            <span>暂无家长申请</span>
          </p>
        </div>
      </router-link>
      <!--家校互动-->
      <!-- 教师岗位都有家校互动权限  之前是兼职教师去除该权限  后来通过请求后端接口返回是否有该权限 -->
      <router-link
        class="mui-table-view-cell mui-media"
        tag="li"
        :to="{name:'message-customer-interact'}"
        v-if="isFullTime"
        v-power="['睿学-家校互动']"
      >
        <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/02@3x.png" />
        <div class="pointer" v-if="customerReply && customerReply.unReadCount"></div>
        <div class="mui-media-body">
          <p class="tit">
            <span class="tit-name">家校互动</span>
            <span class="tit-time" v-if="customerReply">{{customerReply.replyTime | dateTimeFormat}}</span>
          </p>
          <p class="visbile" v-if="customerReply ">
            <!--<span class="num" v-if="customerReply.unReadCount">[{{customerReply.unReadCount}}条]</span>-->
            <span>{{customerReply.replyContent}}</span>
          </p>
        </div>
      </router-link>
      <!--学大资讯-->
      <router-link class="mui-table-view-cell mui-media" tag="li" :to="{name:'message-xd-news'}">
        <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/01@3x.png" />
        <div class="mui-media-body">
          <p class="tit">
            <span class="tit-name">学大资讯</span>
            <span class="tit-time" v-if="XDNews">{{XDNews.createTime | dateTimeFormat}}</span>
          </p>
          <p class="mui-ellipsis txt" v-if="XDNews">{{XDNews.title}}</p>
          <p class="mui-ellipsis txt" v-show="showNews">
            <span>暂无学大资讯</span>
          </p>
        </div>
      </router-link>
      <!--系统消息-->
      <router-link
        class="mui-table-view-cell mui-media"
        tag="li"
        :to="{name:'message-system-notify'}"
      >
        <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/03@3x.png" />
        <div class="pointer" v-if="systemNotify && systemNotify.unReadedCount"></div>
        <div class="mui-media-body">
          <p class="tit">
            <span class="tit-name">系统消息</span>
            <span
              class="tit-time"
              v-if="systemNotify && systemNotify.messages"
            >{{systemNotify.messages.createTime | dateTimeFormat}}</span>
          </p>
          <p
            class="mui-ellipsis"
            style="height:20px;margin-top: 7px;"
            v-if="systemNotify && systemNotify.messages"
          >
            <span class="num" v-if="systemNotify.unReadedCount">[{{systemNotify.unReadedCount}}条]</span>
            <span class="parentCon" v-if="systemNotify.messages.content">
              <span
                class="my-xd-text-s"
                v-html="systemNotify.messages.content.replace(/<img(.*?)src(.*?)>/g,'').replace(/<.{0,5}>/g,' ').replace(/&nbsp;/g,'').replace(/\s/g,'').length<1?systemNotify.messages.msgCatalogValue:systemNotify.messages.content.replace(/<img(.*?)src(.*?)>/g,'').replace(/<.{0,5}>/g,' ')"
              ></span>
            </span>
          </p>
          <p class="mui-ellipsis txt" v-show="showSystem">
            <span>暂无系统消息</span>
          </p>
        </div>
      </router-link>
    </ul>
  </div>
</template>

<script>
import { ACTION_TYPES, NotifyCatalog } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import {
  $getLastReply,
  $partTimeTeacherEnable
} from "@/api/customer-reply/customer-reply-api";
import { $getLastNotify } from "@/api/notify/notify-api";
import {
  $getNewsList,
  $getNewsByDay,
  $getNewestNews
} from "@/api/news/news-api";

export default {
  data() {
    return {
      ParentApplyNotify: {},
      customerReply: {},
      XDNews: null,
      showNews: false,
      showSystem: false,
      showParent: false,
      systemNotify: {},
      isFullTime: true
    };
  },
  mounted() {
    var currentJob = m2.cache.get("ppts-current-job");
    if (currentJob) {
      this.isFullTime = currentJob.isFullTime;
      if (!this.isFullTime && currentJob.jobType == 3) {
        $partTimeTeacherEnable(res => {
          this.isFullTime = res;
        });
      }
    }
  },
  created() {
    loadUserInfo("upd");
    this.getMessageData();
    this.switchJob();
  },
  methods: {
    async getMessageData() {
      await loadUserInfo();
      var ParentApplyParams = {
        msgCatalog: NotifyCatalog.ParentApply
      };
      var systemNotifyParams = {
        msgCatalog: NotifyCatalog.SystemNotify
      };

      if (m2.util.getPermionLoad("睿学-家长申请")) {
        // 家长申请
        $getLastNotify(ParentApplyParams, res => {
          if (res && res.messages) {
            this.ParentApplyNotify = res;
          } else {
            this.showParent = true;
          }
        });
      }
      if (m2.util.getPermionLoad("睿学-家校互动") && this.isFullTime) {
        // 家校互动
        $getLastReply(res => {
          // console.log(res)
          res.replyContent.includes("[###voice###]") &&
            (res.replyContent = "[语音消息]");
          res.replyContent.includes("[###img###]") &&
            (res.replyContent = "[图片]");
          this.customerReply = res;
        });
      }
      // 学大资讯
      let params = {
        date: m2.date.now()
      };

      $getNewestNews(res => {
        if (res) {
          this.XDNews = res;
        } else {
          this.showNews = true;
        }
      });
      // 系统消息
      $getLastNotify(systemNotifyParams, res => {
        if (res && res.messages) {
          this.systemNotify = res;
        } else {
          this.showSystem = true;
        }
      });
    },
    switchJob() {
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getMessageData);
    }
  }
};
</script>
<style lang="scss" scoped>
.mui-table-view-cell:after {
  height: 1px !important;
}
.mui-table-view:after {
  height: 0px;
}
.rx-message-main {
  padding: torem(12) torem(12) torem(10);
  .parentCon {
    width: 100%;
    height: 21px;
    p {
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
  li {
    margin-left: torem(-15);
    .pointer {
      position: absolute;
      width: torem(10);
      height: torem(10);
      border-radius: 50%;
      background: #fb150a;
      margin-left: torem(44);
      margin-top: torem(-4);
    }
    img {
      width: torem(50);
      height: torem(50);
      max-width: 1000px;
    }
    .tit {
      display: flex;
      justify-content: space-between;
      .tit-name {
        font-size: torem(16);
        color: #121212;
        line-height: torem(22);
      }
      .tit-time {
        font-size: torem(12);
        color: #8e8e8e;
        line-height: torem(17);
      }
    }
    .txt {
      color: #999;
      font-size: torem(14);
      margin-top: torem(8);
      display: flex;
    }
    .num {
      color: #e03229;
      float: left;
    }
  }
}

.mt {
  margin-top: torem(6);
  // display: flex;
}
.visbile {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  margin-top: 0.16rem;
}
</style>