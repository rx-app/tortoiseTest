<template>
  <div class="send-message">
    <h4>输入群发消息内容</h4>
    <textarea
      placeholder="请输入要群发的内容"
      v-model="content"
      cols="30"
      rows="10"
      @focus="fnFocus"
      @blur="fnBlur"
    ></textarea>
  </div>
</template>

<script>
import { ACTION_TYPES } from "@/constants";
import { $userSendMultipleCustomerReply } from "@/api/customer-reply/customer-reply-api";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
export default {
  data() {
    return {
      content: "",
      maxlength:800,
      params: {
        CustomerIDs: [],
        ReplyContent: "",
        ReplyFrom: 3
      }
    };
  },
  methods: {
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        //plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    nextType() {
      this.params.ReplyContent = this.content;
      this.params.CustomerIDs = this.customerIDs;
      $userSendMultipleCustomerReply(this.params, res => {
        if (res.msg) {
          mui.alert(res.msg, "提示", () => {
            mui.toast("发送成功!");
            // setTimeout(() => {
            //   this.$router.push({
            //     name: "message-group-detail"
            //   });
            // }, 1000);
          });
        } else {
          mui.alert("发送成功!");
        }
      });
    }
  },
  watch:{
    content(val) {
      this.content = this.content.substr(0, this.maxlength);
      if (val.length >= this.maxlength+1) {
        mui.alert("最多允许输入800字，请修改后再发。");
      }
      xdapp.util.vue.commitActionStatus(val);
    }
  },
  computed: {
    customerIDs() {
      return this.$route.query.customerIDs;
    }
  },
  created() {
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
    window.addEventListener("resize", resize);
  },
  destroyed() {
    window.removeEventListener("resize", resize);
  }
};
</script>

<style lang="scss">
.send-message {
  width: 100%;
  height: 100%;
  position: fixed;
  background: #eee;
  padding: torem(15);
  h4 {
    margin: torem(15) 0;
  }
  textarea {
    padding: torem(15);
    border: none;
  }
}
.mui-popup-inner {
  max-height: torem(300);
  overflow-y: scroll;
}
</style>
