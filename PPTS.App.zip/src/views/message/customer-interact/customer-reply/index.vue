<template>
	<div class="xdapp-msg-wrapper">
		<div class="xdapp-msg-wrapper">
			<h5 v-if="isShow">周反馈必须包括本周授课内容，学生上课表现，教师课后反馈，课后作业完成情况等内容，请按规则添加，以免影响绩效。<i @click="close()" class="iconfont icon-error"></i></h5>
			<loading v-show="loading"></loading>
			<scroll :data="messages" :listen-scroll="listenScroll" :probe-type="probeType" :pulldown="pulldown" @scrollToStart="refreshMore" class="scroll-container" ref="listview">
				<div class="msg-list">
					<ul class="list-group">
						<li class="list-group-item" v-for="(item,index) in messages" ref="groupItem">
							<span class="msg-time mui-badge">{{item.createTime | normalize}}</span>
							<div :class="{'msg-item':item.poster==2,'msg-item-right':item.poster==1,'voice-no-arrow':!item.replyContent.includes('[###voice###]') }">
								<div v-if="item.poster==2">
									<img class="mui-media-object mui-pull-left" :src="getAvatar(item)">
									<!-- <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png"> -->
								</div>
								<dd v-if="!item.replyContent.includes('[###voice###]')"  class="reply" v-html="item.replyContent"></dd>
								<dd v-if="item.replyContent.includes('[###voice###]')" @click="playVoice(item,0,index)" class="reply audio-ico" :class="{speaking:cur==index&&isSpeaking}"></dd>
								<div v-if="item.poster==1">
									<img class="mui-media-object mui-pull-left" :src="getAvatar(item)">
									<!-- <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png"> -->
								</div>
							</div>
						</li>
					</ul>
				</div>
			</scroll>
 <!-- 中间黑框 录音状态 -->
<div v-show="showSpeakIcon" class="blackBoxSpeak">
    <p class="blackBoxSpeakConent">手指上划，取消发送</p>
</div>

<!-- 中间黑框 暂停状态 -->
<div v-show="showSpeakStop" class="blackBoxPause">
    <p class="blackBoxPauseContent" style="background: red">松开手指， 取消发送</p>
</div>
		</div>
		<!--<div class="msg-input">
			<div class="msg-left">
				<textarea type="text" class='input-text' v-model="content" @focus="inpFocus()" @blur="inpBlur()"></textarea>
			</div>
			<div class="msg-right">
				<button :disabled="content ? false : true" class="btn-send" :class="content ? 'btn-on' : 'btn-off'" @click="sendReply()">
          发送
        </button>
			</div>
		</div>-->
		<div class="mask" v-if='maskShow'>
			<div class="mask-box">
				<div class="close">
					<i class="iconfont icon-error" @click="maskDis()"></i>
				</div>
				<div class="msg-box">
					<textarea placeholder="请输入留言" autofocus='autofocus' v-model="content" class="msg-text" name="" id="" cols="30" rows="10"></textarea>
					<button @click="sendReply()" class="send">发送aaa</button>
				</div>
			</div>
		</div>

	</div>
</template>

<script>
	import { ReplyType, PreOrLast, Poster, ACTION_TYPES } from '@/constants';
	import { defaultPageSize } from '@/public/constant';
	import { $getCustomerReplyByType, $sendCustomerReply } from '@/api/customer-reply/customer-reply-api'
	import { loadUserInfo } from '@/api/common/common-api';
	import Scroll from '@/components/scroll/index';
	import Loading from '@/components/loading/index';
	import Tip from '@/components/tip';
	import { getHeadIDsByUserIDs } from "@/api/user/user-api";

	export default {
		data() {
			return {
				isShow: false,
				probeType: 3,
				listenScroll: true,
				pulldown: true,
				loading: false,
				maskShow: false,
				content: '',
				messages: [],
				params: {
					replyObject: this.$route.query.replyObject,
					replyTime: m2.date.now(),
					sort: PreOrLast.Pre,
					count: defaultPageSize
				},
				firstFetch: true,
				tAvatarList: []
			}
		},
		beforeRouteEnter(to, from, next) {
			document.body.style.background = '#fff';
			next();
		},
		beforeRouteLeave: (to, from, next) => {
			document.body.style.background = '#efeff4';
			next();
			if(typeof from.query.tab !== 'undefined' && !to.query.tab) {
				let append = '?'
				if(/\?/.test(to.fullPath)) {
					append = '&'
				}
				return next(to.fullPath + append + 'tab=' + from.query.tab)
			}
			if(typeof from.query.tab !== 'undefined' && to.query.tab !== from.query.tab) {
				// this.$nextTick(()=>{
				to.query.tab = from.query.tab
				// })
			}
			next()
		},
		created() {
			this.setPageTitle();
			this.getCustomerReply();
			this.enableEvent();
		},
		methods: {
			getAvatar(item) {
				let teacherAva = require('@/public/asset/img/home/head.png');
				if(item.poster == 1) {
					this.tAvatarList.map(two => {
						if(item.replierID === two.userID) {
							if(two.gender == 1) {
								teacherAva = require('@/public/asset/img/user/teacher-man.png');
							} else if(two.gender == 2) {
								teacherAva = require('@/public/asset/img/user/teacher-woman.png')
							} else {
								teacherAva = require('@/public/asset/img/home/head.png');
							}
						}
					})
				} else {
					this.tAvatarList.map(two => {
						if(item.replierID === two.userID) {
							if(two.gender == 1) {
								teacherAva = require('@/public/asset/img/user/father.png');
							} else if(two.gender == 2) {
								teacherAva = require('@/public/asset/img/user/mother.png')
							} else {
								teacherAva = require('@/public/asset/img/home/head.png');
							}
						}
					})
				}
				return teacherAva
			},
			close() {
				this.isShow = false;
			},
			getCustomerReply(con) {
				this.getData(con);
			},
			setPageTitle() {
				this.$route.meta.title = this.pageTitle;
			},
			async getData(addDate) {
				await loadUserInfo();
				if(typeof addDate !== 'undefined') {
					this.params.replyTime = addDate
				}
				await loadUserInfo();
				// this.messages = [];
				this.params = {
					customerID: this.customerID,
					...this.params
				};
				$getCustomerReplyByType(this.params, res => {
					let newList = res
					if(typeof addDate !== 'undefined') {
						this.messages = newList
						this.content = '';
					} else {
						this.messages = newList.concat(this.messages);
					}
					if(!res || !res.length || res.length < this.params.queryNumber) {
						this.hasMore = false;
					} else {
						this.hasMore = true;
						this.params.replyTime = res[0].createTime;
					}
					// 获取所有老师的头像参数
					let tids = []
					newList.map(item => {
						// 判断是否已经请求过该头像了
						if(this.tAvatarList.length) {
							this.tAvatarList.map(one => {
								if(item.replierID !== one.userID) {
									tids.push({
										type: '1',
										userID: item.replierID
									})
								}
							})
						} else {
							tids.push({
								type: '1',
								userID: item.replierID
							})
						}
					})
					if(tids.length) {
						let sendIDS = Array.from(new Set([...tids]))
						console.log(sendIDS)
						getHeadIDsByUserIDs(sendIDS, (res) => {
							this.tAvatarList = res
						})
					}
					if(this.firstFetch) {
						this._scrollToBottom();
						this.firstFetch = false;
					}
					this.loading = false;
				});
			},
			refreshMore() {
				this.loading = this.hasMore ? true : false;
				if(!this.hasMore)
					return;
				this.getData();
			},
			enableEvent() {
				xdapp.util.vue.commitActionStatus(true);
				xdapp.util.vue.on(ACTION_TYPES.GOTO_FEEDBACK, this._gotoReply);
			},
			_gotoReply() {
				this.maskShow = true;
			},
			maskDis() {
				this.maskShow = false;
			},
			sendReply() {
				if(!this.content) {
					mui.toast('不能发送空消息!')
					return;
				}
				let params = {
					customerID: this.customerID,
					replyObject: this.replyObject,
					replyContent: this.content,
					replyFrom: ''
				};
				$sendCustomerReply(params, res => {
					this.maskShow = false;
					this.$nextTick(function() {
						this.getCustomerReply(null);
						this.firstFetch = true;
					})
					this.content = '';
				});
			},
			inpFocus() {

				/*var _this=this;
				setTimeout(() => {
					var rectObject = _this.msgText.getBoundingClientRect();
					var moveH = _this.initObj.top - rectObject.top;
					
					alert("rectObject"+rectObject.top);
					alert("initObj"+_this.initObj.top);
					alert("window.isMessageTopAdd"+ window.isMessageTopAdd);
					
					var screenH=document.body.scrollHeight;
					
					alert("screenH值"+screenH)
					if(window.isMessageTopAdd && screenH!==480){
						moveH+=45;
						alert("进来第一次加的里面了");
						window.isMessageTopAdd=false;
					}
					var ua = navigator.userAgent.toLowerCase();
					if(/iphone|ipad|ipod/.test(ua)) {
						this.header = document.getElementsByTagName('header')[0];
						this.msgList = document.getElementsByClassName('msg-list')[0];
						this.h5Lable = document.getElementsByTagName('h5')[0];
						
						alert("moveH值"+moveH);
						
						this.header ? this.header.setAttribute('style', 'position:absolute;top:' + moveH + 'px;left:0') : '';
						this.msgList ? this.msgList.setAttribute('style', 'position:relative;top:' + moveH + 'px;left:0') : '';
						this.h5Lable ? this.h5Lable.setAttribute('style', 'position:relative;top:' + moveH + 'px;left:0') : '';
					}
				}, 0)*/
				var _this = this;
				this.switch = true;
				setTimeout(() => {
					if(_this.switch) {
						_this._viewHeight('focus');
						_this.switch = false;
					}
				}, 0)

			},
			inpBlur() {
				var _this = this;
				this.switch = true;
				//clearInterval(this.interval); //清除计时器
				this._viewHeight('blur');
				/*var ua = navigator.userAgent.toLowerCase();
				if(/iphone|ipad|ipod/.test(ua)) { //苹果手机
					this.header ? this.header.setAttribute('style', 'position:fixed;top:0;left:0') : '';
					this.msgList ? this.msgList.setAttribute('style', 'position:relative;top:0;left:0') : '';
					this.h5Lable ? this.h5Lable.setAttribute('style', 'position:fixed;') : '';
				}
				document.body.scrollTop = this.bfscrolltop;*/
			},
			_viewHeight(type) {
				var _this = this;
				var focusObjTop = _this.msgText.getBoundingClientRect().top;
				console.log("focusObjTop"+focusObjTop)
				var ws = null;

				function plusReady() {
					ws = plus.webview.currentWebview();
					console.log(ws)
					console.log("视图原本高度"+_this.initViewHeight);
					console.log("focus后 view高度"+ (_this.initViewHeight-(_this.initObjTop-focusObjTop)))
					if(type == "focus") {
						ws.setStyle({
							height: _this.initViewHeight-(_this.initObjTop-focusObjTop),
							top: 0
						});
					} else {
						ws.setStyle({
							height: _this.initViewHeight
						});
					}
				};
				if(window.plus) {
					plusReady();
				} else {
					document.addEventListener('plusready', plusReady, false);
				}
			},
			_scrollToBottom() {
				this.$nextTick(() => {
					setTimeout(() => {
						let groupItems = this.$refs.groupItem || 0;
						let el = groupItems[groupItems.length - 1];
						this.$refs.listview.scrollToElement(el, 200, 0, 50);
					}, 20);
				});
			}
		},
		mounted() {
			/*this.msgText = document.getElementsByClassName('msg-input')[0];
			this.initObjTop = this.msgText.getBoundingClientRect().top;获取聊天框距离对象*/
			
			/*this.initViewHeight = document.body.scrollHeight;获取当前页面总高度*/
			
			if(this.replyType == "周反馈") {
				this.isShow = true;
			}
		},
		computed: {
			replyType() {
				return this.$route.query.replyType;
			},
			pageTitle() {
				return this.$route.query.title;
			},
			customerID() {
				return this.$route.query.staffId;
			},
			replyObject() {
				return this.$route.query.replyObject;
			}
		},
		components: {
			Scroll,
			Loading,
			Tip
		}
	}
</script>

<style lang="scss" scoped>
	.xdapp-msg-wrapper {
		position: fixed;
		width: 100%;
		height: 100%;
		.scroll-container {
			height: 100%;
			overflow: hidden;
			.msg-list {
				background: #fff;
				padding-top: 20px;
				ul.list-group {
					li {
						padding-bottom: torem(15);
						&:last-child {
							padding-bottom: torem(125);
						}
					}
					.msg-time {
						text-align: center;
						display: block;
						margin-top: 14px;
						font-size: torem(12);
						margin-left: 40%;
						width: 70px;
						color: #fff;
					}
					.msg-item {
						z-index: 1;
						position: relative;
						padding: 10px 18px 0;
						display: flex;
						img {
							width: 40px;
							height: 40px;
							margin-right: 11px;
							border-radius: 50%;
						}
						.reply {
							margin-left: 0;
							padding: 8px 15px;
							max-width: torem(222);
							font-size: torem(16);
							color: #333;
							// border: 1px solid #eee;
							border-radius: 5px;
							background-color: #eee;
							.tit {
								font-size: torem(20);
								color: #000;
								line-height: 28px;
							}
						}
						&:after {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-right: 7px solid #eee;
							position: absolute;
							left: 56px;
							top: 27px;
							z-index: 10;
						}
						&:before {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-right: 7px solid #eee;
							position: absolute;
							left: 58px;
							top: 27px;
							z-index: 20;
						}
					}
					.msg-item-right {
						z-index: 1;
						position: relative;
						padding: 14px 18px 0;
						display: flex;
						/*align-items: center;*/
						justify-content: flex-end;
						img {
							width: 40px;
							height: 40px;
							margin-left: 11px;
							border-radius: 50%;
						}
						.reply {
							font-size:torem(15);
							color: #333;
							padding: 8px 15px;
							margin-left: torem(57);
							background: #ffe3b6;
							border-radius: 5px;
							.tit {
								font-size: torem(20);
								color: #000;
								line-height: 28px;
							}
						}
						&:after {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-left: 7px solid #ffe3b6;
							position: absolute;
							right: 56px;
							top: 27px;
							z-index: 10;
						}
						&:before {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-left: 7px solid #ffe3b6;
							position: absolute;
							right: 58px;
							top: 27px;
							z-index: 20;
						}
					}
				}
			}
		}
	}
	
	h5 {
		color: red;
		font-size: torem(14);
		position: fixed;
		background-color: rgba(255, 255, 255, 0.8);
		z-index: 99;
		padding: torem(20);
		line-height: 24px;
		border-radius: 15px;
		width: 90%;
		margin-left: 5%;
		i {
			color: #ddd;
			position: absolute;
			right: torem(12);
			top: torem(4);
		}
	}
	
	.mask {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		background-color: rgba(0, 0, 0, 0.2);
		z-index: 99999;
		.mask-box {
			width: torem(300);
			margin: torem(200) auto torem(40) auto;
			.close {
				text-align: right;
				margin-bottom: -3px;
			}
			.iconfont {
				display: inline-block;
				color: #fff;
				font-size: torem(26);
				margin-right: -18px;
			}
		}
		// text-align: center;
		.msg-box {
			position: relative;
			width: 100%;
			// height: torem(200);
			background-color: #fff;
			border-radius: torem(15);
			padding: torem(15) torem(15) torem(10);
			position: relative;
			text-align: center;
			.msg-text {
				padding: torem(10);
				width: 100%;
				height: torem(200);
				border: none;
				border-radius: torem(15);
				border: 1px solid #ccc;
				border-radius: 5px;
				margin-bottom: 5px;
			}
		}
		textarea::-webkit-input-placeholder {
			@include letterStyle(13, #CACFD9, 0, 16);
		}
		.send {
			width: 60%;
			margin: 0 auto;
			background: rgb(255, 130, 1);
			color: #fff;
			display: block;
			border-radius: 30px;
			border: none;
		}
	}
	
	.msg-input {
		position: fixed;
		width: 100%;
		height: 50px;
		min-height: 50px;
		border-top: solid 1px #bbb;
		left: 0px;
		bottom: 0px;
		overflow: hidden;
		padding: 0px 90px 0px 10px;
		background-color: #fafafa;
		.msg-left {
			height: 100%;
			padding: 5px 0px;
			[class*=input] {
				width: 100%;
				height: 100%;
				border-radius: 5px;
			}
			.input-text {
				background: #fff;
				border: solid 1px #ddd;
				padding: 10px !important;
				font-size: torem(16) !important;
				line-height: 18px !important;
				font-family: verdana !important;
				overflow: hidden;
			}
		}
		.msg-right {
			position: absolute;
			width: 100px;
			height: 50px;
			right: 0px;
			bottom: 0px;
			text-align: center;
			vertical-align: middle;
			line-height: 100%;
			padding: 5px 0px;
			display: inline-block;
			.btn-send {
				width: 70px;
				height: 100%;
				border: none;
				text-align: center;
				line-height: torem(-0.04);
				font-size: torem(14)
			}
			.btn-on {
				background: skyblue;
				color: #fff;
			}
			.btn-off {
				background: #ccc;
			}
		}
	}
</style>