﻿<template>
	<div class="xdapp-msg-wrapper">
		<h5 v-if="isShow">周反馈必须包括本周授课内容，学生上课表现，教师课后反馈，课后作业完成情况等内容，请按规则添加，以免影响绩效。<i @click="close()" class="iconfont icon-error"></i></h5>
		<div class="wrapper" ref="wrapper">
			<div>
				<mt-loadmore :top-method="loadTop" ref="loadmore">
					<ul class="msg-content">
						<li v-for="(item,index) in messages" class="msg-list-hook">
							<span class="msg-time mui-badge">{{item.createTime | normalize }}</span>
							<div :class="{'msg-item':item.poster==2,'msg-item-right':item.poster==1 }">
								<div v-if="item.poster==2">
									<img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png">
								</div>
								<dd class="reply" v-html="item.replyContent"></dd>
								<div v-if="item.poster==1">
									<img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png">
								</div>
							</div>
						</li>
					</ul>
				</mt-loadmore>
			</div>
		</div>
	</div>
</template>

<script>
	import BScroll from 'better-scroll';
	import { ReplyType, PreOrLast, Poster, CACHE_KEYS , ACTION_TYPES} from '@/constants';
	import { defaultPageSize } from '@/public/constant';
	import { $getCustomerReplyByType, $sendCustomerReply } from '@/api/customer-reply/customer-reply-api'
	import { loadUserInfo } from '@/api/common/common-api';

	export default {
		data() {
			return {
				isShow: false,
				messages: [],
				firstMessageCreateTime: undefined,
				content: undefined,
				scrollY: 0
			}
		},
		created() {
			this.setPageTitle();
			this.getCustomerReply();
			this.enableEvent();
		},
		mounted() {
			if(this.replyType == "周反馈") {
				this.isShow = true;
			}
		},
		methods: {
			close() {
				this.isShow = false;
			},
			getCustomerReply() {
				this.getData(m2.date.now());
			},
			loadTop() {
				this.getData(this.firstMessageCreateTime);
			},
			setPageTitle() {
				this.$route.meta.title = this.pageTitle + '家长';
			},
			async getData(replyTime, isFirst) {
				await loadUserInfo();

				let params = {
					customerID: this.customerID,
					replyObject: this.replyObject,
					replyTime: replyTime,
					sort: PreOrLast.Pre,
					count: defaultPageSize
				};
				$getCustomerReplyByType(params, res => {
					this.messages = [...res, ...this.messages];
					this.$refs.loadmore.onTopLoaded();
					if(this.messages.length > 0) {
						this.firstMessageCreateTime = this.messages[0].createTime;
					}
					this.$nextTick(() => {
						this._initScroll();
						isFirst && this._scrollToBottom();
					});
				});
			},
			_initScroll() {
				let wrapper = this.$refs.wrapper;
				wrapper.style.height = (window.screen.height - 125) + 'px';

				this.scroll = this.scroll ? this.scroll.refresh() : new BScroll(wrapper, {
					probeType: 3
				});

				this.scroll.on('scroll', (pos) => {
					this.scrollY = Math.abs(Math.round(pos.y));
				});
			},
			_scrollToBottom() {
				let msgList = this.$refs.wrapper.getElementsByClassName('msg-list-hook');
				let height = 0;
				for(let i = 0; i < msgList.length; i++) {
					height += msgList[i].clientHeight;
				}

				let el = msgList[msgList.length - 1];
				this.scroll.scrollToElement(el);
			},
			enableEvent() {
				xdapp.util.vue.commitActionStatus(true);
				xdapp.util.vue.on(ACTION_TYPES.GOTO_FEEDBACK, this._gotoReply);
			},
			_gotoReply() {
				alert(111)
				this.$router.push({
					name: "leaveMessage",
					query: {
						replyObject: this.replyObject,
						replyType: this.replyType,
						title: this.pageTitle,
						staffId: this.customerID
					}
				});
			},
		},
		computed: {
			replyType() {
				return this.$route.query.replyType;
			},
			pageTitle() {
				return this.$route.query.title;
			},
			customerID() {
				return this.$route.query.staffId;
			},
			replyObject() {
				return this.$route.query.replyObject;
			}
		}
	}
</script>
<style lang="scss" scoped>
	.xdapp-msg-wrapper {
		position: absolute;
		top: 0px;
		bottom: 46px;
		width: 100%;
		h5 {
			color: red;
			font-size: torem(14);
			position: fixed;
			background-color: rgba(255, 255, 255, 0.8);
			z-index: 99;
			padding: torem(20);
			line-height: 24px;
			border-radius: 15px;
			width: 90%;
			margin-left: 5%;
			i {
				color: #ddd;
				position: absolute;
				right: torem(12);
				top: torem(4);
			}
		}
		.wrapper {
			ul.msg-content {
				li {
					padding-bottom: 15px;
				}
				.msg-time {
					text-align: center;
					display: block;
					margin-top: 14px;
					font-size: torem(12);
					margin-left: 40%;
					width: 70px;
					color: #fff;
				}
				.msg-item {
					z-index: 1;
					position: relative;
					padding: 10px 18px 0;
					display: flex;
					img {
						width: 40px;
						height: 40px;
						margin-right: 11px;
					}
					.reply {
						margin-left: 0;
						padding: 8px 15px;
						font-size: torem(16);
						color: #333;
						border: 1px solid #ccc;
						background-color: #F9F9FB;
						.tit {
							font-size: torem(20);
							color: #000;
							line-height: 28px;
						}
					}
					&:after {
						content: '';
						width: 0;
						height: 0;
						border: 7px solid transparent;
						border-right: 7px solid #ccc;
						position: absolute;
						left: 56px;
						top: 27px;
						z-index: 10;
					}
					&:before {
						content: '';
						width: 0;
						height: 0;
						border: 7px solid transparent;
						border-right: 7px solid #fff;
						position: absolute;
						left: 58px;
						top: 27px;
						z-index: 20;
					}
				}
				.msg-item-right {
					z-index: 1;
					position: relative;
					padding: 14px 18px 0;
					display: flex;
					align-items: center;
					justify-content: flex-end;
					img {
						width: 40px;
						height: 40px;
						margin-left: 11px;
					}
					.reply {
						font-size: torem(16);
						color: #333;
						padding: 8px 15px;
						margin-left: torem(57);
						background: #ffe3b6;
						border-radius: 5px;
						.tit {
							font-size: torem(20);
							color: #000;
							line-height: 28px;
						}
					}
					&:after {
						content: '';
						width: 0;
						height: 0;
						border: 7px solid transparent;
						border-left: 7px solid #ccc;
						position: absolute;
						right: 56px;
						top: 27px;
						z-index: 10;
					}
					&:before {
						content: '';
						width: 0;
						height: 0;
						border: 7px solid transparent;
						border-left: 7px solid #ffe3b6;
						position: absolute;
						right: 58px;
						top: 27px;
						z-index: 20;
					}
				}
			}
		}
		.msg-input {
			position: fixed;
			width: 100%;
			height: 50px;
			min-height: 50px;
			border-top: solid 1px #bbb;
			left: 0px;
			bottom: 0px;
			overflow: hidden;
			padding: 0px 90px 0px 10px;
			background-color: #fafafa;
			.msg-left {
				height: 100%;
				padding: 5px 0px;
				[class*=input] {
					width: 100%;
					height: 100%;
					border-radius: 5px;
				}
				.input-text {
					background: #fff;
					border: solid 1px #ddd;
					padding: 10px !important;
					font-size: torem(16) !important;
					line-height: 18px !important;
					font-family: verdana !important;
					overflow: hidden;
				}
			}
			.msg-right {
				position: absolute;
				width: 100px;
				height: 50px;
				right: 0px;
				bottom: 0px;
				text-align: center;
				vertical-align: middle;
				line-height: 100%;
				padding: 5px 0px;
				display: inline-block;
				.btn-send {
					width: 70px;
					height: 100%;
					border: none;
					text-align: center;
					line-height: torem(-0.04);
					font-size: torem(14)
				}
				.btn-on {
					background: skyblue;
					color: #fff;
				}
				.btn-off {
					background: #ccc;
				}
			}
		}
	}
</style>