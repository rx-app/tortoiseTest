<template>
	<div class="xdapp-msg-wrapper">
		<textarea placeholder="请输入要留言的内容" name="" v-model="content" id="" cols="30" rows="10">

      </textarea>
	</div>
</template>

<script>
	import Tip from '@/components/tip';
	import { ReplyType, PreOrLast, Poster, ACTION_TYPES } from '@/constants';
	import { defaultPageSize, } from '@/public/constant';
	import { $getCustomerReplyByType, $sendCustomerReply } from '@/api/customer-reply/customer-reply-api'
	import { loadUserInfo } from '@/api/common/common-api';

	export default {
		data() {
			return {
				content: ''
			}
		},
		created() {
			xdapp.util.vue.on(ACTION_TYPES.leave_message, this.sendReply);
		},
		mounted() {
            this.setPageTitle();
		},
		methods: {
			setPageTitle() {
				this.$route.meta.title = this.pageTitle;
			},
			sendReply() {
				let content = this.content;
				let params = {
					customerID: this.customerID,
					replyObject: this.replyObject,
					replyContent: this.content,
					replyFrom: ''
				};
				$sendCustomerReply(params, res => {
					let msg = {
						poster: Poster.Customer,
						replyContent: content,
						createTime: m2.date.now(),
					};
					this.$router.go(-1);
				});
			},
		},
		watch: {
			content: {
				handler: function(val) {
					xdapp.util.vue.commitActionStatus(val);
				},
			}
		},
		computed: {
			replyType() {
				return this.$route.query.replyType;
			},
			pageTitle() {
				return this.$route.query.title;
			},
			customerID() {
				return this.$route.query.staffId;
			},
			replyObject() {
				return this.$route.query.replyObject;
			}
		}
	}
</script>

<style lang="scss" scoped>
.xdapp-msg-wrapper{
	padding: torem(15);
	margin-top: torem(20);
	textarea{
		border-radius: torem(15)
	}
}

</style>