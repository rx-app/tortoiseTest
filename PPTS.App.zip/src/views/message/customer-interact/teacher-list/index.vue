<template>
  <div class="xd-select-student">
    <p class="inp">
      <input type="text" placeholder="输入学员姓名/编号进行查询" v-model="inpVal">
      <i class="iconfont icon-found" @click="searchStudent()"></i>
    </p>
    <mt-navbar v-model="selected">
      <mt-tab-item id="1" @click.stop.prevent="switchTabs('1')" class="todayStu">
        <span v-if="currentType == 1">账户余额不足1000元学员</span>
        <span v-else>有效学员</span>
      </mt-tab-item>
      <mt-tab-item id="2" @click.stop.prevent="switchTabs('2')" class="allStu">
        <span v-if="currentType == 1">签约学员</span>
        <span v-else>所有学员</span>
      </mt-tab-item>
    </mt-navbar>
    <!-- tab-container  -->
    <div id="cus-main-content" class="main-content">
      <mt-loadmore class="loadMore" :bottom-all-loaded="allLoaded" ref="loadmore">
        <mt-tab-container v-model="selected">
          <mt-tab-container-item id="1">
            <div class="students-list">
              <ul v-if="!searchValidStudents.length && !searchStudents.length">
                <li v-for="(item,index) in validStudents" :key="index">
                  <span @click="findMess(item)">{{item.customerName}}</span>
                  <span>{{item.customerCode}}</span>
                  <span v-if="replyType=='日常维护'" @click="addFeedBack(item)">联系家长</span>
                  <span v-if="replyType=='周反馈'" @click="addFeedBack(item)">添加周反馈</span>
                </li>
              </ul>
              <ul v-else-if="searchValidStudents.length">
                <li v-for="(item,index) in searchValidStudents" :key="index">
                  <span @click="findMess(item)">{{item.customerName}}</span>
                  <span>{{item.customerCode}}</span>
                  <span v-if="replyType=='日常维护'" @click="addFeedBack(item)">联系家长</span>
                  <span v-if="replyType=='周反馈'" @click="addFeedBack(item)">添加周反馈</span>
                </li>
              </ul>
              <tip v-else>
                <span>没有查询到任何记录</span>
              </tip>
            </div>
          </mt-tab-container-item>
          <mt-tab-container-item id="2">
            <div class="students-list">
              <ul v-if="!searchStudents.length">
                <li v-for="(item,index) in students" :key="index">
                  <span @click="findMess(item)">{{item.customerName}}</span>
                  <span>{{item.customerCode}}</span>
                  <span v-if="replyType=='日常维护'" @click="addFeedBack(item)">联系家长</span>
                  <span v-if="replyType=='周反馈'" @click="addFeedBack(item)">添加周反馈</span>
                </li>
              </ul>
              <ul v-else-if="searchStudents.length">
                <li v-for="(item,index) in searchStudents" :key="index">
                  <span @click="findMess(item)">{{item.customerName}}</span>
                  <span>{{item.customerCode}}</span>
                  <span v-if="replyType=='日常维护'" @click="addFeedBack(item)">联系家长</span>
                  <span v-if="replyType=='周反馈'" @click="addFeedBack(item)">添加周反馈</span>
                </li>
              </ul>
              <tip v-else>
                <span>没有查询到任何记录</span>
              </tip>
            </div>
          </mt-tab-container-item>
        </mt-tab-container>
      </mt-loadmore>
    </div>
  </div>
</template>

<script>
import { ACTION_TYPES, ReplyType } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import { $getStudentList } from "@/api/customer-reply/customer-reply-api";
import { getAllStudents } from "@/api/customer/customer-api";
import { pager, orderBy } from "@/public/constant";
import {
  Navbar as mtNavbar,
  TabItem as mtTabItem,
  Loadmore as mtLoadmore
} from "mint-ui";
import Tip from "@/components/tip";
export default {
  data() {
    return {
      students: [],
      inpVal: "",
      allLoaded: true,
      isShow: true,
      //replyObject: 0,
      selected: null,
      searchValidStudents: [],
      searchStudents: []
    };
  },
  methods: {
    searchStudent() {
      this.searchValidStudents = [];
      this.searchStudents = [];
      const regTest = new RegExp(this.inpVal, "i");
      if (!this.inpVal) {
        mui.toast("请输入搜索内容!");
        return;
      }
      this.validStudents.forEach(item => {
        if (
          regTest.test(item.customerName) ||
          regTest.test(item.customerCode)
        ) {
          this.searchValidStudents.push(item);
          this.searchStudents.push(item);
        }
      });
      console.log(this.searchValidStudents);
      if (this.searchValidStudents.length) {
        this.selected = "1";
        return;
      } else {
        this.searchStudents = [];
        this.students.forEach(item => {
          if (
            regTest.test(item.customerName) ||
            regTest.test(item.customerCode)
          ) {
            this.searchStudents.push(item);
          }
        });
      }
      console.log(this.searchStudents);
      if (this.searchStudents.length) {
        this.selected = "2";
        return;
      } 
    },
    async getStudentList() {
      await loadUserInfo();
      if (this.jobType() == 1) {
        let params = {
          ...pager({
            pageIndex: 0,
            pageSize: 0
          }),
          ...orderBy
        };
        getAllStudents(params, res => {
          this.students = res.queryResult.pagedData;
        });
      } else {
        $getStudentList(res => {
          this.students = res;
        });
      }
    },
    addFeedBack(item) {
      //this.jobType();
      this.$router.push({
        name: "message-customer-reply",
        query: {
          staffId: item.customerID,
          replyType: this.replyType,
          replyObject: this.jobType(),
          title: this.replyType + "-" + item.customerName + "家长"
        }
      });
    },
    findMess(item) {
      if (this.currentType == 1) {
        this.$router.push({
          name: "studentSignedInfo",
          query: {
            id: item.customerID,
            refer: 2
          }
        });
      } else {
        this.$router.push({
          name: "customerMess",
          query: {
            customerID: item.customerID
          }
        });
      }
    },
    jobType() {
      var currentJobType = m2.cache.get("ppts-current-job").jobType;
      if (currentJobType == 2 && this.replyType == "周反馈") {
        return 6;
      }
      return currentJobType;
    },
    setHeight() {
      let content = document.querySelector("#cus-main-content");
      if (content !== null && typeof content !== "undefined") {
        let windowHeight = window.innerHeight;
        let headHight = document.querySelector("#cus-header");
        let jHight = windowHeight - 50 - 34 - 10 - 32 - 50 + 23;
        if (headHight !== null) {
          content.style.height = "calc(" + jHight + "px - 0.4rem - 2.88rem)";
        } else {
          content.style.height = "calc(" + jHight + "px - 0.4rem)";
        }
      }
    },
    switchTabs(Id) {
      this.selected = Id;
    }
  },
  computed: {
    validStudents() {
      const validStudents = [];
      this.students.forEach(item => {
        if (this.jobType() == 1) {
          if (item.accountMoney < 1000) {
            validStudents.push(item);
          }
        } else {
          if (item.isValid) {
            validStudents.push(item);
          }
        }
      });
      return validStudents;
    },
    replyType() {
      if (this.$route.query.num == 0) return "日常维护";
      if (this.$route.query.num == 1) return "周反馈";
    },
    currentType() {
      return this.jobType();
    }
  },
  watch: {
    inpVal() {
      if (!this.inpVal) {
        this.searchValidStudents = [];
        this.searchStudents = [];
      }
    }
  },
  activated() {
    this.setHeight();
  },
  mounted() {
    this.selected = "1";
    this.setHeight();
  },
  created() {
    this.getStudentList();
  },
  components: {
    Tip
  }
};
</script>

<style lang="scss">
.main-content {
  overflow: auto;
  height: torem(360);
}

.xd-select-student {
  text-align: center;
  .inp {
    width: 90%;
    margin-left: 5%;
    margin-top: torem(15);
    border: 1px solid #d8d8d8;
    border-radius: 100px;
    height: 32px;
    position: relative;
    input {
      width: 90%;
      height: 100%;
      border: none;
      margin-left: -8%;
      border-radius: 100px;
    }
    i {
      position: absolute;
      right: torem(10);
      top: torem(5);
      color: #eee;
      font-size: torem(24);
    }
  }
}

.students-list {
  ul > li {
    width: 100%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: space-around;
    span {
      font-size: torem(14);
    }
    span:nth-child(1) {
      color: skyblue;
    }
    span:nth-child(3) {
      color: skyblue;
    }
  }
}

.selectStudent {
  background-color: #eee;
}
.todayStu {
  border-radius: 6px 0 0 6px;
}
.allStu {
  border-radius: 0 6px 6px 0;
}
</style>