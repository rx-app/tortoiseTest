<template>
  <div class="xd-group-setting">
    <ul v-if="discussionMess">
      <li v-for="(item,index) in discussionMess.members" :key="index">
        <p>
          <img v-if=" item.icons && item.icons.iconID" :src="getIconImg(item.icons.userID)">
          <img
            v-else-if="item.icons && item.icons.gender==2 && item.userType == 4"
            src="~@/public/asset/img/user/mother.png"
            alt
          >
          <img v-else-if="item.userType == 4" src="~@/public/asset/img/user/father.png" alt>
          <img
            v-else-if="item.icons && item.icons.gender==2 && item.userType !== 4"
            src="~@/public/asset/img/user/teacher-woman.png"
            alt
          >
          <img v-else-if="item.userType !== 4" src="~@/public/asset/img/user/teacher-man.png" alt>
        </p>
        <span>
          <span v-if="item.userType !== 4">{{item.userType | userType}}-</span>{{item.userName}}
        </span>
      </li>
      <li @click="uploadPerson('add')">
        <i class="iconfont icon-addBorder"></i>
      </li>
      <li @click="uploadPerson('delect')">
        <i class="iconfont icon-del"></i>
      </li>
    </ul>
    <p class="uploadName" @click="uploadGroupName()" v-if="discussionMess">
      <span class="linkName">讨论组名称</span>
      <span class="linkItem" v-if="discussionMess">{{discussionMess.group.discussionGroupName}}</span>
    </p>
  </div>
</template>
<script>
import store from "@/store";
import * as types from "@/store/mutation-types";
import { $loadDiscussionGroupInfo } from "@/api/customer-reply/customer-reply-api";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";

export default {
  data() {
    return {
      discussionMess: null,
      chatList: [],
      icons: []
    };
  },
  created() {
    $loadDiscussionGroupInfo(this.discussionGroupID, res => {
      this.discussionMess = res;
    });
  },
  methods: {
    uploadGroupName() {
      this.$router.push({
        name: "message-upload-name",
        query: {
          DiscussionGroupID: this.discussionGroupID,
          //DiscussionName: this.discussionMess.group.discussionGroupName
        }
      });
    },
    uploadPerson(type) {
      if (type == "add") {
        this.$router.push({
          name: "message-upload-add",
          query: {
            DiscussionGroupID: this.discussionGroupID
          }
        });
      } else {
        this._delect();
        this.$nextTick(() => {
          this.$router.push({
            name: "message-upload-delect",
            query: {
              members: this.discussionMess.members,
              DiscussionGroupID: this.discussionGroupID
            }
          });
        });
      }
    },
    _delect() {
      var members = this.discussionMess.members;
      members.forEach((item, index) => {
        if (item.userID == m2.cache.get("ppts-current-user").userId) {
          members.splice(members.indexOf(item), 1);
        }
      });
    },
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserIcons() {
      this.discussionMess.members.forEach(item => {
        if (!item.icons || !item.icons.iconID) return;
        var userIcons = this.$store.state.headList.slice() || [];
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === item.icons.userID);
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: curIcon.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: item.icons.iconID
            },
            res => {
              let obj = {
                userID: item.icons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      });
    }
  },
  watch: {
    discussionMess(val) {
      this.chatList = [];
      if (val.members.length) {
        val.members.forEach((item, index) => {
          if (item.userType == 4) {
            this.chatList.push({
              type: "3",
              userID: item.userID
            });
          } else if (item.userType !== 4) {
            this.chatList.push({
              type: "1",
              userID: item.userID
            });
          }
        });
      }
    },
    chatList() {
      getHeadIDsByUserIDs(this.chatList, res => {
        this.discussionMess.members.forEach(item => {
          res.forEach(sel => {
            if (item.userID == sel.userID) {
              this.$set(item, "icons", sel);
            }
          });
        });
        this.$nextTick(() => {
          this.getUserIcons();
        });
      });
    }
  },
  computed: {
    discussionGroupID() {
      return this.$route.query.DiscussionGroupID;
    }
  }
};
</script>
<style lang="scss" scoped>
.xd-group-setting {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  background-color: #eee;
  ul {
    display: flex;
    flex-wrap: wrap;
    padding: torem(15);
    background-color: #fff;
    li {
      width: 33.3%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin: torem(15) 0;
      p {
        width: torem(40);
        height: torem(40);
        img {
          width: 100%;
          height: 100%;
          border-radius: 100%;
        }
      }
      span {
        font-size: torem(14);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 100%;
      }
      i {
        font-size: torem(45);
        color: #bbb;
      }
    }
  }
  .uploadName {
    background-color: #fff;
    padding: torem(10) torem(15);
    margin-top: torem(15);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .linkItem::after {
    content: "\E583";
    font-family: Muiicons;
    color: #bbb;
    -webkit-font-smoothing: antialiased;
    margin-left: 5px;
  }
  .linkName {
    font-weight: bold;
  }
}
</style>

