<template>
  <div>
    <loading v-show="loading"></loading>
    <div class="xdapp-msg-wrapper">
      <scroll
        :listen-scroll="listenScroll"
        :probe-type="probeType"
        :pulldown="pulldown"
        @scrollToStart="refreshMore"
        class="scroll-container"
        ref="listview"
      >
        <div class="msg-list">
          <ul class="list-group">
            <li
              class="list-group-item"
              v-for="(item,index) in detailList"
              ref="groupItem"
              :key="index"
            >
              <span class="msg-time mui-badge">{{item.sendTime | normalize}}</span>
              <div class="msg-item-right">
                <dd class="reply">
                  <p>{{item.content}}</p>
                  <p>接收人：{{item.receiver}}</p>
                </dd>
                <div>
                  <img v-if="currentHeadImg" :src="currentHeadImg">
                  <img
                    v-else-if="currentUserGender==2"
                    src="~@/public/asset/img/user/teacher-woman.png"
                    alt
                  >
                  <img v-else src="~@/public/asset/img/user/teacher-man.png" alt>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </scroll>
    </div>
  </div>
</template>
<script>
import { CACHE_KEYS, PreOrLast } from "@/constants";
import { defaultPageSize } from "@/public/constant";
import Scroll from "@/components/scroll/index";
import Loading from "@/components/loading/index";
import Tip from "@/components/tip";
import * as types from "@/store/mutation-types";
import store from "@/store";
import { loadUserInfo } from "@/api/common/common-api";
import { $loadMultipleCustomerReply } from "@/api/customer-reply/customer-reply-api";
export default {
  data() {
    return {
      probeType: 3,
      listenScroll: true,
      pulldown: true,
      loading: false,
      currentUserGender: 1,
      params: {
        SendTime: m2.date.now(),
        sort: PreOrLast.Pre,
        count: defaultPageSize
      },
      detailList: []
    };
  },
  methods: {
    refreshMore() {
      this.loading = this.hasMore ? true : false;
      if (!this.hasMore) return;
      this.getData();
    },
    getCustomerReply(con) {
      this.getData(con);
    },
    async getData(addDate) {
      await loadUserInfo();
      if (typeof addDate !== "undefined") {
        this.params.SendTime = addDate;
      }
      $loadMultipleCustomerReply(this.params, res => {
        let newList = res;
        if (typeof addDate !== "undefined") {
          this.detailList = newList;
        } else {
          this.detailList = newList.concat(this.detailList);
        }
        if (!res || !res.length || res.length < this.params.count) {
          this.hasMore = false;
        } else {
          this.hasMore = true;
          this.params.SendTime = res[0].sendTime;
        }

        if (this.firstFetch) {
          this._scrollToBottom();
          this.firstFetch = false;
        }
        this.loading = false;
      });
    },
    _scrollToBottom() {
      setTimeout(() => {
        let groupItems = this.$refs.groupItem || 0;
        let el = groupItems[groupItems.length - 1];
        console.log(groupItems);
        console.log(el);
        this.$refs.listview.scrollToElement(el, 200, 0, 0);
      }, 200);
    }
  },
  created() {
    this._scrollToBottom();
    xdapp.util.user.getCurrentHead();
    this.currentUserGender = this.$store.state.currentUserGender;
    this.getCustomerReply(m2.date.now());
  },
  computed: {
    currentHeadImg() {
      if (
        this.$store.state.currentHeadImg &&
        m2.cache.get(CACHE_KEYS.CURRENT_ICONARR)
      ) {
        return (
          this.$store.state.currentHeadImg.imgData ||
          m2.cache.get(CACHE_KEYS.CURRENT_ICONARR).imgData
        );
      }
    }
  },
  components: {
    Scroll,
    Loading,
    Tip
  }
};
</script>
<style lang="scss" scoped>
.xdapp-msg-wrapper {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    .msg-list {
      background: #fff;
      padding-top: 20px;
      ul.list-group {
        li {
          padding-bottom: torem(15);
          &:last-child {
            padding-bottom: torem(125);
          }
        }
        .titKind {
          position: absolute;
          left: torem(63);
          bottom: torem(105);
          color: #bbb;
        }
        .msg-time {
          text-align: center;
          display: block;
          margin-top: 14px;
          font-size: torem(12);
          margin-left: 40%;
          width: 70px;
          color: #fff;
        }
        .msg-item-right {
          z-index: 1;
          position: relative;
          padding: 14px 18px 0;
          display: flex;
          justify-content: flex-end;
          img {
            width: 40px;
            height: 40px;
            margin-left: 11px;
            border-radius: 50%;
          }
          .reply {
            font-size: torem(15);
            color: #333;
            padding: 8px;
           // margin-left: torem(57);
            background: #ffe3b6;
            border-radius: 5px;
            max-width: torem(282);
            //margin-top: torem(17);
            .tit {
              font-size: torem(20);
              color: #000;
              line-height: 28px;
            }
            p:first-child {
              border-bottom: 1px dashed #666;
            }
            p {
              margin-bottom: 0;
              color: #333;
              padding: 8px 6px;
            }
          }
          &:after {
            content: "";
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-left: 7px solid #ffe3b6;
            position: absolute;
            right: 56px;
            top: 27px;
            z-index: 10;
          }
          &:before {
            content: "";
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-left: 7px solid #ffe3b6;
            position: absolute;
            right: 58px;
            top: 27px;
            z-index: 20;
          }
        }
        @media only screen and (max-width: 320px) {
          .msg-item-right {
            display: box;
            /* OLD - Android 4.4- */
            display: -webkit-box;
            /* OLD - iOS 6-, Safari 3.1-6 */
            display: -moz-box;
            /* OLD - Firefox 19- (buggy but mostly works) */
            display: -ms-flexbox;
            /* TWEENER - IE 10 */
            display: -webkit-flex;
            /* NEW - Chrome */
            display: flex;
          }
        }
      }
    }
  }
}
</style>

