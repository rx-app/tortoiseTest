<template>
  <div class="xd-group-list xd-group-list-vh">
    <div class="tab-header">
      <mt-navbar v-model="selected">
        <mt-tab-item id="1" @click.stop.prevent="switchTabs('1')" class="todayStu">按状态选择</mt-tab-item>
        <mt-tab-item id="2" @click.stop.prevent="switchTabs('2')" class="allStu">按年级选择</mt-tab-item>
      </mt-navbar>
    </div>

    <!-- tab-container  -->
    <div id="group-list-content">
      <mt-tab-container v-model="selected">
        <mt-tab-container-item id="1">
          <div class="group-list">
            <ul>
              <li v-for="(item,index) in stateType" :key="index">
                <label :for="item.value">
                  <span>
                    {{item.desc}}
                    <i v-if="item.value == 5" class="tit">(当前有效)</i>
                  </span>
                  <input
                    name="checkbox1"
                    value="Item 1"
                    type="checkbox"
                    :id="item.value"
                    @click="checkInput($event,'status',item.value)"
                  >
                  <span class="checkbox"></span>
                </label>
              </li>
            </ul>
          </div>
        </mt-tab-container-item>
        <mt-tab-container-item id="2">
          <div class="group-list1">
            <ul class="mui-table-view">
              <li
                class="mui-table-view-cell mui-collapse"
                v-for="(item,index) in gradeType"
                :class="item.show?'mui-active':''"
                :key="index"
              >
                <!-- @click="addClass('li'+index)" -->
                <a class="mui-navigate-right" href="#">{{item.gardeType}}</a>
                <div class="mui-collapse-content">
                  <p v-for="(item,index) in item.garde" :key="index">
                    <label :for="item.gardeValue">
                      <span>{{item.gardeName}}</span>
                      <input
                        name="checkbox1"
                        value="Item 1"
                        type="checkbox"
                        :id="item.gardeValue"
                        @click="checkInput($event,'garde',item.gardeValue)"
                      >
                      <span class="checkbox"></span>
                    </label>
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </mt-tab-container-item>
      </mt-tab-container>
    </div>
  </div>
</template>

<script>
import {
  ACTION_TYPES,
  CUSTOMER_STATUS_SHORT,
  CUSTOMER_GRADE
} from "@/constants";
export default {
  data() {
    return {
      selected: null,
      selectCustomerArr: {
        status: ""
      },
      valueArr: [],
      stateType: CUSTOMER_STATUS_SHORT,
      gradeType: CUSTOMER_GRADE
    };
  },
  methods: {
    addClass(idName) {
      var idNameEle = document.getElementById(idName);
      var classListArr = idNameEle.getAttribute("class").split(" ");
      console.log(classListArr);
      if (classListArr.indexOf("mui-active") !== 0) {
        console.log(idNameEle.classList);
        idNameEle.classList.add("mui-active");
        console.log(idNameEle.classList);
      }
    },
    checkInput(e, type, value) {
      this.selectCustomerArr.status = type;
      if (e.srcElement.checked) {
        if (this.valueArr.indexOf(value) == -1) {
          this.valueArr.push(value);
        }
      } else {
        var currentIndex = this.valueArr.indexOf(value);
        this.valueArr.splice(currentIndex, 1);
      }
      console.log(this.valueArr);
    },
    nextType() {
      this.selectCustomerArr.valueArr = this.valueArr;
      this.$router.push({
        name: "message-customer-list",
        query: {
          selectCustomerArr: this.selectCustomerArr,
          reviewAgin: true
        }
      });
    }
  },
  watch: {
    valueArr: {
      handler: function(val) {
        xdapp.util.vue.commitActionStatus(val.length);
      }
    },
    selected() {
      this.valueArr = [];
      var eles = document.getElementsByName("checkbox1");
      eles.forEach(item => {
        item.checked = false;
      });
    }
  },
  created() {
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
  },
  mounted() {
    this.selected = "1";
  }
};
</script>

<style >
.xd-group-list-vh .mint-tab-container-item{
    height: 60vh;
    overflow: scroll;
    height: calc(100vh - 63px - 1.41333rem)
  }
</style>
<style lang="scss" scoped>
.tab-header {
  height: torem(53);
  padding: torem(10) 5%;
  background-color: #fff;
  position: fixed;
  top: torem(56);
  left: 0;
  width: 100%;
  z-index: 99;
  .mint-navbar {
    width: 100%;
    margin-left: 0;
  }
}

.todayStu {
  border-radius: 6px 0 0 6px;
}
.allStu {
  border-radius: 0 6px 6px 0;
}
#group-list-content {
  margin-top: torem(50);
}
.group-list {
  ul {
    background-color: #eee;
    border-radius: 5px;
    width: 94%;
    margin-left: 3%;
    padding: 0 torem(15);
    li {
      height: torem(45);
      line-height: torem(45);
      font-size: torem(15);
      border-bottom: 1px solid #ddd;
      label {
        display: flex;
        align-items: center;
        justify-content: space-between;
        span {
          display: inline-block;
          width: 90%;
        }
      }
      input {
        float: right;
        width: torem(0);
        height: torem(18);
      }
      .tit {
        margin-left: torem(6);
      }
    }
    li:last-child {
      border-bottom: none;
    }
  }
}
.group-list1 {
  .mui-table-view:before {
    height: 0;
  }
  .mui-table-view:after {
    height: 0;
  }
  ul {
    background-color: #eee;
    border-radius: 5px;
    width: 94%;
    margin-left: 3%;
    padding: 10px torem(15);
    li {
      font-size: torem(14);
      .mui-collapse-content:before {
        height: 0;
      }
      .mui-collapse-content:after {
        height: 0;
      }
      .mui-collapse-content {
        padding-top: 0;
        padding-bottom: 0;
        p:last-child {
          border-bottom: none;
        }
      }
      p {
        height: torem(45);
        line-height: torem(45);
        font-size: torem(14);
        border-bottom: 1px solid #ddd;
        label {
          display: flex;
          align-items: center;
          justify-content: space-between;
          span {
            display: inline-block;
            width: 90%;
          }
        }
        input {
          float: right;
          width: torem(0);
          height: torem(18);
        }
      }
    }
  }
}
input[type="checkbox"]:checked + .checkbox[data-v-01165218]::before {
  top: torem(-12);
}
</style>