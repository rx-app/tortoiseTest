<template>
  <div class="xd-disscuion-wrapper">
    <div class="xd-disscuion-header">
      <p class="inp">
        <input
          type="text"
          placeholder="输入学员姓名/编号进行查询"
          v-model="inpVal"
          @focus="fnFocus"
          @blur="fnBlur"
        >
        <i class="iconfont icon-found" @click="getList()"></i>
      </p>
      <p class="add-group" @click="creatGroup()" v-if="isCreateGroup">
        <i class="iconfont icon-add"></i>
        <span>创建讨论组</span>
      </p>
    </div>
    <div class="scroll-container">
      
      <!-- 展示搜索讨论组 -->
      <ul style="overflow:scroll" class="mui-table-view rx-message-reply" v-if="searchList.length">
        <li
          v-for="(item,key) in searchList"
          class="mui-table-view-cell mui-transitioning"
          :key="key"
          @click="todoLink(item)"
        >
          <div class="mui-slider-right mui-disabled">
            <a class="mui-btn mui-btn-red" @click="todoDelete($event, item, key)">删除</a>
          </div>
          <div class="mui-slider-handle" :ref="key">
            <img
              class="mui-media-object mui-pull-left"
              v-if="item.icons && item.icons.iconID && getIconImg(item.icons.userID)"
              :src="getIconImg(item.icons.userID)"
            >
            <img
              class="mui-media-object mui-pull-left"
              v-else-if="item.icons && item.icons.gender==1"
              src="~@/public/asset/img/user/boy.png"
              alt
            >
            <img
              class="mui-media-object mui-pull-left"
              v-else-if="item.icons && item.icons.gender==2"
              src="~@/public/asset/img/user/girl.png"
              alt
            >
            <img
              class="mui-media-object mui-pull-left"
              v-else
              src="~@/public/asset/img/user/boy.png"
              alt
            >
            <div class="pointer" v-if="item.unReadCount"></div>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{item.title}}</span>
                <span
                  class="tit-time"
                  v-if="item.lastInfo"
                >{{item.lastInfo.speakTime | dateTimeFormat}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span>
                <span v-if="item.lastInfo">{{item.lastInfo.content}}</span>
              </p>
            </div>
          </div>
        </li>
      </ul>
      <!-- 默认展示全部讨论组 -->
      <ul class="mui-table-view rx-message-reply" v-else-if="customerReply.length">
        <li
          v-for="(item,key) in customerReply"
          class="mui-table-view-cell mui-transitioning"
          :key="key"
          @click="todoLink(item)"
        >
          <div class="mui-slider-right mui-disabled">
            <a class="mui-btn mui-btn-red" @click.stop="todoDelete($event, item, key)">删除</a>
          </div>
          <div class="mui-slider-handle" :ref="key">
            <img
              class="mui-media-object mui-pull-left"
              v-if="item.icons && item.icons.iconID && getIconImg(item.icons.userID)"
              :src="getIconImg(item.icons.userID)"
            >
            <img
              class="mui-media-object mui-pull-left"
              v-else-if="item.icons && item.icons.gender==2"
              src="~@/public/asset/img/user/girl.png"
              alt
            >
            <img
              class="mui-media-object mui-pull-left"
              v-else
              src="~@/public/asset/img/user/boy.png"
              alt
            >
            <div class="pointer" v-if="item.unReadCount"></div>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{item.title}}</span>
                <span
                  class="tit-time"
                  v-if="item.lastInfo"
                >{{item.lastInfo.speakTime | dateTimeFormat}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span>
                <span v-if="item.lastInfo">{{item.lastInfo.content}}</span>
              </p>
            </div>
          </div>
        </li>
      </ul>
      <tip class="none-tit" v-if="!totalList.length && isCreateGroup && !searchList.length && !searchFlag">暂无学员讨论组，您可以点击右上角“创建讨论组”为其创建。</tip>
      <tip class="none-tit" v-if="!totalList.length && !isCreateGroup && !searchList.length && !searchFlag">暂无学员讨论组。</tip>
      <tip class="none-tit" v-if="!searchList.length && searchFlag">暂无该学员讨论组。</tip>
    </div>
  </div>
</template>
<script>
import * as types from "@/store/mutation-types";
import {
  $loadDiscussionPage,
  $deleteDiscussion,
  $loadDiscussionPageByCustomer
} from "@/api/customer-reply/customer-reply-api";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import store from "@/store";
import Tip from "@/components/tip";
import Scroll from "@/components/scroll/index";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
export default {
  data() {
    return {
      inpVal: "",
      totalList: [],
      customerReply: [],
      searchList: [],
      qStudentIDs: [],
      studentIDs: [],
      icons: [],
      searchFlag: false
    };
  },
  mounted() {
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    setTimeout(() => {
      //this.setHeight();
    }, 500);
  },
  created() {
    this._getCroupList();
    window.addEventListener("resize", resize);
  },
  destroyed() {
    window.removeEventListener("resize", resize);
  },
  methods: {
    getList() {
      this.customerReply = [];
      $loadDiscussionPageByCustomer(this.inpVal, res => {
        
        this.searchList = res;
        if (!res.length) {
          this.searchFlag = true;
        }
      });
    },
    todoDelete(event, item, key) {
      let bts = ["确认", "取消"];
      mui.confirm(
        `删除${item.customerName}同学讨论组的聊天记录后不会再显示，是否删除？`,
        "提示",
        bts,
        e => {
          event.target.style.transform = "translate(0px, 0px)";
          this.$refs[key][0].style.transform = "translate(0px, 0px)";

          if (e.index == 0) {
            $deleteDiscussion(item.discussionGroupID, () => {
              mui.toast("删除成功!");
              this._getCroupList();
            });
          }
        }
      );
    },
    todoLink(item) {
      this.$router.push({
        name: "message-group-mess",
        query: {
          title: item.title,
          groupID: item.discussionGroupID
        }
      });
    },
    creatGroup() {
      this.$router.push({
        name: "message-create-group"
      });
    },
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserIcons(arr) {
      arr.forEach(item => {
        if (!item.icons || !item.icons.iconID) return;

        var userIcons = this.$store.state.headList.slice() || [];
        console.log(userIcons);
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === item.icons.userID);
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: curIcon.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: item.icons.iconID
            },
            res => {
              let obj = {
                userID: item.icons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      });
    },
    _getCroupList() {
      $loadDiscussionPage(res => {
        
        if(res&&res.length&&res[0].lastInfo){
						res.forEach(v=>{
							if(v.lastInfo){
								v.lastInfo.content.includes('[###voice###]')&&(v.lastInfo.content='[语音消息]')
								v.lastInfo.content.includes('[###img###]')&&(v.lastInfo.content='[图片]')
							}
						})
					}
        this.customerReply = this.totalList = res;
      });
    },
    fnTap(e) {
      if (!mui.os.ios) {
        if (e.target.tagName == "TEXTAREA" || e.target.tagName == "INPUT") {
          return;
        }
        if (
          document.activeElement.tagName == "TEXTAREA" ||
          document.activeElement.tagName == "INPUT"
        ) {
          document.activeElement.blur();
        }
      }
    },
    fnFocus() {
      mui.plusReady(() => {
        var ua = navigator.userAgent.toLowerCase();
        if (/iphone|ipad|ipod/.test(ua)) {
          var wv = plus.webview.currentWebview();
          let bottom = this.iosType == "4s" ? "315px" : "655px";

          wv.setStyle({ top: "0px" });
          wv.setStyle({ bottom });
          //plus.webview.currentWebview().setStyle({ background: "#fff" });
        }
      });
    },
    fnBlur() {
      mui.plusReady(() => {
        var ua = navigator.userAgent.toLowerCase();
        if (/iphone|ipad|ipod/.test(ua)) {
          // mui.toast(window.innerHeight)

          var wv = plus.webview.currentWebview();
          wv.setStyle({ top: "0px" });
          wv.setStyle({ bottom: "0px" });
        }
      });
    }
  },
  watch: {
    inpVal(val) {
      if (!val) {
        this.searchList = [];
        this.searchFlag = false;
        this.customerReply = this.totalList;
      }
    },
    searchList(val) {
      this.getUserIcons(val);
      this.qStudentIDs = [];
      if (val.length) {
        val.forEach((item, index) => {
          if (item.customerID) {
            var obj = {
              type: "2",
              userID: item.customerID
            };
            if (
              JSON.stringify(this.qStudentIDs).indexOf(JSON.stringify(obj)) ==
              -1
            ) {
              this.qStudentIDs.push(obj);
            }
          }
        });
      }
    },
    qStudentIDs() {
      getHeadIDsByUserIDs(this.qStudentIDs, res => {
        this.searchList.forEach(item => {
          res.forEach(sel => {
            if (item.customerID == sel.userID) {
              this.$set(item, "icons", sel);
            }
          });
        });
      });
    },
    totalList(val) {
      this.getUserIcons(val);
      this.studentIDs = [];
      if (val.length) {
        val.forEach((item, index) => {
          if (item.customerID) {
            var obj = {
              type: "2",
              userID: item.customerID
            };
            if (
              JSON.stringify(this.studentIDs).indexOf(JSON.stringify(obj)) == -1
            ) {
              this.studentIDs.push(obj);
            }
          }
        });
      }
      this.customerReply = val;
    },
    studentIDs() {
      getHeadIDsByUserIDs(this.studentIDs, res => {
        this.totalList.forEach(item => {
          res.forEach(sel => {
            if (item.customerID == sel.userID) {
              this.$set(item, "icons", sel);
            }
          });
        });
      });
    }
  },
  computed: {
    isCreateGroup() {
      let currentJonType = m2.cache.get("ppts-current-job").jobType;
      return currentJonType == 2; //为2岗位为学管师
    }
  },
  components: {
    Tip,
    Scroll
  }
};
</script>
<style lang="scss" scoped>
.xd-disscuion-wrapper {
  //position: fixed;
  height: 100vh;
  overflow: scroll;
  width: 100%;
  // height: 100%;
  .scroll-container {
    height: 100%;
    overflow-y: scroll;
    background: #fff;
  }
}
.xd-disscuion-header {
  display: flex;
  align-items: center;
  position: fixed;
  top: 65px;
  left: 0;
  margin-top: -2px;
  z-index: 99;
  background: #fff;
  width: 100%;
  padding: torem(15) 0;
  .inp {
    flex: 2;
    margin-left: 5%;
    margin-right: 5%;
    border: 1px solid #d8d8d8;
    border-radius: 100px;
    height: 32px;
    position: relative;
    margin-bottom: 0;
    input {
      width: 90%;
      height: 100%;
      border: none;
      margin-left: 1%;
      border-radius: 100px;
    }
    input::-webkit-input-placeholder {
      font-size: torem(12);
      color: rgb(138, 130, 130);
    }
    i {
      position: absolute;
      right: torem(10);
      top: torem(5);
      color: rgb(138, 130, 130);
      font-size: torem(24);
    }
  }
  .add-group {
    flex: 1;
    //margin-left: torem(20);
    margin-bottom: 0;
    display: flex;
    align-items: center;
    i {
      color: rgb(138, 130, 130);
      font-size: torem(20);
      margin-right: torem(2);
    }
  }
}
.rx-message-reply {
  padding: 0 torem(12);
  margin-top: torem(69);
  //overflow: auto;
  //height: calc(100vh - 126px);
  .mui-table-view-cell {
    //border-bottom: 1px solid #eee;
    // transform: scaleX(1.02);
    margin-right: 4px;
    
    padding: 11px 0px 11px;
    .mui-slider-right{
      transform: translateX(102%);
    }
    &::after {
      // height:px;
      left: 0px;
      transform: scaleY(1);
      background-color: #efefef;
    }
  }
  .mui-btn-red {
    height: 100%;
    width: torem(100);
  }
  li {
    .pointer {
      position: absolute;
      width: torem(10);
      height: torem(10);
      border-radius: 50%;
      background: #fb150a;
      margin-left: torem(36);
      margin-top: torem(-1);
    }
    img {
      width: torem(50);
      height: torem(50);
      max-width: 1000px;
      border-radius: 5px;
    }
    .tit {
      display: flex;
      justify-content: space-between;
      //margin-top: torem(6);
      .tit-name {
        font-size: torem(16);
        color: #121212;
        line-height: torem(22);
        width: torem(145);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .tit-time {
        font-size: torem(12);
        color: #8e8e8e;
        line-height: torem(17);
        // float: right;
      }
    }
    .txt {
      color: #999;
      font-size: torem(14);
      margin-top: torem(8);
    }
    .num {
      color: #e03229;
    }
  }
}
.none-tit {
  margin-top: torem(50);
  padding: 0 torem(15);
  text-align: center;
  line-height: torem(31);
}
</style>

