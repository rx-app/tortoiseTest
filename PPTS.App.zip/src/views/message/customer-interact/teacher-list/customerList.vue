<template>
  <div class="customer-cantainer">
    <h4 v-if="customerList.length">已选学员 :</h4>
    <ul v-if="customerList.length">
      <li v-for="(item,index) in customerList" :key="index">
        <p>
          <span class="name">{{item.customerName}}</span>
          <span
            class="code"
            v-if="item.primaryPhoneNumber"
          >({{item.primaryPhoneNumber.substr(7,4)}})</span>
          <span class="none" v-else>(暂无)</span>
        </p>
        <i class="iconfont icon-error" @click="delectCustomer(item)"></i>
      </li>
    </ul>
    <tip v-else>所选条件下暂无学员</tip>
  </div>
</template>

<script>
import { ACTION_TYPES } from "@/constants";
import Tip from "@/components/tip";
import {
  $loadCustomerByStatus,
  $loadCustomerByGrade
} from "@/api/customer-reply/customer-reply-api";
export default {
  data() {
    return {
      customerList: []
    };
  },
  methods: {
    nextType() {
      this.customerIDs = [];
      this.customerList.forEach(item => {
        this.customerIDs.push(item.customerID);
      });
      this.$nextTick(() => {
        this.$router.push({
          name: "message-send-message",
          query: {
            customerIDs: this.customerIDs
          }
        });
      });
    },
    delectCustomer(item) {
      mui.confirm("是否要移除" + item.customerName + "学员", "提示", e => {
        if (e.index) {
          var currentIndex = this.customerList.indexOf(item);
          this.customerList.splice(currentIndex, 1);
        }
      });
    },
    loadCustomerList() {
      if (
        this.selectCustomerArr &&
        this.selectCustomerArr.status == "status" &&
        this.reviewAgin
      ) {
        $loadCustomerByStatus(this.selectCustomerArr.valueArr, res => {
          this.customerList = res;
        });
      } else if (this.selectCustomerArr && this.reviewAgin) {
        $loadCustomerByGrade(this.selectCustomerArr.valueArr, res => {
          this.customerList = res;
        });
      }
    }
  },
  watch: {
    customerList: {
      handler: function(val) {
        if (val.length == 1) {
          mui.toast("群发消息人数至少2人!");
        }
        xdapp.util.vue.commitActionStatus(val.length >= 2);
      }
    }
  },
  mounted() {
    xdapp.util.vue.commitActionStatus(this.customerList.length);
  },
  created() {
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
  },
  activated() {
    if (!this.reviewAgin) {
      xdapp.util.vue.commitActionStatus(true);
    }
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
    this.loadCustomerList();
  },
  computed: {
    selectCustomerArr() {
      return this.$route.query.selectCustomerArr;
    },
    reviewAgin() {
      return this.$route.query.reviewAgin;
    }
  },
  components: {
    Tip
  }
};
</script>

<style lang="scss" scoped>
.customer-cantainer {
  width: 100%;
  height: 100%;
  padding: torem(15);
  h4 {
    width: 100%;
    height: 40px;
    line-height: 40px;
    position: fixed;
    margin-top: 0;
    background-color: #fff;
  }
  ul {
    display: flex;
    flex-wrap: wrap;
    margin-top: torem(38);
    li {
      width: 42%;
      height: torem(40);
      line-height: torem(40);
      text-align: center;
      font-size: torem(14);
      background-color: #fff;
      border-radius: 5px;
      margin: torem(10);
      display: flex;
      align-items: center;
      background-color: #eee;
      p {
        display: flex;
        align-items: center;
        margin-bottom: 0;
        flex: 4;
        padding: 0 3px;
        .name {
          display: inline-block;
          width: torem(64);
          font-size: torem(16);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .none {
          font-size: torem(12);
        }
      }

      i {
        color: #000;
        margin-left: torem(5);
        flex: 1;
      }
    }
  }
}
</style>