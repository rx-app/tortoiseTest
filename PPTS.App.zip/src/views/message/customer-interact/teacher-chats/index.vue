<template>
  <div class="wrap">
    <div class="select-teacher">
      <router-link tag="div" class="add" :to="{name:'message-teacher-list',query:{num:slideType}}">
        <p v-if="slideType">
          <span>+</span>添加反馈
        </p>
        <p v-if="!slideType">
          <span>+</span>联系家长
        </p>
      </router-link>
      <router-link
        tag="div"
        class="add"
        :to="{name:'message-group-list'}"
        v-if="!slideType && currentJobTypeIsGroup"
      >
        <p>
          <span>o</span>群发消息
        </p>
      </router-link>
    </div>
    <!-- 群发消息置顶 -->
    <ul
      style="overflow:scroll"
      class="mui-table-view rx-group-reply"
      v-if="!slideType && dissGroupList && dissGroupList.sendTime && currentJobTypeIsGroup"
    >
      <li class="mui-table-view-cell mui-transitioning" @click="goDissGroupDetail()">
        <div class="mui-slider-handle">
          <img
            class="mui-media-object mui-pull-left"
            src="~@/public/asset/img/msg/mass-message.png"
            alt
          >
          <!-- <div class="pointer" v-if="item.unReadCount"></div> -->
          <div class="mui-media-body">
            <p class="tit">
              <span class="tit-name">群消息记录</span>
              <span
                class="tit-time"
                v-if="dissGroupList.sendTime"
              >{{dissGroupList.sendTime | dateTimeFormat}}</span>
            </p>
            <p class="mui-ellipsis txt">
              <!-- <span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span> -->
              <span v-if="dissGroupList.content">{{dissGroupList.content}}</span>
            </p>
          </div>
        </div>
      </li>
    </ul>
    <teacher-reply
      :teacherReplyList="teacherReplyList"
      @todoDelChat="getTeacherReplyList()"
      :slideType="slideType"
      :isTance="isTance"
      :hasGroupMessageRecords="!!dissGroupList"
    ></teacher-reply>
  </div>
</template>
<script>
import { loadUserInfo } from "@/api/common/common-api";
import {
  $loadEducatorWeekCustomerReplyPage,
  $loadDailyCustomerReplyPage,
  $loadLastMultipleCustomerReply
} from "@/api/customer-reply/customer-reply-api";
import TeacherReply from "../partials/teacher-reply/index";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
export default {
  data() {
    return {
      teacherReplyList: [],
      dissGroupList: {},
      parentIDs: [],
      switch: true
    };
  },
  created() {
    this.getTeacherReplyList();
    this.setTitle();
  },
  methods: {
    async getTeacherReplyList() {
      await loadUserInfo();
      mui.showLoading()
      // document.querySelector('.mui-show-loading').style.visibility = 'visible'
      // document.querySelector('.mui-show-loading').style.opacity = '100'
      if (this.slideType) {
        $loadEducatorWeekCustomerReplyPage(res => {
          
          if(res&&res.length&&res[0].lastInfo){
            res.forEach(v=>{
              if(v.lastInfo){
                v.lastInfo.replyContent.includes('[###voice###]')&&(v.lastInfo.replyContent='[语音消息]')
                v.lastInfo.replyContent.includes('[###img###]')&&(v.lastInfo.replyContent='[图片]')
              }
            })
            // res[0].lastInfo.replyContent.includes('[###voice###]')&&(res[0].lastInfo.replyContent='[语音消息]')
            // res[0].lastInfo.replyContent.includes('[###img###]')&&(res[0].lastInfo.replyContent='[图片]')
          }
          this.teacherReplyList = res;
          mui.hideLoading()
          // document.querySelector('.mui-show-loading').style.visibility = 'hidden'
          // document.querySelector('.mui-show-loading').style.opacity = '0'
        });
      } else {
        $loadDailyCustomerReplyPage(res => {
          if(res&&res.length&&res[0].lastInfo){
            res.forEach(v=>{
              if(v.lastInfo){
                v.lastInfo.replyContent.includes('[###voice###]')&&(v.lastInfo.replyContent='[语音消息]')
                v.lastInfo.replyContent.includes('[###img###]')&&(v.lastInfo.replyContent='[图片]')
              }
            })
            // res[0].lastInfo.replyContent.includes('[###voice###]')&&(res[0].lastInfo.replyContent='[语音消息]')
            // res[0].lastInfo.replyContent.includes('[###img###]')&&(res[0].lastInfo.replyContent='[图片]')
          }
          this.teacherReplyList = res;
          mui.hideLoading()
          // document.querySelector('.mui-show-loading').style.visibility = 'hidden'
          // document.querySelector('.mui-show-loading').style.opacity = '0'
        });

        if (this.currentJobTypeIsGroup) {
          $loadLastMultipleCustomerReply(res => {
            this.dissGroupList = res;
          });
        }
      }
    },
    goDissGroupDetail() {
      this.$router.push({
        name: "message-group-detail"
      });
    },
    setTitle() {
      if (this.slideType) {
        this.$route.meta.title = "周反馈";
      } else {
        this.$route.meta.title = "日常维护";
      }
    }
  },
  destroyed(){
    mui.hideLoading()
    // document.querySelector('.mui-show-loading').style.visibility = 'hidden'
    // document.querySelector('.mui-show-loading').style.opacity = '0'
  },
  watch: {
    teacherReplyList() {
      if (this.teacherReplyList.length && this.switch) {
        this.switch = false;
        this.teacherReplyList.forEach((item, index) => {
          if (item.lastInfo.parentPassportID) {
            this.parentIDs.push({
              type: "3",
              userID: item.lastInfo.parentPassportID
            });
          }
        });
      }
    },
    parentIDs() {
      if (this.parentIDs.length) {
        getHeadIDsByUserIDs(this.parentIDs, res => {
          this.teacherReplyList.forEach(item => {
            res.forEach(sel => {
              if (item.lastInfo.parentPassportID == sel.userID) {
                this.$set(item, "icons", sel);
              }
            });
          });
        });
      }
    }
  },
  computed: {
    slideType() {
      if (this.$route.query.num == 0) return 0; //日常维护
      if (this.$route.query.num == 1) return 1; //周反馈
    },
    isTance() {
      if (this.dissGroupList && this.dissGroupList.sendTime) {
        return false;
      } else {
        return true;
      }
    },
    currentJobTypeIsGroup() {
      let currnetJobType = m2.cache.get("ppts-current-job").jobType;
      if (currnetJobType == 2) {
        return true;
      }
    }
  },
  components: {
    TeacherReply
  }
};
</script>
<style>
#xd-header{
  height: 67px;
  z-index: 999;
}
</style>
<style lang="scss" scoped>
ul.mui-table-view.rx-message-reply{
  height:calc( 100vh - 63px - 45px + 5px ) 
  // height:calc( 100vh - 63px - 1.33333rem - 1px - 22px - 1.33333rem + 5px) 
}
ul.mui-table-view.rx-message-reply.weekul{
  // height:calc( 100vh - 63px - 45px + 5px ) 
  height:calc( 100vh - 63px - 1.33333rem - 1px - 22px - 1.33333rem + 5px) 
}
ul.mui-table-view.rx-message-reply.weekul.nogroup{
  // height:calc( 100vh - 63px - 45px + 5px ) 
  height:calc( 100vh - 63px - 1.33333rem - 1px + 5px) 
}
.wrap {
  height: 100vh;
  overflow: hidden;//加上防止滚动到最后的试试，群消息记录会往上移动一下
  .select-teacher {
    height: torem(40);
    line-height: torem(40);
    background-color: #fff;
    position: fixed;
    z-index: 99;
    width: 100%;
    margin-top:-3px;
    display: flex;
    .add {
      font-size: torem(14);
      color: #b1b9ca;
      height: 45px;
      line-height: 45px;
      text-align: center;
      flex: 1;
      span {
        font-size: torem(16);
        font-weight: 600;
      }
    }
  }
  .rx-group-reply {
    padding: 0 torem(12);
    margin-top: torem(50);
    .mui-table-view-cell {
      padding: 11px 0;
      &::after {
        left: 0px;
      }
    }
    .mui-btn-red {
      height: 100%;
      width: torem(100);
    }
    li {
      img {
        width: torem(50);
        height: torem(50);
        max-width: 1000px;
        border-radius: 50%;
      }
      .tit {
        display: flex;
        justify-content: space-between;
        .tit-name {
          font-size: torem(16);
          color: #121212;
          line-height: torem(22);
        }
        .tit-time {
          font-size: torem(12);
          color: #8e8e8e;
          line-height: torem(17);
        }
      }
      .txt {
        color: #999;
        font-size: torem(14);
        margin-top: torem(8);
      }
      .num {
        color: #e03229;
      }
    }
  }
}
</style>
