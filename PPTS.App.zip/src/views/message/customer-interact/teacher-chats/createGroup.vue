<template>
  <div class="xd-create-group">
    <div class="scroll-container">
      <div class="xd-creat-header">
        <h4 @click="showAndHide('student')">
          <p>
            <span>选择学员</span>
            <span v-show="isShowAndHideStu && selectCustomer">^</span>
            <span class="turnUp" v-show="!isShowAndHideStu && selectCustomer">^</span>
          </p>
        </h4>
        <p class="inp" v-show="isShowAndHideStu">
          <input
            type="text"
            placeholder="输入学员姓名/编号进行查询"
            @focus="fnFocus"
            @blur="fnBlur"
            v-model="inpValCustomer"
          >
          <i class="iconfont icon-found" @click="getCustomerList()"></i>
        </p>
      </div>
      <div
        class="customer-list"
        :id="selectCustomer?'select-list':''"
        ref="customer"
        v-show="isShowAndHideStu"
        v-if="customerList.length"
      >
        <div
          class="mui-input-row mui-radio"
          v-for="(item,index) in customerList"
          :key="index"
          @click="selectCustomerEvent(item)"
          :id="item.customerCode"
        >
          <label>
            <p class="customerMess">
              <span class="customerName">{{item.customerName}}</span>
              <span class="customerCode">(学员编号{{item.customerCode}})</span>
            </p>
            <input name="radio1" type="radio">
          </label>
        </div>
      </div>
      <p class="none-customer-tit" v-else-if="customerFlag">没有找到该学生，请确认输入内容是否正确</p>
      <div class="xd-creat-header" id="selectTeacherHeader" v-if="selectCustomer">
        <h4 @click="showAndHide('teacher')">
          <p>
            <span>选择老师</span>
            <span v-show="isShowAndHideTea">^</span>
            <span class="turnUp" v-show="!isShowAndHideTea">^</span>
          </p>
        </h4>
        <p class="inp" v-show="isShowAndHideTea">
          <input
            type="text"
            placeholder="输入老师姓名/OA号进行查询"
            @focus="fnFocus"
            @blur="fnBlur"
            v-model="inpValTearch"
          >
          <i class="iconfont icon-found" @click="getTeacherList()"></i>
        </p>
      </div>
      <div class="teacher-list" v-show="isShowAndHideTea" v-if="selectCustomer" id="teacherListDiv">
        <p class="tit" v-if="titFlag">没有找到相关老师</p>
        <div
          class="mui-input-row mui-radio"
          v-for="(item,index) in teacherList"
          :key="index"
          @click="selectTeacherEvent($event)"
          :id="item.staffID"
        >
          <label>
            <p id="teacherMess">
              <span class="teacherName">{{item.jobName}}</span>
              <span class="teacherOA">{{item.staffName}}({{item.staffOA}})</span>
            </p>
            <input name="radio1" type="checkbox" class="checkBox" :dataid="item.staffID">
            <span class="checkbox"></span>
          </label>
        </div>
      </div>
      <div class="popBox" v-if="flag">
        <div class="mui-popup mui-popup-in">
          <div class="mui-popup-inner">
            <!-- <div class="mui-popup-title">请确认讨论组成员</div> -->
            <div class="mui-popup-text">
              <h5>已选学员</h5>
              <p class="selectMess pmb">{{this.selectCustomer.customerName}}</p>
              <p class="selectMess">(学员编号{{this.selectCustomer.customerCode}})</p>
              <h5>已选老师</h5>
              <ul>
                <li v-for="(item,index) in selectTeacherMess" :key="index">
                  <p class="selectMess">{{item.jobName}}:{{item.staffName}}({{item.staffOA}})</p>
                </li>
              </ul>
              <p style="margin-top:15px;color:#000;">是否确认创建？</p>
              <div class="mui-popup-buttons">
                <span class="mui-popup-button cancle" @click="cancle()">取消</span>
                <span class="mui-popup-button mui-popup-button-bold" @click="sure()">确认</span>
              </div>
            </div>
          </div>
        </div>
        <div class="mui-popup-backdrop mui-active"></div>
      </div>
    </div>
  </div>
</template>
<script>
import { ACTION_TYPES, GroupMembersUserType } from "@/constants";
import {
  $queryCustomer,
  $queryDiscussionGroupStaff,
  $createDiscussionGroup
} from "@/api/customer-reply/customer-reply-api";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
export default {
  data() {
    return {
      inpValCustomer: "",
      inpValTearch: "",
      customerList: [],
      teacherList: [],
      selectCustomer: null,
      selectTeacher: [],
      selectPerson: [],
      isShowAndHideStu: true, //学员下方列表内容
      isShowAndHideTea: true, //老师下方列表内容
      selectSwitch: true, //控制是否可以继续选择教师  上限20
      customerFlag: false, //控制搜索不到学生的提示语
      titFlag: false, //控制搜索不到教师的提示语
      flag: false //控制确认讨论组成员框的显示隐藏
    };
  },
  methods: {
    fnFocus() {
      mui.plusReady(() => {
        var ua = navigator.userAgent.toLowerCase();
        if (/iphone|ipad|ipod/.test(ua)) {
          var wv = plus.webview.currentWebview();
          let bottom = this.iosType == "4s" ? "315px" : "655px";

          wv.setStyle({ top: "0px" });
          wv.setStyle({ bottom });
          //plus.webview.currentWebview().setStyle({ background: "#fff" });
        }
      });
    },
    fnBlur() {
      mui.plusReady(() => {
        var ua = navigator.userAgent.toLowerCase();
        if (/iphone|ipad|ipod/.test(ua)) {
          // mui.toast(window.innerHeight)

          var wv = plus.webview.currentWebview();
          wv.setStyle({ top: "0px" });
          wv.setStyle({ bottom: "0px" });
        }
      });
    },
    showAndHide(type) {
      if (!this.selectCustomer || !this.selectTeacher) return;
      if (type == "student") {
        this.isShowAndHideStu = !this.isShowAndHideStu;
        this._isChangeHeight();
      } else {
        this.isShowAndHideTea = !this.isShowAndHideTea;
        this._isChangeHeight();
      }
    },
    getCustomerList() {
      if (!this.inpValCustomer) {
        mui.alert("请输入学员姓名或学员编号进行查询!");
        return;
      }
      $queryCustomer(this.inpValCustomer.toUpperCase(), res => {
        !res.length ? (this.customerFlag = true) : (this.customerFlag = false);
        this.customerList = res;
      });
    },
    getTeacherList() {
      if (!this.inpValTearch) {
        mui.alert("请输入老师姓名或OA号进行查询!");
        return;
      }
      const regTest = new RegExp(this.inpValTearch, "i");
      this.indexArr = [];
      this.teacherList.forEach((item, index) => {
        if (regTest.test(item.staffName) || regTest.test(item.staffOA)) {
          this.indexArr.push(item.staffID);
          this.titFlag = false;
          this._scrollToBottom(this.indexArr[0], "#teacherListDiv");
        }
      });
      this.$nextTick(() => {
        if (!this.indexArr.length) {
          this.titFlag = true;
          this._scrollToBottom(null, "#teacherListDiv");
        }
      });
    },
    selectCustomerEvent(item) {
      this.selectCustomer = item;
      this.$nextTick(() => {
        this._scrollToBottom(item.customerCode, "#select-list");
      });
    },
    selectTeacherEvent(e) {
      var dataID = e.srcElement.attributes.dataid;
      if (!this.selectSwitch && e.srcElement.checked) {
        e.srcElement.checked = false;
        return;
      }
      if (dataID) {
        if (e.srcElement.checked) {
          if (this.selectTeacher.indexOf(dataID.value) == -1) {
            this.selectTeacher.push(dataID.value);
          }
        } else {
          var currentIndex = this.selectTeacher.indexOf(dataID.value);
          this.selectTeacher.splice(currentIndex, 1);
        }
      }
    },
    nextType() {
      this.flag = true;
    },
    cancle() {
      this.flag = false;
    },
    sure() {
      let membersArr = [];
      membersArr.push(this.selectCustomerArr);
      this.selectTeacherArr.map(item => {
        membersArr.push(item);
      });
      $createDiscussionGroup(
        {
          //discussionGroupName: this.selectCustomer.customerName+'学习讨论组',
          members: membersArr
        },
        res => {
          if (res.errorMsg) {
            this.flag = false;
            mui.alert(res.errorMsg);
          } else {
            mui.toast("创建成功!");
            setTimeout(() => {
              this.$router.push({
                name: "message-group-mess",
                query: {
                  title: res.discussionGroupName,
                  groupID: res.discussionGroupID
                }
              });
            }, 1000);
          }
        }
      );
    },
    _scrollToBottom(staffID, el) {
      let son = document.getElementById(staffID);
      let parent = document.querySelector(el); //"#teacherListDiv"
      if (!staffID) {
        parent.scrollTo(0, 0);
        return;
      }
      let distance = son.offsetTop - parent.offsetTop;
      parent.scrollTo(0, distance);
    },
    _isChangeHeight() {
      var ele = document.querySelector("#selectTeacherHeader");
      if (this.isShowAndHideStu && !this.isShowAndHideTea) {
        this._setHeight("customer", "#select-list");
        ele.style.position = "fixed";
        ele.style.bottom = "0";
      }
      if (this.isShowAndHideTea && !this.isShowAndHideStu) {
        this._setHeight("teacher", "#teacherListDiv");
      }
      if (this.isShowAndHideTea && this.isShowAndHideStu) {
        let content = document.querySelector("#select-list");
        content.style.maxHeight = 200 + "px";
        this._setHeight("all", "#teacherListDiv");
      }
      if (this.isShowAndHideTea || this.isShowAndHideStu) {
        ele.style.position = "";
      }
    },
    _setHeight(type, ele) {
      setTimeout(() => {
        var windowHeight = window.innerHeight;
        var content = document.querySelector(ele);
        var selectList = document.querySelector("#select-list");
        if (content == null || typeof content == "undefined") return;
        if (type == "customer") {
          let mayHeight = windowHeight - (65 + 45 + 30 + 62) + "px";
          content.style.maxHeight = mayHeight;
          content.style.height = mayHeight;
        } else if (type == "teacher") {
          let mayHeight = windowHeight - (65 + 35 + 30 + 62) + "px";
          content.style.height = mayHeight;
        } else {
          content.style.height =
            windowHeight - (65 + 184 + selectList.offsetHeight) + "px";
        }
      }, 0);
    }
  },
  watch: {
    selectTeacher: {
      handler: function(val) {
        if (val.length >= 20) {
          this.selectSwitch = false;
          mui.alert("最多可选择教师20人,已达上限!");
          //mui.toast("最多可选择教师20人,已达上限!");
        } else {
          this.selectSwitch = true;
        }
        xdapp.util.vue.commitActionStatus(val.length);
        this.selectTeacherArr = [];
        this.selectTeacherMess = [];
        this.teacherList.map(item => {
          val.map(items => {
            if (item.staffID == items) {
              this.selectTeacherMess.push(item);
              this.selectTeacherArr.push({
                UserID: item.staffID,
                UserType: item.userType,
                UserName: item.staffName,
                UserCode: item.staffOA
              });
            }
          });
        });
      }
    },
    selectCustomer: {
      handler: function(val) {
        if (val) {
          this._setHeight("all", "#teacherListDiv");
          this.selectTeacher = [];
          this.teacherList = [];
          $queryDiscussionGroupStaff(val.customerID, res => {
            this.teacherList = res;
          });
          this.selectCustomerArr = {
            UserID: this.selectCustomer.customerID,
            UserType: GroupMembersUserType.Customer,
            UserName: this.selectCustomer.customerName,
            UserCode: this.selectCustomer.customerCode
          };
        }
      }
    },
    inpValCustomer(val) {
      // if (!val) {
      this.inpValTearch = "";
      this.customerFlag = false;
      this.selectCustomer = null;
      this.selectTeacher = [];
      this.customerList = [];
      this.teacherList = [];
      //}
    },
    inpValTearch(val) {
      if (!val) {
        this._scrollToBottom(null, "#teacherListDiv");
        this.titFlag = false;
      }
    }
  },
  created() {
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
    window.addEventListener("resize", resize);
  },
  destroyed() {
    window.removeEventListener("resize", resize);
  }
};
</script>
<style lang="scss" scoped>
.xd-create-group {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    background: #fff;
  }
}
.xd-create-group {
  .xd-creat-header {
    // position: fixed;
    width: 100%;
    background: #fff;
    z-index: 99;
    h4 {
      background-color: #eee;
      height: 30px;
      line-height: 30px;
      margin: torem(10) 0;
      //transform: skew(-30deg);
      p {
        //transform: skew(30deg);
        padding: 0 15px;
        color: #000;
        font-size: torem(18);
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: space-between;
        .turnUp {
          transform: rotate(180deg);
        }
      }
    }
    .inp {
      width: 70%;
      margin-left: 15%;
      border: 1px solid #d8d8d8;
      border-radius: 100px;
      height: 32px;
      position: relative;
      input {
        width: 90%;
        height: 100%;
        border: none;
        margin-left: 1%;
        border-radius: 100px;
        font-size: torem(14);
      }
      input::-webkit-input-placeholder {
        font-size: torem(14);
        color: rgb(138, 130, 130);
      }
      i {
        position: absolute;
        right: torem(10);
        top: torem(5);
        color: rgb(138, 130, 130);
        font-size: torem(24);
      }
    }
  }
  .none-customer-tit {
    margin-top: torem(110);
    text-align: center;
    color: red;
  }
  #select-list {
    max-height: torem(200);
    height: auto;
  }
  // .teacher-list {
  //   min-height: torem(200);
  //   height: calc(100% - 184px - 5.4rem );
  // }
  .customer-list,
  .teacher-list {
    // margin-top: torem(95);
    overflow-y: scroll;
    height: calc(100vh - 156px);
    .tit {
      color: red;
      text-align: center;
      height: torem(40);
      line-height: torem(40);
    }
    .mui-input-row {
      height: torem(40);
      line-height: torem(35);
      font-size: torem(16);
      margin: 0 torem(20);
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #eee;
      label {
        padding-right: 0;
        padding: 11px 0;
        display: flex;
        justify-content: space-between;
        padding-right: torem(7);
      }
      input[type="radio"] {
        right: 0;
        top: torem(8);
      }
      input[type="radio"]:before {
        font-size: 24px;
      }
      .customerMess {
        display: flex;
        align-items: center;
        margin-bottom: 0;
        font-size: torem(16);
        .customerName {
          //margin-right: torem(15);
          //font-weight: bold;
          width: torem(60);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .customerCode {
          width: torem(230);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
      #teacherMess {
        display: flex;
        align-items: center;
        margin-bottom: 0;
        width: torem(290);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: torem(16);
        .teacherName {
          margin-right: torem(15);
          //font-weight: bold;
          width: torem(75);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .teacherOA {
          width: torem(200);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
    }
  }
}
.popBox {
  .mui-popup {
    width: torem(310);
  }
  .mui-popup-in {
    max-height: torem(340);
    overflow-y: scroll;
    padding: 15px;
    background: #fff;
  }
  .mui-popup-inner {
    padding: 0;
    background: #fff;
  }
  .mui-popup-inner:after {
    height: 0;
  }
  .mui-popup-button:after {
    height: 0;
    width: 0;
    background-color: #fff;
  }
  h5 {
    height: torem(35);
    line-height: torem(35);
    color: #000;
    font-weight: bold;
    font-size: torem(18);
  }
  p {
    font-size: torem(18);
  }
  .selectMess {
    color: darkorange;
    line-height: 24px;
    text-align: center;
  }
}
.mui-popup-buttons {
  .cancle {
    color: #000;
  }
  .mui-popup-button {
    font-size: torem(18);
    background: rgba(255, 255, 255, 0.95);
    //color: skyblue;
    overflow: visible;
  }
}
</style>

