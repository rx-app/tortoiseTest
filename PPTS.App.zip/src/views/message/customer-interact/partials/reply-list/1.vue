<template>
  <div>
    <ul class="mui-table-view rx-message-reply" v-if="customerReply && (customerReply.educator || customerReply.educatorWeek)">
      <li
        v-for="(item,key) in customerReply"
        class="mui-table-view-cell mui-transitioning"
        :key="key"
      >
        <div class="mui-slider-handle" :ref="key">
          <router-link :to="todoLink(item)">
            <img
              v-if="item.title=='日常维护'"
              class="mui-media-object mui-pull-left"
              src="~@/public/asset/img/msg/dail04@3x.png"
            />
            <img
              v-if="item.title=='周反馈'"
              class="mui-media-object mui-pull-left"
              src="~@/public/asset/img/msg/week04@3x.png"
            />
            <div class="pointer" v-if="item.unReadCount"></div>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{item.title}}</span>
                <span
                  class="tit-time"
                  v-if="item.lastInfo"
                >{{item.lastInfo.createTime | dateTimeFormat}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <!-- <span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span>-->
                <span v-if="item.lastInfo">{{item.lastInfo.replyContent}}</span>
              </p>
            </div>
          </router-link>
        </div>
      </li>
      <li class="mui-table-view-cell mui-transitioning" @click="goCussionGroup()" v-if="disResult">
        <div class="mui-slider-handle">
          <a>
            <img
              class="mui-media-object mui-pull-left"
              src="~@/public/asset/img/msg/group05@3x.png"
            />
            <div class="pointer" v-if="disResult.unReadCount"></div>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{disResult.title}}</span>
                <span
                  class="tit-time"
                  v-if="disResult.lastInfo"
                >{{disResult.lastInfo.speakTime | dateTimeFormat}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <!-- <span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span>-->
                <span v-if="disResult.lastInfo">{{disResult.lastInfo.content}}</span>
              </p>
            </div>
          </a>
        </div>
      </li>
    </ul>
    <ul class="mui-table-view rx-message-reply" v-else>
      <li class="mui-table-view-cell mui-transitioning">
        <div class="mui-slider-handle">
          <a>
            <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/week04@3x.png" />
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">周反馈</span>
              </p>
              <p class="mui-ellipsis txt">
                <span>内容正在加载中...</span>
              </p>
            </div>
          </a>
        </div>
      </li>
      <li class="mui-table-view-cell mui-transitioning">
        <div class="mui-slider-handle">
          <a>
            <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/dail04@3x.png" />
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">日常维护</span>
              </p>
              <p class="mui-ellipsis txt">
                <span>内容正在加载中...</span>
              </p>
            </div>
          </a>
        </div>
      </li>
      <li class="mui-table-view-cell mui-transitioning">
        <div class="mui-slider-handle">
          <a>
            <img
              class="mui-media-object mui-pull-left"
              src="~@/public/asset/img/msg/group05@3x.png"
            />
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">学员讨论组</span>
              </p>
              <p class="mui-ellipsis txt">
                <span>内容正在加载中...</span>
              </p>
            </div>
          </a>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import "@/public/asset/js/jquery/jquery-1.8.0";
import { ReplyLinkType } from "@/constants";
import { $loadDiscussionLast } from "@/api/customer-reply/customer-reply-api";
export default {
  data() {
    return {
      disResult: null
    };
  },
  props: ["customerReply"],
  created() {
    $loadDiscussionLast(res => {
      if (res && res.lastInfo) {
        res.lastInfo.content.includes("[###voice###]") &&
          (res.lastInfo.content = "[语音消息]");
        res.lastInfo.content.includes("[###img###]") &&
          (res.lastInfo.content = "[图片]");
      }
      this.disResult = res;
    });
  },
  methods: {
    todoLink(item) {
      console.log(item.title);
      if (
        item.title == ReplyLinkType.Educator ||
        item.title == ReplyLinkType.Conection
      )
        return { name: "message-teacher-chats", query: { num: 0 } };
      else return { name: "message-teacher-chats", query: { num: 1 } };
    },
    goCussionGroup() {
      this.$router.push({
        name: "message-disscuion-group"
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.mui-table-view-cell:after {
  height: 1px !important;
}
.mui-table-view:after {
  height: 0px;
}
.trans {
  transform: translate(0px, 0px);
}

.rx-message-reply {
  padding: 0 torem(12);
  .mui-table-view-cell {
    padding: 11px 0;
    &::after {
      left: 0px;
    }
  }
  .mui-btn-red {
    height: 100%;
    width: torem(100);
  }
  li {
    .pointer {
      position: absolute;
      width: torem(10);
      height: torem(10);
      border-radius: 50%;
      background: #fb150a;
      margin-left: torem(40);
      margin-top: torem(6);
    }
    a {
      img {
        width: torem(50);
        height: torem(50);
        max-width: 1000px;
        border-radius: 5px;
      }
      .tit {
        display: flex;
        justify-content: space-between;
        .tit-name {
          font-size: torem(16);
          color: #121212;
          line-height: torem(22);
        }
        .tit-time {
          font-size: torem(12);
          color: #8e8e8e;
          line-height: torem(17);
        }
      }
      .txt {
        color: #999;
        font-size: torem(14);
        margin-top: torem(8);
      }
      .num {
        color: #e03229;
      }
    }
  }
}
</style>
