<template>
  <div>
    <div v-if="selectTeacherReviewArr.length">
      <h5>选中要删除人员的列表</h5>
      <ul class="selectList">
        <li v-for="(item,index) in selectTeacherReviewArr" :key="index">
          <p class="img">
            <img
             
              v-if="item.icons && item.icons.iconID && getIconImg(item.icons.userID)"
              :src="getIconImg(item.icons.userID)"
            >
            <img
              v-else-if="item.icons && item.icons.gender==2"
              src="~@/public/asset/img/user/teacher-woman.png"
              alt
            >
            <img v-else src="~@/public/asset/img/user/teacher-man.png" alt>
          </p>
          <span>{{item.userType | userType}}--{{item.userName}}</span>
        </li>
      </ul>
    </div>
    <div
      class="mui-input-row mui-radio"
      v-for="(item,index) in members"
      :key="index"
      @click.capture="delectTeacherEvent($event)"
      :class="!(index%2)?'deep':''"
    >
      <label>
        <p id="teacherMess">
          <span class="img">
            <img
              v-if="item.icons && item.icons.iconID && getIconImg(item.icons.userID)"
              :src="getIconImg(item.icons.userID)"
            >
            <img
              v-else-if="item.icons && item.icons.gender==2"
              src="~@/public/asset/img/user/teacher-woman.png"
              alt
            >
            <img v-else src="~@/public/asset/img/user/teacher-man.png" alt>
          </span>          
          <span class="mess">{{item.userType | userType}} : {{item.userName}}({{item.userCode}})</span>
          <input name="radio1" type="checkbox" class="checkBox" :dataid="item.userID">
          <span class="checkbox"></span>
        </p>
      </label>
    </div>
  </div>
</template>
<script>
import { $deleteMemberFromDiscussionGroup } from "@/api/customer-reply/customer-reply-api";
import { ACTION_TYPES } from "@/constants";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import store from "@/store";
import * as types from "@/store/mutation-types";
export default {
  data() {
    return {
      delectTeacherList: [],
      selectTeacherReviewArr: [],
      teacherIDs: [],
      icons: [],
      params: {
        DiscussionGroupID: "",
        UserIDs: []
      }
    };
  },
  created() {
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
    this. getUserIcons();
  },
  methods: {
    delectTeacherEvent(e) {
      var dataID = e.srcElement.attributes.dataid;
      if (dataID) {
        if (e.srcElement.checked) {
          if (this.delectTeacherList.indexOf(dataID.value) == -1) {
            this.delectTeacherList.push(dataID.value);
          }
        } else {
          var currentIndex = this.delectTeacherList.indexOf(dataID.value);
          this.delectTeacherList.splice(currentIndex, 1);
        }
      }
    },
    nextType() {
      this.params.DiscussionGroupID = this.discussionGroupID;
      this.delectTeacherList.forEach(item => {
        this.params.UserIDs.push(item);
      });
      $deleteMemberFromDiscussionGroup(this.params, res => {
        mui.toast("移除成功！");
        this.$router.go(-1);
      });
    },
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserIcons() {
      this.members.forEach(item => {
        if (!item.icons || !item.icons.iconID) return;
        var userIcons = this.$store.state.headList.slice() || [];
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === item.icons.userID);
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: curIcon.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: item.icons.iconID
            },
            res => {
              let obj = {
                userID: item.icons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      });
    }
  },
  watch: {
    delectTeacherList(val) {
      xdapp.util.vue.commitActionStatus(val.length);
      this.selectTeacherReviewArr = [];
      this.teacherIDs = [];
      this.members.forEach((item, index) => {
        val.forEach(selID => {
          if (item.userID == selID) {
            this.selectTeacherReviewArr.push(item);
            this.teacherIDs.push({
              type: "1",
              userID: item.userID
            });
          }
        });
      });
    },
    teacherIDs() {
      getHeadIDsByUserIDs(this.teacherIDs, res => {
        this.members.forEach(item => {
          res.forEach(sel => {
            if (item.userID == sel.userID) {
              this.$set(item, "icons", sel);
            }
          });
        });
      });
    }
  },
  computed: {
    members() {
      var members = this.$route.query.members;
      members.forEach((item, index) => {
        if (item.userType == 4) {
          members.splice(members.indexOf(item), 1);
        }
      });
      return members;
    },
    discussionGroupID() {
      return this.$route.query.DiscussionGroupID;
    }
  }
};
</script>
<style  lang="scss" scoped>
h5 {
  padding: 10px 15px;
  font-size: torem(18);
  font-weight: bold;
}
.selectList {
  display: flex;
  flex-wrap: wrap;
  padding: torem(10);
  background-color: #fff;
  border-bottom: 1px solid #eee;
  min-height: torem(100);
  li {
    width: 33.3%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: torem(15) 0;
    p {
      width: torem(40);
      height: torem(40);
      img {
        width: 100%;
        height: 100%;
        border-radius: 100%;
      }
    }
    span {
      font-size: torem(14);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 100%;
    }
  }
}
.mui-input-row {
  display: flex;
  align-items: center;
  height: torem(70);
  line-height: torem(70);
  border-bottom: 1px solid #eee;
  label {
    padding-right: torem(15);
    #teacherMess {
      margin-bottom: 0;
      font-size: torem(16);
      display: flex;
      align-items: center;
      .img {
        display: inline-block;
        width: torem(40);
        height: torem(40);
        img {
          width: 100%;
          height: 100%;
          border-radius: 100%;
        }
      }
      .mess {
        flex: 1;
        margin-left: torem(15);
      }
    }
  }
}
.deep {
  background: #eee;
}
</style>

