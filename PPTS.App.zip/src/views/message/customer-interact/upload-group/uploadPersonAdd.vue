<template>
  <div class="wrapper-upload-add">
    <p class="search">
      <input
        type="text"
        placeholder="输入教师姓名/OA进行查询"
        v-model="inpVal"
        @focus="fnFocus"
        @blur="fnBlur"
      >
      <i class="iconfont icon-found" @click="getList()"></i>
    </p>
    <!-- 查询到的教师列表 -->
    <div class="xdapp-list" v-if="searchTearchList.length">
      <div
        class="mui-input-row mui-radio"
        v-for="(item,index) in searchTearchList"
        :key="index"
        @click.capture="AddTeacherEvent($event)"
        :class="!(index%2)?'deep':''"
      >
        <label>
          <p id="teacherMess">
            <span class="mess">{{item.jobName}} : {{item.staffName}}({{item.staffOA}})</span>
            <input name="radio1" type="checkbox" class="checkBox" :dataid="item.staffID">
            <span class="checkbox"></span>
          </p>
        </label>
      </div>
    </div>
    <!-- 所有可添加教师 -->
    <div class="xdapp-list" v-else-if="mayAddTeachList.length">
      <div
        class="mui-input-row mui-radio"
        v-for="(item,index) in mayAddTeachList"
        :key="index"
        @click.capture="AddTeacherEvent($event)"
        :class="!(index%2)?'deep':''"
      >
        <label>
          <p id="teacherMess">
            <span class="mess">{{item.jobName}} : {{item.staffName}}({{item.staffOA}})</span>
            <input name="radio1" type="checkbox" class="checkBox" :dataid="item.staffID">
            <span class="checkbox"></span>
          </p>
        </label>
      </div>
    </div>
  </div>
</template>
<script>
import {
  $queryAddDiscussionGroupStaff,
  $addMemberToDiscussionGroup
} from "@/api/customer-reply/customer-reply-api";
import { ACTION_TYPES, GroupMembersUserType } from "@/constants";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
export default {
  data() {
    return {
      toatalList: [],
      mayAddTeachList: [],
      AddtTeacherList: [],
      selectTeacherArr: [],
      searchTearchList: [],
      inpVal: "",
      params: {
        DiscussionGroupID: "",
        Members: []
      }
    };
  },
  created() {
    $queryAddDiscussionGroupStaff(this.discussionGroupID, res => {
      this.mayAddTeachList = this.toatalList = res;
    });
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
    window.addEventListener("resize", resize);
  },
  destroyed() {
    window.removeEventListener("resize", resize);
  },
  methods: {
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        //plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    getList() {
      this.mayAddTeachList = [];
      this.searchTearchList = [];
      const regTest = new RegExp(this.inpVal, "i");
      this.toatalList.forEach(item => {
        if (regTest.test(item.staffName) || regTest.test(item.staffOA)) {
          this.searchTearchList.push(item);
        }
      });
      if(!this.searchTearchList.length){
        mui.toast("没有找到相关老师!");
      }
    },
    AddTeacherEvent(e) {
      var dataID = e.srcElement.attributes.dataid;
      if (dataID) {
        if (e.srcElement.checked) {
          if (this.AddtTeacherList.indexOf(dataID.value) == -1) {
            this.AddtTeacherList.push(dataID.value);
          }
        } else {
          var currentIndex = this.AddtTeacherList.indexOf(dataID.value);
          this.AddtTeacherList.splice(currentIndex, 1);
        }
      }
    },
    selectDelectResult() {
      this.AddtTeacherList = [];
      this.mayAddTeachList.forEach(item => {
        if (item.checked) {
          this.AddtTeacherList.push(item);
        }
      });
    },
    nextType() {
      this.params.DiscussionGroupID = this.discussionGroupID;
      this.params.Members = this.selectTeacherArr;
      $addMemberToDiscussionGroup(this.params, res => {
        mui.toast("添加成功！");
        this.$router.go(-1);
      });
    }
  },
  computed: {
    discussionGroupID() {
      return this.$route.query.DiscussionGroupID;
    }
  },
  watch: {
    AddtTeacherList: {
      handler: function(val) {
        xdapp.util.vue.commitActionStatus(val.length);
        this.selectTeacherArr = [];
        this.toatalList.forEach((item, index) => {
          val.map(selID => {
            if (item.staffID == selID) {
              this.selectTeacherArr.push({
                UserID: item.staffID,
                UserType: item.userType,
                UserName: item.staffName,
                UserCode: item.staffOA
              });
            }
          });
        });
      }
    },
    inpVal(val) {
      if (!val) {
        this.searchTearchList = [];
        this.mayAddTeachList = this.toatalList;
      }
    }
  },
};
</script>
<style  lang="scss" scoped>
.wrapper-upload-add {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    background: #fff;
  }
}
.search {
  margin-top: torem(12);
  padding: 0 torem(15);
  margin-bottom: 0;
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  background: #fff;
  position: fixed;
  width: 100%;
  top: torem(65);
  left: 0;
  z-index: 10;
  input {
    border: none;
    margin-bottom: 0;
  }
  i {
    color: rgb(138, 130, 130);
    font-size: torem(24);
  }
}
.xdapp-list {
  margin-top: torem(68);
  overflow: auto;
  height: calc(100vh - 65px - 1.6rem);
}
.mui-input-row {
  height: torem(50);
  line-height: torem(50);
  border-bottom: 1px solid #eee;
  label {
    padding: torem(11) torem(29);
    #teacherMess {
      margin-bottom: 0;
      font-size: torem(16);
      display: flex;
      align-items: center;
      span.mess {
        display: inline-block;
        flex:1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
}
.deep {
  background: #eee;
}
</style>