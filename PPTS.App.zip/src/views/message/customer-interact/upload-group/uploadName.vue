<template>
  <div class="xd-upload-name">
    <h5>讨论组名称</h5>
    <p>
      <input type="text" placeholder="最多可输入15个汉字" maxlength="15" v-model="uploadName" @focus="fnFocus" @blur="fnBlur">
    </p>
  </div>
</template>
<script>
import { ACTION_TYPES } from "@/constants";
import { $editDiscussionGroupName } from "@/api/customer-reply/customer-reply-api";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
export default {
  data() {
    return {
      uploadName: "",
      params: {
        DiscussionGroupID: "",
        NewDiscussionGroupName: ""
      }
    };
  },
  methods: {
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        //plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    nextType() {
      this.params.DiscussionGroupID = this.discussionGroupID;
      this.params.NewDiscussionGroupName = this.uploadName;
      $editDiscussionGroupName(this.params, res => {
        mui.toast("修改成功!");
        this.$nextTick(() => {
          this.$router.push({
            name: "message-group-mess",
            query: {
              title: this.uploadName,
              groupID: this.discussionGroupID
            }
          });
        });
      });
    }
  },
  computed: {
    discussionGroupID() {
      return this.$route.query.DiscussionGroupID;
    },
    // discussionName(){
    //   return this.$route.query.DiscussionName;
    // }
  },
  watch: {
    uploadName: {
      handler: function(val) {
        xdapp.util.vue.commitActionStatus(val);
      }
    }
  },
  created() {
    xdapp.util.vue.on(ACTION_TYPES.NEXT_TYPE, this.nextType);
    window.addEventListener("resize", resize);
  },
  destroyed() {
    window.removeEventListener("resize", resize);
  },
};
</script>
<style lang="scss" scoped>
.xd-upload-name {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    background: #fff;
  }
}
.xd-upload-name {
  position: fixed;
  top: 0;
  bottom: 0;
  background-color: #eee;
  width: 100%;
  height: 100%;
  h5 {
    padding: torem(15);
    font-size: torem(14);
    font-weight: bold;
  }
  p {
    input {
      border: none;
    }
  }
}
</style>
