<template>
  <div class="wrap">
    <reply-list :customerReply="customerReply" :unload="unload" @todoDelChat="getCustomerReply()"></reply-list>
  </div>
</template>

<script>
import { ACTION_TYPES, CACHE_KEYS, JobType, ReplyType } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import {
  $getLastReply,
  $getCustomerReply,
  $getEducatorCustomerReply
} from "@/api/customer-reply/customer-reply-api";
import ReplyList from "./partials/reply-list/index";

export default {
  data() {
    return {
      customerReply: {},
      unload:true,
    };
  },
  created() {
    loadUserInfo();
    if (m2.cache.get(CACHE_KEYS.CURRENT_JOB).jobType == JobType.MngTeacherJob) {
      this.getEducatorCustomerReply();
    } else {
      $getCustomerReply(res => {
        
        if(res&&res.length&&res[0].lastInfo){
          res[0].lastInfo.replyContent.includes('[###voice###]')&&(res[0].lastInfo.replyContent='[语音消息]')
          res[0].lastInfo.replyContent.includes('[###img###]')&&(res[0].lastInfo.replyContent='[图片]')
        }
        this.customerReply = res;
        this.unload = false;
      });
    }
    this.switchJob();
  },
  methods: {
    getEducatorCustomerReply() {
      $getEducatorCustomerReply(res => {
        
        if(res.educator && res.educator.lastInfo){
          res.educator.lastInfo.replyContent.includes('[###voice###]')&&(res.educator.lastInfo.replyContent='[语音消息]')
          res.educator.lastInfo.replyContent.includes('[###img###]')&&(res.educator.lastInfo.replyContent='[图片]')
        }
        if(res.educatorWeek && res.educatorWeek.lastInfo){
          res.educatorWeek.lastInfo.replyContent.includes('[###voice###]')&&(res.educatorWeek.lastInfo.replyContent='[语音消息]')
          res.educatorWeek.lastInfo.replyContent.includes('[###img###]')&&(res.educatorWeek.lastInfo.replyContent='[图片]')
        }
        this.customerReply = res;
        this.unload = false;
      });
    },
    switchJob() {
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getCustomerReply);
    }
  },
  components: {
    ReplyList
  }
};
</script>