<template>
	<div class="xdapp-message-container " ref="messageContainer">
		<lesson-notify-item :items="systemNotifyItems"  :isDelect="false" v-if="systemNotifyItems.length"></lesson-notify-item>
		<tip v-if="!systemNotifyItems.length">
			<span>暂无系统消息</span>
		</tip>
	</div>
</template>

<script>
	import { ACTION_TYPES, NotifyCatalog, PreOrLast } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api';
	import { $getNotifyList } from '@/api/notify/notify-api';
	import LessonNotifyItem from '../partials/lesson-notify-item';
	import Tip from '@/components/tip';

	export default {
		data() {
			return {
				systemNotifyItems: []
			};
		},
		created() {
			this.getSystemNotifyList();
			this.switchChild();
		},
		mounted() {
			this.scrollToBottom();
		},
		updated: function() {
			this.scrollToBottom();
		},
		methods: {
			async getSystemNotifyList() {
				await loadUserInfo();

				let params = {
					msgCatalog: NotifyCatalog.SystemNotify,
					timePoint: m2.date.now(),
					preOrLast: PreOrLast.Pre
				};

				$getNotifyList(params, (res) => {
					this.systemNotifyItems = this.systemNotifyItems.concat(res.reverse());
				});
			},
			switchChild() {
				xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getSystemNotifyList);
			},
			scrollToBottom: function() {
				this.$nextTick(() => {
					var container = this.$refs.messageContainer;
					container.scrollTop = container.scrollHeight;
					console.log('scrollTop=', container.scrollTop, 'scrollHeight=', container.scrollHeight);
				});
			}
		},
		components: {
			LessonNotifyItem,
			Tip
		}
	}
</script>
<style>
.xdapp-message-container .rx-html-my img{ 
    width: calc(6.5rem + 70px)!important;
    margin-left: -70px;
  }
</style>
<style lang="scss" scoped>
	.xdapp-message-container {
		background-color: #eee;
		position: fixed;
		width: 100%;
		height: 100%;
	}
</style>