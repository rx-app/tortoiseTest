﻿<template>
	<!-- :pulldown="pulldown"-->
	<scroll :data="items" :listen-scroll="listenScroll" :probe-type="probeType" @scroll="scroll" @scrollToStart="refreshMore" class="scroll-container" ref="listview">
		<div class="list-group " @click.capture="addTypeAll()">
			<ul class="msg-list ">
				<li class="list-group-item" v-for="(item,index) in items" ref="groupItem" v-if="!item.delect">
					<div class="msg-time msg-title-base">
						<span>{{item.createTime | dateTimeFormat}}</span>
					</div>
					<div class="msg-wrapper">
						<div v-if="isDelect">
							<div class="triangle" v-if='item.current'></div>
							<div class='delect' v-if='item.current' @click="delectList(item.msgID)">
								<p>删除</p>
							</div>
						</div>
						
						<div @click.stop='addType(index)'>
							<div class="msg-title">
								<img v-if="item.msgCatalog==2" src="~@/public/asset/img/msg/04@3x.png" class="img">
								<img v-if="item.msgCatalog==99" src="~@/public/asset/img/msg/03@3x.png" class="img">
								<span class="messTitle">{{item.msgCatalogValue}}</span>
							</div>
							<div class="msg-content">
								<div class="msg-title-left category-wrapper">
									<span class="cg-title msg-title-base">消息类型</span>
									<span class="cg">{{item.msgCategoryValue}}</span>
								</div>
								<div class="msg-title-left title-wrapper" v-if="item.title">
									<span class="tt-title msg-title-base">消息标题</span>
									<span class="tt">{{item.title}}</span>
								</div>
								<div class="content-wrapper xdsef-feser">
									<span class="ct-title msg-title-base">消息内容</span>
									<!-- <span class="ct rx-html-my" v-html="item.content.replace(/&[lg]t;.{0,5}&[lg]t;/g,'')"></span> -->
									<span class="ct rx-html-my" v-html="editContent(item.content)"></span>
								</div>
							</div>
						</div>

					</div>
				</li>
			</ul>
		</div>
	</scroll>
</template>

<script>
	import Scroll from '@/components/scroll/index';
	import Loading from '@/components/loading/index';
	import { $deletedNotifyMessage } from '@/api/notify/notify-api';
	import '@/public/asset/js/jquery/jquery-1.8.0';
	export default {
		props: {
			items: {
				type: Array,
				default: null
			},
			isDelect:{
                type: Boolean,
				default: false
			}
		},
		data() {
			return {
				MsgID: '',
				firstFetch: true
			}
		},
		mounted(){
			$('.xdsef-feser').on('click','a',(e)=>{
				// plus.runtime.openURL(e.target.);
				// plus.runtime.openURL(e.target.attributes.href.nodeValue)
				if(e.currentTarget.href.includes('.xueda.com/')&&e.currentTarget.href.includes('/profile/settings/edition')){
				$vue.$router.push({name: 'profile-settings-about-list'})
				}else{
				plus.runtime.openURL(e.currentTarget.href)
				}
				// console.log(e.currentTarget.href)
				// console.log(e.target.attributes.href.nodeValue)
				return false
				
			})
	  	},
		created() {
			this.probeType = 3;
			this.listenScroll = true;
			if(this.firstFetch) {
				//this._scrollToBottom();
				this.firstFetch = false;
			}
			//this.pulldown = true;
		},
		methods: {
			editContent(content){
				if((/<img/).test(content.substr(0,7))){
					return '<br />'+content
				}else{
					return content
				}
			},
			delectList(msgID) {
				mui.confirm("确定要删除该条消息么？", "提示", (e) => {
					if(e.index) {
						$deletedNotifyMessage({
							MsgID: msgID
						}, res => {
							for(var i = 0; i < this.items.length; i++) {
								if(this.items[i].msgID == msgID) {
									let obj = this.items[i];
									obj.delect = true;
									this.$set(this.items, i, obj);
								}
							}
							mui.toast("删除成功!")
						});
					}
				})
			},
			addTypeAll() {
				if(!this.isDelect) return;
				for(var i = 0; i < this.items.length; i++) {
					let obj = this.items[i];
					obj.current = false;
					this.$set(this.items, i, obj);
				}
			},
			addType(status) {
				if(!this.isDelect) return;
				for(var i = 0; i < this.items.length; i++) {
					if(i !== status) {
						this.items[i].current = false;
					}
					if(i == status) {
						let obj = this.items[i];
						obj.current = !obj.current;
						this.$set(this.items, i, obj);
					}

				}
			},
			/*_scrollToBottom() {
				this.$nextTick(() => {
					setTimeout(() => {
						let groupItems = this.$refs.groupItem || 0;
						let el = groupItems[groupItems.length - 1];
						this.$refs.listview.scrollToElement(el, 200);
					}, 20);
				});
			},*/
			searchMore() {
				console.log('searchMore');
			},
			refreshMore() {
				this.$emit('refreshMore');
			},
			scroll(pos) {
				this.scrollY = pos.y
			}
		},
		components: {
			Scroll,
			Loading
		}
	}
</script>
<style lang="scss">
	.rx-html-my h2 {
		font-size: torem(16);
	}
	.rx-html-my a{
				word-wrap:break-word!important;
			}
</style>

<style lang="scss" scoped>
	$fontColor: #999;
	.scroll-container {
		
		.rx-html-my{
			width: 6rem;
			word-wrap:break-word!important;
		}
		height: 100%;
		.msg-title-base {
			color: $fontColor;
			flex: 0 0 torem(70);
		}
		.msg-title-left {
			display: flex;
			height: torem(30);
			line-height: torem(30);
		}
		.msg-list {
			.list-group-item {
				padding-bottom: torem(10);
				.msg-time {
					margin-top: torem(10);
					margin-bottom: torem(5);
					text-align: center;
					color: $fontColor;
				}
				.msg-wrapper {
					margin: 0 torem(20);
					background-color: #fff;
					border-radius: torem(5);
					position: relative;
					.delect {
						position: absolute;
						top: torem(-38);
						right: 0;
						background: #fff;
						width: torem(50);
						text-align: center;
						height: torem(30);
						line-height: torem(30);
					}
					.triangle {
						width: 0px;
						height: 0px;
						border-width: 8px;
						border-style: solid;
						border-color: #fff transparent transparent transparent;
						position: absolute;
						top: torem(-9);
						right: torem(28);
					}
					.msg-title {
						display: flex;
						align-items: center;
						padding: torem(10);
						border-bottom: torem(1) inset;
						.messTitle{
							font-size: torem(16);
							font-weight: bold;
						}
						.img {
							width: torem(30);
							height: torem(30);
							margin-right: torem(5);
							border-radius: torem(30);
						}
					}
					.msg-content {
						padding: torem(10);
						font-size: torem(14);
						.category-wrapper {
							.cg-title {}
						}
						.title-wrapper {}
						.content-wrapper {
							display: flex;
							.ct-title {}
						}
					}
				}
				&:last-child {
					padding-bottom: torem(30);
				}
			}
		}
	}
</style>