﻿<template>
	<div class="error-box">
		<img src="~@/public/asset/img/icon_no_network.png" alt="">
		<a @click="goHome">点击重新加载</a>
	</div>
</template>
<script>
export default {
	methods: {
		goHome () {
			this.$router.push({
				name: 'home'
			})
		}
	}
}
</script>

<style>
	.error-box {
		text-align: center;
	}
	.error-box img{
		width: 75%;
		display: block;
		margin: 25% auto 10px;
	}
	.error-box  a{
		border: 1px solid #ccc;
		border-radius: 5px;
		display: block;
		width: 100px;
		height: 35px;
		line-height: 35px;
		color: #000;
		padding: 0 8px;
		margin: 0 auto;
		/* backround:  */
	}
</style>

