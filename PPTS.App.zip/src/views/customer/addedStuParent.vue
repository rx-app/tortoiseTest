<template>
<div style="background:#eee;">
  <span class="top-btn-save" v-show="selectParent.parentName" @click="save">保存</span>
  <span class="top-btn-save disabled"    v-show="!selectParent.parentName" >保存</span>


  <div class="selAlreadyParent">
    		
    <div class="search-head">
      <div v-show="showcr" @click.prevent.stop="selectItem('customerRole')" class="cell">
        <div class="rel-title">
          亲属关系
        </div>
        <div class="rel-con">
          <div v-if="customer.gender==2" class="rel-box"><span class="cname"> {{cname}}</span>是<span class="pname"> {{selectParent.parentName}}</span>的<span class="rname">{{getCr(cr,1) }}</span><span class="ar">></span></div>
          <div v-else-if="customer.gender==1" class="rel-box"> <span class="cname">{{cname}}</span>是<span class="pname"> {{selectParent.parentName}}</span>的<span class="rname">{{getCr(cr,2) }}</span><span class="ar">></span></div>
          <div v-else class="rel-box"><span class="cname">{{selectParent.parentName}}</span>是<span class="pname"> {{cname}}</span>的<span class="ar">></span></div>
          <div v-show="showParentRelation" @click.prevent.stop="selectItem('parentRole')" >
            <div v-if="selectParent.gender==2" class="rel-box"><span class="pname"> {{selectParent.parentName}}</span>是<span class="cname"> {{cname}}</span>的<span class="rname">{{ getPr(pr,1) }}</span><span class="ar">></span></div>
            <div v-else-if="selectParent.gender==1" class="rel-box"> <span class="pname">{{selectParent.parentName}}</span>是<span class="cname"> {{cname}}</span>的<span class="rname">{{ getPr(pr,2)}}</span><span class="ar">></span></div>
            <div v-else class="rel-box"><span class="pname">{{selectParent.parentName}}</span>是<span class="cname"> {{cname}}</span>的</div>
          </div>
        </div>
        
      </div>
      
            <input type="text"   @focus="fnFocus" @blur="fnBlur"  placeholder="输入家长已有孩子姓名" v-model="partials.customerName">
      <input   @focus="fnFocus" @blur="fnBlur"  type="text" placeholder="输入家长姓名" v-model="partials.parentName">
      <input   @focus="fnFocus" @blur="fnBlur"  type="text" placeholder="输入家长主要联系方式" v-model="partials.phoneNumber">
      <button class="search" @click="getSearchList()">查询</button>
    </div>
    <div
      id="stu-main-content"
      class="main-content"
      :style="{'-webkit-overflow-scrolling': scrollMode}"
    >
      <mt-loadmore
        class="loadMore"
        :bottom-all-loaded="allLoaded"
        :auto-fill="false"
        :bottom-method="loadBottom"
        :bottom-distance="-70"
        ref="loadmore"
      >
        <div class="wrap" id="stu-main-content" v-if="searchList.length">
          <li class="bg">
            <span>姓名</span>
            <span>性别</span>
            <span>联系方式</span>
          </li>
          <li class="mui-input-row mui-radio" v-for="(item,index) in searchList" :key="index">
            <label for="radio">
              <span>{{item.parentName}}</span>
              <span>{{item.gender | gender}}</span>
              <span>{{item.phoneNumber}}</span>
            </label>
            <input name="radio"  id="input" type="radio" @click="selParentFun(item)">
            <!-- <mt-radio align="right" @click.native="selParentFun(item)" :options="[{label:' ',value:' '}]"></mt-radio> -->
          </li>
        </div>
      </mt-loadmore>
      <tip v-if="!searchList.length && isShow">没有查询到任何记录，请重新设置条件查询!</tip>
    </div>
    <select-items
        v-show="itemsParams.isShow"
        :title="itemsParams.title"
        :model="itemsParams.model"
        :isShow="itemsParams.isShow"
        :center="itemsParams.center"
        :category="itemsParams.category"
        :items="itemsParams.selectItems"
        @selectItem="selectVisitType"
      ></select-items>
  </div>
  </div>
</template>
<script>
import { ACTION_TYPES } from "@/constants";
import { pager, orderBy } from "@/public/constant";
import Tip from "@/components/tip";
import 
{ getStudentInfo as getCustomerInfo ,
  getAllParents,
  addStudentParent as addCustomerParent } 
from "@/api/customer/customer-api";
import SelectItems from "@/components/select-items/index";
import { spr, psr } from "@/constants";
import { Checklist  as mtChecklist } from 'mint-ui';



function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
function resize2() {
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}

export default {
  data() {
    return {
      v:'',
      showParentRelation:false,
      itemsParams: {
        isShow: false,
        title: "",
        model: "",
        center:false,
        category: "",
        selectItems: []
      },
      allLoaded: false,
      scrollMode: "auto",
      isShow: false,
      partials: {
        customerName: "",
        parentName: "",
        phoneNumber: "",
        ...pager({
          pageIndex: 1,
          pageSize: 10
        }),
        ...orderBy({
          dataField: "CreateTime",
          sortDirection: 1
        })
      },
      parentSex:'',
      customer:{},
      customerRole:'',
      selectParent: {},
      searchList: [],
      showcr:false,
      pr:'',
      cr:'',
    };
  },
  created() {
    this.registerSubmit();
    this.getCustomerInfo();
    document.body.style.overflow='hidden'
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
    document.querySelector('.xd-header').style.position='fixed'
  },
  destroyed() {
      window.removeEventListener("resize", resize);
      if (/Android/gi.test(navigator.userAgent)) {
        window.removeEventListener("resize", resize2);
      }
      // document.body.style.overflow = "scroll";
      // document.querySelector("html").style.overflow = "scroll";
    document.body.style.overflow=''
  },
  mounted() {
    this.setHeight();
  },
  computed:{
    cname(){
      return this.$route.query.cname
    }
  },
  methods: {
    save(){
      addCustomerParent({
        customer:this.customer,
        parent:{
          gender:this.selectParent.gender,
          parentID:this.selectParent.parentID,
          parentName:this.selectParent.parentName,
        },
        customerRole:this.cr,
        parentRole:this.pr,
      },res=>{
        // this.$router.back();
        window.history.back();
      })
    },
    getCustomerInfo(){
      let id = this.$route.query.id;
      
      getCustomerInfo({id}, res => {
        this.customer=res.customer;
        this.sex=this.customer.gender;
        console.log('customer',res)
      });
    },
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "765px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
        //mui.alert('---tttt----')
        //mui('header')[0].style.transform='translateY(-10px)'
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    getPr(cr,i){

      if(cr=='25') return '伯父';
      switch(i){
        case 1: return this.$options.filters.parentFemale(cr)?this.$options.filters.parentFemale(cr):'请选择';break;
        case 2: return this.$options.filters.parentMale(cr)?this.$options.filters.parentMale(cr):'请选择';break;
      }
      
    },
    getCr(cr,i){
      
      switch(i){
        case 1: return this.$options.filters.childFemale(cr)?this.$options.filters.childFemale(cr):'请选择';break;
        case 2: return this.$options.filters.childMale(cr)?this.$options.filters.childMale(cr):'请选择';break;
      }
      
    },
    getSearchList() {
      if (
        !this.partials.customerName ||
        !this.partials.parentName ||
        !this.partials.phoneNumber
      ) {
        mui.alert("学员姓名、家长姓名、家长联系方式必须全都输入！");
        return;
      }
      this.getAllParentsFun();
    },
    getAllParentsFun() {
      
      getAllParents(this.partials, res => {
        let pageIndex = res.queryResult.pageIndex;
        let pageSize = res.queryResult.pageSize;
        let totalCount = res.queryResult.totalCount;
        let pagedData = res.queryResult.pagedData;
        pagedData.length ? (this.isShow = false) : (this.isShow = true);
        pageIndex * pageSize >= totalCount
          ? (this.allLoaded = true)
          : (this.allLoaded = false);
        this.searchList = pagedData;//[...this.searchList, ...pagedData];
        document.querySelector('#input').checked=false;
        
        this.cr='';
        this.pr='';
        this.showcr = false;
        this.showParentRelation = false;
      });
    },
    loadBottom() {
      this.partials.pageParams.pageIndex++;
      this.getAllParentsFun();
      this.$refs.loadmore.onBottomLoaded();
    },
    selParentFun(item) {
      this.selectParent = item;
      this.showcr = true;
      if(this.parentSex!=''&&this.parentSex!=item.gender){
        // this.editingModel.gender = obj.item.key;
            try {
              let list4 = spr.filter(v=>v.key==this.cr && v.ss == this.customer.gender)
              let r2=(list4[0].r.filter(v=>v.ps==item.gender))[0].key
              this.pr = r2;
              this.showParentRelation=true
            } catch (error) {
              this.showParentRelation=false
            }
      }
      this.parentSex= item.gender;
      console.log(item)
    },
    registerSubmit() {
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    submit() {
      this.$router.push({
        name: "addGuest",
        query: this.selectParent
      });
    },
    setHeight() {
      let content = document.querySelector("#stu-main-content");
      if (content !== null && typeof content !== "undefined") {
        let windowHeight = window.innerHeight;
        content.style.height = "calc(" + windowHeight + "px - 63px - 5.52rem)";
      }
    },
    selectItem(category) {
      this.itemsParams.isShow = true;
      this.itemsParams.center = false;
      this.itemsParams.category = category;
      switch (category) {
        case "parentRole":
          if(this.sex==1||this.sex==2){
            this.itemsParams.title = "亲属关系";
            this.itemsParams.model = this.pr;
            this.itemsParams.selectItems = this._getSelectItems(category);
          }else{
            mui.alert('请先补充完整学员性别');
            this.itemsParams.isShow = false;
          }
          break;
        case "customerRole":
          if(this.sex==1||this.sex==2){
            this.itemsParams.title = "亲属关系";
            this.itemsParams.model = this.cr;
            this.itemsParams.selectItems = this._getSelectItems(category);
          }else{
            mui.alert('请先补充完整学员性别');
            this.itemsParams.isShow = false;
          }
				  break;
      }
    },
		_getSelectItems(category) {
      let res = [];
      
      let parentGender = this.selectParent.gender;
      let customerGender = this.customer.gender;
      switch (category) {
        case "customerRole":
          let list= spr.filter((v,i)=>{
            return v.ss ==customerGender
          })
          res = list
          break;
        case "parentRole":
          let list2= spr.filter((v,i)=>{
            return v.key==this.cr && v.ss ==this.customer.gender
          })
          try {
              res = list2[0].r.filter((v)=>{
              return v.ps==parentGender
              this.showParentRelation=true
            })
          } catch (error) {
            this.showParentRelation=false
          }
          break;
        default:
          break;
      }
      return res;
    },
		selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "customerRole":
            this.cr = obj.item.key;
            try {
              let list3 = spr.filter(v=>v.key==this.cr && v.ss == this.customer.gender)
              // let r = (list3[0].r.filter(v=>v.ps==this.customer.gender))[0].key
              let r = (list3[0].r.filter(v=>v.ps==this.selectParent.gender))[0].key
              this.pr = r;
              this.showParentRelation=true
            } catch (error) {
              this.showParentRelation=false
            }
            break;
          case "parentRole":
            this.pr = obj.item.key;
            this.itemsParams.model = this.cr;
            break;
        }
      }
    },
  },
  watch: {
    selectParent(obj) {
      if (obj !== null) {
        xdapp.util.vue.commitActionStatus(true);
      }
    }
  },
  components: {
    Tip,
    SelectItems,
  }
};
</script>
<style lang="scss">
html,body{
	height: 100%;
	overflow: hidden;
}
.selAlreadyParent {
  
  // position: absolute;
  // width: 100%;
  // left: 0;
  // right: 0;
  // top:torem(65);
  // bottom: 0;
  // overflow-y: scroll;
  // z-index: 1;
  // -webkit-overflow-scrolling: touch; /* 解决ios滑动不流畅问题 */

  a.mint-cell{
    background: #eee;
    transform: translateY(-4px);
  }
}
</style>

<style lang="scss" scoped>
.disabled{    color: #e0e0e0!important}
.edit{
	color: #aaa;
}
  .top-btn-save{
    position: fixed;
    font-size: torem(15);
    top: 30px;
    right: 20px;
    color: #fff;
    z-index: 100;
  }
.selAlreadyParent {
  background: #eee;
  .search-head {
    .cell{
      margin: 5px 10%;
    }
    .rel-title{
      padding: 10px 0;
      font-size: torem(16)
    }
    .rel-con{
      padding: 0 0 8px;
      border-radius: 5px;
      background: #fff;
      .ar{
        float: right;
        padding-right: 8px;
      }
    }
    .rel-box{
      // margin-left: 10%;
      display: flex;
      background: #fff;
      border-radius: 6px;
      padding: 10px 5px;
      font-size: torem(16);
      border-bottom: 1px solid #ddd;
      .cname{
        color:rgb(60, 41, 223);
        display: inline-block;
        min-width: 10vw;
        flex:5;
        text-align: center;
      }
      .pname{
        color:#f17b43;;
        display: inline-block;
        min-width: 10vw;
        flex:5;
        text-align: center;
      }
      .rname{
        flex: 5;
        text-align: center;
        // min-width: 15vw
      }
    }
    input,
    .search {
      width: 80%;
      height: 100%;
      padding: torem(5) torem(10);
      border-radius: 10px;
      margin: torem(10) 0;
      margin-left: 10%;
    }
    .search {
      background: #428bca;
      border-color: #428bca;
      color: #fff;
      font-size: torem(16);
    }
    input::-webkit-input-placeholder {
      font-size: torem(12);
    }
    .cell {
      // display: flex;
      // font-size: torem(16);
      // line-height: torem(32);
      // margin: torem(5) torem(8);
      // border-bottom: torem(1) solid #ddd;
    }
    .cell-1 {
        span {
          color: red;
          font-size: torem(20);
        }
        flex: 4;
        text-align: right;
        padding-right: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(16);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
  }
  .wrap {
    li {
      width: 90%;
      margin-left: 5%;
      height: 40px;
      line-height: 40px;
      font-size: torem(16);
      display: flex;
      align-items: center;
      label {
        flex: 1;
      }
    }
    .bg {
      background: #eee;
    }
    span {
      width: 28%;
      text-align: center;
      display: inline-block;
    }
    input {
      width: 6%;
      text-align: center;
      font-size: torem(20);
      width: torem(18);
      height: torem(18);
    }
  }
  #stu-main-content {
    overflow: auto;
  }

}
</style>
