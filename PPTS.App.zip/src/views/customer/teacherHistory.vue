<template>
  <div class="history">
    <div class="his-tit">归属{{tName}}</div>
    <div class="his-content">
      <div  v-for="(item,index) in list"  :key="index+1"  class="cell">
        <div v-if="type!=3" class="cell-1">{{getVersionTime(item.versionStartTime)}} - {{getVersionTime(item.versionEndTime)}}</div>
        <div v-else class="cell-1">{{getVersionTime(item.versionStartTime)}}</div>
        <div class="cell-box">
          <div class="cell-2">{{item.staffJobOrgName}}</div>
          <div class="cell-3">{{item.staffName}}</div>
        </div>
        
      </div>
    </div>
  </div>
</template>
<script>
import {
	getTeacherRelations,
	getStaffRelations,
} from "@/api/customer/customer-api";

export default {
  data() {
    return {
      list:[{}],
      tName:'',
    };
  },
  mounted(){
    this.$nextTick(() => {
      this.tName=this.getTypeName();
    });
    
  },
  methods:{
	  init(){
		  if(this.type!=3){
			  getStaffRelations({id:this.id,relationType:this.type,pageParams:{pageSize:0,pageIndex:0,}},res=>{
          console.log(res)
          this.list=res.queryResult.pagedData
			  })
		  }else{
        getTeacherRelations({id:this.id,relationType:this.type,pageParams:{pageSize:0,pageIndex:0,}},res=>{
          console.log(res)
          this.list=res.queryResult.pagedData
			  })
      }
    },
    getVersionTime(t){
      if(!t) return
      t = this.$options.filters.dateFormat(t);
      if(t=='9999-09-09'){
        t='至今'
      }else{
        t= t.replace(/[-]/g,'.')
      }
      return t;
    },
    getTypeName(){
      let n = this.$route.query.type.toString();//刷新后悔变成字符串的1，不刷新是int的1
      switch(n){
        case '1':return '咨询师';
        case '2':return '学管师';
        case '3':return '教师';
        case '4':return '坐席';
        case '5':return '市场专员';
        case '100':return '校长';
        default :return '';
      }
    },
  },
  created(){
	  this.init();
  },
  computed:{
	  type(){
		  return this.$route.query.type;
    },
    
	  id(){
		  return this.$route.query.id;
	  }
  },
  components: {}
};
</script>


<style lang='scss' scoped>
.history {
  background: #eee;
  font-size: 0;
  height: 100vh; //calc(100vh - 65px);
  overflow: hidden;
  .his-tit {
    font-size: torem(16);
    margin: 15px torem(8);
  }
  .his-content {
    height: 100%;
    background: #fff;
    overflow: scroll;
    padding-bottom: 150px;
	  margin: 0 torem(8);
    .cell {
      border-radius: 5px;

      // display: flex;
      font-size: torem(16);
      line-height: torem(32);
     
      padding: torem(5) 0;
      // border-bottom: torem(0.5) solid #ddd;
      .cell-1 {
        flex: 6;
        text-align: left;
		    text-indent: 10px;
      }
      .cell-box{
        display: flex;
        margin: 0 10px;
        border-bottom: 1px solid #ddd;
      }
      .cell-2 {

        flex: 4;
        text-align: left;
      }
      .cell-3 {
        flex: 2;
        text-align: left;
      }
    }
  }
}
</style>
