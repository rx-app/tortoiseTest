<template>
  <div class="student-info">
    <!-- <mt-navbar class="student-info-nav" v-model="navIndex" v-power="['睿学-学员信息-不带电话']">
			<mt-tab-item id="1" @click="this.curIndex=index" v-for="(item,index) in navList" :key="index" class="nav-item" :class="{on:curIndex==index}">{{item}}</mt-tab-item>
    </mt-navbar>-->
    <mt-navbar class="student-info-nav" v-model="selected">
      <mt-tab-item id="1">基本信息</mt-tab-item>
      <mt-tab-item id="2">家长信息</mt-tab-item>
      <mt-tab-item id="3">跟进记录</mt-tab-item>
    </mt-navbar>

    <div class="info-edit-des">注意：★为必填项，▲为充值所需项，■为关键信息，签约后只允许分审核经理修改。</div>

    <!-- tab-container -->
    <mt-tab-container v-model="selected">
      <mt-tab-container-item id="1">
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span>★▲■</span>学员姓名
            </div>
            <div class="cell-2">
              <input type="text" value="张瑜幂">
            </div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲</span>学员编号
            </div>
            <div class="cell-2">NS190222000001</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲</span>学员性别
            </div>
            <div class="cell-2">
              <mt-radio align="right" v-model="sex" :options="[{label:'男',value:'1'},{label:'女',value:'2'}]"></mt-radio>
            </div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲</span>出生日期
            </div>
            <div class="cell-2">2019-01-30 <span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">证件类型</div>
            <div class="cell-2">身份证<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">输入编号</div>
            <div class="cell-2">123492948852</div>
          </div>
					<div class="cell">
            <div class="cell-1">联系方式</div>
            <div class="cell-2">123492948852</div>
          </div>
        </div>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span>■</span>入学大年级
            </div>
            <div class="cell-2">小学五年级<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲■</span>当前年级
            </div>
            <div class="cell-2">小学五年级<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲</span>在读学校
            </div>
            <div class="cell-2">第五中学<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">学年制</div>
            <div class="cell-2">五年制<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">文理科</div>
            <div class="cell-2">
              <mt-radio align="right" v-model="subject" :options="[{label:'文',value:'1'},{label:'理',value:'2'},{label:'不分',value:'3'}]"></mt-radio>
						</div>
          </div>
          <div class="cell">
            <div class="cell-1">是否复读</div>
            <div class="cell-2">
              <mt-radio align="right" v-model="restudy" :options="[{label:'是',value:'1'},{label:'否',value:'2'}]"></mt-radio>
						</div>
          </div>
        </div>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span>★</span>客户资源所在地
            </div>
            <div class="cell-2">安徽-南七</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>★</span>接触方式
            </div>
            <div class="cell-2">呼出</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>★</span>信息来源
            </div>
            <div class="cell-2">转介绍</div>
          </div>
          <div class="cell">
            <div class="cell-1">转介绍员工</div>
            <div class="cell-2">韩玉敏（教育咨询师-hanym）</div>
          </div>
          <div class="cell">
            <div class="cell-1">转介绍学员</div>
            <div class="cell-2">陈禹蒙（NS190222000001）</div>
          </div>
          <div class="cell">
            <div class="cell-1">辅导意愿</div>
            <div class="cell-2">线下和线上</div>
          </div>
          <div class="cell">
            <div class="cell-1">主监护人</div>
            <div class="cell-2">张长乐</div>
          </div>
          <div class="cell">
            <div class="cell-1">VIP客户</div>
            <div class="cell-2">非VIP客户<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-1">VIP客户</div>
            <div class="cell-2"><span class="ar">></span></div>
          </div>
        </div>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">初始签约人</div>
            <div class="cell-2">梁爽</div>
          </div>
          <div class="cell">
            <div class="cell-1">归属坐席</div>
            <div class="cell-2">陈禹</div>
          </div>
          <div class="cell">
            <div class="cell-1">归属咨询师</div>
            <div class="cell-2">靳乐</div>
          </div>
          <div class="cell">
            <div class="cell-1">归属学管师</div>
            <div class="cell-2">陈禹</div>
          </div>
          <div class="cell">
            <div class="cell-1">归属教师</div>
            <div class="cell-2">靳乐</div>
          </div>
          <div class="cell">
            <div class="cell-1">归属市场专员</div>
            <div class="cell-2">靳乐</div>
          </div>
          <div class="cell">
            <div class="cell-1">建档部门</div>
            <div class="cell-2">咨询管理部</div>
          </div>
          <div class="cell">
            <div class="cell-1">建档人</div>
            <div class="cell-2">靳乐</div>
          </div>
          <div class="cell">
            <div class="cell-1">当前状态</div>
            <div class="cell-2">正常</div>
          </div>
        </div>
      </mt-tab-container-item>
      <mt-tab-container-item id="2">
        <ul class="parent-tabs">
          <li>张长乐（主）</li>
          <li>汪玉霞</li>
          <li>陈康年</li>
          <li>+</li>
        </ul>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span>★▲■</span>家长姓名
            </div>
            <div class="cell-2"><input type="text"  value="张长乐"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家长性别</div>
            <div class="cell-2"><mt-radio align="right" v-model="restudy" :options="[{label:'男',value:'1'},{label:'女',value:'2'}]"></mt-radio></div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲</span>亲属关系
            </div>
            <div class="cell-2">母女</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲★</span>主要联系方式
            </div>
            <div class="cell-2"><input type="text" value="13320493234"></div>
          </div>
          <div class="cell">
            <div class="cell-1">辅助联系方式</div>
            <div class="cell-2"><input type="text" value="13245677654"></div>
          </div>
          <div class="cell">
            <div class="cell-1">是否主监护人</div>
            <div class="cell-2">
							<mt-radio align="right" v-model="restudy" :options="[{label:'是',value:'1'},{label:'否',value:'2'}]"></mt-radio>
						</div>
          </div>
        </div>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">现住址</div>
            <div class="cell-2">湖南省长沙市-芙蓉区<span class="ar">></span></div>
          </div>
					<div class="cell">
            <div class="cell-1">详细地址</div>
            <div class="cell-2"><input type="text" value="东大街45号"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家长Email</div>
            <div class="cell-2">24893584894@qq.com</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>■</span>证件类型
            </div>
            <div class="cell-2">
							身份证<span class="ar">></span>
						</div>
          </div>
					<div class="cell">
            <div class="cell-1">输入编号</div>
            <div class="cell-2"><input type="text" value="123456789"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家庭年总收入</div>
            <div class="cell-2">30万以上<span class="ar">></span></div>
          </div>
        </div>
      </mt-tab-container-item>
      <mt-tab-container-item id="3"></mt-tab-container-item>
    </mt-tab-container>
  </div>
</template>
<script>
import {
  cell as mtCell,
  Navbar as mtNavbar,
  TabItem as mtTabItem,
  radio as mtRadio,
  Loadmore as mtLoadmore
} from "mint-ui";
export default {
  data() {
    return {
      selected: "1",
			navIndex: null,
			sex:null,
			curIndex: 0,
			subject:null,
			restudy:null,
      navList: ["基本信息", "家长信息", "跟进记录"]
    };
  },
  components: {}
};
</script>
<style lang="scss">
.student-info {
	.ar{float: right;}

	.mint-radiolist{display: flex}
	.mint-radiolist *{margin: 0}
	.mint-cell-wrapper,.mint-radiolist,.mint-cell{height: torem(16);line-height: torem(16)}
	.mint-radiolist .mint-cell{    background: transparent;}
	.mint-cell-wrapper{background: none;transform: translateY(-8px);}

	span.mint-radio-label{display: inline-block;transform:translateX(-20px);}
	.mint-radiolist-title{margin-left: 0}
}
</style>

<style lang='scss' scoped>

.parent-tabs {
  margin-bottom: 10px;
  font-size: 0px;
  li {
    background: #fff;
    display: inline-block;
    font-size: torem(16);
    line-height: torem(16);
    padding: torem(8);
    border-right: 1px solid #ddd;
    // width:30vw;
    &.on {
      background: #888;
    }
  }
}
.student-info {
	.mint-radiolist{display: flex}
	span.mint-radio-label{display: inline-block;transform:translateX(-15px);}
  .student-info-nav {
    margin-top: 16px;
    width: 100%;
    margin-left: 0;
    border-radius: 5px;
    overflow: hidden;
  }
  background: #eee;
  padding: 30px 10px 20px;
  .info-edit-des {
    font-size: torem(16);
    color: #888;
    margin: 15px 0;
  }
  .info-tab {
    background: #fff;
    margin: 0 0 15px;
    padding-bottom: 10px;
    .cell {
      display: flex;
      font-size: torem(16);
      line-height: torem(32);
      margin: torem(5) torem(8);
      border-bottom: torem(1) solid #ddd;
      .cell-1 {
        span {
          color: red;
          font-size: torem(20);
        }
        flex: 4;
        text-align: right;
        padding-right: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(16);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
    }
  }
}

.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
