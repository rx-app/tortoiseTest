<template>
  <div>
    <div class="btn-box">
      <button
        type="button"
        class="mui-btn mui-btn-block btn"
        v-power="['新增跟进记录']"
        @click="$router.push({name:'follow-add', query:{customerID:$route.query.id, cName: $route.query.cName,actionType: 'create',isPotential:$route.query.isPotential}})"
      >新增跟进记录</button>
    </div>
    <tip v-if="!list.length">
      <span>该学员暂无跟进记录信息</span>
    </tip>
    <div class="list-box" v-if="list.length">
      <div class="page-tit">已录入跟进记录:</div>
      <ul class="mui-table-view rx-list-items">
        <li
          v-for="(item, index) in list"
          :key="index"
          tag="li"
          class="item link-item"
          @click="go(item)"
        >
          <span>{{item.followTime | dateTimeFormat({locale: 'en-US'})}}</span>
          <span>{{item.followType | followType}}</span>
          <span>{{item.followObject | followObject}}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import Tip from "@/components/tip";
import { getAllFollows } from "@/api/customerFollows/customerFollows-api";
import { pager, orderBy } from "@/public/constant";
export default {
  data() {
    return {
      list: []
    };
  },
  created() {
    this.getList();
  },
  methods: {
    go(item) {
      this.$router.push({
        name: "follow-info",
        query: {
					followId: item.followID,
					cName: item.customerName, 
          actionType: "view"
        }
      });
    },
    async getList() {
      let params = {
        customerID: this.$route.query.id,
        ...pager({
          pageIndex: 1,
          pageSize: 10
        }),
        ...orderBy({
          dataField: "followTime",
          sortDirection: 1
        })
      };
      getAllFollows(params, res => {
        this.list = res.queryResult.pagedData;
      });
    }
  },
  mounted() {
    this.$route.meta.title = this.$route.query.cName + "的跟进记录";
  },
  components: {
    Tip
  }
};
</script>

<style lang="scss" scoped>
.mui-title {
  font-size: torem(14) !important;
}
.page-tit {
  text-align: left;
  padding: 0 20px 10px;
}
.btn-box {
  width: 90%;
  margin: 10px auto;
  .btn {
    background: rgb(255, 153, 102);
    color: #fff;
    border: none;
    width: 100%;
    margin: 10px auto;
    border-radius: 10px;
  }
}
.rx-list-items {
  .item {
    display: flex !important;
    justify-content: space-between;
    align-items: center;
    padding: torem(10) torem(15);
    border-bottom: 1px solid #eee;
    margin: 0 0 0 torem(5);
    position: relative;
    padding-right: 15px;
    span {
      display: block;
    }
    span:first-child {
      // flex-basis: torem(1515)
    }
    span:nth-child(2) {
      // flex-basis: torem(615)
    }
    span:last-child {
      margin-right: 15px;
    }
  }
  .link-item:after {
    content: "\E583";
    font-family: Muiicons;
    color: #bbb;
    -webkit-font-smoothing: antialiased;
    margin-left: 5px;
    position: absolute;
    top: 30%;
    right: 15px;
    // transform: translateX(50%) translateY(50%)
  }
  .name {
    color: #777;
  }
  .value {
    display: block;
    text-align: right;
    flex: 1;
    color: #aaa;

    .img-header {
      width: 1.70667rem;
      height: 1.70667rem;
    }
  }
  .no-arrow {
    margin-right: 17px;
  }
}
</style>
