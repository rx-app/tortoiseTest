<template>
  <div class="visit-info-wrapper" v-if="this.followInfo.follow" id="wrap">
    <h4>
      学员
      <span class="color">{{cName}}</span>
      的跟进记录
    </h4>
    <div class="margin-top-15 margin-bottom-15 wrapper-color">
      <ul class="list-group">
        <li
          class="item"
          :class="{'edit': actionType=='create'}"
          @click.prevent.stop="selectItem('followType')"
        >
          <div class="item-left">
            <span class="request" v-if="actionType=='create'">*</span>跟进方式
          </div>
          <div class="item-right">{{followInfo.follow.followType | followType}}</div>
        </li>
        <li
          class="item"
          :class="{'edit': actionType=='create'}"
          @click.prevent.stop="selectItem('followObject')"
        >
          <div class="item-left">
            <span class="request" v-if="actionType=='create'">*</span>跟进对象
          </div>
          <div class="item-right">{{followInfo.follow.followObject | followObject}}</div>
        </li>
        <li
          class="item"
          :class="{'edit': actionType=='create'}"
          @click.prevent.stop="selectItem('purchaseIntention')"
        >
          <div class="item-left">
            <span class="request" v-if="actionType=='create'">*</span>购买意愿
          </div>
          <div class="item-right">{{followInfo.follow.purchaseIntention | purchaseIntention}}</div>
        </li>
        <li
          class="item"
          :class="{'edit': actionType=='create'}"
          @click.prevent.stop="selectItem('customerLevel')"
        >
          <div class="item-left">
            <span class="request" v-if="actionType=='create'">*</span>客户级别
          </div>
          <div class="item-right">{{followInfo.follow.customerLevel | customerLevel}}</div>
        </li>
        <li class="item" :class="followInfo.follow.talkResult?'talkResult':''">
          <div class="item-left">
            <span class="eleVis" v-if="actionType=='create'">*</span>沟通结果
          </div>
          <div class="item-right">{{followInfo.follow.talkResult}}</div>
        </li>
        <li
          class="item"
          v-if="followInfo.follow.customerLevel == 11"
          :class="{'edit': actionType=='create'}"
          @click.prevent.stop="selectItem('invalidReason')"
        >
          <div class="item-left">
            <span class="eleVis" v-if="actionType=='create'">*</span>无效理由
          </div>
          <div class="item-right">{{followInfo.follow.invalidReason | invalidReason}}</div>
        </li>
      </ul>
    </div>
    <div class="margin-bottom-15 wrapper-color">
      <li class="item">
        <div class="item-left">
          <span class="eleVis" v-if="actionType=='create'">*</span>跟进前阶段
        </div>
        <div class="item-right">{{followInfo.previousFollowStage | followStage}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('followStage')">
        <div class="item-left">
          <span class="request" v-if="actionType=='create'">*</span>本次跟进阶段
        </div>
        <div class="item-right">{{followInfo.follow.followStage | followStage}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @tap="action('planVerifyTime')">
        <div class="item-left">
          <span class="request" v-if="actionType=='create'">*</span>预计上门时间
        </div>
        <div class="item-right">{{followInfo.follow.planVerifyTime | cast | dateFormat}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @tap="action('nextFollowTime')">
        <div class="item-left">
          <span class="request" v-if="actionType=='create'">*</span>预计下次沟通时间
        </div>
        <div class="item-right">{{followInfo.follow.nextFollowTime | cast | dateFormat}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @tap="action('planSignDate')">
        <div class="item-left">
          <span class="request" v-if="actionType=='create'">*</span>预计签约时间
        </div>
        <div class="item-right">{{followInfo.follow.planSignDate | cast | dateFormat}}</div>
      </li>
      <li class="item">
        <div class="item-left">
          <span class="eleVis" v-if="actionType=='create'">*</span>此次通电号码
        </div>
        <div class="item-right" v-if="actionType=='view'">{{followInfo.follow.followPhone}}</div>
        <div class="item-right" v-if="actionType=='create'">
          <input
            type="text"
            maxlength="19"
            placeholder="请输入电话号码"
            v-model="followInfo.follow.followPhone"
            @blur.stop="returnResult('followPhone')"
            @input="handleInput($event)"
          >
        </div>
      </li>
      <tip v-if="followPhoneFlag" class="tip">输入的电话号码格式不正确！</tip>
    </div>
    <div class="margin-top-15 wrapper-color">
      <li
        class="item"
        :class="{'edit': isEdit,'interSubject':followInfo.follow.intensionSubjects && actionType=='create','talkResult':followInfo.follow.intensionSubjects && actionType=='view'}"
        @click.prevent.stop="selectItem('intensionSubjects')"
      >
        <div class="item-left">
          <span class="request" v-if="actionType=='create'">*</span>想要补习的科目
        </div>
        <div class="item-right" v-if="followInfo.follow.intensionSubjects">
          <span
            v-for="(item,index) in followInfo.follow.intensionSubjects.split(',')"
            :key="index"
          >{{item | subject}},</span>
        </div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('isStudyThere')">
        <span class="item-left">
          <span class="request" v-if="actionType=='create'">*</span>是否在其他机构辅导
        </span>
        <div class="item-right">{{followInfo.follow.isStudyThere | ifElse}}</div>
      </li>
      <!-- 查看跟进记录 其他辅导机构罗列 -->
      <div v-if="followInfo.follow.isStudyThere && actionType=='view'" class="studyThere">
        <div v-for="(item,index) in followInfo.followItems" :key="index">
          <ul>
            <li>
              <span>科目：</span>
              <span>{{item.subject | subject}}</span>
            </li>
            <li>
              <span>机构：</span>
              <span>{{item.institude}}</span>
            </li>
          </ul>
          <ul>
            <li>
              <span>开始时间：</span>
              <span>{{item.startDate | cast | dateFormat}}</span>
            </li>
            <li>
              <span>结束时间：</span>
              <span>{{item.endDate | cast | dateFormat}}</span>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="followInfo.follow.isStudyThere && actionType=='create'" class="studyThereLine">
        <ul v-for="(item,index) in followInfo.followItems" :key="index">
          <p @click="delectCurrent(index)">
            <i class="iconfont icon-error"></i>
          </p>
          <li
            class="item"
            :class="{'edit': isEdit}"
            @click.prevent.stop="selectItem('coachSubject',index)"
          >
            <span class="item-left">辅导科目</span>
            <div class="item-right">{{item.subject | subject}}</div>
          </li>
          <li class="item">
            <span class="item-left">辅导机构</span>
            <div class="item-right">
              <input
                type="text"
                maxlength="20"
                placeholder="请输入辅导机构名称"
                v-model="item.institude"
                @blur.stop="returnResult('institude',index,$event)"
              >
            </div>
          </li>
          <li class="item" :class="{'edit': isEdit}" @tap="action('startDate',index)">
            <span class="item-left">辅导开始时间</span>
            <div class="item-right">{{item.startDate | cast | dateFormat}}</div>
          </li>
          <li class="item" :class="{'edit': isEdit}" @tap="action('endDate',index)">
            <span class="item-left">辅导结束时间</span>
            <div class="item-right">{{item.endDate | cast | dateFormat}}</div>
          </li>
        </ul>
        <p class="pt" @click="addIns()">
          <i class="iconfont icon-add"></i>
          <span class="margin-left-5">新增其他辅导机构</span>
        </p>
      </div>
      <li class="item border-none">
        <div class="item-left">
          <span class="eleVis" v-if="actionType=='create'">*</span>跟进情况备注:
        </div>
        <div class="item-right"></div>
      </li>
      <p class="followMemo" v-if="actionType=='view'">{{followInfo.follow.followMemo}}</p>
      <div v-if="actionType=='create'" class="textDiv">
        <textarea
          name
          id="followInp"
          cols="30"
          rows="10"
          placeholder="请输入..."
          v-model="followInfo.follow.followMemo"
        ></textarea>
      </div>
    </div>
    <select-items
      v-show="itemsParams.isShow"
      :title="itemsParams.title"
      :model="itemsParams.model"
      :isShow="itemsParams.isShow"
      :category="itemsParams.category"
      :items="itemsParams.selectItems"
      :isRadio="itemsParams.isRadio"
      @selectItem="selectVisitType"
    ></select-items>
  </div>
</template>
<script>
import { ACTION_TYPES, talkData, isStudyThereArr } from "@/constants";
import { DATE_FORMAT } from "@/public/constant";
import { loadUserInfo } from "@/api/common/common-api";
import {
  viewFollow,
  createFollow,
  $createFollow
} from "@/api/customerFollows/customerFollows-api";
import SelectItems from "@/components/select-items/index";
import InputFullLayer from "@/components/input-full-layer/index";
import Tip from "@/components/tip";
import { setTimeout } from "timers";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({
      bottom: "-1px"
    });
  }
}
export default {
  data() {
    this.viewType = {
      CREATE: "create",
      VIEW: "view"
    };
    return {
      followInfo: {},
      option: {
        type: "date",
        beginYear: 2010
      },
      itemsParams: {
        isShow: false,
        title: "",
        model: "",
        category: "",
        isRadio: true,
        selectItems: []
      },
      layerParams: {
        isShowLayer: false
      },
      active: false,
      followPhoneFlag: false,
      currentInsKey: 0
    };
  },
  created() {
    this.getActionData();
    this.registerSubmit();
  },
  methods: {
    async getActionData() {
      await loadUserInfo();
      if (this.actionType == this.viewType.VIEW) {
        this.getFollowInfo();
      } else if (this.actionType == this.viewType.CREATE) {
        this.getFollowInfoForCreate();
      }
    },
    getFollowInfo() {
      viewFollow(
        {
          followId: this.followId
        },
        res => {
          this.followInfo = res;
          this._initTalkResult();
        }
      );
    },
    getFollowInfoForCreate() {
      createFollow(
        {
          customerID: this.customerID,
          isPotential: this.isPotential
        },
        res => {
          this.followInfo = res;
          this.followInfo.followItems = [];
        }
      );
    },
    submit() {
      delete this.followInfo.dictionaries;
      $createFollow(this.followInfo, res => {
        mui.toast("新增跟进记录成功！");
        this.$router.go(-1);
      });
    },
    returnResult(type, key, intObj) {
      if (type == "followPhone" && this.followInfo.follow.followPhone) {
        var reg = /(^1[2-9]\d{9}$)|(^\d{3,4}-\d{7,8}-\d{1,5}$)|(^\d{3,4}-\d{7,8}$)/;
        if (reg.test(this.followInfo.follow.followPhone)) {
          this.followPhoneFlag = false;
        } else {
          this.followPhoneFlag = true;
        }
      }
      if (type == "institude") {
        this.followInfo.followItems[key].institude = intObj.target.value;
      }
    },
    handleInput(e) {
      this.followInfo.follow.followPhone = e.target.value.replace(
        /[^\d-]/g,
        ""
      );
    },
    //添加其他辅导机构
    addIns() {
      var insObj = {
        institude: "",
        startDate: "",
        endDate: "",
        subject: ""
      };
      this.followInfo.followItems.push(insObj);
    },
    //删除当前添加的其他辅导机构
    delectCurrent(key) {
      if (
        this.followInfo.follow.isStudyThere &&
        this.followInfo.followItems.length > 1 &&
        (this.followInfo.followItems[key].startDate ||
          this.followInfo.followItems[key].endDate ||
          this.followInfo.followItems[key].subject ||
          this.followInfo.followItems[key].institude)
      ) {
        mui.confirm(
          "删除后无法恢复，是否确认删除？",
          "提示",
          e => {
            if (e.index) {
              this.followInfo.followItems.splice(key, 1);
            }
          },
          "",
          "div"
        );
      } else if (
        this.followInfo.follow.isStudyThere &&
        this.followInfo.followItems.length > 1 &&
        (!this.followInfo.followItems[key].startDate &&
          !this.followInfo.followItems[key].endDate &&
          !this.followInfo.followItems[key].subject &&
          !this.followInfo.followItems[key].institude)
      ) {
        this.followInfo.followItems.splice(key, 1);
      } else {
        mui.alert("必须添加一项辅导机构!", "提示", "", "", "div");
      }
    },
    selectItem(category, key) {
      if (!this.isEdit) return;
      this.itemsParams.isShow = true;
      this.itemsParams.category = category;
      if (category == "intensionSubjects") {
        this.itemsParams.isRadio = false;
      } else {
        this.itemsParams.isRadio = true;
      }
      switch (category) {
        case "followType":
          this.itemsParams.title = "跟进方式";
          this.itemsParams.model = this.followInfo.follow.followType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "followObject":
          this.itemsParams.title = "跟进对象";
          this.itemsParams.model = this.followInfo.follow.followObject;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "purchaseIntention":
          this.itemsParams.title = "购买意愿";
          this.itemsParams.model = this.followInfo.follow.purchaseIntention;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "customerLevel":
          this.itemsParams.title = "客户级别";
          this.itemsParams.model = this.followInfo.follow.customerLevel;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "invalidReason":
          this.itemsParams.title = "无效理由";
          this.itemsParams.model = this.followInfo.follow.invalidReason;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "followStage":
          this.itemsParams.title = "本次跟进阶段";
          this.itemsParams.model = this.followInfo.follow.followStage;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "isStudyThere":
          this.itemsParams.title = "是否在其他机构辅导";
          this.itemsParams.model = this.followInfo.follow.isStudyThere;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "intensionSubjects":
          this.itemsParams.title = "想要补习的科目";
          this.itemsParams.model = this.followInfo.follow.intensionSubjects;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "coachSubject":
          this.currentInsKey = key;
          this.itemsParams.title = "辅导科目";
          this.itemsParams.model = this.followInfo.followItems[key].subject;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        default:
          break;
      }
    },
    _getSelectItems(category) {
      let res = [];
      switch (category) {
        case "followType":
          res = this.followInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_SaleContactType;
          break;
        case "followObject":
          res = this.followInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_SaleContactTarget;
          break;
        case "purchaseIntention":
          res = this.followInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_PurchaseIntent;
          break;
        case "customerLevel":
          res = this.followInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_CustomerLevelEx;
          break;
        case "invalidReason":
          res = this.followInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_InvaliCustomerType;
          break;
        case "followStage":
          res = this.followInfo.dictionaries.C_CODE_ABBR_Customer_CRM_SalePhase;
          break;
        case "isStudyThere":
          res = isStudyThereArr;
          break;
        case "intensionSubjects":
          res = this.followInfo.dictionaries
            .c_codE_ABBR_BO_Product_TeacherSubject;
          break;
        case "coachSubject":
          res = this.followInfo.dictionaries
            .c_codE_ABBR_BO_Product_TeacherSubject;
          break;
        default:
          break;
      }
      return res;
    },
    selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "followType":
            this.followInfo.follow.followType = obj.item.key;
            break;
          case "followObject":
            this.followInfo.follow.followObject = obj.item.key;
            break;
          case "purchaseIntention":
            this.followInfo.follow.purchaseIntention = obj.item.key;
            break;
          case "customerLevel":
            this.followInfo.follow.customerLevel = obj.item.key;
            break;
          case "invalidReason":
            this.followInfo.follow.invalidReason = obj.item.key;
            break;
          case "followStage":
            this.followInfo.follow.followStage = obj.item.key;
            break;
          case "isStudyThere":
            this.followInfo.follow.isStudyThere = obj.item.key;
            break;
          case "intensionSubjects":
            let subjectArr = [];
            obj.itemArr.forEach(item => {
              subjectArr.push(item.key);
            });
            this.followInfo.follow.intensionSubjects = subjectArr.join(",");
            break;
          case "coachSubject":
            this.followInfo.followItems[this.currentInsKey].subject =
              obj.item.key;
            break;
          default:
            break;
        }
      }
    },
    action(paramName, key) {
      if (this.viewType.VIEW == this.actionType) return;
      let dtPicker = new mui.DtPicker(this.option);
      const _this = this;
      dtPicker.show(function(selectItems) {
        _this.$nextTick(() => {
          var currentDate = new Date(_this._getDate());
          var selTime = new Date(selectItems.value.replace(/-/g, "/"));
          if (
            selTime.getTime() < currentDate.getTime() &&
            (paramName === "planVerifyTime" ||
              paramName === "nextFollowTime" ||
              paramName === "planSignDate")
          ) {
            mui.alert("只能选择当天及以后的日期!", "提示", "", "", "div");
            return;
          }
          if (paramName === "planVerifyTime") {
            _this.followInfo.follow.planVerifyTime = new Date(
              selectItems.value.replace(/-/g, "/")
            );
          } else if (paramName === "nextFollowTime") {
            _this.followInfo.follow.nextFollowTime = new Date(
              selectItems.value.replace(/-/g, "/")
            );
          } else if (paramName === "planSignDate") {
            _this.followInfo.follow.planSignDate = new Date(
              selectItems.value.replace(/-/g, "/")
            );
          } else if (paramName === "startDate") {
            if (_this.followInfo.followItems[key].endDate) {
              var startTime = new Date(selectItems.value.replace(/-/g, "/"));
              var endTime = new Date(_this.followInfo.followItems[key].endDate);
              if (endTime.getTime() < startTime.getTime()) {
                mui.alert(
                  "辅导结束时间必须大于开始时间! 请重新选择结束时间!",
                  "提示",
                  "",
                  "",
                  "div"
                );
                _this.followInfo.followItems[key].endDate = "";
              }
            }
            _this.followInfo.followItems[key].startDate = new Date(
              selectItems.value.replace(/-/g, "/")
            );
          } else if (paramName === "endDate") {
            if (_this.followInfo.followItems[key].startDate) {
              var startTime = new Date(
                _this.followInfo.followItems[key].startDate
              );
              var endTime = new Date(selectItems.value.replace(/-/g, "/"));
              if (endTime.getTime() < startTime.getTime()) {
                mui.alert(
                  "辅导结束时间必须大于开始时间!",
                  "提示",
                  "",
                  "",
                  "div"
                );
                return;
              }
            }
            _this.followInfo.followItems[key].endDate = new Date(
              selectItems.value.replace(/-/g, "/")
            );
          }
          dtPicker.dispose();
        });
      });
    },
    registerSubmit() {
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    _initTalkResult() {
      var _this = this;
      var talkResultArray = talkData.filter(function(item) {
        return item.key == _this._customerLevel();
      });
      this.followInfo.follow.talkResult =
        talkResultArray != undefined && talkResultArray.length > 0
          ? talkResultArray[0].value
          : "";
    },
    _customerLevel() {
      var _this = this;
      var customerLevel = "";
      this.followInfo.dictionaries.C_CODE_ABBR_Customer_CRM_CustomerLevelEx.forEach(
        item => {
          if (item.key == _this.followInfo.follow.customerLevel) {
            customerLevel = item.value;
          }
        }
      );
      return customerLevel;
    },
    _getDate(d) {
      let date = new Date();
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let day = date.getDate();
      let z = year + "/" + month + "/" + day;
      return z;
    }
  },
  computed: {
    followId() {
      return this.$route.query.followId;
    },
    cName() {
      return this.$route.query.cName;
    },
    customerID() {
      return this.$route.query.customerID;
    },
    actionType() {
      return this.$route.query.actionType;
    },
    isPotential() {
      return this.$route.query.isPotential;
    },
    isEdit() {
      if (this.actionType == this.viewType.VIEW) {
        return false;
      } else if (this.actionType == this.viewType.CREATE) {
        return true;
      }
    }
  },
  watch: {
    followInfo: {
      handler: function(obj) {
        if (
          this.actionType == this.viewType.CREATE &&
          obj.follow &&
          obj.follow.followType &&
          obj.follow.followObject &&
          obj.follow.purchaseIntention &&
          obj.follow.customerLevel &&
          obj.follow.followStage &&
          obj.follow.planVerifyTime &&
          obj.follow.nextFollowTime &&
          obj.follow.planSignDate &&
          obj.follow.intensionSubjects
        ) {
          xdapp.util.vue.commitActionStatus(true);
        } else {
          xdapp.util.vue.commitActionStatus(false);
        }
      },
      deep: true
    },
    "followInfo.follow.customerLevel"() {
      this._initTalkResult();
    },
    "followInfo.follow.isStudyThere"(val) {
      var insObj = {
        institude: "",
        startDate: "",
        endDate: "",
        subject: ""
      };
      if (val && this.actionType == "create" && !this.followInfo.followItems) {
        this.followInfo.followItems.push(insObj);
      }
    }
  },
  components: {
    SelectItems,
    InputFullLayer,
    Tip
  }
};
</script>

<style lang="scss" scoped>
$wrapperColor: #fff;
$titleColor: #777;
$contentColor: #999;
.scroll-container {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.visit-info-wrapper {
  position: absolute;
  width: 100%;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch; /* 解决ios滑动不流畅问题 */
  background-color: $backgroundColor;
  font-size: torem(14);
  color: $titleColor;
  h4 {
    padding: torem(5) 0 0 torem(10);
    margin-bottom: torem(-5);
    .color {
      color: orange;
    }
  }
  .item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: torem(50);
    line-height: torem(50);
    border-bottom: 1px solid rgba(239, 239, 244, 0.5);
    .item-left {
      padding-left: torem(10);
      .request {
        color: red;
        margin-top: torem(3);
        margin-right: torem(3);
      }
      .eleVis {
        visibility: hidden;
      }
    }
    .item-right {
      position: absolute;
      right: torem(25);
      flex: 1;
      text-align: right;
      color: $contentColor;
      width: 50%;
      line-height: 25px;
      input {
        border: none;
        margin-bottom: 0;
        text-align: right;
        padding-right: 0;
      }
      input::-webkit-input-placeholder {
        font-size: torem(14);
        color: #999;
      }
    }
  }
  .tip {
    height: torem(20);
    line-height: torem(20);
    color: red;
  }
  .studyThere {
    background-color: #f3f3f3;
    padding: torem(15) torem(10);
    div {
      ul {
        display: flex;
        li {
          flex: 1;
          height: torem(40);
          line-height: torem(40);
          font-size: torem(14);
        }
      }
    }
  }
  .studyThereLine {
    margin: torem(15) torem(10);
    .item-right {
      right: torem(30);
    }
    ul {
      background-color: #f3f3f3;
      border-radius: 10px;
      padding-bottom: torem(18);
      margin-bottom: torem(10);
      p {
        margin-bottom: 0;
        text-align: right;
        i {
          color: #999;
          font-size: torem(18);
        }
      }
    }
    input {
      background-color: #f3f3f3;
    }
    .pt {
      height: torem(30);
      margin-bottom: 0;
      text-align: right;
      padding-right: torem(15);
      background-color: #fff;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      i {
        color: #999;
        font-size: torem(20);
      }
    }
  }
  .followMemo {
    padding: torem(5) torem(12);
    line-height: torem(24);
    color: #8f8f94;
  }
  .talkResult {
    height: auto;
    .item-right {
      position: static;
      padding-right: torem(25);
      max-width: torem(200);
    }
  }
  .interSubject {
    height: auto;
    .item-right {
      position: static;
      margin-right: torem(-36);
      max-width: torem(200);
      span {
        margin-right: torem(3);
      }
    }
  }
  .edit {
    &:after {
      margin: 0 5px;
      content: "\E583";
      font-family: Muiicons;
      -webkit-font-smoothing: antialiased;
      font-size: torem(14);
      color: $contentColor;
    }
  }
  .text-flow {
    p {
      width: torem(260);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-bottom: 0;
    }
  }
  .active {
    height: torem(120);
    padding: torem(10) 0;
    overflow: hidden;
    div.text-flow {
      max-height: torem(100);
      //overflow-y: scroll;
      p {
        line-height: torem(20);
        white-space: normal;
      }
    }
  }
  .textDiv {
    padding: torem(15) torem(10);
    padding-top: 0;
    textarea {
      padding: torem(15) torem(10);
      border-radius: torem(8);
    }
    #followInp::-webkit-scrollbar {
      width: 2px;
    }
  }
}

.border-none {
  border-bottom: none !important;
}
.margin-top-15 {
  margin-top: torem(15);
}

.margin-bottom-15 {
  margin-bottom: torem(15);
}

.margin-left-5 {
  margin-left: torem(5);
}

.wrapper-color {
  background-color: $wrapperColor;
}
</style>