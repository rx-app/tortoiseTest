﻿<template>
	<div class="wrap">
		<div class="course-mess">
			<p class='course-title bt'>本次成绩:</p>
			<div class="course-info">
				<p><span class='course-title'>学年度 : </span>
					<!--<span v-if='!isshow(studyYear)'>{{studyYear}}</span>-->
					<span>{{studyYear | studyYear}}</span>
				</p>
				<p><span class='course-title'>学期 : </span><span class="subjects">{{studyTerm | studyTerm}} </span></p>
				<p><span class='course-title'>考试类型 : </span>
					<span v-if='scoreType==2 || scoreType==4'>期中考试</span>
					<span v-else-if='scoreType==3 || scoreType==5'>期末考试</span>
					<span v-else>{{scoreType | scoreType}}</span> </span>
				</p>
				<p><span class='course-title'>考试年级 : </span><span class="subjects" v-if='scoreGrade!=0'>{{scoreGrade | grade}} </span><span v-else>不限</span></p>
			</div>
			<div class="item-score" v-for='(scoreItem,index) in scoreList'>
				<span class="cname course-title" v-if='scoreItem.subject'>{{scoreItem.subject | examSubject}}</span>
				<p class="teacher" v-if='scoreItem.teacherName'>(<span class='teacherN'>教师：</span>{{scoreItem.teacherName}})</p>
				<span class="score-num" v-if='scoreItem.realScore || scoreItem.paperScore'><span class="score">{{scoreItem.realScore}}分</span>/{{scoreItem.paperScore}}分</span>
				<p class="right" v-if="scoreItem.parentSatisficing">满意度: <i :class="{'lv3':scoreItem.parentSatisficing>=5, 'lv1':scoreItem.parentSatisficing<=4}"></i><span>{{scoreItem.parentSatisficing}}分</span></p>
			</div>
		</div>
	</div>
</template>
<script>
	import { loadUserInfo } from '@/api/common/common-api'
	import { pager, orderBy } from '@/public/constant'
	import { getScore, GetCurrentJobCustomerScores } from '@/api/customer/customer-api'
	export default {
		data() {
			return {
				scoreList: [],
				reg: /^\d+$/g
			}
		},
		created() {
			this.$route.meta.title = this.customerName + '的成绩';
			document.querySelector('footer').style.display = 'none';
		},
		destroyed(){
           document.querySelector('footer').style.display = 'block';
		},
		mounted() {
			let params = {
				filterStatus: 0,
				...pager({
					pageIndex: 1,
					pageSize: 5,
				})
			};
			GetCurrentJobCustomerScores(params);
			getScore(this.scoreID, (res => {
				this.scoreList = res.scores;
			}));
		},
		methods: {
			isshow(item) {
				var booleans = this.reg.test(item);
				return booleans;
			},
		},
		computed: {
			scoreID() {
				return this.$route.query.scoreID;
			},
			studyYear() {
				return this.$route.query.studyYear;
			},
			studyTerm() {
				return this.$route.query.studyTerm;
			},
			scoreType() {
				return this.$route.query.scoreType;
			},
			scoreGrade() {
				return this.$route.query.scoreGrade;
			},
			customerName() {
				return this.$route.query.customerName;
			}
		}
	}
</script>
<style lang='scss' scoped>
    .wrap{
    	padding-bottom: torem(70);
    }
	.course-mess {
		width: 90%;
		margin-left: 5%;
		height: auto;
		background-color: #fff;
		margin-top: torem(15);
		box-shadow: 0 2px 4px 0 rgba(148, 148, 148, 0.25);
		border: 1px solid #eee;
		border-radius: 10px;
		padding: torem(10);
		p.course-title {
			height: torem(40);
			line-height: torem(40);
			border-bottom: 1px dotted #000;
		}
		.course-info {
			display: flex;
			flex-wrap: wrap;
			padding: torem(10);
			border-bottom: 1px dotted #000;
			p {
				width: 50%;
				height: torem(30);
				line-height: torem(30);
			}
		}
		.item-score {
			display: flex;
			align-items: center;
			height: torem(40);
			white-space: nowrap;
			overflow-x: scroll;
			.cname {
				width: auto;
				margin-left: torem(10);
			}
			.score-num {
				width: auto;
				text-align: center;
				margin: 0 torem(7);
			}
			.right {
				width: auto;
				text-align: center;
				margin-right: torem(10);
			}
			.teacher {
				color: #121212;
				font-size: torem(14);
				font-weight: bold;
				width: auto;
				text-align: center;
				margin-right: torem(7);
			}
			p {
				font-size: torem(12)
			}
		}
		.item-score:last-child {
			box-sizing: content-box;
			padding-top: torem(10);
			border-top: 1px dotted #000;
		}
		i {
			display: inline-block;
			background: url('~@/public/asset/img/course/level3.png');
			background-size: 100%;
			height: 20px;
			width: 20px;
			margin: 0 2px;
			vertical-align: bottom;
			&.lv3 {
				background: url('~@/public/asset/img/course/level3.png');
				background-size: 100%;
			}
			&.lv2 {
				background: url('~@/public/asset/img/course/level2.png');
				background-size: 100%;
			}
			&.lv1 {
				background: url('~@/public/asset/img/course/level1.png');
				background-size: 100%;
			}
		}
	}
	
	.course-title {
		color: #121212;
		font-size: torem(14);
		font-weight: bold;
	}
	
	p {
		margin-bottom: 0;
	}
</style>