<template>
	<div class="xd-score">
		<course-header></course-header>
		<p class="inp">
			<input type="text" placeholder="输入学员姓名/编号进行查询" v-model="inpVal" @click='inpFocus()'  @blur="inpBlur" />
			<i class="iconfont icon-found" @click="getList()"></i>
		</p>
		<p class="inpty" v-if='!rsLisr.length && isShow'>没有查到该学员的成绩记录，请到PPTS电脑端进行录入。</p>
		<p class="inpt" v-if="rsLisr.length ">成绩内容较多，添加和查看完整内容请到PPTS端操作。</p>
		<div id="stu-main-content" class="main-content" :style="{'-webkit-overflow-scrolling': scrollMode}">
			<mt-loadmore class="loadMore" :bottom-all-loaded="allLoaded" :auto-fill="false" :bottom-method="loadBottom" :bottom-distance=-70 ref="loadmore">
				<li v-for="(item,index) in rsLisr" :key='index' @tap="getDetail(item)">
					<!--姓名-->
					<span>{{item.customerName}}</span>
					<!--成绩年份-->
					<span v-if="item.studyYear.length==1">{{item.studyYear | studyYear}}</span>
					<span v-else>{{item.studyYear}}</span>
					<!--成绩学期-->
					<span>{{item.studyTerm | studyTerm}}</span>
					<!--成绩类型-->
					<span v-if='item.scoreType==2 || item.scoreType==4'>期中考试</span>
					<span v-else-if='item.scoreType==3 || item.scoreType==5'>期末考试</span>
					<span v-else>{{item.scoreType | scoreType}}</span>

					<span><i class="mui-icon mui-icon-forward"></i></span>
				</li>
			</mt-loadmore>
		</div>
		<!--<p class="inpt inptEnd" v-if="rsLisr.length">因成绩包含内容较多，添加成绩和查看完整内容请到PPTS电脑端进行操作。</p>-->

	</div>
</template>
<script>
	import Tip from '@/components/tip';
	import { GetCurrentJobCustomerScores } from '@/api/customer/customer-api'
	import { pager, orderBy } from '@/public/constant'
	import courseHeader from '../partials/course-header.vue'
	import resize from '@/public/lib/resize'
	export default {
		mixins:[resize],
		data() {
			return {
				inpVal: '',
				rsLisr: [],
				isShow: false,
				allLoaded: false,
				scrollMode: "auto",
				pageIndex: 1,
				pageSize: 20
			}
		},
		watch: {
			inpVal(val, newVal) {
				if(this.inpVal == '') {
					this.rsLisr = [];
					this.isShow = false;
				}
			}
		},
		methods: {
			inpFocus() {
				var h = document.body.scrollHeight;
				//this.focus_footer(h);
				if(mui.os.ios){
					document.querySelector('footer').style.display = 'none';
				}
			},
			inpBlur() {
				if(mui.os.ios){
					document.querySelector('footer').style.display = 'block';
				}
			},
			focus_footer(h) {
				var _this = this;
				window.onresize = function() {
					if(document.body.scrollHeight < h) {
						if(_this.$route.name == "score") {
							xdapp.footer.style.display = 'none';
						}
					} else {
						if(_this.$route.name == "score") {
							xdapp.footer.style.display = 'block';
						}
					}
				};
			},
			loadBottom() {
				event.preventdefault;
				event.stopPropagation();
				this.pageIndex++;
				this.getList('more');
				this.$refs.loadmore.onBottomLoaded();
			},
			getDetail(item) {
				console.log(item.scoreGrade);
				this.$router.push({
					name: 'scoreList',
					query: {
						scoreID: item.scoreID,
						studyYear: item.studyYear,
						studyTerm: item.studyTerm,
						scoreType: item.scoreType,
						customerName: item.customerName,
						scoreGrade: item.scoreGrade
					}
				})

			},
			async getList(type) {
				if(!type) {
					this.rsLisr = [];
					this.pageIndex=1;
				}
				let params = {
					SearhKeyword: this.inpVal.trim(),
					...pager({
						pageIndex: this.pageIndex,
						pageSize: this.pageSize,
					})
				}
				GetCurrentJobCustomerScores(params, (res) => {
					this.rsLisr = this.rsLisr.concat(res.queryResult.pagedData);
					if(!this.rsLisr.length) {
						this.isShow = true;
						return;
					}
					const len = res.queryResult.pagedData.length;
					if(this.pageSize * this.pageIndex >= res.queryResult.totalCount) {
						this.allLoaded = true;
					} else {
						this.allLoaded = false;
					}
				});
			},
			setHeight() {
				let content = document.querySelector('#stu-main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 240;
					let headHight = document.querySelector('#course-head');
					console.log('stu-#course-head：' + headHight)
					if(headHight !== null) {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem - 2.88rem)'
					} else {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem)'
					}
				}
			}
		},
		mounted() {
			this.setHeight();
		},
		components: {
			courseHeader,
			Tip
		},
		created() {
			document.querySelector('.xd-header').style.position='absolute';
		},
		destroyed() {
			document.querySelector('.xd-header').style.position='fixed';			
		},
	}
</script>

<style lang="scss" scoped>
.xd-score{
		position:absolute;
		background: #fff;
		z-index: 5;
		width: 100%;
	}
	.xd-score {
		.inp {
			width: 90%;
			margin-left: 5%;
			margin-top: torem(15);
			border: 1px solid #D8D8D8;
			border-radius: 100px;
			height: 32px;
			position: relative;
			input {
				width: 90%;
				height: 100%;
				border: none;
				margin-left: 1%;
				border-radius: 100px;
			}
			input::-webkit-input-placeholder {
				font-size: torem(12);
				color: skyblue;
			}
			i {
				position: absolute;
				right: torem(10);
				top: torem(5);
				color: #eee;
				font-size: torem(24)
			}
		}
		.inpt {
			padding-left: 12px;
			font-size: torem(13);
			margin-top: torem(12);
		}
		.inpt {
			padding-left: torem(15);
			font-size: torem(12);
			color: #333;
		}
		li {
			width: 100%;
			display: flex;
			border-top: 1px solid #eee;
			border-bottom: 1px solid #eee;
			justify-content: space-between;
			padding: torem(10) torem(15);
			font-size: torem(12);
			color: #333;
			span:first-child {
				flex-basis: torem(130)
			}
			span:nth-child(2) {
				text-align: center;
				flex-basis: torem(100)
			}
			span:nth-child(3) {
				text-align: center;
				flex-basis: torem(100);
				margin-left: torem(20)
			}
			span:nth-child(4) {
				text-align: right;
				flex-basis: torem(100)
			}
		}
	}
	
	.main-content {
		overflow: auto;
	}
	
	.inpty {
		text-align: center;
	    padding: torem(10) torem(20);
	}
</style>