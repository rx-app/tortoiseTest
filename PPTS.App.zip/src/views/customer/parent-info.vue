<template>


<div style="background:#eee;padding-bottom:30px;">		
    <span v-show="!editing" class="top-btn-edit"  v-power="['编辑潜客信息']" @click="editParentInfo">编辑</span>
		<span v-show="editing" class="top-btn-save" @click="save">保存</span>
		<span v-show="editing" class="top-btn-cancel" @click="cancel">取消</span>
  <div class="student-info" style="overflow:scroll;height:calc(100vh - 65px)">
    <!-- <mt-navbar class="student-info-nav" v-model="navIndex" v-power="['睿学-学员信息-不带电话']">
			<mt-tab-item id="1" @click="this.curIndex=index" v-for="(item,index) in navList"  class="nav-item" :class="{on:curIndex==index}">{{item}}</mt-tab-item>
    </mt-navbar>-->

    <mt-navbar class="student-info-nav" v-model="selected">
      <mt-tab-item @click.native="toStudentView"   id="2">基本信息</mt-tab-item>
      <mt-tab-item id="1">家长信息</mt-tab-item>
      <mt-tab-item @click.native="toRecordView" id="3">跟进记录</mt-tab-item>
    </mt-navbar>

	<div class="info-edit-des">
		注意：<span class="red"><span class="wjx">★</span></span>为必填项，<span class="red">▲</span>为充值所需项，<span class="red">■</span>为关键信息，签约后只允许分审核经理修改。
	</div>
	
    <!-- tab-container -->
    <mt-tab-container v-model="selected">
      <mt-tab-container-item  v-if="!editing"  id="2"></mt-tab-container-item>
			<mt-tab-container-item v-if="editing"  id="2"></mt-tab-container-item>
      <mt-tab-container-item v-if="!editing" id="1">
				<ul  class="parent-tabs">
					<template v-if="parentList.length" >
						<li  v-for="(item,index) in parentList" @click="parentIndex=index" :class="{active:parentIndex==index}"  >{{item.parentName}}{{item.isPrimary==1?'（主）':''}}</li>
					</template>
						<li v-power="['添加孩子家长']" @click.prevent.stop="selectItem('addParent')" >+</li>
						<!-- <li @click="getAddParentModel">+</li> -->
				</ul>

	
				<div v-if="parentList[parentIndex]"  class="info-tab">
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span>▲■</span>家长姓名</div>
						<div class="cell-2">{{parentList[parentIndex].parentName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家长性别</div>
						<div class="cell-2">{{ toParentGender( parentList[parentIndex].gender ) }}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>亲属关系</div>
						<div class="cell-2" v-if="parentList[parentIndex].gender=='2'" >{{parentList[parentIndex].parentRole|parentFemale}}</div>
						<div class="cell-2" v-else-if="parentList[parentIndex].gender=='1'" >{{getParentMale(parentList[parentIndex].parentRole)}}</div>
						<div class="cell-2" v-else > </div>
						<!--  -->
					</div>
					<div class="cell">
						<div class="cell-3 cell-4"><span><span class="wjx">★</span>▲■</span>主要联系方式</div>
						<!-- <div class="cell-2"> </div> -->
					</div>
          <div v-if="isViewTel" class="cell">
            <div class="cell-1"> </div>
						<div class="cell-2">{{parentList[parentIndex].primaryPhone && parentList[parentIndex].primaryPhone.phoneNumber}}</div>
					</div>
          
					<div class="cell">
						<div class="cell-1">辅助联系方式</div>
						<div v-if="isViewTel" class="cell-2">{{parentList[parentIndex].secondaryPhone && parentList[parentIndex].secondaryPhone.phoneNumber}}</div>
						<div v-else class="cell-2"> </div>
					</div>
					<div class="cell">
						<div class="cell-1">是否主监护人</div>
						<div class="cell-2">{{parentList[parentIndex].isPrimary==1?'是':'否'}}</div>
					</div>
				</div>
				<div v-if="parentList[parentIndex]"   class="info-tab">
					<div class="cell" >
						<div class="cell-1">现住址</div>
						<div class="cell-2"></div>
					</div>
          <div class="cell" >
						<!-- <div class="cell-1">现住址</div> -->
						<div class="cell-3">{{parentList[parentIndex].province|region}}{{parentList[parentIndex].city|region}}{{parentList[parentIndex].county|region}}{{parentList[parentIndex].addressDetail}}</div>
					</div>
					
					<div class="cell">
						<div class="cell-1">家长Email</div>
						<div class="cell-2">{{parentList[parentIndex].email}}</div>
					</div>

					<div class="cell">
						<div class="cell-1"><span>■</span>{{getIdType(parentList[parentIndex].idType)}}</div>
						<div class="cell-2">{{parentList[parentIndex].idNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家庭年总收入</div>
						<div class="cell-2">{{parentList[parentIndex].income | homeIncome}}</div>
					</div>
				</div>
			</mt-tab-container-item>
			<mt-tab-container-item v-if="editing" id="1">
				
        <ul v-show="!isAdd"  class="parent-tabs">
          <template v-if="parentList.length" >
						<li v-for="(item,index) in parentList" @click="parentIndex=index" :class="{active:parentIndex==index}"  >{{item.parentName}}{{item.isPrimary=='true'?'（主）':''}}</li>
					</template>
        </ul>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span><span class="wjx">★</span>▲■</span>家长姓名
            </div>
            <div class="cell-2"><input maxlength="30"  @focus="fnFocus" @blur="fnBlur" type="text" placeholder="输入家长姓名" v-model="editingModel.parentName"></div>
          </div>
          <div v-show="f1" class="cell err">
						学生姓名与家长姓名不能相同
					</div>
					<div v-show="f2" class="cell err">
						姓名中包含非法字符，请检查
					</div>
          <div class="cell"  @click.prevent.stop="selectItem('gender')" >
          <!-- <div class="cell"  > -->
            <div class="cell-1">家长性别</div>
						<div class="cell-2 edit">{{ toParentGender2( editingModel.gender ) }}<span class="ar">></span></div>
            <!-- <div class="cell-2"><mt-radio align="right" v-model="editingModel.gender" :options="[{label:'男',value:'1'},{label:'女',value:'2'}]"></mt-radio></div> -->
          </div>
          <div @click.prevent.stop="selectItem('customerRole')" class="cell">
            <div class="cell-1">
              <span>▲</span>亲属关系
            </div>
            <div v-if="sex==2" class="cell-2"><span class="cname">{{pResult.customerName}}</span>是<span class="pname">{{editingModel.parentName}}</span>的{{ getChildRoleFixed(editingModel.customerRole,editingModel.parentRole,editingModel)  }}<span class="ar">></span></div>
            <div v-else-if="sex==1" class="cell-2"><span class="pname">{{pResult.customerName}}</span>是<span class="cname">{{editingModel.parentName}}</span>的{{ getChildRoleFixed(editingModel.customerRole,editingModel.parentRole,editingModel,editingModel) }}<span class="ar">></span></div>
            <div v-else class="cell-2"><span class="pname">{{pResult.customerName}}</span>是<span class="cname">{{editingModel.parentName}}</span>的<span class="ar">></span></div>
          </div>
          <div v-show="showParentRelation" @click.prevent.stop="selectItem('parentRole')"  class="cell">
            <div class="cell-1">
               <span>▲</span>亲属关系
            </div>
            <div v-if="editingModel.gender=='2'" class="cell-2"><span class="pname">{{editingModel.parentName}}</span>是<span class="cname">{{pResult.customerName}}</span>的{{editingModel.parentRole|parentFemale}}<span class="ar">></span></div>
            <div v-if="editingModel.gender=='1'" class="cell-2"><span class="pname">{{editingModel.parentName}}</span>是<span class="cname">{{pResult.customerName}}</span>的{{getParentMale(editingModel.parentRole)}}<span class="ar">></span></div>
          </div>
          <div class="cell">
            <div class="cell-3 cell-4">
              <span><span class="wjx">★</span>▲■</span>主要联系方式
            </div>
            <!-- <div class="cell-2"> </div> -->
          </div>
          
          <div class="cell">
            <div class="cell-1"></div>
            <div v-if="isEditTel" class="cell-2"><input @focus="fnFocus" @blur="fnBlur('phone')" placeholder="输入家长手机号码" type="text" v-model="editingModel.primaryPhone.phoneNumber"></div>
            <div v-else-if="!isEditTel&&isViewTel" class="cell-2"><span>{{editingModel.primaryPhone.phoneNumber}}</span></div>
						<div v-else class="cell-2"><span> </span></div>
          </div>
          <div v-show="f3" class="cell err">
						请检查输入的数据项是否为正确的手机号码！
					</div>
          <div class="cell">
            <div class="cell-1">辅助联系方式</div>
            <!-- <div v-if="isEditTel" class="cell-2"><input @focus="fnFocus" @blur="fnBlur('tel')" placeholder="输入其它电话号码" type="text" v-model="editingModel.secondaryPhone.phoneNumber"></div> -->
            <div v-if="isEditTel" class="cell-2"><input  @focus="fnFocus" @blur="fnBlur('tel')" placeholder="输入其它电话号码" type="text" v-model="editingModel.secondaryPhone.phoneNumber"></div>            
            <div v-else-if="!isEditTel&&isViewTel" class="cell-2"><span>{{editingModel.secondaryPhone.phoneNumber}}</span></div>
						<div v-else class="cell-2"><span> </span></div>

          </div>
          <div v-show="f4" class="cell err">
						请检查输入的数据项是否为正确的电话号码！
					</div>
          <div class="cell">
            <div class="cell-1">是否主监护人</div>
            <div class="cell-2">
							<mt-radio align="right" v-model="editingModel.isPrimary" :options="[{label:'是',value:'true'},{label:'否',value:'false'}]"></mt-radio>
						</div>
          </div>
        </div>
        <div class="info-tab">
          <!-- <div class="cell">
            <div class="cell-1">现住址</div>
            <div class="cell-2">湖南省-长沙市-芙蓉区<span class="ar">></span></div>
          </div> -->
					<div class="cell" @click.prevent.stop="selectItem('province')">
						<div class="cell-1">现住址：省</div>
						<div class="cell-2 edit"> {{getCitys(editingModel.province,1)}} <span class="ar">></span></div>
					</div>
					<div class="cell" @click.prevent.stop="selectItem('city')">
						<div class="cell-1">市</div>
						<div class="cell-2 edit">{{getCitys(editingModel.city,2)}}<span class="ar">></span></div>
					</div>
					<div class="cell" @click.prevent.stop="selectItem('county')">
						<div class="cell-1">县</div>
						<div class="cell-2 edit">{{getCitys(editingModel.county,3)}}<span class="ar">></span></div>
					</div>
					<div class="cell">
            <div class="cell-1">详细地址</div>
            <div class="cell-2"><input @focus="fnFocus" @blur="fnBlur" type="text" v-model="editingModel.addressDetail"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家长Email</div>
            <div class="cell-2"><input @focus="fnFocus" @blur="fnBlur('mail')" placeholder="输入家长常用Email地址" type="text" v-model="editingModel.email"></div>
          </div>
          <div v-show="f5" class="cell err">
						邮箱格式错误，请检查！
					</div>
					<div class="cell" @click.prevent.stop="selectItem('parentIDType')">
						<div class="cell-1"   ><span>■</span>证件类型</div>
						<div class="cell-2 edit">{{editingModel.idType | idtype}}<span class="ar">></span></div>
					</div>
					<div class="cell">
						<div class="cell-1">输入编号</div>
						<div class="cell-2"><input @focus="fnFocus" @blur="fnBlur('id')" placeholder="输入证件号码" type="text" v-model="editingModel.idNumber"></div>
					</div>
          <div v-show="f6" class="cell err">
						输入数据项不是合法身份证号！
					</div>
          <div class="cell"  @click.prevent.stop="selectItem('Income')">
            <div class="cell-1">家庭年总收入</div>
            <div class="cell-2 edit">{{getIncome(editingModel.income) }}<span class="ar">></span></div>
          </div>
        </div>
      </mt-tab-container-item>
      <mt-tab-container-item id="3"></mt-tab-container-item>
    </mt-tab-container>
  </div>
  <select-items
        v-show="itemsParams.isShow"
        :title="itemsParams.title"
        :model="itemsParams.model"
        :isShow="itemsParams.isShow"
        :center="itemsParams.center"
        :category="itemsParams.category"
        :items="itemsParams.selectItems"
        @selectItem="selectVisitType"
      ></select-items>
  </div>
</template>
<script>
import { spr, psr } from "@/constants";
import {
  cell as mtCell,
  Navbar as mtNavbar,
  TabItem as mtTabItem,
	Loadmore as mtLoadmore,
	Actionsheet  as mtActionsheet,
} from "mint-ui";
import {
	getCustomerInfo,
	getAllCustomers,
	getCustomerParents,
	updateCustomerParent,
  updateCustomer,
  createCustomerParent,
  createCustomerParentGet,
} from "@/api/customer/customer-api";
import {
	getCustomerSource,
	getLocationData,
	getSchools,
} from "@/api/metadata/metadata-api";
import { debug } from 'util';
import SelectItems from "@/components/select-items/index";
import { setTimeout } from 'timers';

function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
function resize2() {
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}

export default {
  data() {
    return {
      f1:false,
      f2:false,
      f3:false,
      f4:false,
      f5:false,
      f6:false,
      f7:false,
      f8:false,
      f9:false,
      f10:false,
			itemsParams: {
        isShow: false,
        title: "",
        model: "",
        center:false,
        category: "",
        selectItems: []
      },
      selected: "1",
      navIndex: null,
			curIndex: 0,
			info:{},
			zxs:{},
			xgs:{},
			js:{},
			zxzy:{},
			sczy:{},
			parentList:[],
			restudy:null,
      rawEditingModel:{},
      editingModel:{},
			parentIndex:0,
			navList: ["基本信息", "家长信息", "跟进记录"],
			editing:false,
			clone:{},
			infoSrc:'',
			newInfo:{},
			infoRes:{},
			result:{},
      pResult:{},
      customerName:'',
      oldGender:'',
      isAdd:false,
			areaMess: {
        provinceMess: [],
        cityMess: [],
        countyMess: [],
        provinceName: "省份",
        cityName: "城市",
        countyName: "区县"
      },
      editOrAdd:'',
      pm:{},
      addRes:{},
      showParentRelation:false,
      isDataChange:false,
      
    };
	},
	created(){
		this.init();
		if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
    document.querySelector('.xd-header').style.position='fixed'
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
  },
	computed:{
    isEditTel(){
			return m2.util.getPermionLoad('修改潜客联系方式')
		},
		isViewTel(){
			return m2.util.getPermionLoad('查看联系方式')
		},
		sex(){
      
      return this.$route.query.sex;
    },
		editingModel2(){
			if(!this.rawEditingModel.primaryPhone){
				this.rawEditingModel.primaryPhone={}
			}
			if(!this.rawEditingModel.secondaryPhone){
				this.rawEditingModel.secondaryPhone={}
			}




			return this.rawEditingModel
    },
    cName(){
      
      return this.$route.query.cname;
    },
	},
	mounted(){
		// this.$nextTick(()=>{
		// 		this.editing=true
		// })
		
    // this.selectVisitType()
    this.fontFixed();
    
	},
	watch:{
    "editingModel":{
      
      handler:function(d1,d2,d3){
        this.isDataChange=true;
        // console.log(d2)
        // console.log(d3)
      },
      deep:true,
    },
    "editingModel.primaryPhone.phoneNumber":{
      handler:function(d1){
				if(d1==''){
					this.f3=false;
				}
        if(  (/^\d{11}$/.test( d1 )) && d1.length==11 ){
					this.f3=false;
				}else{
					
				}
      },
    },
    "editingModel.secondaryPhone.phoneNumber":{
      handler:function(d1){
				if(d1==''){
					this.f4=false;
				}
        if(  (/(^1[1-9]\d{9}$)|(^\d{3,4}-\d{7,8}-\d{1,5}$)|(^\d{3,4}-\d{7,8}$)/.test( d1 )) && d1.length==11 ){
					this.f4=false;
				}else{
					
				}
      },
    },
    "editingModel.email":{
      handler:function(d1){
        
				if(d1==''){
					this.f5=false;
				}
        if(  (/^[0-9a-z][_.0-9a-z-]{0,31}@([0-9a-z][0-9a-z-]{0,30}[0-9a-z]\.){1,4}[a-z]{2,4}$/.test( d1 )) ){
					this.f5=false;
				}else{
					
				}
      },
    },
    "editingModel.idNumber":{
      handler:function(d1){
				if(d1==''){
					this.f6=false;
				}
        if( (this.editingModel.idType==1)&& ( this.editingModel.idNumber && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.editingModel.idNumber)) ){
					
				}else{
					this.f6=false;
				}
      },
    },
    "editingModel.idType":{
      handler:function(d1){
				if(d1!=1){
					this.f6=false;
				}else{
          if( (this.editingModel.idType==1)&& ( this.editingModel.idNumber && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.editingModel.idNumber)) ){
            this.f6=true;
				  }
        }
      },
		},
    "editingModel.parentName":{
      handler:function(d1){
        if( d1==this.cName ){
					this.f1=true;
				}else if( !(/^[\u4e00-\u9fa5]{1,30}$/.test(d1)) && d1){
					this.f2=true;
				}else{
					this.f1=false;
					this.f2=false;
				}
      },
		},
    // "editingModel.gender":{
    //   handler:function(data){
    //     // debugger
    //     console.log(this.editingModel.parentRole)
    //     if (data =='1') {
    //       this.editingModel.parentRole=((this.editingModel.parentRole)*1-1).toString()
    //     }
    //     if (data =='2') {
    //       this.editingModel.parentRole=((this.editingModel.parentRole)*1+1).toString()
    //     }
    //     console.log(this.editingModel.parentRole)
    //   },
    // },
		// "editingModel.province"(obj) {
    //   debugger
    //   if (!obj) return;
    //   this.getLocationDataFun("city", obj);
    //   this.areaMess.cityName = "城市";
    //   this.areaMess.countyName = "区县";
    //   // this.editingModel.city = null;
    //   // this.editingModel.county = null;
    // },
    // "editingModel.city"(obj) {
      
    //   if (!obj) return;
    //   this.getLocationDataFun("county", obj);
    //   this.areaMess.countyName = "区县";
    //   // this.editingModel.county = null;
    // },
	},
	methods:{
		 init(){
			let id = this.$route.query.id;
      this.viewDetail(id);
    },
    toParentGender(sex){
      let v = this.$options.filters.gender(sex);
      return v || '未知';
    },
    toParentGender2(sex){
      let v = this.$options.filters.gender(sex);
      return v || '请选择性别';
    },
    fontFixed(){
      // alert(mui.os.ios)
      
      if(mui.os.ios){
        let size = getComputedStyle(document.querySelector('.wjx'))['font-size'].replace('px','')*0.8+'px';
        [...document.querySelectorAll('.wjx')].forEach(v=>{
         v.style.fontSize=size}
        )
      }
    },
    fontFixed2(){
      if(mui.os.ios){
        let size = getComputedStyle(document.querySelector('.wjx'))['font-size'].replace('px','')*1+'px';
        [...document.querySelectorAll('.wjx')].forEach(v=>v.style.fontSize=size)
      }
    },
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "765px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
        //mui.alert('---tttt----')
        //mui('header')[0].style.transform='translateY(-10px)'
      }
    },
    fnBlur(t) {
      if(t=="phone"){
				if(  !(/^\d{11}$/.test( this.editingModel.primaryPhone.phoneNumber ))  &&  this.editingModel.primaryPhone.phoneNumber ){
					this.f3=true;
				}else{

				}
      }
      if(t=="tel"){
				if(  !(/(^1[1-9]\d{9}$)|(^\d{3,4}-\d{7,8}-\d{1,5}$)|(^\d{3,4}-\d{7,8}$)/.test( this.editingModel.secondaryPhone.phoneNumber ))  &&  this.editingModel.secondaryPhone.phoneNumber ){
					this.f4=true;
				}else{

				}
			}
			if(t=="id"){
				if((this.editingModel.idType==1)&&( this.editingModel.idNumber && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.editingModel.idNumber))){
					this.f6=true
				}
      }
      if(t=="mail"){
				if(this.editingModel.email && !(/^[0-9a-z][_.0-9a-z-]{0,31}@([0-9a-z][0-9a-z-]{0,30}[0-9a-z]\.){1,4}[a-z]{2,4}$/.test(this.editingModel.email)) ){
					this.f5=true
				}
			}
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    toStudentView(){
      this.$router.push({name:'studentInfo',query:{id:this.$route.query.id,refer:this.$route.query.refer}})
    },
    toRecordView(){
      this.$router.push({name:'records',query:{id:this.$route.query.id,sex:this.$route.query.sex,cname:this.$route.query.cname,refer:this.$route.query.refer}})
      // this.$router.push({name:'records',query:{id:this.$route.query.id,refer:this.$route.query.refer}})
    },
    getAddParentModel(flag){
      this.editOrAdd='add';
      this.isAdd=true;
      createCustomerParentGet({id:this.$route.query.id}, async res=>{
        console.log('resssssssssssssssss')
        console.log(res)
        console.log('resssssssssssssssss')
        
        this.addRes=res;
        this.editingModel=res.parent;
        this.editingModel.customerID=res.customer.customerID;
        
        if(this.editingModel.parentRole){
          this.showParentRelation=true;
        }else{
          this.showParentRelation=false;
        }
        if(!this.editingModel.primaryPhone){
          this.editingModel.primaryPhone={}
        }
        if(!this.editingModel.secondaryPhone){
          this.editingModel.secondaryPhone={}
        }
        this.editing=true;
        if(flag){
          // this.editingModel.province=
        }
        await this.getLocationDataFun("province", 0);
        await this.getLocationDataFun("city", this.editingModel.province);
        await this.getLocationDataFun("county", this.editingModel.city);
        
        this.$nextTick(a=>{this.fontFixed2();})
        setTimeout(() => {
          this.isDataChange=false;
        },100);
        // console.log(res)
      })
    },
    addParent(){
      let param = {...this.addRes,customerParentRelation:{
					customerID:this.editingModel.customerID,
					parentID:this.editingModel.parentID,
					customerRole:this.editingModel.customerRole,
					parentRole:this.editingModel.parentRole,
					isPrimary:this.editingModel.isPrimary,
				}}
      createCustomerParent(param,res=>{
        if(res==''){
          mui.alert('保存成功')
          // this.editing=false;
          // this.init();
          this.cancelEdit();
        }
        console.log(res)
      })
    },
	
		//获取省份
    getLocationDataFun(type, key) {
      if(!key&&key!==0) return
      getLocationData(
        {
          parentKey: key
        },
        res => {
          console.log(res)
          if (type == "province") {
            this.areaMess.provinceMess = res;
          } else if (type == "city") {
            this.areaMess.cityMess = res;
          } else if (type == "county") {
            this.areaMess.countyMess = res;
          }
        }
      );
    },
		getInfoSource(key,secKey){
			if(key || key=='0'){
				let r={}
				getCustomerSource({parentKey:key},res=>{
					r= res.find((v) => (v.key == secKey))
					this.infoSrc=r.value
				})
				
			}
		},
		idTypeName(id){
			switch(id){
				case 0:return '身份证';
				case 1:return '学生证';
				default :return '其它证件'
			}
		},
		showBox(){
			this.itemsParams.isShow = true;
		},
		viewHistory(tea){
			if(tea && tea.customerID){
				this.$router.push({name:'teacherHistory',query:{type:tea.relationType,id:tea.customerID}})
			}else{
				return false;
			}
    }, 
    saveHandle(){
       // this.saveInfo();
      if( !this.checkData() ) return
      if(this.editOrAdd=='edit'){
        this.saveParentInfo();
      }else if(this.editOrAdd=='add'){
        this.addParent();
      }
    },
		save(){
      if (/Android/gi.test(navigator.userAgent)) {
        mui.confirm("确定要保存吗？", "提示",["确认","取消"], e => {
          if (!e.index) {
            this.saveHandle()
          }
        });
			}else{
        mui.confirm("确定要保存吗？", "提示",["取消","确认"], e => {
          if (e.index) {
            this.saveHandle()
          }
        });
			}

    
    },
    checkData(){
      if( !(this.editingModel.parentName) ){
				mui.alert('家长姓名为必填项，请输入')
				return false
      }
      if( this.editingModel.parentName==this.pResult.customerName ){
				mui.alert('家长姓名不能和孩子姓名重复，请检查')
				return false
      }
      if( !(this.editingModel.primaryPhone.phoneNumber) ){
				mui.alert('主要联系方式为必填项，请输入')
				return false
      }
      
      if( !(/^[\u4e00-\u9fa5]{1,30}$/.test(this.editingModel.parentName)) ){
				mui.alert('姓名输入有误，请检查')
				return false
      }
      if(this.editingModel.email && !(/^[0-9a-z][_.0-9a-z-]{0,31}@([0-9a-z][0-9a-z-]{0,30}[0-9a-z]\.){1,4}[a-z]{2,4}$/.test(this.editingModel.email)) ){
				mui.alert('邮箱格式输入有误，请检查')
				return false
      }
			if(  this.editingModel.primaryPhone.phoneNumber &&   !(/^\d{11}$/.test( this.editingModel.primaryPhone.phoneNumber ))   ){
				mui.alert('主要联系方式输入有误，请检查')
				return false
      }
      if(  this.editingModel.secondaryPhone.phoneNumber && !(/(^1[1-9]\d{9}$)|(^\d{3,4}-\d{7,8}-\d{1,5}$)|(^\d{3,4}-\d{7,8}$)/.test( this.editingModel.secondaryPhone.phoneNumber ))  ){
				mui.alert('辅助联系方式输入有误，请检查')
				return false
      }
      
			if( (this.editingModel.idType==1)&& ( this.editingModel.idNumber && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.editingModel.idNumber)) ){
				mui.alert('身份证号码输入有误，请检查')
				return false
			}
			return true;
		},
		saveInfo(){
      updateCustomer(this.infoRes,(res)=>{
        console.log(res)
      })
      
			
    },
    getIncome(c){
      return this.$options.filters.homeIncome(c)?this.$options.filters.homeIncome(c):'请选择'
    },
    getParentMale(c){
      return c=='25'?'伯父':this.$options.filters.parentMale(c);
    },
    getChildRoleFixed(cr,pr,m){
      try {
        let v = psr.find(r=>r.key==pr).r.find( r=>r.ss==this.sex)
        if(v.key!=v.cr){
          m.customerRole=v.key;
        }
        return v.value;
      } catch (error) {
        let v = this.$options.filters.childMale(cr) || this.$options.filters.childFemale(cr);
        return v;
      }
      

      // let v = this.$options.filters.childMale(c) || this.$options.filters.childFemale(c);
      
    },
    getIdType(c){
      return this.$options.filters.idtype(c)?this.$options.filters.idtype(c):'证件号码'
    },
    getCitys(c,a){
      let res=''
      switch(a){
        case 1:res='省';break;
        case 2:res='市';break;
        case 3:res='县';break;
      }
      return this.$options.filters.region(c)?this.$options.filters.region(c) :'请选择'+res;
    },
		saveParentInfo(){
			
			let customerID=this.editingModel.customerID;
			
			console.log(this.editingModel)
			console.log(this.parentList[this.parentIndex])
			// console.log(this.editParentInfo())
			// console.log({...this.editParentInfo()})

			// console.log(this.editParentInfo.customerID)
			updateCustomerParent({
				customer:this.info,
				// customerID,
				parent:this.editingModel,
				customerParentRelation:{
					customerID:this.editingModel.customerID,
					parentID:this.editingModel.parentID,
					customerRole:this.editingModel.customerRole,
					parentRole:this.editingModel.parentRole,
					isPrimary:this.editingModel.isPrimary,
				},
			},(res)=>{
        if(res==''){
          mui.alert('保存成功')
          // this.editing=false;
          // this.init();
          this.cancelEdit();
        }
			})
    },
    cancel(){
      
      if(!this.isDataChange){
        
        this.editing=false;
        // this.cancelEdit();
      }else{
        if (/Android/gi.test(navigator.userAgent)) {
          
          mui.confirm("确定要取消吗？", "提示",["确认","取消"], e => {
            if (!e.index) {
              this.cancelEdit();
            }
          });
        }else{
          mui.confirm("确定要取消吗？", "提示",["取消","确认"], e => {
            if (e.index) {
              this.cancelEdit();
            }
          });
        }
       
      }
      
    },
		cancelEdit(){
			this.editing=false;
			this.init();
			// this.rawEditingModel=this.clone
		},
	  async	editParentInfo(){
      
      this.editing=true;
      this.isAdd=true;
      this.editOrAdd='edit'
      this.editingModel=this.parentList[this.parentIndex];
      if(this.editingModel.parentRole){
        this.showParentRelation=true;
      }else{
        this.showParentRelation=false;
      }
      if(!this.editingModel.primaryPhone){
				this.editingModel.primaryPhone={}
			}
			if(!this.editingModel.secondaryPhone){
				this.editingModel.secondaryPhone={}
			}
      // this.oldGender=this.editingModel.gender;
      // this.newInfo=this.info;
      
      await this.getLocationDataFun("province", 0);
      await this.getLocationDataFun("city", this.editingModel.province);
      await this.getLocationDataFun("county", this.editingModel.city);
      setTimeout(() => {
        this.isDataChange=false;
      },100);
			
			// this.rawEditingModel=this.parentList[this.parentIndex];
			
			// this.clone=copy(this.rawEditingModel,this.clone)
		},
		viewDetail(id){
      getCustomerInfo({id}, res => {
        console.log(res)
        
				this.infoRes=res;
				this.info=res.customer;
				this.result=res;
				this.getInfoSource(this.info.sourceMainType,this.info.sourceSubType)
        res.customerStaffRelations.forEach((v)=>{
					if(v.relationType==1){
						this.zxs=v;
					}else if(v.relationType==2){
						this.xgs=v;
					}else if(v.relationType==3){
						this.js=v;
					}else if(v.relationType==4){
						this.zxzy=v;
					}else if(v.relationType==5){
						this.sczy=v;
					}
				})
			});
			getCustomerParents({id},res=>{
				console.log(res)
        this.pResult=res;
        
        this.parentList=res.queryResult;
        this.$nextTick(a=>{this.fontFixed2();})
        
				console.log(this.parentList)
				// console.log(this.parentList[0].parentName)
			})
		},
		selectItem(category) {
      this.itemsParams.isShow = true;
      this.itemsParams.center = false;
      this.itemsParams.category = category;
      switch (category) {
        case "branchID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.result.customer.branchID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "addParent":
          this.itemsParams.title = "添加方式";
          this.itemsParams.center = true;
          // this.itemsParams.model = this.result.customer.branchID;
          this.itemsParams.selectItems = [{key:2,value:'添加已有家长'},{key:1,value:'新建家长'}];
          break;
        case "campusID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.result.customer.campusID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;

        case "contactType":
          this.itemsParams.title = "接触方式";
          this.itemsParams.model = this.result.customer.contactType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceMain":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.result.customer.sourceMainType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceSec":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.result.customer.sourceSubType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "tutoringWill":
          this.itemsParams.title = "辅导意愿";
          this.itemsParams.model = this.result.customer.tutoringWill;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentRole":
          if(this.sex==1||this.sex==2){
            this.itemsParams.title = "亲属关系";
            // this.itemsParams.model = this.parentRoleKey;
            this.itemsParams.model = this.editingModel.parentRole;
            this.itemsParams.selectItems = this._getSelectItems(category);
          }else{
            mui.alert('请先补充完整学员性别');
            this.itemsParams.isShow = false;
          }
          break;
        case "customerRole":
          if(this.sex==1||this.sex==2){
            this.itemsParams.title = "亲属关系";
            // this.itemsParams.model = this.customerRoleKey;
            this.itemsParams.model = this.editingModel.customerRole;
            this.itemsParams.selectItems = this._getSelectItems(category);
          }else{
            mui.alert('请先补充完整学员性别');
            this.itemsParams.isShow = false;
          }
				  break;
				case "province":
          this.itemsParams.title = "省";
          this.itemsParams.model = this.editingModel.province;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "city":
          this.itemsParams.title = "市";
          this.itemsParams.model = this.editingModel.city;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "county":
          this.itemsParams.title = "县/区";
          this.itemsParams.model = this.editingModel.county;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentIDType":
          this.itemsParams.title = "家长证件类型";
          this.itemsParams.model = String(this.editingModel.idType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "Income":
          this.itemsParams.title = "家庭年收入";
          this.itemsParams.model = String(this.editingModel.income);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "gender":
          this.itemsParams.title = "性别";
          this.itemsParams.model = this.editingModel.gender;
          this.itemsParams.selectItems = xdapp.dict.c_code_abbr_gender


          break;

      }
    },
		_getSelectItems(category) {
      let res = [];
      let parentGender = this.result.parent.gender;
      let customerGender = this.result.customer.gender;
      switch (category) {
        case "branchID":
          res = this.departMentObj.branchMess;
          break;
        case "campusID":
          res = this.departMentObj.campusMess;
          break;
        case "contactType":
          res = this.result.dictionaries
            .C_CODE_ABBR_Customer_CRM_NewContactType;
          break;
        case "sourceMain":
          res = this.sourceType.sourceMainMess;
          break;
        case "sourceSec":
          res = this.sourceType.sourceSecMess;
          break;
        case "tutoringWill":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_TutorWill;
          break;
        case "customerRole":
          
          console.log(psr)
          console.log(spr)
          // let list= psr.filter((v,i)=>{
          //   return v.key==this.editingModel.parentRole && v.ps ==this.editingModel.gender
          // })
          let list= spr.filter((v,i)=>{
            return v.ss ==this.sex
          })
          res = list
          // console.log(list)
          // if(this.sex==1){
            
            
          //   res= xdapp.dict.c_code_abbr_childmaledictionary
          // }else if(this.sex==2){
            
          //   res= xdapp.dict.c_code_abbr_childfemaledictionary
          // }
          break;
        case "parentRole":
          // debugger
          let list2= spr.filter((v,i)=>{
            return v.key==this.editingModel.customerRole && v.ss ==this.sex
          })
          try {
              res = list2[0].r.filter((v)=>{
              return v.ps==this.editingModel.gender;
              this.showParentRelation=true
            })
          } catch (error) {
            this.showParentRelation=false
            // res=[]
          }
          
          // if(this.editingModel.gender=='1'){
          //   res= xdapp.dict.c_code_abbr_parentmaledictionary
          // }else if(this.editingModel.gender=='2'){
          //   res= xdapp.dict.c_code_abbr_parentfemaledictionary
          // }
          break;
        case "referralStaffJobID":
          res = this.referralStaffJobArr;
          break;
        case "parentIDType":
          res = this.result.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
				case "Income":
          res = this.pResult.dictionaries.C_CODE_ABBR_HOMEINCOME;
          break;
        case "province":
          res = this.areaMess.provinceMess;
          break;
        case "city":
          res = this.areaMess.cityMess;
          break;
        case "county":
          res = this.areaMess.countyMess;
          break;
        case "entranceGrade":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
					break;
				case "grade":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
          break;
        case "subjectType":
          res = this.result.dictionaries.C_CODE_ABBR_STUDENTBRANCH;
          break;
        case "schoolYear":
          res = this.result.dictionaries.C_CODE_ABBR_ACDEMICYEAR;
          break;
        case "customerIDType":
          res = this.result.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
        case "vipType":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_VipType;
          break;
        case "vipLevel":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_VipLevel;
          break;
        default:
          break;
      }
      return res;
    },
		selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "gender":
            this.editingModel.gender = obj.item.key;
            try {
              let list4 = spr.filter(v=>v.key==this.editingModel.customerRole && v.ss == this.sex)
              let r2=(list4[0].r.filter(v=>v.ps==this.editingModel.gender))[0].key
              this.editingModel.parentRole = r2;
              this.showParentRelation=true
            } catch (error) {
              this.showParentRelation=false
            }
            
            break;
          case "branchID":
            this.result.customer.branchID = obj.item.key;
            this.departMentObj.branchName = obj.item.value;
            break;
          case "campusID":
            this.result.customer.campusID = obj.item.key;
            this.result.customer.campusName = obj.item.value;
            break;
          case "sourceMain":
            this.result.customer.sourceMainType = obj.item.key;
            this.sourceType.sourceMainName = obj.item.value;
            break;
          case "addParent":
            if(obj.item.key==1){
              this.getAddParentModel(1);
            }else{
              this.$router.push({name:'addedParent',query:{cname:this.$route.query.cname,id:this.$route.query.id}})
            }
            break;
          case "sourceSec":
            this.result.customer.sourceSubType = obj.item.key;
            this.sourceType.sourceSecName = obj.item.value;
            break;
          case "contactType":
            this.result.customer.contactType = obj.item.key;
            break;
          case "tutoringWill":
            this.result.customer.tutoringWill = obj.item.key;
            break;
          case "customerRole":
            this.editingModel.customerRole = obj.item.key;
            try {
              let list3 = spr.filter(v=>v.key==this.editingModel.customerRole && v.ss == this.sex)
              let r=(list3[0].r.filter(v=>v.ps==this.editingModel.gender))[0].key
              this.editingModel.parentRole = r;
              this.showParentRelation=true
            } catch (error) {
              this.showParentRelation=false
            }
            
            // this.customerRoleKey = obj.item.key;
            break;
          case "parentRole":
            this.editingModel.parentRole = obj.item.key;
            this.itemsParams.model = this.editingModel.customerRole;
            // this.editingModel.customerRole = obj.item.key;
            // this.parentRoleKey = obj.item.key;
            break;
          case "referralStaffJobID":
            //判断存储OA人员岗位列表  是否有用户手动选择的
            if (this.referralStaffJobArr.length) {
              this.referralStaffJobArr.forEach(item => {
                if (item.key == obj.item.key) {
                  this.result.customer.referralStaffJobID = obj.item.key;
                  this.result.customer.referralStaffJobName = obj.item.value;
                } else {
                  this.result.customer.referralStaffJobID = this.referralStaffJobArr[0].key;
                  this.result.customer.referralStaffJobName = this.referralStaffJobArr[0].value;
                }
              });
            } else {
              this.result.customer.referralStaffJobID = obj.item.key;
              this.result.customer.referralStaffJobName = obj.item.value;
            }
            break;
          case "parentIDType":
            this.editingModel.idType = obj.item.key;
            break;
          case "Income":
            this.editingModel.income = obj.item.key;
            break;
          case "province":
            this.editingModel.province = obj.item.key;
            this.getLocationDataFun("city", this.editingModel.province);
            this.areaMess.cityName = "城市";
            this.areaMess.countyName = "区县";
            this.editingModel.city = null;
            this.editingModel.county = null;
            this.areaMess.provinceName = obj.item.value;
            break;
          case "city":
            this.editingModel.city = obj.item.key;
            this.getLocationDataFun("county", this.editingModel.city);
            this.areaMess.countyName = "区县";
            this.editingModel.county = null;
            this.areaMess.cityName = obj.item.value;
            break;
          case "county":

            this.editingModel.county = obj.item.key;
            this.areaMess.countyName = obj.item.value;
            break;
          case "entranceGrade":
            this.result.customer.entranceGrade = obj.item.key;
						break;
					case "grade":
            this.result.customer.grade = obj.item.key;
            break;
          case "subjectType":
            this.result.customer.subjectType = obj.item.key;
            break;
          case "schoolYear":
            this.result.customer.schoolYear = obj.item.key;
            break;
          case "customerIDType":
            this.result.customer.idType = obj.item.key;
            break;
					case "vipType":
						if(obj.item.key == 3){
							this.result.customer.vipLevel=null;
						}
            this.result.customer.vipType = obj.item.key;
            break;
          case "vipLevel":
            this.result.customer.vipLevel = obj.item.key;
            break;
        }
      }
    },
	},
  components: {
    SelectItems,
  }
};
</script>

<style lang="scss">
html,body{
	height: 100%;
	overflow: hidden;
}
.student-info {
  // position: absolute;
  // width: 100%;
  // left: 0;
  // right: 0;
  // top:torem(35);
  // bottom: 0;
  // overflow-y: scroll;
  // -webkit-overflow-scrolling: touch; /* 解决ios滑动不流畅问题 */


	.mint-radiolist{display: flex}
	.mint-radiolist *{margin: 0}
	.mint-cell-wrapper,.mint-radiolist,.mint-cell{height: torem(16);line-height: torem(16)}
	.mint-radiolist .mint-cell{    background: transparent;}
	.mint-cell-wrapper{background: none;transform: translateY(-8px);}

	span.mint-radio-label{display: inline-block;transform:translateX(-20px);}
	.mint-radiolist-title{margin-left: 0}
}
</style>

<style lang='scss' scoped>
.edit{
	color: #aaa;
	span{color:#333}
}
.cname{
  color:rgb(60, 41, 223);
  display: inline-block;
  min-width: 10vw;
}
.pname{
  color:#f17b43;;
  display: inline-block;
  min-width: 10vw;
}
span.red{
			color:red;
			font-size: torem(16);
			.wjx{font-size:torem(20)}
		}
.top-btn-edit{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 990;
}
.top-btn-save{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 990;
}
.top-btn-cancel{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 60px;
	color: #fff;
	z-index: 990;
}
  .ar{float: right;}
.parent-tabs {

  margin-bottom: 10px;
  font-size: 0px;
  li {
		&.active{    
			background-image: linear-gradient(90deg, #FF9900 0%, #FFB82A 100%);
			height: 100%;
			border-bottom: none!important;
			color: #fff!important;
		}
    background: #fff;
    display: inline-block;
    font-size: torem(16);
    line-height: torem(16);
    padding: torem(8);
    border-right: 1px solid #ddd;
    // width:30vw;
    &.on {
      background: #888;
    }
  }
}
.student-info {
	.mint-radiolist{display: flex}
	span.mint-radio-label{display: inline-block;transform:translateX(-15px);}
  .student-info-nav {
    margin-top: 16px;
    width: 100%;
    margin-left: 0;
    border-radius: 5px;
    overflow: hidden;
  }
  background: #eee;
  padding: 5px 10px 20px;
  .info-edit-des {
    font-size: torem(16);
    color: #888;
    margin: 15px 0;
  }
  .info-tab {
    background: #fff;
    margin: 0 0 15px;
    padding-bottom: 10px;
    .cell {
      display: flex;
      font-size: torem(16);
      line-height: torem(32);
      margin: torem(5) torem(8);
      border-bottom: torem(1) solid #ddd;
      &.err{
				text-align: center;
				color:red;
				display: block;
				font-size: torem(14);
			}
      .cell-1 {
        span {
          color: red;
          font-size: torem(16);
					.wjx{font-size:torem(20)}
        }
        flex: 4;
        text-align: right;
        padding-right: 20px;
      }
      
      .cell-3 {
        &.cell-4{
          span {
            color: red;
            font-size: torem(16);
            .wjx{font-size:torem(20)}
          }
        }
        span {
          color: red;
          font-size: torem(20);
        }
         input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(24);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
        // padding-left: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(24);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
    }
  }
}

.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
