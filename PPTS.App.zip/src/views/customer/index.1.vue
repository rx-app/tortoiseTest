<template>
  <div class="wrap">
    <course-header :items="items"></course-header>
    <customer-list></customer-list>
  </div>
</template>
<script>
import courseHeader from "./partials/course-header.vue";
import customerList from "./partials/customer-list.vue";
export default {
  data() {
    return {
      items: [
        {
          title: "学员",
          pathname: "customer",
          icon_active: require("@/public/asset/img/course/customer-on.png"),
          icon: require("@/public/asset/img/course/customer-off.png"),
          active: true,
          functions: "睿学-学员列表"
        },
        {
          title: "成绩",
          pathname: "score",
          icon_active: require("@/public/asset/img/course/ppts-score-on.png"),
          icon: require("@/public/asset/img/course/ppts-score.png"),
          active: false,
          functions: "睿学-成绩列表"
        },
        {
          title: "回访",
          pathname: "returnVisit",
          icon_active: require("@/public/asset/img/course/return-on.png"),
          icon: require("@/public/asset/img/course/return-off.png"),
          active: false,
          functions: "睿学-回访列表"
        },
        {
          title: "家长会",
          pathname: "parentMeet",
          icon_active: require("@/public/asset/img/course/parent-on.png"),
          icon: require("@/public/asset/img/course/parent-off.png"),
          active: false,
          functions: "睿学-家长会列表"
        }
      ]
    };
  },
  components: {
    courseHeader,
    customerList
  }
  // created() {
  // 	document.querySelector('.xd-header').style.position='absolute'
  // },
  // destroyed() {
  // 	document.querySelector('.xd-header').style.position='fixed'
  // },
  /*beforeRouteLeave(to, from, next) {
			from.meta.keepAlive = false;
			if(to.name=='customerMess'){
				from.meta.keepAlive=true;
			}else{
				from.meta.keepAlive=false;
			}
			next();
		},*/
};
</script>
<style>
/* .xd-header {
		position: absolute;
		top:0;
		left: 0;
		z-index: 9999;
	}
	html,body{
		height: 100%;
		overflow: hidden;
	} */
</style>

<style lang='scss' scoped>
.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
