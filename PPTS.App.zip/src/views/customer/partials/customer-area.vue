<template>
  <div class="xd-select-student">
    <div class="students-head">
      <p class="inp">
        <input
          type="text"
          placeholder="输入学员姓名/编号进行查询"
          v-model="inpVal"
          @click="inpFocus()"
          @blur="inpBlur"
        >
        <i class="iconfont icon-found" @click="searchStudents()"></i>
      </p>
      <mt-navbar v-model="selected" v-power="['睿学-学员信息-不带电话']">
        <mt-tab-item id="1" @click.stop.prevent="switchTabs('1')" class="todayStu">今日上课学员</mt-tab-item>
        <mt-tab-item id="2" @click.stop.prevent="switchTabs('2')" class="allStu">所有学员</mt-tab-item>
      </mt-navbar>
      <!-- tab-container  -->
      <div id="cus-main-content" class="main-content" v-power="['睿学-学员信息-不带电话']">
        <mt-loadmore
          class="loadMore"
          :top-method="loadTop"
          :bottom-method="loadBottom"
          :auto-fill="false"
          :bottom-all-loaded="allLoaded"
          :bottom-distance="-70"
          ref="loadmore"
        >
          <mt-tab-container v-model="selected">
            <mt-tab-container-item id="1">
              <div class="students-list">
                <tip v-if="!todayStudents.length">
                  <span>没有查询到任何记录</span>
                </tip>
                <ul>
                  <li
                    v-for="(item,index) in todayStudents"
                    :key="index"
                    :class="item.current?'selectStudent':''"
                  >
                    <span
                      @tap="goCustomeMess(item.customerID)"
                      class="customer-name"
                    >{{item.customerName}}</span>
                    <span class="customer-code">{{item.customerCode}}</span>
                    <span class="customer-mess">
                      <p>
                        <a
                          :href="'tel:'+item.parentPhone"
                          v-power="['睿学-联系家长']"
                          v-if="item.parentPhone"
                        >
                          <i class="iconfont icon-phone"></i>
                        </a>
                      </p>
                      <i class="iconfont icon-message" @tap="todoLink(item)"></i>
                    </span>
                  </li>
                </ul>
              </div>
            </mt-tab-container-item>
            <mt-tab-container-item id="2">
              <ol class="filterStatus">
                <li
                  v-for="(item,index) in filterStatus"
                  :key="index"
                  @tap="getStatus(item.value)"
                  :class="item.current?'slected':''"
                >{{item.desc}}</li>
              </ol>
              <div class="students-list">
                <tip v-if="!allStudents.length">
                  <span>没有查询到任何记录</span>
                </tip>
                <ul class="statusStudent">
                  <li v-for="(item,index) in allStudents" :key="index">
                    <span
                      @tap="goCustomeMess(item.customerID)"
                      class="customer-name"
                    >{{item.customerName}}</span>
                    <span class="customer-code">{{item.customerCode}}</span>
                    <span class="customer-mess">
                      <p>
                        <a
                          :href="'tel:'+item.parentPhone"
                          v-power="['睿学-联系家长']"
                          v-if="item.parentPhone"
                        >
                          <i class="iconfont icon-phone"></i>
                        </a>
                      </p>
                      <i class="iconfont icon-message" @tap="todoLink(item)"></i>
                    </span>
                  </li>
                </ul>
              </div>
            </mt-tab-container-item>
          </mt-tab-container>
        </mt-loadmore>
      </div>
    </div>
  </div>
</template>

<script>
import Tip from "@/components/tip";
import { ACTION_TYPES, CUSTOMER_STATUS, ReplyLinkType } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import {
  getTodayHasCourseCustomers,
  getCurrentJobCustomers
} from "@/api/customer/customer-api";
import { getHead, getHeadIDsByUserIDs } from "@/api/user/user-api";
import { pager, orderBy } from "@/public/constant";
import {
  Navbar as mtNavbar,
  TabItem as mtTabItem,
  Loadmore as mtLoadmore
} from "mint-ui";
import resize from "@/public/lib/resize";
export default {
  mixins: [resize],
  data() {
    return {
      inpVal: "",
      allStudents: [],
      todayStudents: [],
      filterStatus: CUSTOMER_STATUS,
      selected: null,
      pageIndex: 1,
      pageSize: 20,
      zeed: 0,
      replyObject: "", //当前登录人身份
      allLoaded: false,
      scrollMode: "auto"
    };
  },
  created() {
    mui.plusReady(function() {
      plus.webview.currentWebview().setStyle({ softinputMode: "adjustResize" });
    });
  },
  methods: {
    inpFocus() {
      // var h = document.body.scrollHeight;
      console.log(this.$route.name);
      // this.focus_footer(h);
      if (mui.os.ios) {
        document.querySelector("footer").style.display = "none";
      }
    },
    inpBlur() {
      if (mui.os.ios) {
        document.querySelector("footer").style.display = "block";
      }
    },
    focus_footer(h) {
      var _this = this;
      window.onresize = function() {
        if (document.body.scrollHeight < h) {
          if (_this.$route.name == "customer") {
            xdapp.footer.style.display = "none";
          }
        } else {
          if (_this.$route.name == "customer") {
            xdapp.footer.style.display = "block";
          }
        }
      };
    },
    goCustomeMess(customerID) {
      this.$router.push({
        name: "customerMess",
        query: {
          customerID: customerID,
          tab: this.selected
        }
      });
    },
    _goToMess(item, res) {
      this.$router.push({
        name: "message-customer-reply",
        query: {
          icons: res[0],
          parentID: item.parentUUID,
          parentIconID: item.parentIconID,
          staffId: item.customerID,
          replyType: ReplyLinkType.Conection,
          replyObject: this.replyObject,
          title: item.customerName,
          tab: this.selected
        }
      });
    },
    todoLink(item) {
		  var _this = this;
      if (item.parentUUID) {
        getHeadIDsByUserIDs(
          [{ type: "3", userID: item.parentUUID }],
          res => {
			  _this._goToMess(item,res)
		  }
        );
      } else {
        _this._goToMess(item,[{}])
      }
    },
    searchStudents() {
      this.clearData();
      this.navKind();
    },
    async getCustomerList() {
      await loadUserInfo();

      let params = {
        CustomerName: this.inpVal.trim(),
        startDateBegin: m2.date.today(),
        startDateEnd: m2.date.today(),
        ...pager({
          pageIndex: 0,
          pageSize: 0
        })
      };
      getTodayHasCourseCustomers(params, res => {
        this.todayStudents = this.todayStudents.concat(
          res.queryResult.pagedData
        );
      });
    },
    switchJob() {
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getCustomerList);
    },

    getStatus(Index) {
      if (!Index) Index = 0;
      this.zeed = Index;
      this.filterStatus.forEach((item, index) => {
        item.current = false;
        if (index == Index) {
          item.current = true;
        }
      });
    },
    getAllStudents(Index) {
      //this.getStatus(Index);
      let params = {
        filterStatus: Index || 0,
        CustomerName: this.inpVal,
        ...pager({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize
        })
      };
      getCurrentJobCustomers(params, res => {
        this.allStudents = this.allStudents.concat(res.queryResult.pagedData);
        if (this.pageSize * this.pageIndex >= res.queryResult.totalCount) {
          this.allLoaded = true;
        } else {
          this.allLoaded = false;
        }
      });
    },
    switchTabs(Id) {
      this.selected = Id;
    },
    //下拉刷新  初始化加载
    loadTop() {
      this.$refs.loadmore.onTopLoaded(); //刷新完重新定位
      this.topBack();
    },
    loadBottom() {
      event.preventdefault;
      event.stopPropagation();
      this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
      this.bottomBack();
    },
    navKind() {
      if (this.selected == "1") {
        this.allLoaded = true;
        this.getCustomerList();
      } else {
        this.getAllStudents(this.zeed);
      }
    },
    topBack() {
      this.pageIndex = 1;
      this.clearData();
      this.chooseCourse();
    },
    bottomBack() {
      this.pageIndex++;
      this.chooseCourse();
    },
    chooseCourse() {
      this.navKind();
    },
    clearData() {
      this.pageIndex = 1;
      if (this.selected == "1") {
        this.todayStudents = [];
      } else {
        this.allStudents = [];
      }
    },
    setHeight() {
      let content = document.querySelector("#cus-main-content");
      if (content !== null && typeof content !== "undefined") {
        let windowHeight = window.innerHeight;
        let headHight = document.querySelector("#cus-header");
        console.log("学员列表-#cus-header：" + headHight);
        let jHight = windowHeight - 85 - 34 - 10 - 32 + 23;
        if (headHight !== null) {
          content.style.height = "calc(" + jHight + "px - 0.4rem - 2.88rem)";
        } else {
          content.style.height = "calc(" + jHight + "px - 0.4rem)";
        }
      }
    }
  },
  activated() {
    this.setHeight();
  },
  mounted() {
    this.setHeight();
    this.switchJob();
    if (typeof this.$route.query.tab !== "undefined") {
      this.selected = this.$route.query.tab + "";
    } else {
      this.selected = "1";
    }
    var currentJob = m2.cache.get("ppts-current-job").jobType;
    switch (currentJob) {
      case 1:
        this.replyObject = 1;
        break;
      case 2:
        this.replyObject = 2;
        break;
      case 3:
        this.replyObject = 3;
        break;
    }
  },
  watch: {
    selected() {
      if (this.selected == 2) {
        this.getStatus(0);
      }
      this.pageIndex = 1;
      this.clearData();
      this.allLoaded = false;
      this.chooseCourse();
    },
    inpVal() {
      if (!this.inpVal) {
        this.clearData();
        this.navKind();
      }
    },
    zeed() {
      this.allStudents = [];
      this.pageIndex = 1;
      this.allLoaded = false;
      this.chooseCourse();
    }
  },
  components: {
    Tip,
    mtNavbar,
    mtTabItem,
    mtLoadmore
  }
};
</script>

<style lang="scss" scoped>
.main-content {
  overflow: auto;
}

.xd-select-student {
  text-align: center;
  .students-head {
    width: 100%;
    background-color: #fff;
  }
  .inp {
    width: 90%;
    margin-left: 5%;
    margin-top: torem(15);
    border: 1px solid #d8d8d8;
    border-radius: 100px;
    height: 32px;
    position: relative;
    input {
      width: 90%;
      height: 100%;
      border: none;
      margin-left: -8%;
      border-radius: 100px;
    }
    input::-webkit-input-placeholder {
      font-size: torem(12);
      color: skyblue;
    }
    i {
      position: absolute;
      right: torem(10);
      top: torem(5);
      color: #eee;
      font-size: torem(24);
    }
  }
  .students-list {
    ul {
      padding-left: torem(15);
      padding-right: torem(15);
      /*margin-top: torem(15);*/
    }
    li {
      width: 100%;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: space-around;
      border-bottom: 1px solid #eee;
      span {
        text-align: left;
        font-size: torem(14);
        i {
          font-size: torem(20);
          color: #ff9900;
        }
      }
      .customer-name {
        display: inline-block;
        width: 20%;
        text-align: left;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        color: #ff9900;
      }
      .customer-code {
        display: inline-block;
        text-align: left;
        margin-left: torem(-40);
      }
      .customer-mess {
        display: inline-block;
        width: 16%;
        display: flex;
        justify-content: space-between;
        p {
          width: torem(27);
          height: torem(23);
          display: block;
          margin-bottom: 0;
          a:nth-child(1) {
            width: torem(27);
            height: torem(23);
            display: block;
            border-right: 1px solid #eee;
            padding-right: torem(6);
          }
        }
      }
      a: {
        width: torem(60);
        display: flex;
        justify-content: space-between;
      }
    }
  }
  .selectStudent {
    background-color: #eee;
  }
}
/*.statusStudent {
		margin-top: 30px!important;
	}
	*/

.filterStatus {
  display: flex;
  justify-content: center;
  /*position: absolute;*/
  background: #fff;
  width: 100%;
  z-index: 99;
  li {
    padding: torem(3) torem(3);
    margin: 0 torem(4);
    color: #888;
  }
}
.slected {
  color: #ff9900 !important;
  border: 1px solid #ff9900;
  border-radius: 10px;
}
.todayStu{
  border-radius: 6px 0 0 6px;
}
.allStu{
  border-radius: 0 6px 6px 0 ;
}
</style>