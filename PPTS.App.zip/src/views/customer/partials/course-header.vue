<template>
  <div class="xd-customer-list-nav" id="cus-header">
    <router-link
      v-for="(item,index) in showItems"
      :to="{name:item.pathname}"
      :key="index"
      class="item"
      tag="div"
    >
      <img :src="$route.name == item.pathname ? item.icon_active : item.icon" alt class="icon">
      <span class="txt">{{item.title}}</span>
    </router-link>
  </div>
</template>
<script>
import { CUSTOMER_INDEX } from "@/constants";
export default {
  data() {
    return {
      items: CUSTOMER_INDEX
    };
  },
  computed: {
    showItems() {
      var showItemsArr = [];
      this.items.forEach(item => {
        if (m2.util.getPermionLoad(item.functions)) {
          showItemsArr.push(item);
        }
      });
      return showItemsArr;
    }
  }
};
</script>
<style lang="scss" scoped>
.xd-customer-list-nav {
  height: torem(72);
  display: flex;
  align-items: center;
  text-align: center;
  background: #fff;
  margin-bottom: torem(-12);
  .item {
    display: inline-block;
    width: 25%;
    //flex: 1;
    .icon {
      width: torem(28);
      height: torem(28);
    }
    .txt {
      display: block;
      font-size: torem(14);
      color: #4b5160;
      line-height: torem(20);
    }
  }
}
</style>