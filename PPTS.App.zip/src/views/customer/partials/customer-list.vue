<template>
  <div>
    <customer-area v-power="['睿学-学员信息-不带电话']"></customer-area>
    <guest-area v-power="['睿学-潜客管理']"></guest-area>
  </div>
</template>

<script>
import customerArea from "./customer-area.vue";
import guestArea from "./guest-area.vue";
export default {
  components: {
    customerArea,
    guestArea
  }
};
</script>
