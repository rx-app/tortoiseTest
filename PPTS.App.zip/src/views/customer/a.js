var arr=['北京','上海','广东']

function removeArea(arr,delValue){
    return arr.filter((item)=>{
        return item!=delValue;
    })
}

let res=removeArea(arr,'北京')
console.log()




// arr=[{areaName:'北京'},{areaName:'上海'},{areaName:'广东'}]