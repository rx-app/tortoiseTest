<template>
  <div class="rx-account-tab">
    <router-link
      tag="div"
      :to="{name:'orderList',query:{id:$route.query.id,code:$route.query.code}}"
      class="left"
      :class="on=='left'?'on':''"
    >
      <i class="iconfont icon-shop"></i>订购单
    </router-link>
    <router-link
      tag="div"
      :to="{name:'accountStatement',query:{id:$route.query.id,code:$route.query.code}}"
      class="right"
      :class="on=='right'?'on':''"
    >
      <i class="iconfont icon-accountAtate"></i>对账单
    </router-link>
  </div>
</template>
<script>
export default {
  props: ["on"]
};
</script>

<style lang="scss" scoped>
.rx-account-tab {
  padding: 20px 18px;
  overflow: hidden;
  font-size: torem(14);
  background: #eee;
  div {
    color: #999;
    float: left;
    padding: 5px 0;
    text-align: center;
    line-height: 20px;
    vertical-align: bottom;
    width: 50%;
    i {
      width: 20px;
      height: 20px;
      display: inline-block;
      vertical-align: bottom;
      margin-right: 8px;
      &::before {
        vertical-align: bottom;
        //border-radius: 50%;border: 1px solid #333;
        color: #999;
      }
    }
    &.on i {
      &::before {
        color: #fff;
        //border: 1px solid #fff
      }
    }
    &.left {
      border-radius: 5px 0 0 5px;
      vertical-align: bottom;
      background: #fff;
    }
    &.right {
      border-radius: 0 5px 5px 0;
      transform: translateX(-1px);
      background: #fff;
    }
    &.right.on {
      background-image: linear-gradient(90deg, #ffb82a 0%, #ff9900 100%);
      color: #fff;
    }
    &.left.on {
      background-image: linear-gradient(90deg, #ff9900 0%, #ffb82a 100%);
      color: #fff;
    }
  }
}
</style>

