<template>
	<div class="students-list">
		<ul v-if="parentMess.isPrimary">
			<li class="header-icon">
				<span>头像：</span>
				<span class="imgSrc">
					<img v-if="imgSrc" :src="imgSrc">
			        <img  v-else-if='userGender==2' src="~@/public/asset/img/user/mother.png" alt="" />
					<img v-else src="~@/public/asset/img/user/father.png" alt="" />
				</span>
			</li>
			<li><span>姓名：</span><span v-if="parentMess.parent">{{parentMess.parent.parentName}}</span></li>
			<li><span>性别：</span><span v-if="parentMess.parent">{{parentMess.parent.gender | gender}}</span></li>
			<li><span>亲属关系：</span><span>{{parentMess.parentRoleName}}</span></li>
			<li><span>是否是主监护人：</span><span>是</span></li>
			<li v-power="['睿学-学员信息-带电话']"><span>主要联系方式：</span><span>{{mainConect}}</span></li>
			<li v-power="['睿学-学员信息-带电话']"><span>辅助联系方式：</span><span>{{minorConect}}</span></li>
		</ul>
		<tip v-else><span>暂无该学员主要监护人信息</span></tip>
	</div>
</template>
<script>
	import Tip from '@/components/tip';
	import store from '@/store';
	import { getHead } from '@/api/user/user-api';
	import * as types from '@/store/mutation-types';
	export default {
		data() {
			return {
				userGender: 0,
				imgSrc: ''
			}
		},
		props: ['parentMess'],
		updated() {
			var userIcons = this.$store.state.headList.slice() || [];
			var curIcon = userIcons.find(i => i.userID === this.parentMess.parent.iconID);
			var _this = this;
			this.userGender = this.parentMess.parent.gender;
			if(curIcon) {
				this.imgSrc = curIcon.imgData;
			} else {
				if(this.parentMess.parent.iconID) {
					getHead({
						iconID: this.parentMess.parent.iconID
					}, (res) => {
						this.imgSrc = res;
						let obj = {
							userID: _this.parentMess.parent.iconID,
							imgData: res
						};
						userIcons.push(obj);
						store.commit(types.HEADLIST_ARR, userIcons);
					})
				}

			}
		},
		computed: {
			mainConect() {
				var mainConect = '';
				if(this.parentMess.phones) {
					this.parentMess.phones.forEach((item) => {
						if(item.isPrimary) {
							mainConect = item.phoneNumber;
						}
					})
					return mainConect;
				}
			},
			minorConect() {
				var minorConect = '';
				if(this.parentMess.phones) {
					this.parentMess.phones.forEach((item) => {
						if(!item.isPrimary) {
							minorConect = item.phoneNumber;
						}
					})
					return minorConect;
				}
			}
		},
		components: {
			Tip,
		}
	}
</script>