<template>
	<div>
		<div class="students-list">
			<ul>
				<li class="header-icon">
					<span>头像：</span>
					<span class="imgSrc">
						<img v-if="imgSrc" :src="imgSrc">
			            <img v-else-if='userGender==2' src="~@/public/asset/img/user/girl.png" alt="" />
			            <img v-else src="~@/public/asset/img/user/boy.png" alt="" />
					</span>
				</li>
				<li><span>姓名：</span><span>{{customerMess.customerName}}</span></li>
				<li><span>性别：</span><span>{{customerMess.gender | gender}}</span></li>
				<li><span>学员编号：</span><span>{{customerMess.customerCode}}</span></li>
				<li><span>出生日期：</span><span>{{customerMess.birthday | dateFormat({locale: 'zh-CN'})}}</span></li>
				<li><span>资源所在地：</span><span>{{customerMess.campusName}}</span></li>
				<li><span>接触方式：</span><span>{{customerMess.contactType | contactType}}</span></li>
				<li><span>信息来源：</span><span>{{customerMess.sourceTypeName}}</span></li>
				<li><span>入学年级：</span><span>{{customerMess.entranceGrade | grade}}</span></li>
				<li><span>当前年级：</span><span>{{customerMess.grade | grade}}</span></li>
				<li><span>在读学校：</span><span>{{customerMess.schoolName}}</span></li>
			</ul>
		</div>
	</div>
</template>
<script>
	import store from '@/store';
	import { getHead } from '@/api/user/user-api';
	import * as types from '@/store/mutation-types';
	export default {
		data() {
			return {
				userGender: 0,
				imgSrc: ''
			}
		},
		props: ['customerMess'],
		updated() {
			var userIcons = this.$store.state.headList.slice() || [];
			var curIcon = userIcons.find(i => i.userID === this.customerMess.customerID);
			var _this = this;
			this.userGender = this.customerMess.gender;
			if(curIcon) {
				this.imgSrc = curIcon.imgData;
			} else {
				if(this.customerMess.iconID) {
					getHead({
						iconID: this.customerMess.iconID
					}, (res) => {
						this.imgSrc = res;
						let obj = {
							userID: _this.customerMess.customerID,
							imgData: res
						};
						userIcons.push(obj);
						store.commit(types.HEADLIST_ARR, userIcons);
					})
				}

			}
		},
	}
</script>

<style lang="scss" scoped>
	.mint-tab-container-item {
		padding-bottom: 0;
	}

</style>