<template>



  <div class="student-info">
    <!-- <mt-navbar class="student-info-nav" v-model="navIndex" v-power="['睿学-学员信息-不带电话']">
			<mt-tab-item id="1" @click="this.curIndex=index" v-for="(item,index) in navList" :key="index" class="nav-item" :class="{on:curIndex==index}">{{item}}</mt-tab-item>
    </mt-navbar>-->
		<span v-show="!editing" class="top-btn-edit" @click="editParentInfo">编辑</span>
		<span v-show="editing" class="top-btn-save" @click="save">保存</span>
		<span v-show="editing" class="top-btn-cancel" @click="cancelEdit">取消</span>
    <mt-navbar class="student-info-nav" v-model="selected">
      <mt-tab-item id="2">基本信息</mt-tab-item>
      <mt-tab-item id="1">家长信息</mt-tab-item>
      <mt-tab-item id="3">跟进记录</mt-tab-item>
    </mt-navbar>

	<div class="info-edit-des">
		注意：★为必填项，▲为充值所需项，■为关键信息，签约后只允许分审核经理修改。
	</div>
	
    <!-- tab-container -->
    <mt-tab-container v-model="selected">
      <mt-tab-container-item  v-if="!editing"  id="2"></mt-tab-container-item>
			<mt-tab-container-item v-if="editing"  id="2"></mt-tab-container-item>
      <mt-tab-container-item v-if="!editing" id="1">
				<ul class="parent-tabs">
					<template v-if="parentList.length" >
						<li v-for="(item,index) in parentList" @click="parentIndex=index" :class="{active:parentIndex==index}" :key="index" >{{item.parentName}}{{item.isPrimary==1?'（主）':''}}</li>
					</template>
						<li>+</li>
				</ul>

	
				<div v-for="(item,index) in parentList"  :key="index+1"  class="info-tab">
					<div class="cell">
						<div class="cell-1"><span>★▲■</span>家长姓名</div>
						<div class="cell-2">{{item.parentName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家长性别</div>
						<div class="cell-2">{{item.gender|gender}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>亲属关系</div>
						<div class="cell-2">{{item.parentRole}}</div>
						<!--  -->
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲★</span>主要联系方式</div>
						<div class="cell-2">{{item.primaryPhone.phoneNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">辅助联系方式</div>
						<div class="cell-2">{{item.secondaryPhone && item.secondaryPhone.phoneNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">是否主监护人</div>
						<div class="cell-2">{{item.isPrimary==1?'是':'否'}}</div>
					</div>
				</div>
				<div   v-for="(item,index) in parentList" :key="index"  class="info-tab">
					<div class="cell">
						<div class="cell-1">现住址</div>
						<div class="cell-2">{{item.addressDetail}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家长Email</div>
						<div class="cell-2">{{item.email}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>■</span>身份证</div>
						<div class="cell-2">{{item.idNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家庭年总收入</div>
						<div class="cell-2">{{item.income}}</div>
					</div>
				</div>
			</mt-tab-container-item>
			<mt-tab-container-item v-if="editing" id="1">
				
        <ul class="parent-tabs">
          <template v-if="parentList.length" >
						<li v-for="(item,index) in parentList" @click="parentIndex=index" :class="{active:parentIndex==index}" :key="index" >{{item.parentName}}{{item.isPrimary=='true'?'（主）':''}}</li>
					</template>
        </ul>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span>★▲■</span>家长姓名
            </div>
            <div class="cell-2"><input type="text"  v-model="editingModel.parentName"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家长性别</div>
            <div class="cell-2"><mt-radio align="right" v-model="editingModel.gender" :options="[{label:'男',value:'1'},{label:'女',value:'2'}]"></mt-radio></div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲</span>亲属关系
            </div>
            <div class="cell-2">{{editingModel.parentRole}}</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲★</span>主要联系方式
            </div>
            <div class="cell-2"><input type="text" v-model="editingModel.primaryPhone.phoneNumber"></div>
          </div>
          <div class="cell">
            <div class="cell-1">辅助联系方式</div>
            <div class="cell-2"><input type="text" v-model="editingModel.secondaryPhone.phoneNumber"></div>
          </div>
          <div class="cell">
            <div class="cell-1">是否主监护人</div>
            <div class="cell-2">
							<mt-radio align="right" v-model="editingModel.isPrimary" :options="[{label:'是',value:'true'},{label:'否',value:'false'}]"></mt-radio>
						</div>
          </div>
        </div>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">现住址</div>
            <div class="cell-2">湖南省-长沙市-芙蓉区<span class="ar">></span></div>
          </div>
					<div class="cell">
            <div class="cell-1">详细地址</div>
            <div class="cell-2"><input type="text" v-model="editingModel.addressDetail"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家长Email</div>
            <div class="cell-2"><input type="text" v-model="editingModel.email"></div>
          </div>
          <div class="cell" @click="showBox">
            <div class="cell-1">
              <span>■</span>证件类型
            </div>
            <div class="cell-2">
							{{this.idTypeName(editingModel.idType)}}<span class="ar">></span>
						</div>
          </div>
					
					
					<div class="cell">
            <div class="cell-1">输入编号</div>
            <div class="cell-2"><input type="text" v-model="editingModel.idNumber"></div>
          </div>
					<div class="cell">
            <div class="cell-1">家庭年总收入</div>
            <div class="cell-2">

							</div>
          </div>
          <div class="cell">
            <div class="cell-1">家庭年总收入</div>
            <div class="cell-2">{{editingModel.income}}<span class="ar">></span></div>
          </div>
        </div>
      </mt-tab-container-item>
      <mt-tab-container-item id="3"></mt-tab-container-item>
    </mt-tab-container>
		<select-items
        v-show="itemsParams.isShow"
        :title="itemsParams.title"
        :model="itemsParams.model"
        :isShow="itemsParams.isShow"
        :category="itemsParams.category"
        :items="itemsParams.selectItems"
        @selectItem="selectVisitType"
      ></select-items>
  </div>
</template>
<script>
import {
  cell as mtCell,
  Navbar as mtNavbar,
  TabItem as mtTabItem,
	Loadmore as mtLoadmore,
	Actionsheet  as mtActionsheet,
} from "mint-ui";
import {
	getCustomerInfo,
	getAllCustomers,
	getCustomerParents,
	updateCustomerParent,
	updateCustomer,
} from "@/api/customer/customer-api";
import {
	getCustomerSource,
	getLocationData,
	getSchools,
} from "@/api/metadata/metadata-api";
import { debug } from 'util';
import SelectItems from "@/components/select-items/index";
import { setTimeout } from 'timers';


export default {
  data() {
    return {
			itemsParams:{
				isShow:false,
				title:'证件类型',
				model:'model',
				category:'类型',
				selectItems:[{key:'0',value:'身份证'},{key:'1',value:'学生证'}],
			},
      selected: "1",
      navIndex: null,
			curIndex: 0,
			info:{},
			zxs:{},
			xgs:{},
			js:{},
			zxzy:{},
			sczy:{},
			parentList:[],
			restudy:null,
			rawEditingModel:{},
			parentIndex:0,
			navList: ["基本信息", "家长信息", "跟进记录"],
			editing:false,
			clone:{},
			infoSrc:'',
			newInfo:{},
			infoRes:{},
    };
	},
	created(){
		// debugger
		this.init();
		// getAllCustomers({pageParams:{pageIndex: 0, pageSize: 0}},(res)=>{
		// 	console.log(res)
		// });
	},
	computed:{
		
		editingModel(){
			if(!this.rawEditingModel.primaryPhone){
				this.rawEditingModel.primaryPhone={}
			}
			if(!this.rawEditingModel.secondaryPhone){
				this.rawEditingModel.secondaryPhone={}
			}
			// debugger
			this.rawEditingModel.isPrimary=this.rawEditingModel.isPrimary.toString();
			this.rawEditingModel.gender=this.rawEditingModel.gender.toString();
			// this.rawEditingModel.isPrimary &&	(this.rawEditingModel.isPrimary=this.rawEditingModel.isPrimary.toString());
			// this.rawEditingModel.gender && (this.rawEditingModel.gender=this.rawEditingModel.gender.toString());

			return this.rawEditingModel
		}
	},
	mounted(){
		// this.$nextTick(()=>{
		// 		this.editing=true
		// })
		
		// this.selectVisitType()
	},
	methods:{
		init(){
			let id = this.$route.query.id;
			this.viewDetail(id);
		},
		getInfoSource(key,secKey){
			if(key || key=='0'){
				let r={}
				getCustomerSource({parentKey:key},res=>{
					r= res.find((v) => (v.key == secKey))
					this.infoSrc=r.value
				})
				
			}
		},
		idTypeName(id){
			switch(id){
				case 0:return '身份证';
				case 1:return '学生证';
				default :return '其它证件'
			}
		},
		showBox(){
			this.itemsParams.isShow = true;
		},
		selectVisitType({cate,item}){
			this.itemsParams.isShow = false;
			// debugger
			this.rawEditingModel.idType=item.key*1;
			// this.editingModel.idType=item.key*1;  似乎这么写也能起作用，但是感觉不合理
			console.log(cate,item)
			// setTimeout(()=>{
			// 	this.itemsParams.isShow = true;
			// })
			
		},
		viewHistory(tea){
			if(tea && tea.customerID){
				this.$router.push({name:'teacherHistory',query:{type:tea.relationType,id:tea.customerID}})
			}else{
				return false;
			}
		}, 
		save(){
			this.saveInfo();
			// this.saveParentInfo();
		},
		saveInfo(){
			updateCustomer(this.infoRes,(res)=>{
				console.log(res)
			})
		},
		saveParentInfo(){
			
			let customerID=this.editingModel.customerID;
			
			console.log(this.editingModel)
			console.log(this.parentList[this.parentIndex])
			// console.log(this.editParentInfo())
			// console.log({...this.editParentInfo()})
			// debugger
			// console.log(this.editParentInfo.customerID)
			updateCustomerParent({
				customer:this.info,
				// customerID,
				parent:this.editingModel,
				customerParentRelation:{
					customerID:this.editingModel.customerID,
					parentID:this.editingModel.parentID,
					customerRole:this.editingModel.customerRole,
					parentRole:this.editingModel.parentRole,
					isPrimary:this.editingModel.isPrimary,
				},
			},(res)=>{
				console.log(res)
			})
		},
		cancelEdit(){
			this.editing=false;
			this.init();
			// this.rawEditingModel=this.clone
		},
		editParentInfo(){
			this.editing=true;
			// debugger
			
			this.rawEditingModel=this.parentList[this.parentIndex];
			this.newInfo=this.info;
			// this.clone=copy(this.rawEditingModel,this.clone)
		},
		viewDetail(id){
      getCustomerInfo({id}, res => {
				console.log(res)
				this.infoRes=res;
				this.info=res.customer;
				this.getInfoSource(this.info.sourceMainType,this.info.sourceSubType)
        res.customerStaffRelations.forEach((v)=>{
					if(v.relationType==1){
						this.zxs=v;
					}else if(v.relationType==2){
						this.xgs=v;
					}else if(v.relationType==3){
						this.js=v;
					}else if(v.relationType==4){
						this.zxzy=v;
					}else if(v.relationType==5){
						this.sczy=v;
					}
				})
			});
			getCustomerParents({id},res=>{
				console.log(res)
				this.parentList=res.queryResult;
				console.log(this.parentList.length)
				// console.log(this.parentList[0].parentName)
			})
    },
	},
  components: {
    SelectItems,
  }
};
</script>

<style lang="scss">
.student-info {
	.ar{float: right;}

	.mint-radiolist{display: flex}
	.mint-radiolist *{margin: 0}
	.mint-cell-wrapper,.mint-radiolist,.mint-cell{height: torem(16);line-height: torem(16)}
	.mint-radiolist .mint-cell{    background: transparent;}
	.mint-cell-wrapper{background: none;transform: translateY(-8px);}

	span.mint-radio-label{display: inline-block;transform:translateX(-20px);}
	.mint-radiolist-title{margin-left: 0}
}
</style>

<style lang='scss' scoped>
.edit{
	color: #aaa;
	span{color:#333}
}
.top-btn-edit{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 100;
}
.top-btn-save{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 100;
}
.top-btn-cancel{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 60px;
	color: #fff;
	z-index: 100;
}
.parent-tabs {
  margin-bottom: 10px;
  font-size: 0px;
  li {
		&.active{    
			background-image: linear-gradient(90deg, #FF9900 0%, #FFB82A 100%);
			height: 100%;
			border-bottom: none!important;
			color: #fff!important;
		}
    background: #fff;
    display: inline-block;
    font-size: torem(16);
    line-height: torem(16);
    padding: torem(8);
    border-right: 1px solid #ddd;
    // width:30vw;
    &.on {
      background: #888;
    }
  }
}
.student-info {
	.mint-radiolist{display: flex}
	span.mint-radio-label{display: inline-block;transform:translateX(-15px);}
  .student-info-nav {
    margin-top: 16px;
    width: 100%;
    margin-left: 0;
    border-radius: 5px;
    overflow: hidden;
  }
  background: #eee;
  padding: 30px 10px 20px;
  .info-edit-des {
    font-size: torem(16);
    color: #888;
    margin: 15px 0;
  }
  .info-tab {
    background: #fff;
    margin: 0 0 15px;
    padding-bottom: 10px;
    .cell {
      display: flex;
      font-size: torem(16);
      line-height: torem(32);
      margin: torem(5) torem(8);
      border-bottom: torem(1) solid #ddd;
      .cell-1 {
        span {
          color: red;
          font-size: torem(20);
        }
        flex: 4;
        text-align: right;
        padding-right: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(16);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
    }
  }
}

.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
