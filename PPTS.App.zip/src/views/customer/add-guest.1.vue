<template>
  <div class="xd-add-guest">
    <div class="tab-header">
      <mt-navbar v-model="selected">
        <mt-tab-item id="1" @click.stop.prevent="switchTabs('1')" class="todayStu">主要信息</mt-tab-item>
        <mt-tab-item id="2" @click.stop.prevent="switchTabs('2')" class="allStu">其他信息</mt-tab-item>
      </mt-navbar>
    </div>

    <!-- tab-container  -->
    <div id="group-list-content">
      <mt-tab-container v-model="selected">
        <mt-tab-container-item id="1">
          <div class="group-list">
            <ul class="mui-table-view">
              <li class="mui-table-view-cell mui-collapse mui-active">
                <a class="mui-navigate-right" href="#">家长信息</a>
                <div class="mui-collapse-content">
                  <text-type
                    :isShowLine="1"
                    keyMess="parentName"
                    lineName="家长姓名"
                    :isRequest="true"
                    tipText="请输入家长姓名"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <text-type
                    :isShowLine="1"
                    keyMess="parentPriPhone"
                    lineName="家长手机"
                    :isRequest="true"
                    tipText="请输入家长手机号码"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <text-type
                    :isShowLine="1"
                    keyMess="parentSecPhone"
                    lineName
                    :isRequest="false"
                    tipText="请输入其他电话号码"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <text-type
                    :isShowLine="2"
                    :radioArr="parentGenderGroup"
                    keyMess="parentGender"
                    lineName="家长性别"
                    :isRequest="false"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <button class="select-parent" @click="goSelAlreadyParent()">选择已有家长</button>
                </div>
              </li>
              <li class="mui-table-view-cell mui-collapse">
                <a class="mui-navigate-right" href="#">学员信息</a>
                <div class="mui-collapse-content">
                  <text-type
                    :isShowLine="1"
                    lineName="学员姓名"
                    keyMess="customerName"
                    :isRequest="true"
                    tipText="请输入学员姓名"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <text-type
                    :isShowLine="2"
                    :radioArr="customerGenderGroup"
                    keyMess="customerGender"
                    lineName="学员性别"
                    :isRequest="false"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                </div>
              </li>
              <li class="mui-table-view-cell mui-collapse">
                <a class="mui-navigate-right" href="#">亲属关系</a>
                <div class="mui-collapse-content">
                  <li class="item edit" @click.prevent.stop="selectItem('customerRole')">
                    <div class="item-left">
                      <span
                        v-if="guestMess.customer"
                        :class="!guestMess.customer.customerName?'vis':''"
                      >{{guestMess.customer.customerName}}</span> 是
                      <span
                        v-if="guestMess.parent"
                        :class="!guestMess.parent.parentName?'vis':''"
                      >{{guestMess.parent.parentName}}</span>
                    </div>
                    <div class="item-right">{{guestMess.customerRole}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('parentRole')">
                    <div class="item-left">
                      <span
                        v-if="guestMess.parent"
                        :class="!guestMess.parent.parentName?'vis':''"
                      >{{guestMess.parent.parentName}}</span> 是
                      <span
                        v-if="guestMess.customer"
                        :class="!guestMess.customer.customerName?'vis':''"
                      >{{guestMess.customer.customerName}}</span>
                    </div>
                    <div class="item-right">{{guestMess.parentRole}}</div>
                  </li>
                </div>
              </li>
              <li class="mui-table-view-cell mui-collapse">
                <a class="mui-navigate-right" href="#">客户信息</a>
                <div class="mui-collapse-content">
                  <!-- <mt-picker :slots="slots" value-key="name" @change="onValuesChange"></mt-picker> -->
                  <li class="item edit" @click.prevent.stop="selectItem('branchID')">
                    <div class="eleDisplay">
                      <span class="request">*</span>
                      <div>资源归属地</div>
                    </div>
                    <div class="item-right" v-if="guestMess.customer">{{departMentObj.branchName}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('campusID')">
                    <div class="eleDisplay">
                      <!-- <span class="request">*</span>
                      <div>资源归属地</div>-->
                    </div>
                    <div class="item-right" v-if="guestMess.customer">{{departMentObj.campusName}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('contactType')">
                    <div class="eleDisplay">
                      <span class="request">*</span>
                      <div>接触方式</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.contactType"
                    >{{guestMess.customer.contactType | contactType}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('sourceMain')">
                    <div class="eleDisplay">
                      <span class="request">*</span>
                      <div>信息来源</div>
                    </div>
                    <div class="item-right" v-if="guestMess.customer">{{sourceType.sourceMainName}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('sourceSec')">
                    <div class="eleDisplay"></div>
                    <div class="item-right" v-if="guestMess.customer">{{sourceType.sourceSecName}}</div>
                  </li>
                  <div v-if="guestMess.customer && guestMess.customer.sourceMainType == '617'">
                    <text-type
                      :isShowLine="1"
                      lineName="转介绍员工OA"
                      keyMess="ReferralStaffOACode"
                      :isRequest="false"
                      tipText="填写后无法修改，请正确填写"
                      @textTypeBack="textTypeFun"
                    ></text-type>
                    <tip v-if="ReferralStaffOACodeFlag">输入的转介绍员工OA不正确！</tip>
                    <li class="item edit" @click.prevent.stop="selectItem('referralStaffJobID')">
                      <div class="eleDisplay">
                        <span class="request vis">*</span>
                        <div>转介绍员工岗位</div>
                      </div>
                      <div
                        class="item-right"
                        v-if="guestMess.customer && guestMess.customer.referralStaffJobName"
                      >{{guestMess.customer.referralStaffJobName}}</div>
                    </li>
                    <text-type
                      :isShowLine="1"
                      lineName="转介绍学员编号"
                      keyMess="customerCode"
                      :isRequest="false"
                      tipText="填写后无法修改，请正确填写"
                      @textTypeBack="textTypeFun"
                    ></text-type>
                    <tip v-if="customerCodeFlag">输入的转介绍学员编号不正确！</tip>
                  </div>

                  <li class="item edit" @click.prevent.stop="selectItem('tutoringWill')">
                    <div class="eleDisplay">
                      <span class="request">*</span>
                      <div>辅导意愿</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.tutoringWill"
                    >{{guestMess.customer.tutoringWill | tutorWill}}</div>
                  </li>
                </div>
              </li>
            </ul>
          </div>
        </mt-tab-container-item>
        <mt-tab-container-item id="2">
          <div class="group-list">
            <ul class="mui-table-view">
              <li class="mui-table-view-cell mui-collapse">
                <a class="mui-navigate-right" href="#">家庭信息</a>
                <div class="mui-collapse-content">
                  <li class="item edit" @click.prevent.stop="selectItem('parentIDType')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>家长证件</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.parent && guestMess.parent.idType"
                    >{{guestMess.parent.idType | idtype}}</div>
                  </li>
                  <text-type
                    :isShowLine="1"
                    keyMess="parentIDNumber"
                    lineName
                    :isRequest="true"
                    tipText="请输入证件号码"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <li class="item edit" @click.prevent.stop="selectItem('Income')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>家庭年收入</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.parent && guestMess.parent.income"
                    >{{guestMess.parent.income | homeIncome}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('province')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>现住址</div>
                    </div>
                    <div class="item-right" v-if="guestMess.parent">{{areaMess.provinceName}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('city')">
                    <div class="eleDisplay"></div>
                    <div class="item-right" v-if="guestMess.parent">{{areaMess.cityName}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('county')">
                    <div class="eleDisplay"></div>
                    <div class="item-right" v-if="guestMess.parent">{{areaMess.countyName}}</div>
                  </li>
                  <text-type
                    :isShowLine="1"
                    keyMess="AddressDetail"
                    lineName
                    :isRequest="true"
                    tipText="请输入详细地址，如街道名称，门牌号等。"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <text-type
                    :isShowLine="1"
                    keyMess="parentEmail"
                    lineName="家长邮箱"
                    :isRequest="false"
                    tipText="请输入家长常用Email邮件地址"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                </div>
              </li>
              <li class="mui-table-view-cell mui-collapse">
                <a class="mui-navigate-right" href="#">学员补充信息</a>
                <div class="mui-collapse-content">
                  <text-type
                    :isShowLine="1"
                    keyMess="customerPhone"
                    lineName="联系方式"
                    :isRequest="false"
                    tipText="请输入学员自己的电话号码"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <li class="item edit" @click.prevent.stop="selectItem('entranceGrade')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>入学大年级</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.entranceGrade"
                    >{{guestMess.customer.entranceGrade | grade}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('subjectType')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>文科理科</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.subjectType"
                    >{{guestMess.customer.subjectType | subjectType}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('schoolYear')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>学年制</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.schoolYear"
                    >{{guestMess.customer.schoolYear | academicYear}}</div>
                  </li>
                  <text-type
                    class="relative"
                    :isShowLine="1"
                    keyMess="schoolName"
                    lineName="当前所在学校"
                    :isRequest="false"
                    :sureSchoolName="guestMess.customer?guestMess.customer.schoolName:''"
                    tipText="请输入校名进行选择"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <ul class="schollList" v-if="schoolListData.length">
                    <li
                      v-for="(items,index) in schoolListData"
                      :key="index"
                      @click="selectSchoolFun(items)"
                      v-html="hightLightFun(items.schoolName)"
                    >{{items.schoolName}}</li>
                  </ul>
                  <li class="item edit" @tap.prevent.stop="action()">
                    <div class="item-left">学员出生日期</div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.birthday"
                    >{{guestMess.customer.birthday | dateFormat}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('customerIDType')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>学员证件</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.idType"
                    >{{guestMess.customer.idType | idtype}}</div>
                  </li>
                  <text-type
                    :isShowLine="1"
                    keyMess="customerIDNumber"
                    lineName
                    :isRequest="true"
                    tipText="请输入证件号码"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                  <text-type
                    :isShowLine="2"
                    :radioArr="isStudyAgainGroup"
                    keyMess="isStudyAgain"
                    lineName="是否复读"
                    :isRequest="false"
                    @textTypeBack="textTypeFun"
                  ></text-type>
                </div>
              </li>
              <li class="mui-table-view-cell mui-collapse">
                <a class="mui-navigate-right" href="#">VIP信息</a>
                <div class="mui-collapse-content">
                  <li class="item edit" @click.prevent.stop="selectItem('vipType')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>VIP客户</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.vipType"
                    >{{guestMess.customer.vipType | vipType}}</div>
                  </li>
                  <li class="item edit" @click.prevent.stop="selectItem('vipLevel')">
                    <div class="eleDisplay">
                      <span class="request vis">*</span>
                      <div>VIP等级</div>
                    </div>
                    <div
                      class="item-right"
                      v-if="guestMess.customer && guestMess.customer.vipLevel"
                    >{{guestMess.customer.vipLevel | vipLevel}}</div>
                  </li>
                </div>
              </li>
            </ul>
          </div>
        </mt-tab-container-item>
      </mt-tab-container>
    </div>
    <select-items
      v-show="itemsParams.isShow"
      :title="itemsParams.title"
      :model="itemsParams.model"
      :isShow="itemsParams.isShow"
      :category="itemsParams.category"
      :items="itemsParams.selectItems"
      @selectItem="selectVisitType"
    ></select-items>
  </div>
</template>
<script>
import { ACTION_TYPES, DepartmentType, spr, psr } from "@/constants";
import SelectItems from "@/components/select-items/index";
import TextType from "@/components/text-diffent-type";
import Tip from "@/components/tip";
import {
  $createCustomer,
  createCustomer,
  getStaffByOA,
  getCustomerByCode
} from "@/api/customer/customer-api";
import {
  getOrgInfo,
  getChildrenByType
} from "@/api/organiZation/organiZation-api";
import {
  getCustomerSource,
  getLocationData,
  getSchools
} from "@/api/metadata/metadata-api";

export default {
  data() {
    return {
      selected: null,
      ReferralStaffOACodeFlag: false,
      customerCodeFlag: false,
      referralStaffJobArr: [],
      searchSchoolNameKeyValue: "",
      schoolParams: {
        searchTerm: "",
        maxCount: 20
      },
      schoolListData: [],
      parentGenderGroup: [
        {
          group: "parentGenderGroup",
          name: "男",
          key: 1
        },
        {
          group: "parentGenderGroup",
          name: "女",
          key: 2
        }
      ],
      customerGenderGroup: [
        {
          group: "customerGenderGroup",
          name: "男",
          key: 1
        },
        {
          group: "customerGenderGroup",
          name: "女",
          key: 2
        }
      ],
      isStudyAgainGroup: [
        {
          group: "isStudyAgainGroup",
          name: "是",
          key: 1
        },
        {
          group: "isStudyAgainGroup",
          name: "否",
          key: 2
        }
      ],
      customerRoleKey: "",
      parentRoleKey: "",
      parentRoleDefault: [
        {
          isValidate: true,
          key: "",
          parentKey: "0",
          value: "家属关系"
        }
      ],
      customerRoleDefault: [
        {
          isValidate: true,
          key: "",
          parentKey: "0",
          value: "子女关系"
        }
      ],
      itemsParams: {
        isShow: false,
        title: "",
        model: "",
        category: "",
        selectItems: []
      },
      guestMess: {}, //存储新增潜客 Model
      departMentObj: {
        isDepart: true,
        branchMess: [],
        campusMess: [],
        branchName: "分公司",
        campusName: "校区"
      },
      sourceType: {
        isDepart: true,
        sourceMainMess: [],
        sourceSecMess: [],
        sourceMainName: "信息来源一",
        sourceSecName: "信息来源二"
      },
      areaMess: {
        provinceMess: [],
        cityMess: [],
        countyMess: [],
        provinceName: "省份",
        cityName: "城市",
        countyName: "区县"
      }
    };
  },
  mounted() {
    this.selected = "1";
  },
  async created() {
    await this.getCreateGuestModel();
    this.registerSubmit();
  },
  methods: {
    textTypeFun(type, msg) {
      switch (type) {
        case "parentName":
          this.guestMess.parent.parentName = msg;
          break;
        case "parentPriPhone":
          this.guestMess.parent.primaryPhone = msg;
          break;
        case "parentSecPhone":
          this.guestMess.parent.secondaryPhone = msg;
          break;
        case "parentGender":
          this.guestMess.parent.gender = msg;
          break;
        case "customerName":
          this.guestMess.customer.customerName = msg;
          break;
        case "customerGender":
          this.guestMess.customer.gender = msg;
          break;
        case "ReferralStaffOACode":
          var _this = this;
          getStaffByOA({ staffOA: msg }, res => {
            if (!res.length) {
              this.ReferralStaffOACodeFlag = true;
            } else {
              _this.guestMess.customer.referralStaffOACode = msg;
              _this.referralStaffJobArr = _this.changeJobListfun(res);
              _this.ReferralStaffOACodeFlag = false;
            }
          });
          break;
        case "customerCode":
          var _this = this;
          getCustomerByCode({ customerCode: msg }, res => {
            if (!res) {
              this.customerCodeFlag = true;
            } else {
              _this.guestMess.customer.customerCode = msg;
              _this.customerCodeFlag = false;
            }
          });
          break;
        case "parentIDNumber":
          this.guestMess.parent.idNumber = msg;
          break;
        case "AddressDetail":
          this.guestMess.parent.addressDetail = msg;
          break;
        case "parentEmail":
          this.guestMess.parent.email = msg;
          break;
        case "customerPhone":
          this.guestMess.customer.primaryPhone = msg;
          break;
        case "customerIDNumber":
          this.guestMess.customer.idNumber = msg;
          break;
        case "isStudyAgain":
          this.guestMess.customer.isStudyAgain = msg;
          break;
        case "schoolName":
          if (!msg) {
            this.schoolListData = [];
            return;
          }
          this.searchSchoolNameKeyValue = msg;
          this.schoolParams.searchTerm = msg;
          getSchools(this.schoolParams, res => {
            this.schoolListData = res;
          });
          break;
      }
    },
    // 获取新增潜客Model
    getCreateGuestModel() {
      $createCustomer({}, res => {
        this.guestMess = res;
        this.init();
        this.initDate(res);
        this.getOrgInfoFun();
        this.getCustomerSourceFun(0);
        this.getLocationDataFun("province", 0);
      });
    },
    // 获取机构信息
    getOrgInfoFun() {
      var _this = this;
      getOrgInfo({}, res => {
        if (res.branch && res.campus) {
          this.departMentObj.branchName = res.branch.name;
          this.departMentObj.campusName = res.campus.name;
          _this.guestMess.customer.branchID = res.branch.id;
          _this.guestMess.customer.campusID = res.campus.id;
          this.departMentObj.isDepart = false;
          return;
        }
        this.getChildrenByTypeFun(
          res.hq.id,
          DepartmentType.Branch,
          "branchMess"
        );
      });
    },
    // 获取子机构
    getChildrenByTypeFun(id, type, dataType) {
      var _this = this;
      getChildrenByType(
        {
          ParentKey: id,
          DepartmentType: type,
          queryDataScope: ""
        },
        res => {
          if (dataType == "branchMess") {
            _this.departMentObj.branchMess = res;
          } else if (dataType == "campusMess")
            _this.departMentObj.campusMess = res;
        }
      );
    },
    // 获取信息来源
    getCustomerSourceFun(id) {
      var _this = this;
      getCustomerSource(
        {
          parentKey: id
        },
        res => {
          if (!id) {
            _this.sourceType.sourceMainMess = res;
            return;
          }
          _this.sourceType.sourceSecMess = res;
        }
      );
    },
    //获取省份
    getLocationDataFun(type, key) {
      getLocationData(
        {
          parentKey: key
        },
        res => {
          if (type == "province") {
            this.areaMess.provinceMess = res;
          } else if (type == "city") {
            this.areaMess.cityMess = res;
          } else if (type == "county") {
            this.areaMess.countyMess = res;
          }
        }
      );
    },
    initDate(data) {
      data.customer.birthday = null;
    },
    changeJobListfun(res) {
      let newArr = [];
      res.forEach(item => {
        let newObj = {
          key: item.id,
          value: item.name,
          moreMess: item
        };
        newArr.push(newObj);
      });
      return newArr;
    },
    //选择学生出生日期
    action() {
      var option = {
        type: "date",
        beginYear: 1990
      };
      let dtPicker = new mui.DtPicker(option);
      const _this = this;
      dtPicker.show(function(selectTime) {
        _this.guestMess.customer.birthday = new Date(
          selectTime.value.replace(/-/g, "/")
        );
      });
    },
    goSelAlreadyParent() {
      this.$router.push({
        name: "selParent"
      });
    },
    selectSchoolFun(item) {
      this.guestMess.customer.schoolID = item.schoolID;
      this.guestMess.customer.schoolName = item.schoolName;
      this.schoolListData = [];
    },
    hightLightFun(schoolName) {
      let replaceReg = new RegExp(this.searchSchoolNameKeyValue, "gi");
      // 高亮替换v-html值
      let replaceString =
        '<span style="color:red;">' + this.searchSchoolNameKeyValue + "</span>";
      // 开始替换
      schoolName = schoolName.replace(replaceReg, replaceString);
      return schoolName;
    },
    registerSubmit() {
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    init() {
      this.guestMess.parentRole = "家属关系";
      this.guestMess.customerRole = "子女关系";
    },
    submit() {
      console.log("提交成功");
    },
    selectItem(category) {
      if (!this.guestMess.customer.branchID && category == "campusID") return;
      if (!this.guestMess.customer.sourceMainType && category == "sourceSec")
        return;
      if (this.guestMess.customer.vipType == 3 && category == "vipLevel")
        return;
      this.itemsParams.isShow = true;
      this.itemsParams.category = category;
      switch (category) {
        case "branchID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.guestMess.customer.branchID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "campusID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.guestMess.customer.campusID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;

        case "contactType":
          this.itemsParams.title = "接触方式";
          this.itemsParams.model = this.guestMess.customer.contactType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceMain":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.guestMess.customer.sourceMainType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceSec":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.guestMess.customer.sourceSubType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "tutoringWill":
          this.itemsParams.title = "辅导意愿";
          this.itemsParams.model = this.guestMess.customer.tutoringWill;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentRole":
          this.itemsParams.title = "亲属关系";
          this.itemsParams.model = this.parentRoleKey;
          //this.itemsParams.model = this.guestMess.parentRole;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "customerRole":
          this.itemsParams.title = "亲属关系";
          this.itemsParams.model = this.customerRoleKey;
          //this.itemsParams.model = this.guestMess.customerRole;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "referralStaffJobID":
          this.itemsParams.title = "转介绍员工岗位";
          this.itemsParams.model = this.guestMess.customer.referralStaffJobID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentIDType":
          this.itemsParams.title = "家长证件类型";
          this.itemsParams.model = String(this.guestMess.parent.idType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "Income":
          this.itemsParams.title = "家庭年收入";
          this.itemsParams.model = String(this.guestMess.parent.income);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "province":
          this.itemsParams.title = "现住址";
          this.itemsParams.model = this.guestMess.parent.province;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "city":
          this.itemsParams.title = "现住址";
          this.itemsParams.model = this.guestMess.parent.city;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "county":
          this.itemsParams.title = "现住址";
          this.itemsParams.model = this.guestMess.parent.county;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "entranceGrade":
          this.itemsParams.title = "入学大年级";
          this.itemsParams.model = this.guestMess.customer.entranceGrade;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "subjectType":
          this.itemsParams.title = "文理科";
          this.itemsParams.model = String(this.guestMess.customer.subjectType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "schoolYear":
          this.itemsParams.title = "学年制";
          this.itemsParams.model = this.guestMess.customer.schoolYear;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "customerIDType":
          this.itemsParams.title = "学员证件类型";
          this.itemsParams.model = String(this.guestMess.customer.idType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "vipType":
          this.itemsParams.title = "VIP客户";
          this.itemsParams.model = String(this.guestMess.customer.vipType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "vipLevel":
          this.itemsParams.title = "VIP等级";
          this.itemsParams.model = String(this.guestMess.customer.vipLevel);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
      }
    },
    _getSelectItems(category) {
      let res = [];
      let parentGender = this.guestMess.parent.gender;
      let customerGender = this.guestMess.customer.gender;
      switch (category) {
        case "branchID":
          res = this.departMentObj.branchMess;
          break;
        case "campusID":
          res = this.departMentObj.campusMess;
          break;
        case "contactType":
          res = this.guestMess.dictionaries
            .C_CODE_ABBR_Customer_CRM_NewContactType;
          break;
        case "sourceMain":
          res = this.sourceType.sourceMainMess;
          break;
        case "sourceSec":
          res = this.sourceType.sourceSecMess;
          break;
        case "tutoringWill":
          res = this.guestMess.dictionaries.C_CODE_ABBR_CUSTOMER_TutorWill;
          break;
        case "customerRole":
          if (!parentGender || !customerGender) {
            res = this.customerRoleDefault;
          } else {
            res = [
              ...this.customerRoleDefault,
              ...this._children(customerGender)
            ];
          }
          break;
        case "parentRole":
          if (!parentGender || !customerGender) {
            res = this.parentRoleDefault;
          } else if (parentGender && customerGender && !this.customerRoleKey) {
            res = [...this.parentRoleDefault, ...this._parents(parentGender)];
          } else if (customerGender && this.customerRoleKey) {
            res = [
              ...this.parentRoleDefault,
              ...this._myParents(this.customerRoleKey, parentGender)
            ];
          }
          break;
        case "referralStaffJobID":
          res = this.referralStaffJobArr;
          break;
        case "parentIDType":
          res = this.guestMess.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
        case "Income":
          res = this.guestMess.dictionaries.C_CODE_ABBR_HOMEINCOME;
          break;
        case "province":
          res = this.areaMess.provinceMess;
          break;
        case "city":
          res = this.areaMess.cityMess;
          break;
        case "county":
          res = this.areaMess.countyMess;
          break;
        case "entranceGrade":
          res = this.guestMess.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
          break;
        case "subjectType":
          res = this.guestMess.dictionaries.C_CODE_ABBR_STUDENTBRANCH;
          break;
        case "schoolYear":
          res = this.guestMess.dictionaries.C_CODE_ABBR_ACDEMICYEAR;
          break;
        case "customerIDType":
          res = this.guestMess.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
        case "vipType":
          res = this.guestMess.dictionaries.C_CODE_ABBR_CUSTOMER_VipType;
          break;
        case "vipLevel":
          res = this.guestMess.dictionaries.C_CODE_ABBR_CUSTOMER_VipLevel;
          break;
        default:
          break;
      }
      return res;
    },
    selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "branchID":
            this.guestMess.customer.branchID = obj.item.key;
            this.departMentObj.branchName = obj.item.value;
            break;
          case "campusID":
            this.guestMess.customer.campusID = obj.item.key;
            this.departMentObj.campusName = obj.item.value;
            break;
          case "sourceMain":
            this.guestMess.customer.sourceMainType = obj.item.key;
            this.sourceType.sourceMainName = obj.item.value;
            break;
          case "sourceSec":
            this.guestMess.customer.sourceSubType = obj.item.key;
            this.sourceType.sourceSecName = obj.item.value;
            break;
          case "contactType":
            this.guestMess.customer.contactType = obj.item.key;
            break;
          case "tutoringWill":
            this.guestMess.customer.tutoringWill = obj.item.key;
            break;
          case "customerRole":
            this.guestMess.customerRole = obj.item.value;
            this.customerRoleKey = obj.item.key;
            break;
          case "parentRole":
            this.guestMess.parentRole = obj.item.value;
            this.parentRoleKey = obj.item.key;
            break;
          case "referralStaffJobID":
            this.guestMess.customer.referralStaffJobID = obj.item.key;
            this.guestMess.customer.referralStaffJobName = obj.item.value;
            break;
          case "parentIDType":
            this.guestMess.parent.idType = obj.item.key;
            break;
          case "Income":
            this.guestMess.parent.income = obj.item.key;
            break;
          case "province":
            this.guestMess.parent.province = obj.item.key;
            this.areaMess.provinceName = obj.item.value;
            break;
          case "city":
            this.guestMess.parent.city = obj.item.key;
            this.areaMess.cityName = obj.item.value;
            break;
          case "county":
            this.guestMess.parent.county = obj.item.key;
            this.areaMess.countyName = obj.item.value;
            break;
          case "entranceGrade":
            this.guestMess.customer.entranceGrade = obj.item.key;
            break;
          case "subjectType":
            this.guestMess.customer.subjectType = obj.item.key;
            break;
          case "schoolYear":
            this.guestMess.customer.schoolYear = obj.item.key;
            break;
          case "customerIDType":
            this.guestMess.customer.idType = obj.item.key;
            break;
          case "vipType":
            this.guestMess.customer.vipType = obj.item.key;
            break;
          case "vipLevel":
            this.guestMess.customer.vipLevel = obj.item.key;
            break;
        }
      }
    },
    //通过性别获取家长列表
    _parents(ps) {
      var ret = [];
      for (var i = 0; i < psr.length; i++) {
        if (psr[i].ps == ps) {
          ret.push(psr[i]);
        }
      }
      return ret;
    },
    //通过家长ID及孩子性别获取孩子列表
    _myChildren(key, ss) {
      var ret = [];
      for (var i = 0; i < psr.length; i++) {
        if (psr[i].key == key) {
          if (!ss) return psr[i].r;
          else {
            for (var j = 0; j < psr[i].r.length; j++) {
              if (ss == psr[i].r[j].ss) {
                ret.push(psr[i].r[j]);
              }
            }
          }
        }
      }
      return ret;
    },
    //通过孩子性别获取孩子列表
    _children(ss) {
      var ret = [];
      for (var i = 0; i < spr.length; i++) {
        if (spr[i].ss == ss) {
          ret.push(spr[i]);
        }
      }
      return ret;
    },
    //通过孩子ID及家长性别获取家长列表
    _myParents(key, ps) {
      var ret = [];
      for (var i = 0; i < spr.length; i++) {
        if (spr[i].key == key) {
          if (!ps) return spr[i].r;
          else {
            for (var j = 0; j < spr[i].r.length; j++) {
              if (ps == spr[i].r[j].ps) {
                ret.push(spr[i].r[j]);
              }
            }
          }
        }
      }
      return ret;
    }
  },
  watch: {
    "guestMess.customerRole"() {
      this.guestMess.parentRole = "家属关系";
      this.parentRoleKey = "";
    },
    "guestMess.customer.branchID"(obj) {
      if (obj) {
        if (!this.departMentObj.isDepart) return;
        this.departMentObj.campusName = "校区";
        this.guestMess.customer.campusID = null;
        this.getChildrenByTypeFun(obj, DepartmentType.Campus, "campusMess");
      }
    },
    "guestMess.customer.sourceMainType"(obj) {
      if (obj) {
        this.sourceType.sourceSecName = "信息来源二";
        this.guestMess.customer.sourceSubType = null;
        this.getCustomerSourceFun(obj);
      }
    },
    "guestMess.parent.province"(obj) {
      if (!obj) return;
      this.getLocationDataFun("city", obj);
      this.areaMess.cityName = "城市";
      this.areaMess.countyName = "区县";
      this.guestMess.parent.city = null;
      this.guestMess.parent.county = null;
    },
    "guestMess.parent.city"(obj) {
      if (!obj) return;
      this.getLocationDataFun("county", obj);
      this.areaMess.countyName = "区县";
      this.guestMess.parent.county = null;
    },
    "guestMess.customer.vipType"(obj) {
      if (!obj) return;
      if (obj == 3) {
        this.guestMess.customer.vipLevel = null;
      }
    }
  },
  components: {
    TextType,
    SelectItems,
    Tip
  }
};
</script>
<style lang="scss" scoped>
$contentColor: #999;
.xd-add-guest {
  .tab-header {
    margin-top: torem(10);
  }
  .group-list {
    margin-top: torem(12);
    li {
      font-size: torem(14);
      .select-parent {
        border: none;
        float: right;
        margin-right: torem(15);
        color: skyblue;
        font-size: torem(16);
        margin-top: torem(10);
      }
    }
    .eleDisplay {
      display: flex;
      .request {
        color: red;
        margin-top: torem(3);
        margin-right: torem(3);
      }
    }
    .item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: torem(45);
      line-height: torem(45);
      border-bottom: 1px solid rgba(239, 239, 244, 0.5);
      .item-left {
        padding-left: torem(10);
        span {
          display: inline-block;
          width: torem(120);
          text-align: center;
        }
      }
      .item-right {
        position: absolute;
        right: torem(40);
        flex: 1;
        text-align: right;
        color: $contentColor;
      }
    }
    .vis {
      visibility: hidden;
    }
    .edit {
      &:after {
        margin: 0 5px;
        content: "\E583";
        font-family: Muiicons;
        -webkit-font-smoothing: antialiased;
        font-size: 14px;
        color: $contentColor;
      }
    }
  }
  .xdapp-tip {
    height: torem(21);
    color: red;
  }
  .relative {
    position: relative;
  }
  .schollList {
    background: #ddd;
    position: absolute;
    width: 90%;
    height: auto;
    max-height: torem(170);
    z-index: 99;
    left: 5%;
    right: 5%;
    padding: 10px 15px;
    border-radius: 15px;
    overflow: auto;
    li {
      height: torem(40);
      line-height: torem(40);
      border-bottom: 1px solid #eee;
      padding-left: 15px;
    }
  }
}
</style>


