<template>
 <div v-for="(currentItem,index) in parentList"    class="info-tab">
					<div class="cell">
						<div class="cell-1"><span>★▲■</span>家长姓名</div>
						<div class="cell-2">{{currentItem.parentName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家长性别</div>
						<div class="cell-2">{{currentItem.gender|gender}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>亲属关系</div>
						<div class="cell-2">{{currentItem.parentRole|childFemale}}</div>
						<!--  -->
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲★</span>主要联系方式</div>
						<div class="cell-2">{{currentItem.primaryPhone && currentItem.primaryPhone.phoneNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">辅助联系方式</div>
						<div class="cell-2">{{currentItem.secondaryPhone && currentItem.secondaryPhone.phoneNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">是否主监护人</div>
						<div class="cell-2">{{currentItem.isPrimary==1?'是':'否'}}</div>
					</div>
				</div>
				<div   v-for="(currentItem,index) in parentList"   class="info-tab">
					<div class="cell" >
						<div class="cell-1">现住址</div>
						<div class="cell-2">{{currentItem.province|region}}{{currentItem.city|region}}{{currentItem.county|region}}{{currentItem.addressDetail}}</div>
					</div>
					
					<div class="cell">
						<div class="cell-1">家长Email</div>
						<div class="cell-2">{{currentItem.email}}</div>
					</div>

					<div class="cell">
						<div class="cell-1"><span>■</span>{{currentItem.idType | idtype}}</div>
						<div class="cell-2">{{currentItem.idNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家庭年总收入</div>
						<div class="cell-2">{{currentItem.income | homeIncome}}</div>
					</div>
				</div>
</template>
