<template>



  <div class="student-info">
    <!-- <mt-navbar class="student-info-nav" v-model="navIndex" v-power="['睿学-学员信息-不带电话']">
			<mt-tab-item id="1" @click="this.curIndex=index" v-for="(item,index) in navList"  class="nav-item" :class="{on:curIndex==index}">{{item}}</mt-tab-item>
    </mt-navbar>-->
		<span v-show="!editing" class="top-btn-edit" @click="editParentInfo">编辑</span>
		<span v-show="editing" class="top-btn-save" @click="save">保存</span>
		<span v-show="editing" class="top-btn-cancel" @click="cancelEdit">取消</span>
    <mt-navbar class="student-info-nav" v-model="selected">
      <mt-tab-item id="2">基本信息</mt-tab-item>
      <mt-tab-item id="1">家长信息</mt-tab-item>
      <mt-tab-item id="3">跟进记录</mt-tab-item>
    </mt-navbar>

	<div class="info-edit-des">
		注意：★为必填项，▲为充值所需项，■为关键信息，签约后只允许分审核经理修改。
	</div>
	
    <!-- tab-container -->
    <mt-tab-container v-model="selected">
      <mt-tab-container-item  v-if="!editing"  id="2"></mt-tab-container-item>
			<mt-tab-container-item v-if="editing"  id="2"></mt-tab-container-item>
      <mt-tab-container-item v-if="!editing" id="1">
				<ul class="parent-tabs">
					<template v-if="parentList.length" >
						<li v-for="(item,index) in parentList" @click="parentIndex=index" :class="{active:parentIndex==index}"  >{{item.parentName}}{{item.isPrimary==1?'（主）':''}}</li>
					</template>
						<li @click="getAddParentModel">+</li>
				</ul>

	
				<div v-for="(item,index) in parentList"    class="info-tab">
					<div class="cell">
						<div class="cell-1"><span>★▲■</span>家长姓名</div>
						<div class="cell-2">{{item.parentName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家长性别</div>
						<div class="cell-2">{{item.gender|gender}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>亲属关系</div>
						<div class="cell-2">{{item.parentRole|childFemale}}</div>
						<!--  -->
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲★</span>主要联系方式</div>
						<div class="cell-2">{{item.primaryPhone && item.primaryPhone.phoneNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">辅助联系方式</div>
						<div class="cell-2">{{item.secondaryPhone && item.secondaryPhone.phoneNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">是否主监护人</div>
						<div class="cell-2">{{item.isPrimary==1?'是':'否'}}</div>
					</div>
				</div>
				<div   v-for="(item,index) in parentList"   class="info-tab">
					<div class="cell" >
						<div class="cell-1">现住址</div>
						<div class="cell-2">{{item.province|region}}{{item.city|region}}{{item.county|region}}{{item.addressDetail}}</div>
					</div>
					
					<div class="cell">
						<div class="cell-1">家长Email</div>
						<div class="cell-2">{{item.email}}</div>
					</div>

					<div class="cell">
						<div class="cell-1"><span>■</span>{{item.idType | idtype}}</div>
						<div class="cell-2">{{item.idNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">家庭年总收入</div>
						<div class="cell-2">{{item.income | homeIncome}}</div>
					</div>
				</div>
			</mt-tab-container-item>
			<mt-tab-container-item v-if="editing" id="1">
				
        <ul class="parent-tabs">
          <template v-if="parentList.length" >
						<li v-for="(item,index) in parentList" @click="parentIndex=index" :class="{active:parentIndex==index}"  >{{item.parentName}}{{item.isPrimary=='true'?'（主）':''}}</li>
					</template>
        </ul>
        <div class="info-tab">
          <div class="cell">
            <div class="cell-1">
              <span>★▲■</span>家长姓名
            </div>
            <div class="cell-2"><input type="text"  v-model="editingModel.parentName"></div>
          </div>
          <div class="cell"  @click.prevent.stop="selectItem('gender')" >
            <div class="cell-1">家长性别</div>
						<div class="cell-2 edit">{{editingModel.gender|gender}}<span class="ar">></span></div>
            <!-- <div class="cell-2"><mt-radio align="right" v-model="editingModel.gender" :options="[{label:'男',value:'1'},{label:'女',value:'2'}]"></mt-radio></div> -->
          </div>
          <div @click.prevent.stop="selectItem('customerRole')" class="cell">
            <div class="cell-1">
              <span>▲</span>亲属关系
            </div>
            <div v-if="sex==2" class="cell-2">{{pResult.customerName}}是{{editingModel.parentName}}的{{editingModel.customerRole|childFemale}}</div>
            <div v-if="sex==1" class="cell-2">{{pResult.customerName}}是{{editingModel.parentName}}的{{editingModel.customerRole|childMale}}</div>
          </div>
          <div v-show="showParentRelation" @click.prevent.stop="selectItem('parentRole')"  class="cell">
            <div class="cell-1">
               <span>▲</span>亲属关系
            </div>
            <div v-if="editingModel.gender=='2'" class="cell-2">{{editingModel.parentName}}是{{pResult.customerName}}的{{editingModel.parentRole|parentFemale}}</div>
            <div v-if="editingModel.gender=='1'" class="cell-2">{{editingModel.parentName}}是{{pResult.customerName}}的{{editingModel.parentRole|parentMale}}</div>
          </div>
          <div class="cell">
            <div class="cell-1">
              <span>▲★</span>主要联系方式
            </div>
            <div class="cell-2"><input type="text" v-model="editingModel.primaryPhone.phoneNumber"></div>
          </div>
          <div class="cell">
            <div class="cell-1">辅助联系方式</div>
            <div class="cell-2"><input type="text" v-model="editingModel.secondaryPhone.phoneNumber"></div>
          </div>
          <!-- <div class="cell">
            <div class="cell-1">是否主监护人</div>
            <div class="cell-2">
							<mt-radio align="right" v-model="editingModel.isPrimary" :options="[{label:'是',value:'true'},{label:'否',value:'false'}]"></mt-radio>
						</div>
          </div> -->
        </div>
        <div class="info-tab">
          <!-- <div class="cell">
            <div class="cell-1">现住址</div>
            <div class="cell-2">湖南省-长沙市-芙蓉区<span class="ar">></span></div>
          </div> -->
					<div class="cell" @click.prevent.stop="selectItem('province')">
						<div class="cell-1">现住址：省</div>
						<div class="cell-2 edit">{{editingModel.province|region}}<span class="ar">></span></div>
					</div>
					<div class="cell" @click.prevent.stop="selectItem('city')">
						<div class="cell-1">市</div>
						<div class="cell-2 edit">{{editingModel.city|region}}<span class="ar">></span></div>
					</div>
					<div class="cell" @click.prevent.stop="selectItem('county')">
						<div class="cell-1">县</div>
						<div class="cell-2 edit">{{editingModel.county|region}}<span class="ar">></span></div>
					</div>
					<div class="cell">
            <div class="cell-1">详细地址</div>
            <div class="cell-2"><input type="text" v-model="editingModel.addressDetail"></div>
          </div>
          <div class="cell">
            <div class="cell-1">家长Email</div>
            <div class="cell-2"><input type="text" v-model="editingModel.email"></div>
          </div>

					<div class="cell" @click.prevent.stop="selectItem('parentIDType')">
						<div class="cell-1"   >证件类型</div>
						<div class="cell-2 edit">{{editingModel.idType | idtype}}<span class="ar">></span></div>
					</div>
					<div class="cell">
						<div class="cell-1">输入编号</div>
						<div class="cell-2"><input type="text" v-model="editingModel.idNumber"></div>
					</div>

          <div class="cell"  @click.prevent.stop="selectItem('Income')">
            <div class="cell-1">家庭年总收入</div>
            <div class="cell-2">{{editingModel.income | homeIncome}}<span class="ar">></span></div>
          </div>
        </div>
      </mt-tab-container-item>
      <mt-tab-container-item id="3"></mt-tab-container-item>
    </mt-tab-container>
		<select-items
        v-show="itemsParams.isShow"
        :title="itemsParams.title"
        :model="itemsParams.model"
        :isShow="itemsParams.isShow"
        :category="itemsParams.category"
        :items="itemsParams.selectItems"
        @selectItem="selectVisitType"
      ></select-items>
  </div>
</template>
<script>
import { spr, psr } from "@/constants";
import {
  cell as mtCell,
  Navbar as mtNavbar,
  TabItem as mtTabItem,
	Loadmore as mtLoadmore,
	Actionsheet  as mtActionsheet,
} from "mint-ui";
import {
	getCustomerInfo,
	getAllCustomers,
	getCustomerParents,
	updateCustomerParent,
  updateCustomer,
  createCustomerParent,
  createCustomerParentGet,
} from "@/api/customer/customer-api";
import {
	getCustomerSource,
	getLocationData,
	getSchools,
} from "@/api/metadata/metadata-api";
import { debug } from 'util';
import SelectItems from "@/components/select-items/index";
import { setTimeout } from 'timers';


export default {
  data() {
    return {
			itemsParams: {
        isShow: false,
        title: "",
        model: "",
        category: "",
        selectItems: []
      },
      selected: "1",
      navIndex: null,
			curIndex: 0,
			info:{},
			zxs:{},
			xgs:{},
			js:{},
			zxzy:{},
			sczy:{},
			parentList:[],
			restudy:null,
      rawEditingModel:{},
      editingModel:{},
			parentIndex:0,
			navList: ["基本信息", "家长信息", "跟进记录"],
			editing:false,
			clone:{},
			infoSrc:'',
			newInfo:{},
			infoRes:{},
			result:{},
      pResult:{},
      customerName:'',
      oldGender:'',
			areaMess: {
        provinceMess: [],
        cityMess: [],
        countyMess: [],
        provinceName: "省份",
        cityName: "城市",
        countyName: "区县"
      },
      editOrAdd:'',
      pm:{},
      addRes:{},
      showParentRelation:false,
    };
	},
	created(){
		this.init();
		// getAllCustomers({pageParams:{pageIndex: 0, pageSize: 0}},(res)=>{
		// 	console.log(res)
		// });
	},
	computed:{
		sex(){
      
      return this.$route.query.sex;
    },
		editingModel2(){
			if(!this.rawEditingModel.primaryPhone){
				this.rawEditingModel.primaryPhone={}
			}
			if(!this.rawEditingModel.secondaryPhone){
				this.rawEditingModel.secondaryPhone={}
			}




			return this.rawEditingModel
		}
	},
	mounted(){
		// this.$nextTick(()=>{
		// 		this.editing=true
		// })
		
		// this.selectVisitType()
	},
	watch:{
    // "editingModel.gender":{
    //   handler:function(data){
    //     // debugger
    //     console.log(this.editingModel.parentRole)
    //     if (data =='1') {
    //       this.editingModel.parentRole=((this.editingModel.parentRole)*1-1).toString()
    //     }
    //     if (data =='2') {
    //       this.editingModel.parentRole=((this.editingModel.parentRole)*1+1).toString()
    //     }
    //     console.log(this.editingModel.parentRole)
    //   },
    // },
		// "editingModel.province"(obj) {
    //   debugger
    //   if (!obj) return;
    //   this.getLocationDataFun("city", obj);
    //   this.areaMess.cityName = "城市";
    //   this.areaMess.countyName = "区县";
    //   // this.editingModel.city = null;
    //   // this.editingModel.county = null;
    // },
    // "editingModel.city"(obj) {
      
    //   if (!obj) return;
    //   this.getLocationDataFun("county", obj);
    //   this.areaMess.countyName = "区县";
    //   // this.editingModel.county = null;
    // },
	},
	methods:{
		 init(){
			let id = this.$route.query.id;
			
       this.viewDetail(id);
      

			
    },
    getAddParentModel(){
      this.editOrAdd='add';
      createCustomerParentGet({id:this.$route.query.id},res=>{
        // debugger
        // console.log(res)
        this.addRes=res;
        this.editingModel=res.parent;
        if(this.editingModel.parentRole){
          this.showParentRelation=true;
        }else{
          this.showParentRelation=false;
        }
        if(!this.editingModel.primaryPhone){
          this.editingModel.primaryPhone={}
        }
        if(!this.editingModel.secondaryPhone){
          this.editingModel.secondaryPhone={}
        }
        this.editing=true;
        console.log(res)
      })
    },
    addParent(){
      createCustomerParent(this.addRes,res=>{
        console.log(res)
      })
    },
	
		//获取省份
    getLocationDataFun(type, key) {
      getLocationData(
        {
          parentKey: key
        },
        res => {
          console.log(res)
          if (type == "province") {
            this.areaMess.provinceMess = res;
          } else if (type == "city") {
            this.areaMess.cityMess = res;
          } else if (type == "county") {
            this.areaMess.countyMess = res;
          }
        }
      );
    },
		getInfoSource(key,secKey){
			if(key || key=='0'){
				let r={}
				getCustomerSource({parentKey:key},res=>{
					r= res.find((v) => (v.key == secKey))
					this.infoSrc=r.value
				})
				
			}
		},
		idTypeName(id){
			switch(id){
				case 0:return '身份证';
				case 1:return '学生证';
				default :return '其它证件'
			}
		},
		showBox(){
			this.itemsParams.isShow = true;
		},
		viewHistory(tea){
			if(tea && tea.customerID){
				this.$router.push({name:'teacherHistory',query:{type:tea.relationType,id:tea.customerID}})
			}else{
				return false;
			}
		}, 
		save(){
      debugger
      // this.saveInfo();
      if(this.editOrAdd=='edit'){
        this.saveParentInfo();
      }else if(this.editOrAdd=='add'){
        this.addParent();
      }
			
		},
		saveInfo(){
      updateCustomer(this.infoRes,(res)=>{
        console.log(res)
      })
      
			
		},
		saveParentInfo(){
			
			let customerID=this.editingModel.customerID;
			
			console.log(this.editingModel)
			console.log(this.parentList[this.parentIndex])
			// console.log(this.editParentInfo())
			// console.log({...this.editParentInfo()})

			// console.log(this.editParentInfo.customerID)
			updateCustomerParent({
				customer:this.info,
				// customerID,
				parent:this.editingModel,
				customerParentRelation:{
					customerID:this.editingModel.customerID,
					parentID:this.editingModel.parentID,
					customerRole:this.editingModel.customerRole,
					parentRole:this.editingModel.parentRole,
					isPrimary:this.editingModel.isPrimary,
				},
			},(res)=>{
				console.log(res)
			})
		},
		cancelEdit(){
			this.editing=false;
			this.init();
			// this.rawEditingModel=this.clone
		},
	  async	editParentInfo(){
      this.editing=true;
      this.editOrAdd='edit'
      this.editingModel=this.parentList[this.parentIndex];
      if(this.editingModel.parentRole){
        this.showParentRelation=true;
      }else{
        this.showParentRelation=false;
      }
      if(!this.editingModel.primaryPhone){
				this.editingModel.primaryPhone={}
			}
			if(!this.editingModel.secondaryPhone){
				this.editingModel.secondaryPhone={}
			}
      // this.oldGender=this.editingModel.gender;
      // this.newInfo=this.info;
      
      await this.getLocationDataFun("province", 0);
      await this.getLocationDataFun("city", this.editingModel.province);
      await this.getLocationDataFun("county", this.editingModel.city);
			
			// this.rawEditingModel=this.parentList[this.parentIndex];
			
			// this.clone=copy(this.rawEditingModel,this.clone)
		},
		viewDetail(id){
      getCustomerInfo({id}, res => {
				console.log(res)
				this.infoRes=res;
				this.info=res.customer;
				this.result=res;
				this.getInfoSource(this.info.sourceMainType,this.info.sourceSubType)
        res.customerStaffRelations.forEach((v)=>{
					if(v.relationType==1){
						this.zxs=v;
					}else if(v.relationType==2){
						this.xgs=v;
					}else if(v.relationType==3){
						this.js=v;
					}else if(v.relationType==4){
						this.zxzy=v;
					}else if(v.relationType==5){
						this.sczy=v;
					}
				})
			});
			getCustomerParents({id},res=>{
				console.log(res)
        this.pResult=res;
        
				this.parentList=res.queryResult;
				console.log(this.parentList.length)
				// console.log(this.parentList[0].parentName)
			})
		},
		selectItem(category) {
      this.itemsParams.isShow = true;
      this.itemsParams.category = category;
      switch (category) {
        case "branchID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.result.customer.branchID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "campusID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.result.customer.campusID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;

        case "contactType":
          this.itemsParams.title = "接触方式";
          this.itemsParams.model = this.result.customer.contactType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceMain":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.result.customer.sourceMainType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceSec":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.result.customer.sourceSubType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "tutoringWill":
          this.itemsParams.title = "辅导意愿";
          this.itemsParams.model = this.result.customer.tutoringWill;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentRole":
          this.itemsParams.title = "亲属关系";
          // this.itemsParams.model = this.parentRoleKey;
          this.itemsParams.model = this.editingModel.parentRole;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "customerRole":
          this.itemsParams.title = "亲属关系";
          // this.itemsParams.model = this.customerRoleKey;
          this.itemsParams.model = this.editingModel.customerRole;
          this.itemsParams.selectItems = this._getSelectItems(category);
				  break;
				case "province":
          this.itemsParams.title = "省";
          this.itemsParams.model = this.editingModel.province;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "city":
          this.itemsParams.title = "市";
          this.itemsParams.model = this.editingModel.city;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "county":
          this.itemsParams.title = "县/区";
          this.itemsParams.model = this.editingModel.county;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentIDType":
          this.itemsParams.title = "家长证件类型";
          this.itemsParams.model = String(this.editingModel.idType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "Income":
          this.itemsParams.title = "家庭年收入";
          this.itemsParams.model = String(this.editingModel.income);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "gender":
          this.itemsParams.title = "性别";
          this.itemsParams.model = this.editingModel.gender;
          this.itemsParams.selectItems = xdapp.dict.c_code_abbr_gender


          break;

      }
    },
		_getSelectItems(category) {
      let res = [];
      let parentGender = this.result.parent.gender;
      let customerGender = this.result.customer.gender;
      switch (category) {
        case "branchID":
          res = this.departMentObj.branchMess;
          break;
        case "campusID":
          res = this.departMentObj.campusMess;
          break;
        case "contactType":
          res = this.result.dictionaries
            .C_CODE_ABBR_Customer_CRM_NewContactType;
          break;
        case "sourceMain":
          res = this.sourceType.sourceMainMess;
          break;
        case "sourceSec":
          res = this.sourceType.sourceSecMess;
          break;
        case "tutoringWill":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_TutorWill;
          break;
        case "customerRole":
          
          console.log(psr)
          console.log(spr)
          // let list= psr.filter((v,i)=>{
          //   return v.key==this.editingModel.parentRole && v.ps ==this.editingModel.gender
          // })
          let list= spr.filter((v,i)=>{
            return v.ss ==this.sex
          })
          res = list
          // console.log(list)
          // if(this.sex==1){
            
            
          //   res= xdapp.dict.c_code_abbr_childmaledictionary
          // }else if(this.sex==2){
            
          //   res= xdapp.dict.c_code_abbr_childfemaledictionary
          // }
          break;
        case "parentRole":
          // debugger
          let list2= spr.filter((v,i)=>{
            return v.key==this.editingModel.customerRole && v.ss ==this.sex
          })
          try {
              res = list2[0].r.filter((v)=>{
              return v.ps==this.editingModel.gender;
              this.showParentRelation=true
            })
          } catch (error) {
            this.showParentRelation=false
            // res=[]
          }
          
          // if(this.editingModel.gender=='1'){
          //   res= xdapp.dict.c_code_abbr_parentmaledictionary
          // }else if(this.editingModel.gender=='2'){
          //   res= xdapp.dict.c_code_abbr_parentfemaledictionary
          // }
          break;
        case "referralStaffJobID":
          res = this.referralStaffJobArr;
          break;
        case "parentIDType":
          res = this.result.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
				case "Income":
          res = this.pResult.dictionaries.C_CODE_ABBR_HOMEINCOME;
          break;
        case "province":
          res = this.areaMess.provinceMess;
          break;
        case "city":
          res = this.areaMess.cityMess;
          break;
        case "county":
          res = this.areaMess.countyMess;
          break;
        case "entranceGrade":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
					break;
				case "grade":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
          break;
        case "subjectType":
          res = this.result.dictionaries.C_CODE_ABBR_STUDENTBRANCH;
          break;
        case "schoolYear":
          res = this.result.dictionaries.C_CODE_ABBR_ACDEMICYEAR;
          break;
        case "customerIDType":
          res = this.result.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
        case "vipType":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_VipType;
          break;
        case "vipLevel":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_VipLevel;
          break;
        default:
          break;
      }
      return res;
    },
		selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "gender":
            this.editingModel.gender = obj.item.key;
            try {
              let list4 = spr.filter(v=>v.key==this.editingModel.customerRole && v.ss == this.sex)
              let r2=(list4[0].r.filter(v=>v.ps==this.editingModel.gender))[0].key
              this.editingModel.parentRole = r2;
              this.showParentRelation=true
            } catch (error) {
              this.showParentRelation=false
            }
            
            break;
          case "branchID":
            this.result.customer.branchID = obj.item.key;
            this.departMentObj.branchName = obj.item.value;
            break;
          case "campusID":
            this.result.customer.campusID = obj.item.key;
            this.result.customer.campusName = obj.item.value;
            break;
          case "sourceMain":
            this.result.customer.sourceMainType = obj.item.key;
            this.sourceType.sourceMainName = obj.item.value;
            break;
          case "sourceSec":
            this.result.customer.sourceSubType = obj.item.key;
            this.sourceType.sourceSecName = obj.item.value;
            break;
          case "contactType":
            this.result.customer.contactType = obj.item.key;
            break;
          case "tutoringWill":
            this.result.customer.tutoringWill = obj.item.key;
            break;
          case "customerRole":
            this.editingModel.customerRole = obj.item.key;
            try {
              let list3 = spr.filter(v=>v.key==this.editingModel.customerRole && v.ss == this.sex)
              let r=(list3[0].r.filter(v=>v.ps==this.editingModel.gender))[0].key
              this.editingModel.parentRole = r;
              this.showParentRelation=true
            } catch (error) {
              this.showParentRelation=false
            }
            
            // this.customerRoleKey = obj.item.key;
            break;
          case "parentRole":
            this.editingModel.parentRole = obj.item.key;
            this.itemsParams.model = this.editingModel.customerRole;
            // this.editingModel.customerRole = obj.item.key;
            // this.parentRoleKey = obj.item.key;
            break;
          case "referralStaffJobID":
            //判断存储OA人员岗位列表  是否有用户手动选择的
            if (this.referralStaffJobArr.length) {
              this.referralStaffJobArr.forEach(item => {
                if (item.key == obj.item.key) {
                  this.result.customer.referralStaffJobID = obj.item.key;
                  this.result.customer.referralStaffJobName = obj.item.value;
                } else {
                  this.result.customer.referralStaffJobID = this.referralStaffJobArr[0].key;
                  this.result.customer.referralStaffJobName = this.referralStaffJobArr[0].value;
                }
              });
            } else {
              this.result.customer.referralStaffJobID = obj.item.key;
              this.result.customer.referralStaffJobName = obj.item.value;
            }
            break;
          case "parentIDType":
            this.editingModel.idType = obj.item.key;
            break;
          case "Income":
            this.editingModel.income = obj.item.key;
            break;
          case "province":
            this.editingModel.province = obj.item.key;
            this.getLocationDataFun("city", this.editingModel.province);
            this.areaMess.cityName = "城市";
            this.areaMess.countyName = "区县";
            this.editingModel.city = null;
            this.editingModel.county = null;
            this.areaMess.provinceName = obj.item.value;
            break;
          case "city":
            this.editingModel.city = obj.item.key;
            this.getLocationDataFun("county", this.editingModel.city);
            this.areaMess.countyName = "区县";
            this.editingModel.county = null;
            this.areaMess.cityName = obj.item.value;
            break;
          case "county":

            this.editingModel.county = obj.item.key;
            this.areaMess.countyName = obj.item.value;
            break;
          case "entranceGrade":
            this.result.customer.entranceGrade = obj.item.key;
						break;
					case "grade":
            this.result.customer.grade = obj.item.key;
            break;
          case "subjectType":
            this.result.customer.subjectType = obj.item.key;
            break;
          case "schoolYear":
            this.result.customer.schoolYear = obj.item.key;
            break;
          case "customerIDType":
            this.result.customer.idType = obj.item.key;
            break;
					case "vipType":
						if(obj.item.key == 3){
							this.result.customer.vipLevel=null;
						}
            this.result.customer.vipType = obj.item.key;
            break;
          case "vipLevel":
            this.result.customer.vipLevel = obj.item.key;
            break;
        }
      }
    },
	},
  components: {
    SelectItems,
  }
};
</script>

<style lang="scss">
.student-info {
	.ar{float: right;}

	.mint-radiolist{display: flex}
	.mint-radiolist *{margin: 0}
	.mint-cell-wrapper,.mint-radiolist,.mint-cell{height: torem(16);line-height: torem(16)}
	.mint-radiolist .mint-cell{    background: transparent;}
	.mint-cell-wrapper{background: none;transform: translateY(-8px);}

	span.mint-radio-label{display: inline-block;transform:translateX(-20px);}
	.mint-radiolist-title{margin-left: 0}
}
</style>

<style lang='scss' scoped>
.edit{
	color: #aaa;
	span{color:#333}
}
.top-btn-edit{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 100;
}
.top-btn-save{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 100;
}
.top-btn-cancel{
	position: fixed;
	font-size: 15px;
	top: 30px;
	right: 60px;
	color: #fff;
	z-index: 100;
}
.parent-tabs {
  margin-bottom: 10px;
  font-size: 0px;
  li {
		&.active{    
			background-image: linear-gradient(90deg, #FF9900 0%, #FFB82A 100%);
			height: 100%;
			border-bottom: none!important;
			color: #fff!important;
		}
    background: #fff;
    display: inline-block;
    font-size: torem(16);
    line-height: torem(16);
    padding: torem(8);
    border-right: 1px solid #ddd;
    // width:30vw;
    &.on {
      background: #888;
    }
  }
}
.student-info {
	.mint-radiolist{display: flex}
	span.mint-radio-label{display: inline-block;transform:translateX(-15px);}
  .student-info-nav {
    margin-top: 16px;
    width: 100%;
    margin-left: 0;
    border-radius: 5px;
    overflow: hidden;
  }
  background: #eee;
  padding: 30px 10px 20px;
  .info-edit-des {
    font-size: torem(16);
    color: #888;
    margin: 15px 0;
  }
  .info-tab {
    background: #fff;
    margin: 0 0 15px;
    padding-bottom: 10px;
    .cell {
      display: flex;
      font-size: torem(16);
      line-height: torem(32);
      margin: torem(5) torem(8);
      border-bottom: torem(1) solid #ddd;
      .cell-1 {
        span {
          color: red;
          font-size: torem(20);
        }
        flex: 4;
        text-align: right;
        padding-right: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(16);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
    }
  }
}

.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
