<template>

<div style="background:#eee;padding-bottom:30px;">		
		<span class="top-btn-edit" @click="addRecord" >新增跟进</span>
		<!-- <span v-show="editing" class="top-btn-save" @click="save">保存</span>
		<span v-show="editing" class="top-btn-cancel" @click="cancel">取消</span> -->

  <div style="overflow:hidden;height:calc(100vh - 65px)" class="student-info">
    <!-- <mt-navbar class="student-info-nav" v-model="navIndex" v-power="['睿学-学员信息-不带电话']">
			<mt-tab-item id="1" @click="this.curIndex=index" v-for="(item,index) in navList" :key="index" class="nav-item" :class="{on:curIndex==index}">{{item}}</mt-tab-item>
    </mt-navbar>-->

    <mt-navbar class="student-info-nav" v-model="selected">
      <mt-tab-item @click.native="toStudentView"  id="1">基本信息</mt-tab-item>
      <mt-tab-item @click.native="toParentView"  id="2">家长信息</mt-tab-item>
      <mt-tab-item id="3">跟进记录</mt-tab-item>
    </mt-navbar>

	<!-- <div class="info-edit-des">
		注意：<span class="red"><span class="wjx">★</span></span>为必填项，<span class="red">▲</span>为充值所需项，<span class="red">■</span>为关键信息，签约后只允许分审核经理修改。
	</div> -->
	
    <!-- tab-container -->
    <mt-tab-container v-model="selected">
      <mt-tab-container-item  id="1"></mt-tab-container-item>
		
      <mt-tab-container-item   id="2"></mt-tab-container-item>
      <mt-tab-container-item id="3">
				<div class="records" v-if="loaded&&recordList.length>0">
					<div class="record-header">
						<div>跟进时间</div>
						<div>跟进后阶段</div>
						<div>预计上门时间</div>
						<span style="color:transparent">></span>
					</div>
					<div class="record-items">
						<ul >
							<li @click="viewRecord(item)" v-for="(item,index) in recordList">
								<span class="con">{{item.followTime | dateFormat('yyyy-MM-dd')}}</span>
								<span class="con">{{item.followStage | followStage}}</span>
								<span class="con">{{item.planVerifyTime | dateFormat('yyyy-MM-dd')}}</span>
								<span class="arrow">></span>
							</li>
						</ul>
						
					</div>
				</div>
				<div class="nothing" v-else>
							暂无跟进记录
						</div>
			</mt-tab-container-item>
    </mt-tab-container>
		
  </div>
	</div>
</template>
<script>
import {
  cell as mtCell,
  Navbar as mtNavbar,
  TabItem as mtTabItem,
	Loadmore as mtLoadmore,
	Actionsheet  as mtActionsheet,
} from "mint-ui";
import {
	getAllFollows,
} from "@/api/customerFollows/customerFollows-api";
import {
	getCustomerSource,
	getLocationData,
	getSchools,
} from "@/api/metadata/metadata-api";
import { debug } from 'util';
import SelectItems from "@/components/select-items/index";
import { setTimeout } from 'timers';

function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
function resize2() {
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}

export default {
  data() {
    return {
			cname:'',
			
			loaded:false,
			phoneNumber:'',
      selected: "3",
      navIndex: null,
			curIndex: 0,
			parentList:[],
			restudy:null,
			rawEditingModel:{},
			parentIndex:0,
			navList: ["基本信息", "家长信息", "跟进记录"],
			editing:false,
			clone:{},
			sex:'',
			infoSrc:'',
			newInfo:{},
			guardian:'aaa',
			result:{},
			schoolListData: [],
			searchSchoolNameKeyValue: "",
			schoolParams: {
        searchTerm: "",
        maxCount: 20
			},
			isDataChange:false,
			pName:'',
			recordList:[],
    };
	},
	watch:{
    
	},
	created(){
		this.init();
		if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
		document.querySelector('.xd-header').style.position='fixed'
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
    // document.body.style.overflow = "scroll";
    // document.querySelector("html").style.overflow = "scroll";
  },
	computed:{

	},
	mounted(){
		
	},
	methods:{
		init(){
			this.getRecords();
		},
		getRecords(){
			getAllFollows({CustomerID:this.$route.query.id,pageParams:{pageSize:0,pageIndex:0,}},res=>{
				console.log(res)
				this.loaded=true;
				this.recordList=res.queryResult.pagedData
			})
		},
		fnFocus() {
			var ua = navigator.userAgent.toLowerCase();
			console.log(document.body.sr)
      // if (/iphone|ipad|ipod/.test(ua)) {
      //   var wv = plus.webview.currentWebview();
      //   let bottom = this.iosType == "4s" ? "315px" : "765px";

      //   wv.setStyle({ top: "0px" });
      //   wv.setStyle({ bottom });
      //   plus.webview.currentWebview().setStyle({ background: "#fff" });
      //   //mui.alert('---tttt----')
      //   //mui('header')[0].style.transform='translateY(-10px)'
      // }
    },
    fnBlur(t) {
			var ua = navigator.userAgent.toLowerCase();

		
			if(t=="phone"){
				if(  !(/^\d{11}$/.test( this.phoneNumber ))  &&  this.phoneNumber ){
					this.f3=true;
				}else{

				}
			}
			if(t=="id"){
				if((this.info.idType==1)&&( this.info.idNumber && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.info.idNumber))){
					this.f4=true
				}
			}
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
			}

			
    },
		toParentView(){
			this.$router.push({name:'parentInfo',query:{id:this.$route.query.id,sex:this.$route.query.sex,cname:this.$route.query.cname,refer:this.$route.query.refer}})
		},
		toStudentView(){
      this.$router.push({name:'studentInfo',query:{id:this.$route.query.id,refer:this.$route.query.refer}})
		},
		toRecordView(){
      this.$router.push({name:'records',query:{id:this.$route.query.id,refer:this.$route.query.refer}})
		},
		addRecord(){
      this.$router.push({name:'follow-add',query:{customerID:this.$route.query.id,cName:this.$route.query.cname,actionType:'create',isPotential:true}})
		},
		viewRecord(f){
      this.$router.push({name:'follow-info',query:{followId:f.followID,cName:this.$route.query.cname,actionType:'view'}})
		},
	},
  components: {
    SelectItems,
  }
};
</script>

<style lang="scss">
html,body{
	height: 100%;
	overflow: hidden;
}
.record-header{
	display: flex;
	margin: torem(10) torem(8) torem(5);
	// font-weight: 400;
	font-size: torem(16);
	font-weight: bold;
	div{
		flex:1;
	}
}
.record-items{
	font-size: torem(14);
	ul{
		height: calc(100vh - 175px);
		padding-bottom: 40px;
		overflow: scroll;
		li{
			display: flex;
			font-size: torem(16);
			line-height: torem(32);
			margin: torem(5) torem(8);
			border-bottom: torem(1) solid #ddd;
			span.con{
				flex:1;
			}
			span.arrow{
			}
		}
	}
}
.student-info {
	// position: absolute;
  // width: 100%;
  // left: 0;
  // right: 0;
  // top:torem(35);
  // bottom: 0;
  // overflow-y: scroll;
  // -webkit-overflow-scrolling: touch; /* 解决ios滑动不流畅问题 */

	.ar{float: right;}

	.mint-radiolist{display: flex}
	.mint-radiolist *{margin: 0}
	.mint-cell-wrapper,.mint-radiolist,.mint-cell{height: torem(16);line-height: torem(16)}
	.mint-radiolist .mint-cell{    background: transparent;}
	.mint-cell-wrapper{background: none;transform: translateY(-8px);}

	span.mint-radio-label{display: inline-block;transform:translateX(-20px);}
	.mint-radiolist-title{margin-left: 0}
}
</style>

<style lang='scss' scoped>
.nothing{
	margin-top: 15px;
	font-size: torem(15);
	text-align: center;
	color: #aaa;
}
.edit{
	color: #aaa;
	span{color:#333}
}

.top-btn-edit{
	position: fixed;
	// margin-top: -23px;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 990;
}
.top-btn-save{
	position: fixed;
	// margin-top: -23px;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 990;
}
.top-btn-cancel{
	position: fixed;
	// margin-top: -23px;
	font-size: 15px;
	top: 30px;
	right: 60px;
	color: #fff;
	z-index: 990;
}
.parent-tabs {
  margin-bottom: 10px;
  font-size: 0px;
  li {
		&.active{    
			background-image: linear-gradient(90deg, #FF9900 0%, #FFB82A 100%);
			height: 100%;
			border-bottom: none!important;
			color: #fff!important;
		}
    background: #fff;
    display: inline-block;
    font-size: torem(16);
    line-height: torem(16);
    padding: torem(8);
    border-right: 1px solid #ddd;
    // width:30vw;
    &.on {
      background: #888;
    }
  }
}
.student-info {
	.mint-radiolist{display: flex}
	span.mint-radio-label{display: inline-block;transform:translateX(-15px);}
  .student-info-nav {
    margin-top: 16px;
    width: 100%;
    margin-left: 0;
    border-radius: 5px;
    overflow: hidden;
  }
  background: #eee;
  padding: 5px 10px 20px;
  .info-edit-des {
    font-size: torem(16);
    color: #888;
    margin: 15px 0;
  }
		span.red{
			color:red;
			font-size: torem(16);
			.wjx{font-size:torem(20)}
		}
  .info-tab {
    background: #fff;
    margin: 0 0 15px;
    padding-bottom: 10px;
		
    .cell {
      display: flex;
      font-size: torem(16);
      line-height: torem(32);
      margin: torem(5) torem(8);
      border-bottom: torem(1) solid #ddd;
			&.err{
				text-align: center;
				color:red;
				display: block;
				font-size: torem(14);
			}
      .cell-1 {
        span {
          color: red;
          font-size: torem(16);
					.wjx{font-size:torem(20)}
        }
        flex: 5;
        text-align: right;
        padding-right: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(24);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
    }
  }
	.schollList {
    background: #ddd;
    position: absolute;
    width: 90%;
    height: auto;
    max-height: torem(170);
    z-index: 99;
    left: 5%;
    right: 5%;
    padding: 10px 15px;
    border-radius: 15px;
    overflow: auto;
    li {
      height: torem(40);
      line-height: torem(40);
      border-bottom: 1px solid #eee;
      padding-left: 15px;
    }
  }
}

.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
