<template>
  <div class="wrap">
    <course-header></course-header>
    <customer-list></customer-list>
  </div>
</template>
<script>
import { loadUserInfo } from "@/api/common/common-api";
import courseHeader from "./partials/course-header.vue";
import customerList from "./partials/customer-list.vue";
export default {
  created() {
    loadUserInfo("upd");
  },
  components: {
    courseHeader,
    customerList
  }
};
</script>
<style lang='scss' scoped>
.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
