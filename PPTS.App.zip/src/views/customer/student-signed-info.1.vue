<template>

<div style="background:#eee;padding-bottom:30px;">		
		<span v-show="!editing" class="top-btn-edit" @click="editInfo">编辑</span>
		<span v-show="editing" class="top-btn-save" @click="save">保存</span>
		<span v-show="editing" class="top-btn-cancel" @click="cancel">取消</span>

  <div style="overflow:scroll;height:calc(100vh - 65px)" class="student-info">
    <!-- <mt-navbar class="student-info-nav" v-model="navIndex" v-power="['睿学-学员信息-不带电话']">
			<mt-tab-item id="1" @click="this.curIndex=index" v-for="(item,index) in navList" :key="index" class="nav-item" :class="{on:curIndex==index}">{{item}}</mt-tab-item>
    </mt-navbar>-->

    <mt-navbar class="student-info-nav" v-model="selected">
      <mt-tab-item id="1">基本信息</mt-tab-item>
      <mt-tab-item @click.native="toParentView"  id="2">家长信息</mt-tab-item>
      <!-- <mt-tab-item id="3">跟进记录</mt-tab-item> -->
    </mt-navbar>

	<div class="info-edit-des">
		注意：<span class="red"><span class="wjx">★</span></span>为必填项，<span class="red">▲</span>为充值所需项，<span class="red">■</span>为关键信息，签约后只允许分审核经理修改。
	</div>
	
    <!-- tab-container -->
    <mt-tab-container v-model="selected">
      <mt-tab-container-item  v-if="!editing"  id="1">
				<div class="info-tab">
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span>▲■</span>学员姓名</div>
						<div class="cell-2">{{info.customerName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>学员编号</div>
						<div class="cell-2">{{info.customerCode}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>学员性别</div>
						<div class="cell-2">{{info.gender| genderFormat}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>出生日期</div>
						<div class="cell-2">{{info.birthday | dateFormat('yyyy-MM-dd')}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">{{getIdType(info.idType)}}</div>
						<div class="cell-2">{{info.idNumber}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">联系方式</div>
						<div class="cell-2">{{phoneNumber}}</div>
					</div>
				</div>
				<div class="info-tab">
					<div class="cell">
						<div class="cell-1"><span>■</span>入学大年级</div>
						<div class="cell-2">{{info.entranceGrade|grade}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲■</span>当前年级</div>
						<div class="cell-2">{{info.grade|grade}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>在读学校</div>
						<div class="cell-2">{{info.schoolName}}</div>
					</div>
					
					<div class="cell">
						<div class="cell-1">学年制</div>
						<div class="cell-2">{{info.schoolYear |  academicYear}}</div>
					</div>
					<div class="cell" >
						<div class="cell-1">文理科</div>
						<div class="cell-2">{{info.subjectType|subjectType}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">是否复读</div>
						<div class="cell-2">{{info.isStudyAgain|isStudyAgain}}</div>
					</div>
				</div>
				<div class="info-tab">
					<div class="cell">
						<div style="text-indent:-15px" class="cell-1"><span><span class="wjx">★</span></span>客户资源所在地</div>
						<div class="cell-2">{{info.orgName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span></span>接触方式</div>
						<div class="cell-2">{{info.contactType|contactType}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span></span>信息来源</div>
						<div class="cell-2">{{infoSrc}}</div>
						<!-- C_CODE_ABBR_BO_Customer_Source 没有对应的过滤器name -->
					</div>
					<div class="cell">
						<div class="cell-1">转介绍员工</div>
						<div class="cell-2">{{info.referralStaffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">转介绍学员</div>
						<div class="cell-2">{{info.referralCustomerName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">辅导意愿</div>
						<div class="cell-2">{{info.tutoringWill|tutoringWill}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">主监护人</div>
						<div class="cell-2">{{guardian}}</div>
						<!-- 找不到对应的字段 -->
					</div>
					<div class="cell">
						<div class="cell-1">VIP客户</div>
						<div class="cell-2">{{info.vipType|vipType}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">VIP等级</div>
						<div class="cell-2">{{info.vipLevel|vipLevel}}</div>
					</div>
				</div>
				<div class="info-tab">
					<div class="cell">
						<div class="cell-1">初始签约人</div>
						<div class="cell-2">{{info.firstSignerName}}</div>
					</div>
					<div @click="viewHistory(zxzy)" class="cell">
						<div class="cell-1">归属坐席</div>
						<div class="cell-2">{{zxzy.staffName}}<span class="ar">></span></div>
					</div>
					<div @click="viewHistory(zxs)"  class="cell">
						<div class="cell-1">归属咨询师</div>
						<div class="cell-2">{{zxs.staffName}}<span class="ar">></span></div>
					</div>
					<div @click="viewHistory(xgs)" class="cell">
						<div class="cell-1">归属学管师</div>
						<div class="cell-2">{{xgs.staffName}}<span class="ar">></span></div>
					</div>
					<div @click="viewHistory(js)" class="cell">
						<div class="cell-1">归属教师</div>
						<div class="cell-2">{{js.staffName}}<span class="ar">></span></div>
					</div>
					<div @click="viewHistory(sczy)" class="cell">
						<div class="cell-1">归属市场专员</div>
						<div class="cell-2">{{sczy.staffName}}<span class="ar">></span></div>
					</div>
					<div class="cell">
						<div class="cell-1">建档部门</div>
						<div class="cell-2">{{info.creatorJobName}}</div>
						<!-- 似乎不是这个字段 -->
					</div>
					<div class="cell">
						<div class="cell-1">建档人</div>
						<div class="cell-2">{{info.creatorName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">当前状态</div>
						<!-- <div class="cell-2">{{info.status|customerStatus}}</div> -->
						<div class="cell-2">正常</div>
					</div>
				</div>
			</mt-tab-container-item>
			<mt-tab-container-item v-if="editing"  id="1">
				<div class="info-tab">
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span>▲■</span>学员姓名</div>
						<div class="cell-2"><input @focus="fnFocus" @blur="fnBlur" type="text" v-model="newInfo.customerName"></div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>学员编号</div>
						<div class="cell-2">{{info.customerCode}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span>▲</span>学员性别</div>
						<div class="cell-2"><mt-radio align="right" v-model="newInfo.gender" :options="[{label:'男',value:'1'},{label:'女',value:'2'}]"></mt-radio></div>
					</div>
					<div class="cell" @tap.prevent.stop="chooseDate()">
						<div class="cell-1"><span>▲</span>出生日期</div>
						<div class="cell-2 edit">{{info.birthday | dateFormat}}<span class="ar">></span></div>
					</div>
					<div class="cell" @click.prevent.stop="selectItem('customerIDType')">
						<div class="cell-1">证件类型</div>
						<div class="cell-2 edit">{{info.idType | idtype}}<span class="ar">></span></div>
					</div>
					<div class="cell">
						<div class="cell-1">输入编号</div>
						<div class="cell-2"><input @focus="fnFocus" @blur="fnBlur"  type="text" v-model="newInfo.idNumber"></div>
					</div>
					<div class="cell">
						<div class="cell-1">联系方式</div>
						<div class="cell-2"><input maxlength="11"  @focus="fnFocus" @blur="fnBlur" type="text" v-model="phoneNumber"></div>
					</div>
				</div>
				<div class="info-tab">
					<div  @click.prevent.stop="selectItem('entranceGrade')" class="cell">
						<div class="cell-1"><span>■</span>入学大年级</div>
						<div class="cell-2 edit">{{info.entranceGrade|grade}}<span class="ar">></span></div>
					</div>
					<div   @click.prevent.stop="selectItem('grade')" class="cell">
						<div class="cell-1"><span>▲■</span>当前年级</div>
						<div class="cell-2 edit">{{info.grade|grade}}<span class="ar">></span></div>
					</div>
					
					<div class="cell">
						<div class="cell-1"><span>▲</span>在读学校</div>
						<div class="cell-2"> <input type="text" v-model="info.schoolName"  @focus="fnFocus" @blur="fnBlur" ></div>
						<!-- <div class="cell-2"> <input type="text" v-model="info.schoolName"  @focus="fnFocus" @blur="fnBlur" @input="showShoolList(info.schoolName)"></div> -->
					</div>
					<ul class="schollList" v-if="schoolListData.length">
                    <li
                      v-for="(items,index) in schoolListData"
                      :key="index"
                      @click="selectSchoolFun(items)"
                      v-html="hightLightFun(items.schoolName)"
                    >{{items.schoolName}}</li>
                  </ul>
					<div @click.prevent.stop="selectItem('schoolYear')"  class="cell">
						<div class="cell-1">学年制</div>
						<div class="cell-2 edit">{{info.schoolYear |  academicYear}}<span class="ar">></span></div>
					</div>
					<div class="cell"  @click.prevent.stop="selectItem('subjectType')">
						<div class="cell-1">文理科</div>
						<div class="cell-2 edit">{{info.subjectType|subjectType}}<span class="ar">></span></div>
					</div>
					<div class="cell">
						<div class="cell-1">是否复读</div>
						<div class="cell-2"><mt-radio align="right" v-model="newInfo.isStudyAgain" :options="[{label:'是',value:1},{label:'否',value:2}]"></mt-radio></div>
					</div>
				</div>
				<div class="info-tab">
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span></span>客户资源所在地</div>
						<div class="cell-2">{{info.orgName}}</div>
					</div>
					<div  class="cell">
						<div class="cell-1"><span><span class="wjx">★</span></span>接触方式</div>
						<div class="cell-2">{{info.contactType|contactType}}</div>
					</div>
					<div class="cell">
						<div class="cell-1"><span><span class="wjx">★</span></span>信息来源</div>
						<div class="cell-2">{{infoSrc}}</div>
						<!-- C_CODE_ABBR_BO_Customer_Source 没有对应的过滤器name -->
					</div>
					<div class="cell">
						<div class="cell-1">转介绍员工</div>
						<div class="cell-2">{{info.referralStaffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">转介绍学员</div>
						<div class="cell-2">{{info.referralCustomerName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">辅导意愿</div>
						<div class="cell-2">{{info.tutoringWill|tutoringWill}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">主监护人</div>
						<div class="cell-2">{{guardian}}</div>
					</div>
					<div  @click.prevent.stop="selectItem('vipType')"  class="cell">
						<div class="cell-1">VIP客户</div>
						<div class="cell-2 edit">{{info.vipType|vipType}}<span class="ar">></span></div>
					</div>
					<div  @click.prevent.stop="selectItem('vipLevel')" class="cell">
						<div class="cell-1">VIP等级</div>
						<div class="cell-2 edit">{{info.vipLevel|vipLevel}}<span class="ar">></span></div>
					</div>
				</div>
				<div class="info-tab">
					<div class="cell">
						<div class="cell-1">初始签约人</div>
						<div class="cell-2">{{info.firstSignerName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">归属坐席</div>
						<div class="cell-2">{{zxzy.staffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">归属咨询师</div>
						<div class="cell-2">{{zxs.staffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">归属学管师</div>
						<div class="cell-2">{{xgs.staffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">归属教师</div>
						<div class="cell-2">{{js.staffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">归属市场专员</div>
						<div class="cell-2">{{sczy.staffName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">建档部门</div>
						<div class="cell-2">{{info.creatorJobName}}</div>
						<!-- 似乎不是这个字段 -->
					</div>
					<div class="cell">
						<div class="cell-1">建档人</div>
						<div class="cell-2">{{info.creatorName}}</div>
					</div>
					<div class="cell">
						<div class="cell-1">当前状态</div>
						<div class="cell-2">正常</div>
						<!-- <div class="cell-2">{{info.status|customerStatus}}</div> -->
					</div>
				</div>
			</mt-tab-container-item>
      <mt-tab-container-item   id="2"></mt-tab-container-item>
      <mt-tab-container-item id="3"></mt-tab-container-item>
    </mt-tab-container>
		<select-items
        v-show="itemsParams.isShow"
        :title="itemsParams.title"
        :model="itemsParams.model"
        :isShow="itemsParams.isShow"
        :category="itemsParams.category"
        :items="itemsParams.selectItems"
        @selectItem="selectVisitType"
      ></select-items>
  </div>
	</div>
</template>
<script>
import {
  cell as mtCell,
  Navbar as mtNavbar,
  TabItem as mtTabItem,
	Loadmore as mtLoadmore,
	Actionsheet  as mtActionsheet,
} from "mint-ui";
import {
	getStudentInfo as getCustomerInfo,
	// getStudentInfo
	getAllCustomers,
	getCustomerParents,
	updateStudentParent as updateCustomerParent  ,
	updateStudent as updateCustomer,
} from "@/api/customer/customer-api";
// import {
// 	getStudentInfo ,
// 	updateStudentParent,
// 	updateStudent,
// } from "@/api/customer/customer-api";
import {
	getCustomerSource,
	getLocationData,
	getSchools,
} from "@/api/metadata/metadata-api";
import { debug } from 'util';
import SelectItems from "@/components/select-items/index";
import { setTimeout } from 'timers';

function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
function resize2() {
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}

function copy(obj1,obj2){
  var obj2=obj2||{}; //最初的时候给它一个初始值=它自己或者是一个json
  for(var name in obj1){
    if(typeof obj1[name] === "object"){ //先判断一下obj[name]是不是一个对象
      obj2[name]= (obj1[name].constructor===Array)?[]:{}; //我们让要复制的对象的name项=数组或者是json
      copy(obj1[name],obj2[name]); //然后来无限调用函数自己 递归思想
    }else{
      obj2[name]=obj1[name];  //如果不是对象，直接等于即可，不会发生引用。
    }
  }
  return obj2; //然后在把复制好的对象给return出去
}
export default {
  data() {
    return {
			// itemsParams:{
			// 	isShow:false,
			// 	title:'证件类型',
			// 	model:'model',
			// 	category:'类型',
			// 	selectItems:[{key:'0',value:'身份证'},{key:'1',value:'学生证'}],
			// },
			itemsParams: {
        isShow: false,
        title: "",
        model: "",
        category: "",
        selectItems: []
			},
			cname:'',
			phoneNumber:'',
      selected: "1",
      navIndex: null,
			curIndex: 0,
			info:{},
			zxs:{},
			xgs:{},
			js:{},
			zxzy:{},
			sczy:{},
			parentList:[],
			restudy:null,
			rawEditingModel:{},
			parentIndex:0,
			navList: ["基本信息", "家长信息", "跟进记录"],
			editing:false,
			clone:{},
			sex:'',
			infoSrc:'',
			newInfo:{},
			guardian:'aaa',
			result:{},
			schoolListData: [],
			searchSchoolNameKeyValue: "",
			schoolParams: {
        searchTerm: "",
        maxCount: 20
			},
			isDataChange:false,
			pName:'',
    };
	},
	watch:{
    "info":{
      handler:function(d1,d2,d3){
        this.isDataChange=true;
      },
      deep:true,
		},
	},
	created(){
		this.init();
		if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
		document.querySelector('.xd-header').style.position='fixed'
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
    // document.body.style.overflow = "scroll";
    // document.querySelector("html").style.overflow = "scroll";
  },
	computed:{
		idTypeName(){
			switch(this.result.customer.idType){
				case 0:return '身份证';
				case 1:return '学生证';
				default :return '其它证件'
			}
		},
		editingModel(){
			if(!this.rawEditingModel.primaryPhone){
				this.rawEditingModel.primaryPhone= {}
			}
			if(!this.rawEditingModel.secondaryPhone){
				this.rawEditingModel.secondaryPhone= {}
			}
			// debugger
			this.rawEditingModel.isPrimary=this.rawEditingModel.isPrimary.toString();
			this.rawEditingModel.gender=this.rawEditingModel.gender.toString();
			// this.rawEditingModel.isPrimary &&	(this.rawEditingModel.isPrimary=this.rawEditingModel.isPrimary.toString());
			// this.rawEditingModel.gender && (this.rawEditingModel.gender=this.rawEditingModel.gender.toString());

			return this.rawEditingModel
		}
	},
	mounted(){
		// this.$nextTick(()=>{
		// 		this.editing=true
		// })
		
		// this.selectVisitType()
	},
	methods:{
		init(){
			let id = this.$route.query.id;
			this.viewDetail(id);
		},
		fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "765px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
        //mui.alert('---tttt----')
        //mui('header')[0].style.transform='translateY(-10px)'
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
		toParentView(){
			this.$router.push({name:'parentSignedInfo',query:{id:this.$route.query.id,sex:this.sex,cname:this.cname,refer:this.$route.query.refer}})
		},
		showShoolList(txt){
			if (!txt) {
				this.schoolListData = [];
				return;
			}
			this.searchSchoolNameKeyValue = txt;
			this.schoolParams.searchTerm = txt;
			getSchools(this.schoolParams, res => {
				this.schoolListData = res;
			});
		},
		getIdType(c){
      return this.$options.filters.idtype(c)?this.$options.filters.idtype(c):'证件号码'
    },
		selectSchoolFun(item) {
      this.result.customer.schoolID = item.schoolID;
      this.result.customer.schoolName = item.schoolName;
      this.schoolListData = [];
    },
    hightLightFun(schoolName) {
      let replaceReg = new RegExp(this.searchSchoolNameKeyValue, "gi");
      // 高亮替换v-html值
      let replaceString =
        '<span style="color:red;">' + this.searchSchoolNameKeyValue + "</span>";
      // 开始替换
      schoolName = schoolName.replace(replaceReg, replaceString);
      return schoolName;
    },
		selectItem(category) {
      this.itemsParams.isShow = true;
      this.itemsParams.category = category;
      switch (category) {
        case "branchID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.result.customer.branchID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "campusID":
          this.itemsParams.title = "资源归属地";
          this.itemsParams.model = this.result.customer.campusID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;

        case "contactType":
          this.itemsParams.title = "接触方式";
          this.itemsParams.model = this.result.customer.contactType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceMain":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.result.customer.sourceMainType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "sourceSec":
          this.itemsParams.title = "信息来源";
          this.itemsParams.model = this.result.customer.sourceSubType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "tutoringWill":
          this.itemsParams.title = "辅导意愿";
          this.itemsParams.model = this.result.customer.tutoringWill;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentRole":
          this.itemsParams.title = "亲属关系";
          this.itemsParams.model = this.parentRoleKey;
          //this.itemsParams.model = this.result.parentRole;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "customerRole":
          this.itemsParams.title = "亲属关系";
          this.itemsParams.model = this.customerRoleKey;
          //this.itemsParams.model = this.result.customerRole;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "referralStaffJobID":
          this.itemsParams.title = "转介绍员工岗位";
          this.itemsParams.model = this.result.customer.referralStaffJobID;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "parentIDType":
          this.itemsParams.title = "家长证件类型";
          this.itemsParams.model = String(this.result.parent.idType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "Income":
          this.itemsParams.title = "家庭年收入";
          this.itemsParams.model = String(this.result.parent.income);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "province":
          this.itemsParams.title = "现住址";
          this.itemsParams.model = this.result.parent.province;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "city":
          this.itemsParams.title = "现住址";
          this.itemsParams.model = this.result.parent.city;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "county":
          this.itemsParams.title = "现住址";
          this.itemsParams.model = this.result.parent.county;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "entranceGrade":
          this.itemsParams.title = "入学大年级";
          this.itemsParams.model = this.result.customer.entranceGrade;
          this.itemsParams.selectItems = this._getSelectItems(category);
					break;
				case "grade":
          this.itemsParams.title = "当前年级";
          this.itemsParams.model = this.result.customer.grade;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "subjectType":
          this.itemsParams.title = "文理科";
          this.itemsParams.model = String(this.result.customer.subjectType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "schoolYear":
          this.itemsParams.title = "学年制";
          this.itemsParams.model = this.result.customer.schoolYear;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "customerIDType":
          this.itemsParams.title = "学员证件类型";
          this.itemsParams.model = String(this.result.customer.idType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "vipType":
          this.itemsParams.title = "VIP客户";
          this.itemsParams.model = String(this.result.customer.vipType);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "vipLevel":
          this.itemsParams.title = "VIP等级";
          this.itemsParams.model = String(this.result.customer.vipLevel);
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
      }
    },
		_getSelectItems(category) {
      let res = [];
      let parentGender = this.result.parent.gender;
      let customerGender = this.result.customer.gender;
      switch (category) {
        case "branchID":
          res = this.departMentObj.branchMess;
          break;
        case "campusID":
          res = this.departMentObj.campusMess;
          break;
        case "contactType":
          res = this.result.dictionaries
            .C_CODE_ABBR_Customer_CRM_NewContactType;
          break;
        case "sourceMain":
          res = this.sourceType.sourceMainMess;
          break;
        case "sourceSec":
          res = this.sourceType.sourceSecMess;
          break;
        case "tutoringWill":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_TutorWill;
          break;
        case "customerRole":
          if (!parentGender || !customerGender) {
            res = this.customerRoleDefault;
          } else {
            res = [
              ...this.customerRoleDefault,
              ...this._children(customerGender)
            ];
          }
          break;
        case "parentRole":
          if (!parentGender || !customerGender) {
            res = this.parentRoleDefault;
          } else if (parentGender && customerGender && !this.customerRoleKey) {
            res = [...this.parentRoleDefault, ...this._parents(parentGender)];
          } else if (customerGender && this.customerRoleKey) {
            res = [
              ...this.parentRoleDefault,
              ...this._myParents(this.customerRoleKey, parentGender)
            ];
          }
          break;
        case "referralStaffJobID":
          res = this.referralStaffJobArr;
          break;
        case "parentIDType":
          res = this.result.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
        case "Income":
          res = this.result.dictionaries.C_CODE_ABBR_HOMEINCOME;
          break;
        case "province":
          res = this.areaMess.provinceMess;
          break;
        case "city":
          res = this.areaMess.cityMess;
          break;
        case "county":
          res = this.areaMess.countyMess;
          break;
        case "entranceGrade":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
					break;
				case "grade":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE;
          break;
        case "subjectType":
          res = this.result.dictionaries.C_CODE_ABBR_STUDENTBRANCH;
          break;
        case "schoolYear":
          res = this.result.dictionaries.C_CODE_ABBR_ACDEMICYEAR;
          break;
        case "customerIDType":
          res = this.result.dictionaries
            .C_CODE_ABBR_BO_Customer_CertificateType;
          break;
        case "vipType":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_VipType;
          break;
        case "vipLevel":
          res = this.result.dictionaries.C_CODE_ABBR_CUSTOMER_VipLevel;
          break;
        default:
          break;
      }
      return res;
    },
		selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "branchID":
            this.result.customer.branchID = obj.item.key;
            this.departMentObj.branchName = obj.item.value;
						break;

          case "campusID":
            this.result.customer.campusID = obj.item.key;
            this.result.customer.campusName = obj.item.value;
            break;
          case "sourceMain":
            this.result.customer.sourceMainType = obj.item.key;
            this.sourceType.sourceMainName = obj.item.value;
            break;
          case "sourceSec":
            this.result.customer.sourceSubType = obj.item.key;
            this.sourceType.sourceSecName = obj.item.value;
            break;
          case "contactType":
            this.result.customer.contactType = obj.item.key;
            break;
          case "tutoringWill":
            this.result.customer.tutoringWill = obj.item.key;
            break;
          case "customerRole":
            this.result.customerRole = obj.item.value;
            this.customerRoleKey = obj.item.key;
            break;
          case "parentRole":
            this.result.parentRole = obj.item.value;
            this.parentRoleKey = obj.item.key;
            break;
          case "referralStaffJobID":
            //判断存储OA人员岗位列表  是否有用户手动选择的
            if (this.referralStaffJobArr.length) {
              this.referralStaffJobArr.forEach(item => {
                if (item.key == obj.item.key) {
                  this.result.customer.referralStaffJobID = obj.item.key;
                  this.result.customer.referralStaffJobName = obj.item.value;
                } else {
                  this.result.customer.referralStaffJobID = this.referralStaffJobArr[0].key;
                  this.result.customer.referralStaffJobName = this.referralStaffJobArr[0].value;
                }
              });
            } else {
              this.result.customer.referralStaffJobID = obj.item.key;
              this.result.customer.referralStaffJobName = obj.item.value;
            }
            break;
          case "parentIDType":
            this.result.parent.idType = obj.item.key;
            break;
          case "Income":
            this.result.parent.income = obj.item.key;
            break;
          case "province":
            this.result.parent.province = obj.item.key;
            this.areaMess.provinceName = obj.item.value;
            break;
          case "city":
            this.result.parent.city = obj.item.key;
            this.areaMess.cityName = obj.item.value;
            break;
          case "county":
            this.result.parent.county = obj.item.key;
            this.areaMess.countyName = obj.item.value;
            break;
          case "entranceGrade":
            this.result.customer.entranceGrade = obj.item.key;
						break;
					case "grade":
            this.result.customer.grade = obj.item.key;
            break;
          case "subjectType":
            this.result.customer.subjectType = obj.item.key;
            break;
          case "schoolYear":
            this.result.customer.schoolYear = obj.item.key;
            break;
          case "customerIDType":
            this.result.customer.idType = obj.item.key;
            break;
					case "vipType":
						if(obj.item.key == 3){
							this.result.customer.vipLevel=null;
						}
            this.result.customer.vipType = obj.item.key;
            break;
          case "vipLevel":
            this.result.customer.vipLevel = obj.item.key;
            break;
        }
      }
    },
		//选择学生出生日期
    chooseDate() {
			let endYear=new Date().getFullYear();
			let endMonth=new Date().getMonth()+1;
			let endDate=new Date().getDate();
      var option = {
        type: "date",
				beginYear: 1980,
				endDate: new Date(endYear, endMonth, endDate),
				// endDate,
				// beginDate: new Date('2015,04,25'),//设置开始日期 
    		// endDate: new Date('2016,04,25'),//设置结束日期 
      };
      let dtPicker = new mui.DtPicker(option);
      const _this = this;
      dtPicker.show(function(selectTime) {
				let t = new Date(
          selectTime.value.replace(/-/g, "/")
				);
				if(t.getTime()>new Date().getTime()){
					mui.alert('您选择的时间大于当前时间，请核对后重新选择') 
				}else{
					_this.result.customer.birthday = t
				}
        
      });
    },
		getInfoSource(key,secKey){
			if(key || key=='0'){
				let r={}
				getCustomerSource({parentKey:key},res=>{
					r= res.find((v) => (v.key == secKey))
					this.infoSrc=r.value
				})
				
			}
		},
		
		showBox(){
			this.itemsParams.isShow = true;
		},
		// selectVisitType({cate,item}){
		// 	this.itemsParams.isShow = false;
		// 	this.rawEditingModel.idType=item.key*1;
		// 	// this.editingModel.idType=item.key*1;  似乎这么写也能起作用，但是感觉不合理
		// 	console.log(cate,item)
		// 	// setTimeout(()=>{
		// 	// 	this.itemsParams.isShow = true;
		// 	// })
			
		// },
		viewHistory(tea){
			if(tea && tea.customerID){
				this.$router.push({name:'teacherHistory',query:{type:tea.relationType,id:tea.customerID}})
			}else{
				return false;
			}
		}, 
		save(){
			if (/Android/gi.test(navigator.userAgent)) {
				mui.confirm("确定要保存吗？", "提示",["确认","取消"], e => {
					if (!e.index) {
						this.saveInfo();
					}
				});
			}else{
				mui.confirm("确定要保存吗？", "提示",["取消","确认"], e => {
					if (e.index) {
						this.saveInfo();
					}
				});
			}

			
			// this.saveParentInfo();
		},
		saveInfo(){
			let phone = this.info.primaryPhone;
			this.info.primaryPhone.phoneNumber = this.phoneNumber;
			// console.log(this.info)
			if(!this.checkData()) return false
			updateCustomer(this.result,(res)=>{
				if(res==''){
					mui.alert('修改成功')
					this.cancelEdit()
				}
				console.log(res)
			})
		},
		checkData(){
			// let t = this.info.primaryPhone.phoneNumber;
			// if(/[-]/.test(t)){
				
			// }
			// if(!/[^\u4e00-\u9fa5a-zA-Z]{1,10}/.test( this.info.customerName )){
			// 	mui.alert('姓名输入有误，请检查')
			// 	return false
			// }
			// console.log(this.info)
			if( !(this.info.customerName) ){
				mui.alert('学员姓名为必填项，请输入')
				return false
			}
			if( this.info.customerName==this.pName ){
				mui.alert('学员姓名与家长姓名不能一致，请检查')
				return false
			}
			if( !(/^[\u4e00-\u9fa5]{1,30}$/.test(this.info.customerName)) ){
				mui.alert('姓名输入有误，请检查')
				return false
			}
			if(  !(/^\d{11}$/.test( this.info.primaryPhone.phoneNumber ))  &&  this.info.primaryPhone.phoneNumber ){
				mui.alert('联系方式输入有误，请检查')
				return false
			} 
			///^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|[xX])$/
			
			if((this.info.idType==1)&&( this.info.idNumber && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.info.idNumber))){
				mui.alert('身份证号码输入有误，请检查')
				return false
			}
			return true;

		},
		saveParentInfo(){
			
			let customerID=this.editingModel.customerID;
			
			console.log(this.editingModel)
			console.log(this.parentList[this.parentIndex])
			// console.log(this.editParentInfo())
			// console.log({...this.editParentInfo()})
			// console.log(this.editParentInfo.customerID)
			updateCustomerParent({
				customer:this.info,
				// customerID,
				parent:this.editingModel,
				customerParentRelation:{
					customerID:this.editingModel.customerID,
					parentID:this.editingModel.parentID,
					customerRole:this.editingModel.customerRole,
					parentRole:this.editingModel.parentRole,
					isPrimary:this.editingModel.isPrimary,
				},
			},(res)=>{
				console.log(res)
			})
		},
		cancel(){
			if(this.isDataChange){
				if (/Android/gi.test(navigator.userAgent)) {
					mui.confirm("确定要取消吗？", "提示",["确认","取消"], e => {
						if (!e.index) {
							this.cancelEdit()
						}
					});
				}else{
					mui.confirm("确定要取消吗？", "提示",["取消","确认"], e => {
						if (e.index) {
							this.cancelEdit()
						}
					});
				}
				
			}else{
				this.editing=false;
			}
		},
		cancelEdit(){
			this.editing=false;
			this.init();
			// this.rawEditingModel=this.clone
		},
		editInfo(){
			this.editing=true;
			// debugger
			
			this.rawEditingModel=this.parentList[this.parentIndex];
			this.newInfo=this.info;//这么写暂时没什么用，修改newInfo实际上还是修改info
			// this.clone=copy(this.rawEditingModel,this.clone)
			this.isDataChange=false;
		},
		viewDetail(id){
      getCustomerInfo({id}, res => {
				console.log(res)
				this.pName=res.parent.parentName;
				this.result = res;
				this.result.customerSourceDict=[];
				this.info=this.result.customer;
				if(!this.info.primaryPhone){
					this.info.primaryPhone= {}
				}else{
					this.phoneNumber = this.info.primaryPhone.phoneNumber
				}
				if(!this.info.secondaryPhone){
					this.info.secondaryPhone= {}
				}else{
					this.phoneNumber = this.info.secondaryPhone.phoneNumber
				}
				this.sex=this.info.gender
				this.cname= this.info.customerName
				this.guardian=this.result.parent.parentName
				// 获取来源
				this.getInfoSource(this.result.customer.sourceMainType,this.result.customer.sourceSubType)
				// 数组里的字段不能直接根据名称获取，需要处理一下
        res.customerStaffRelations.forEach((v)=>{
					switch(v.relationType){
						case 1:this.zxs=v;break;
						case 2:this.xgs=v;break;
						case 3:this.js=v;break;
						case 4:this.zxzy=v;break;
						case 5:this.sczy=v;break;
					}
				})
			});
    },
	},
  components: {
    SelectItems,
  }
};
</script>

<style lang="scss">
html,body{
	height: 100%;
	overflow: hidden;
}
.student-info {
	// position: absolute;
  // width: 100%;
  // left: 0;
  // right: 0;
  // top:torem(35);
  // bottom: 0;
  // overflow-y: scroll;
  // -webkit-overflow-scrolling: touch; /* 解决ios滑动不流畅问题 */

	.ar{float: right;}

	.mint-radiolist{display: flex}
	.mint-radiolist *{margin: 0}
	.mint-cell-wrapper,.mint-radiolist,.mint-cell{height: torem(16);line-height: torem(16)}
	.mint-radiolist .mint-cell{    background: transparent;}
	.mint-cell-wrapper{background: none;transform: translateY(-8px);}

	span.mint-radio-label{display: inline-block;transform:translateX(-20px);}
	.mint-radiolist-title{margin-left: 0}
}
</style>

<style lang='scss' scoped>

.edit{
	color: #aaa;
	span{color:#333}
}
.top-btn-edit{
	position: fixed;
	// margin-top: -23px;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 990;
}
.top-btn-save{
	position: fixed;
	// margin-top: -23px;
	font-size: 15px;
	top: 30px;
	right: 20px;
	color: #fff;
	z-index: 990;
}
.top-btn-cancel{
	position: fixed;
	// margin-top: -23px;
	font-size: 15px;
	top: 30px;
	right: 60px;
	color: #fff;
	z-index: 990;
}
.parent-tabs {
  margin-bottom: 10px;
  font-size: 0px;
  li {
		&.active{    
			background-image: linear-gradient(90deg, #FF9900 0%, #FFB82A 100%);
			height: 100%;
			border-bottom: none!important;
			color: #fff!important;
		}
    background: #fff;
    display: inline-block;
    font-size: torem(16);
    line-height: torem(16);
    padding: torem(8);
    border-right: 1px solid #ddd;
    // width:30vw;
    &.on {
      background: #888;
    }
  }
}
.student-info {
	.mint-radiolist{display: flex}
	span.mint-radio-label{display: inline-block;transform:translateX(-15px);}
  .student-info-nav {
    margin-top: 16px;
    width: 100%;
    margin-left: 0;
    border-radius: 5px;
    overflow: hidden;
  }
  background: #eee;
  padding: 5px 10px 20px;
  .info-edit-des {
    font-size: torem(16);
    color: #888;
    margin: 15px 0;
  }
		span.red{
			color:red;
			font-size: torem(16);
			.wjx{font-size:torem(20)}
		}
  .info-tab {
    background: #fff;
    margin: 0 0 15px;
    padding-bottom: 10px;
	
    .cell {
      display: flex;
      font-size: torem(16);
      line-height: torem(32);
      margin: torem(5) torem(8);
      border-bottom: torem(1) solid #ddd;
      .cell-1 {
        span {
          color: red;
          font-size: torem(16);
					.wjx{font-size:torem(20)}
        }
        flex: 5;
        text-align: right;
        padding-right: 20px;
      }
      .cell-2 {
        flex: 6;
        input {
          border: none;
          font-size: torem(16);
          line-height: torem(16);
          height: torem(24);
          color: #aaa;
          margin: 0;
          padding: 0;
        }
      }
    }
  }
	.schollList {
    background: #ddd;
    position: absolute;
    width: 90%;
    height: auto;
    max-height: torem(170);
    z-index: 99;
    left: 5%;
    right: 5%;
    padding: 10px 15px;
    border-radius: 15px;
    overflow: auto;
    li {
      height: torem(40);
      line-height: torem(40);
      border-bottom: 1px solid #eee;
      padding-left: 15px;
    }
  }
}

.mui-bar-nav ~ .mui-content {
  padding-top: 30px;
}
.wrap {
  position: absolute;
  background: #fff;
  z-index: 5;
  width: 100%;
}
</style>
