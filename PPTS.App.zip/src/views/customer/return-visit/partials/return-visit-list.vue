<template>
	<div>
		<ul class="mui-table-view rx-list-items">
			<li class="item" v-for="(item,index) in list" :key="index">
				<span>{{item.customerName}}</span>
				<span>{{item.customerCode}}</span>
				<span @tap="goView(item)">查看回访</span>
				<span @tap="goAdd(item)" v-power="['睿学-录入回访']">录入回访</span>
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		props: ['list'],
		methods: {
			goView(item) {
				this.$router.push({
					name: 'return-visit-detail-list',
					query: {
						id: item.customerID,
						cName: item.customerName
					}
				})
			},
			goAdd(item) {
				this.$router.push({
					name: 'visit-add',
					query: {
						customerID: item.customerID,
						actionType: 'create'
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.rx-list-items {
		.item {
			display: flex !important;
			justify-content: space-between;
			align-items: center;
			padding: torem(10) torem(15);
			border-bottom: 1px solid #eee;
			margin: 0 0 0 torem(5);
			span {
				text-align: left;
			}
			span:first-child {
				flex-basis: torem(45);
			}
			span:nth-child(3) {
				color: deepskyblue;
			}
			span:nth-child(4) {
				color: deepskyblue;
			}
		}
	}
	
	.mui-table-view:before {
		top: 0
	}
</style>