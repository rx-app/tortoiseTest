<template>
	<div class="xd-parent-meet">
		<course-header></course-header>
		<div class="xd-select-student">
			<p class="inp"><input type="text" placeholder="输入学员姓名/编号进行查询" v-model="serachName" @click='inpFocus()'  @blur="inpBlur"/>
				<i class="iconfont icon-found" @click="getSearchList()"></i></p>
			<tip v-if="isShow">
				<span>没有查到该学员</span>
			</tip>
			<tip v-if="isEmptyShow">
				<span>没有查询到任何记录</span>
			</tip>
			<div class="page-tit" v-if="rsList.length">查询结果:</div>
			<div id="stu-main-content" class="main-content" :style="{'-webkit-overflow-scrolling': scrollMode}">
				<mt-loadmore class="loadMore" :bottom-all-loaded="allLoaded" :auto-fill="false" :bottom-method="loadBottom" :bottom-distance=-70 ref="loadmore">
					<return-visit-list :list="rsList"></return-visit-list>
				</mt-loadmore>
			</div>
		</div>
	</div>
</template>
<script>
	import Tip from '@/components/tip';
	import { getCurrentJobCustomerVisits , getCurrentJobCustomers } from '@/api/customer/customer-api'
	import { pager, orderBy } from '@/public/constant'
	import courseHeader from '../partials/course-header.vue'
	import returnVisitList from './partials/return-visit-list.vue'
	import { Loadmore as mtLoadmore } from 'mint-ui';
import { setTimeout } from 'timers';
	import resize from '@/public/lib/resize'
	export default {
		mixins:[resize],
		data() {
			return {
				rsList: [],
				isShow: false,
				isEmptyShow: false,
				allLoaded: false,
				pageIndex: 1,
				pageSize: 10,
				scrollMode: "auto",
				serachName: ''
			}
		},
		methods: {
			inpFocus() {
				var h = document.body.scrollHeight;
				// this.focus_footer(h);
				if(mui.os.ios){
					document.querySelector('footer').style.display = 'none';
				}
			},
			inpBlur() {
				if(mui.os.ios){
					document.querySelector('footer').style.display = 'block';
				}
			},
			focus_footer(h) {
				var _this=this;
				window.onresize = function() {
					if(document.body.scrollHeight < h) {
						if(_this.$route.name=="returnVisit"){
							xdapp.footer.style.display = 'none';
						}						
					} else {
						if(_this.$route.name=="returnVisit"){
							xdapp.footer.style.display = 'block';
						}	
					}
				};
			},
			getSearchList() {
				this.getList();
			},
			async getList(type) {
				if(!type){
					this.rsList=[];
					this.pageIndex=1;
				}
				var params = null;
				if(!this.serachName) {
					params = {
						createTimeBegin: m2.date.firstDay('m'),
						createTimeEnd: m2.date.endDay('m'),
						...pager({
							pageIndex: 0,
							pageSize: 0
						})
					}
					getCurrentJobCustomerVisits(params,res=>{
						if(!res.queryResult.pagedData.length){
							this.isEmptyShow=true;
						}else{
							this.isEmptyShow=false;
						}
						this.rsList=this._noReaptList(res.queryResult.pagedData);
					})
					return;

				} else {
					params = {
						filterStatus: 0,
						SearhKeyword: this.serachName.trim(),
						...pager({
							pageIndex: this.pageIndex,
							pageSize: this.pageSize
						})
					}

				}

				getCurrentJobCustomers(params, (res) => {
					this.rsList = this.rsList.concat(res.queryResult.pagedData);
					if(this.pageSize * this.pageIndex >= res.queryResult.totalCount) {
						this.allLoaded = true;
					} else {
						this.allLoaded = false;
					}
					if(!this.rsList.length) {
						this.isShow = true;
					} else {
						this.isShow = false;
					}
				})
			},
			loadBottom() {
				if(!this.serachName){this.allLoaded = true;return;} 
				this.pageIndex++;
				this.getList('more');
				this.$refs.loadmore.onBottomLoaded();
			},
			setHeight() {
				let content = document.querySelector('#stu-main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 240;
					let headHight = document.querySelector('#course-head');
					console.log('stu-#course-head：' + headHight)
					if(headHight !== null) {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem - 2.88rem)'
					} else {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem)'
					}
				}
			},
			 _noReaptList(arr) {
				var hash = {};
				arr = arr.reduce(function(item, next) {
					hash[next.customerName] ? '' : hash[next.customerName] = true && item.push(next);
					return item
				}, [])
				return arr;
			}
		},
		watch: {
			serachName() {
				if(!this.serachName) {
					this.rsList = [];
					this.isShow=false;
				}else{
					this.isEmptyShow=false;
				}
			},
		},
		mounted() {
			this.setHeight();
		},
		components: {
			courseHeader,
			returnVisitList,
			mtLoadmore,
			Tip
		}
	}
</script>

<style lang="scss" scoped>
	.page-tit {
		text-align: left;
		padding: 0 20px 10px;
	}
	
	.xd-parent-meet {
		position:absolute;
		background: #fff;
		z-index: 5;
		width: 100%;
	
		text-align: center;
		.students-head {
			width: 100%;
		}
		.inp {
			width: 90%;
			margin-left: 5%;
			margin-top: torem(15);
			border: 1px solid #D8D8D8;
			border-radius: 100px;
			height: 32px;
			position: relative;
			input {
				width: 90%;
				height: 100%;
				border: none;
				margin-left: -8%;
				border-radius: 100px;
			}
			input::-webkit-input-placeholder {
				font-size: torem(12);
				color: skyblue;
			}
			i {
				position: absolute;
				right: torem(10);
				top: torem(5);
				color: #eee;
				font-size: torem(24)
			}
		}
	}
	
	.main-content {
		overflow: auto;
	}
</style>