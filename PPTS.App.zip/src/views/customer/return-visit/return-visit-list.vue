<template>
  <div>
    <div class="btn-box">
      <button type="button" class="mui-btn mui-btn-block btn"
              @click="$router.push({name:'visit-add', query:{customerID:$route.query.id, actionType: 'create'}})">
        录入回访
      </button>
    </div>
    <tip v-if="!list.length">
      <span>该学员暂无回访信息</span>
    </tip>
    <div class="list-box">
      <div class="page-tit" v-if="list.length">已录入回访:</div>
      <div id="stu-main-content" class="main-content" :style="{'-webkit-overflow-scrolling': scrollMode}">
        <mt-loadmore class="loadMore" :bottom-all-loaded="allLoaded" :auto-fill="false" :bottom-distance=-70 :bottom-method="loadBottom"
                     ref="loadmore">
          <ul class="mui-table-view rx-list-items">
            <li v-for="(item, index) in list" :key="index" tag="li" class="item link-item" @click="go(item)">
              <span>{{item.visitTime | dateTimeFormat({locale: 'en-US'})}}</span>
              <span>{{item.visitWay | visitWay}}</span>
              <span>{{item.visitType | visitType}}</span>
            </li>
          </ul>
        </mt-loadmore>
      </div>
    </div>
  </div>
</template>

<script>
  import Tip from '@/components/tip';
  import {getCurrentJobCustomerVisits} from '@/api/customer/customer-api'
  import {pager, orderBy} from '@/public/constant'
  export default {
    data() {
      return {
        list: [],
        allLoaded: false,
        pageIndex: 1,
        pageSize: 10,
        scrollMode: "auto",
      }
    },
    created() {
      this.getList()
    },
    methods: {
      go(item) {
        this.$router.push({
          name: 'visit-info',
          query: {
            visitID: item.visitID,
            actionType: 'view'
          }
        });
      },
      async getList() {
        let params = {
          customerID: this.$route.query.id,
          ...pager({
            pageIndex: this.pageIndex,
            pageSize: this.pageSize
          }),
        }
        getCurrentJobCustomerVisits(params, (res) => {
          this.list = this.list.concat(res.queryResult.pagedData);
          if (this.pageSize * this.pageIndex >= res.queryResult.totalCount) {
            this.allLoaded = true;
          } else {
            this.allLoaded = false;
          }
        })
      },
      loadBottom() {
        this.pageIndex++;
        this.getList();
        this.$refs.loadmore.onBottomLoaded();
      },
      setHeight() {
        let content = document.querySelector('#stu-main-content');
        if (content !== null && typeof content !== 'undefined') {
          let windowHeight = window.innerHeight;
          let jHight = windowHeight - 160;
          let headHight = document.querySelector('#course-head');
          console.log('stu-#course-head：' + headHight)
          if (headHight !== null) {
            content.style.height = 'calc(' + jHight + 'px - 0.4rem - 2.88rem)'
          } else {
            content.style.height = 'calc(' + jHight + 'px - 0.4rem)'
          }
        }
      }
    },
    mounted() {
      this.setHeight();
      this.$route.meta.title = this.$route.query.cName + '的回访';
    },
    components: {
      Tip
    }
  }
</script>

<style lang="scss" scoped>
  .page-tit {
    text-align: left;
    padding: 0 20px 10px;
  }

  .btn-box {
    width: 90%;
    margin: 10px auto;
    .btn {
      background: rgb(255, 153, 102);
      color: #fff;
      border: none;
      width: 100%;
      margin: 10px auto;
      border-radius: 10px;
    }
  }

  .rx-list-items {
    .item {
      display: flex !important;
      justify-content: space-between;
      align-items: center;
      padding: torem(10) torem(15);
      border-bottom: 1px solid #eee;
      margin: 0 0 0 torem(5);
      position: relative;
      padding-right: 15px;
      span {
        display: block;
      }
      span:first-child {
        flex-basis: torem(415)
      }
      span:nth-child(2) {
        flex-basis: torem(215);
        text-align: center;
      }
      span:last-child {
        margin-right: 15px;
        flex-basis: torem(415);
        text-align: right;
      }
    }
    .link-item:after {
      content: '\E583';
      font-family: Muiicons;
      color: #bbb;
      -webkit-font-smoothing: antialiased;
      margin-left: 5px;
      position: absolute;
      top: 30%;
      right: 15px;
      // transform: translateX(50%) translateY(50%)
    }
    .name {
      color: #777;
    }
    .value {
      display: block;
      text-align: right;
      flex: 1;
      color: #aaa;
      .img-header {
        width: 1.70667rem;
        height: 1.70667rem;
      }
    }
    .no-arrow {
      margin-right: 17px;
    }
  }

  .main-content {
    overflow: auto;
  }
</style>
