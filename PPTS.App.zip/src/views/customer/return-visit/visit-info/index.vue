<template>
  <div class="visit-info-wrapper" v-if="this.visitInfo.visit" id="wrap">
    <div class="visit-info margin-top-15 margin-bottom-15 wrapper-color">
      <ul class="list-group">
        <li
          class="item"
          :class="{'edit': actionType=='create'}"
          @tap.prevent.stop="action('visitTime')"
        >
          <div class="item-left">回访时间</div>
          <div class="item-right">{{visitInfo.visit.visitTime | cast | dateTimeFormat}}</div>
        </li>
        <li class="item">
          <div class="item-left">被访学员</div>
          <div class="item-right">{{visitInfo.visit.customerName}}</div>
        </li>
        <li class="item">
          <div class="item-left">回访人</div>
          <div class="item-right">{{visitInfo.visit.visitorName}}</div>
        </li>
      </ul>
    </div>
    <div class="visit-set margin-bottom-15 wrapper-color">
      <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('visitType')">
        <div class="item-left">回访类型</div>
        <div class="item-right">{{visitInfo.visit.visitType | visitType}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('visitWay')">
        <div class="item-left">回访方式</div>
        <div class="item-right">{{visitInfo.visit.visitWay | visitWay}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('satisficing')">
        <div class="item-left">家长满意度</div>
        <div class="item-right">{{visitInfo.visit.satisficing | satisficing}}</div>
      </li>
      <li
        v-if="!conView"
        class="item"
        :class="{'edit': isEdit}"
        @click.prevent.stop="editContent()"
      >
        <span class="item-left">回访内容</span>
        <div class="item-right text-flow" @click="viewContent()">
          <p>{{visitInfo.visit.visitContent}}</p>
        </div>
      </li>
      <li
        v-if="conView"
        class="item"
        :class="[{'edit': isEdit},{'active': active}]"
        @click.prevent.stop="editContent()"
      >
        <span class="item-left">回访内容</span>
        <div class="item-right text-flow" @click="viewContent()">
          <p>{{visitInfo.visit.visitContent}}</p>
        </div>
      </li>
    </div>
    <div class="visit-next wrapper-color">
      <li class="item" :class="{'edit': isEdit}" @tap="action('nextVisitTime')">
        <div class="item-left">预计下次回访时间</div>
        <div class="item-right">{{visitInfo.visit.nextVisitTime | cast | dateTimeFormat}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @tap="action('remindTime')">
        <span class="item-left">设置提醒时间</span>
        <div class="item-right">{{visitInfo.visit.remindTime | cast | dateTimeFormat}}</div>
      </li>
      <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('selectType')">
        <div class="item-left">设置提醒方式</div>
        <div class="item-right">{{selectTypeName}}</div>
      </li>
    </div>
    <select-items
      v-show="itemsParams.isShow"
      :title="itemsParams.title"
      :model="itemsParams.model"
      :isShow="itemsParams.isShow"
      :category="itemsParams.category"
      :items="itemsParams.selectItems"
      @selectItem="selectVisitType"
    ></select-items>
    <inputFullLayer
      :isShow="layerParams.isShowLayer"
      :content="visitInfo.visit.visitContent"
      title="请输入回访内容"
      @completeAction="completeAction"
    ></inputFullLayer>
  </div>
</template>
<script>
import { ACTION_TYPES, selectWay } from "@/constants";
import { DATE_FORMAT } from "@/public/constant";
import { loadUserInfo } from "@/api/common/common-api";
import {
  postCustomerVisit as $postCustomerVisit,
  getVisit as $getVisit,
  getCreateVisitModel as $getCreateVisitModel
} from "@/api/customer/customer-api";
import SelectItems from "@/components/select-items/index";
import InputFullLayer from "@/components/input-full-layer/index";

import Scroll from "@/components/scroll/index";
import { setTimeout } from "timers";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({
      bottom: "-1px"
    });
  }
}

export default {
  data() {
    this.viewType = {
      CREATE: "create",
      VIEW: "view"
    };
    return {
      visitInfo: {},
      itemsParams: {
        isShow: false,
        title: "",
        model: "",
        category: "",
        selectItems: []
      },
      layerParams: {
        isShowLayer: false
      },
      active: false
    };
  },
  created() {
    this.getActionData();
    this.enableAction();
    this.registerSubmit();
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    // window.addEventListener('resize',resize)
  },
  destroyed() {
    // window.removeEventListener('resize',resize)
  },
  methods: {
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    viewContent() {
      this.active = !this.active;
      document.getElementById("wrap").style.overflow = "hidden";
    },
    async getActionData() {
      await loadUserInfo();
      if (this.actionType == this.viewType.VIEW) {
        this.getVisitInfo();
      } else if (this.actionType == this.viewType.CREATE) {
        this.getVisitInfoForCreate();
      }
    },
    getVisitInfo() {
      $getVisit(
        {
          visitID: this.visitID
        },
        res => {
          this.visitInfo = res;
          //this.visitInfo.visit.selectType="1";/*暂且添加测试*/
          this._visit = this._copy(res.visit);
          this.disabledAction();
        }
      );
    },
    getVisitInfoForCreate() {
      $getCreateVisitModel(
        {
          customerID: this.customerID
        },
        res => {
          res.customerVisit.visitTime = "";
          res.customerVisit.nextVisitTime = "";
          res.customerVisit.remindTime = "";
          this.visitInfo = res;
          this.visitInfo.visit = res.customerVisit;
          this._visit = this._copy(res.visit);
        }
      );
    },
    submit() {
      if (this.actionType == this.viewType.VIEW && this._checkIsChange()) {
        this.$router.go(-1);
        return;
      }
      if (mui.os.ios) {
        this.visitInfo.visit.fromSystemID = 1;
      } else if (mui.os.android) {
        this.visitInfo.visit.fromSystemID = 2;
      } else {
        this.visitInfo.visit.fromSystemID = 3;
      }
      $postCustomerVisit(this.visitInfo.visit, res => {
        console.log(res);
        this.$router.go(-1);
      });
    },
    selectItem(category) {
      if (!this.isEdit) return;
      this.itemsParams.isShow = true;
      this.itemsParams.category = category;
      switch (category) {
        case "visitWay":
          this.itemsParams.title = "回访方式";
          this.itemsParams.model = this.visitInfo.visit.visitWay;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "visitType":
          this.itemsParams.title = "回访类型";
          this.itemsParams.model = this.visitInfo.visit.visitType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "satisficing":
          this.itemsParams.title = "家长满意度";
          this.itemsParams.model = this.visitInfo.visit.satisficing;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "selectType":
          this.itemsParams.title = "设置提醒方式";
          this.itemsParams.model = this.visitInfo.visit.selectType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        default:
          break;
      }
    },
    selectVisitType(obj) {
      this.itemsParams.isShow = false;
      if (obj && obj.category) {
        switch (obj.category) {
          case "visitWay":
            this.visitInfo.visit.visitWay = obj.item.key;
            break;
          case "visitType":
            this.visitInfo.visit.visitType = obj.item.key;
            break;
          case "satisficing":
            this.visitInfo.visit.satisficing = obj.item.key;
            break;
          case "selectType":
            this.visitInfo.visit.selectType = obj.item.key;
            break;
          default:
            break;
        }
      }
    },
    editContent() {
      this._removeElementsByClass("mui-dtpicker");
      if (!this.isEdit) return;
      this.layerParams.isShowLayer = true;
      document.getElementById("wrap").style.overflow = "hidden";
    },
    completeAction(obj) {
      this.layerParams.isShowLayer = false;
      document.getElementById("wrap").style.overflow = "scroll";
      if (obj && obj.content) {
        this.visitInfo.visit.visitContent = obj.content;
      }
    },
    action(paramName) {
      if (
        this.viewType.VIEW == this.actionType &&
        (!this.visitInfo.isEdit || paramName == "visitTime")
      )
        return;
      let dtPicker = new mui.DtPicker(this.option);
      const _this = this;
      dtPicker.show(function(selectItems) {
        _this.$nextTick(() => {
          if (paramName === "nextVisitTime") {
            let date = _this._getDate();
            let visitTime = _this.visitInfo.visit["visitTime"];
            let nextVisitTime = new Date(selectItems.value.replace(/-/g, "/"));
            let currDate = new Date(selectItems.value.replace(/-/g, "/"));
            if (currDate.getTime() < date.getTime()) {
              mui.toast("只能选择当前时间以后的日期");
            } else {
              _this.visitInfo.visit[paramName] = new Date(
                selectItems.value.replace(/-/g, "/")
              );
            }
          } else if (paramName === "remindTime") {
            let date = _this._getDate();
            let currDate = new Date(selectItems.value.replace(/-/g, "/"));
            if (currDate.getTime() < date.getTime()) {
              mui.toast("只能选择当前时间以后的日期");
            } else {
              _this.visitInfo.visit[paramName] = new Date(
                selectItems.value.replace(/-/g, "/")
              );
            }
          } else if (paramName === "visitTime") {
            let date = _this._getDate();
            let date_3 = _this._getDate(-3);
            let currDate = new Date(selectItems.value.replace(/-/g, "/"));
            if (
              currDate.getTime() > date.getTime() ||
              currDate.getTime() < date_3.getTime()
            ) {
              mui.toast("只能选择当前日期及当前日期的前三天");
            } else {
              _this.visitInfo.visit[paramName] = new Date(
                selectItems.value.replace(/-/g, "/")
              );
            }
          } else {
            _this.visitInfo.visit[paramName] = new Date(
              selectItems.value.replace(/-/g, "/")
            );
          }
          dtPicker.dispose();
        });
      });
    },
    enableAction() {
      if (this.actionType == this.viewType.VIEW) {
        xdapp.util.vue.commitActionStatus(true);
      }
    },
    registerSubmit() {
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    disabledAction() {
      this.$nextTick(() => {
        if (!this.isEdit) {
          let actions = document.getElementsByClassName("action");
          let actionList = Array.prototype.slice.call(actions);
          actionList.forEach(action => {
            action.style.display = "none";
          });
        }
      });
    },
    _copy(obj) {
      var newobj = {};
      for (var attr in obj) {
        newobj[attr] = obj[attr];
      }
      return newobj;
    },
    _checkIsChange() {
      return (
        this._visit.visitTime == this.visitInfo.visit.visitTime &&
        this._visit.selectType == this.visitInfo.visit.selectType &&
        this._visit.visitType == this.visitInfo.visit.visitType &&
        this._visit.visitWay == this.visitInfo.visit.visitWay &&
        this._visit.satisficing == this.visitInfo.visit.satisficing &&
        this._visit.visitContent == this.visitInfo.visit.visitContent &&
        this._visit.nextVisitTime == this.visitInfo.nextVisitTime &&
        this._visit.remindTime == this.visitInfo.remindTime
      );
    },
    _getSelectItems(category) {
      let res = [];
      switch (category) {
        case "visitType":
          res = this.visitInfo.dictionaries
            .C_CODE_ABBR_BO_Customer_ReturnInfoType;
          break;
        case "visitWay":
          res = this.visitInfo.dictionaries.C_CODE_ABBR_Customer_CRM_ReturnWay;
          break;
        case "satisficing":
          res = this.visitInfo.dictionaries
            .C_CODE_ABBR_BO_Customer_Satisfaction;
          break;
        case "selectType":
          res = selectWay;
          break;
        default:
          break;
      }
      return res;
    },
    _getDate(d) {
      let date = new Date();
      if (typeof d !== "undefined") {
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);
        date.setMilliseconds(0);
        let targetday_milliseconds = date.getTime() + 1000 * 60 * 60 * 24 * d;
        date.setTime(targetday_milliseconds);
      }
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let day = date.getDate();
      let h = date.getHours();
      let m = date.getMinutes();
      let z = year + "-" + month + "-" + day + " " + h + ":" + m;

      let time = new Date(
        z.format(DATE_FORMAT["en-US"].dateTimeIos).replace(/-/g, "/")
      );
      return time;
    },
    // 1.封装了一个可以去除mui日历插件的方法  2. dtPicker.dispose();
    _removeElementsByClass(className) {
      var elements = document.getElementsByClassName(className);
      while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
      }
    }
  },
  beforeDestroy() {
    this._removeElementsByClass("mui-dtpicker");
  },
  computed: {
    visitID() {
      return this.$route.query.visitID;
    },
    customerID() {
      return this.$route.query.customerID;
    },
    actionType() {
      return this.$route.query.actionType;
    },
    conView() {
      if (this.$route.query.actionType == "view") {
        return true;
      }
      return false;
    },
    isEdit() {
      if (this.actionType == this.viewType.VIEW) {
        return this.visitInfo.isEdit;
      } else if (this.actionType == this.viewType.CREATE) {
        return true;
      }
    },
    selectTypeName() {
      switch (this.visitInfo.visit.selectType) {
        case "1":
          return "发邮件";
          break;
        case "2":
          return "发短信";
          break;
        case "3":
          return "app内消息";
          break;
      }
    }
  },
  watch: {
    visitInfo: {
      handler: function(obj) {
        if (
          this.actionType == this.viewType.CREATE &&
          obj.visit &&
          (this._visit.visitTime != obj.visit.visitTime &&
            this._visit.visitType != obj.visit.visitType &&
            this._visit.visitWay != obj.visit.visitWay &&
            this._visit.satisficing != obj.visit.satisficing &&
            this._visit.visitContent !=
              obj.visit
                .visitContent) /*&&
							this._visit.nextVisitTime != obj.visit.nextVisitTime &&
							this._visit.remindTime != obj.visit.remindTime*/
        ) {
          xdapp.util.vue.commitActionStatus(true);
        }
      },
      deep: true
    },
    "visitInfo.visit.nextVisitTime"(obj) {
      var remindTime = this.visitInfo.visit.remindTime;
      if (!obj || !remindTime) return;
      if (obj.getTime() < remindTime.getTime()) {
        mui.toast("设置提醒 应小于下次回访时间!");
        this.visitInfo.visit.remindTime = "";
      }
    },
    "visitInfo.visit.remindTime"(obj) {
      var nextVisitTime = this.visitInfo.visit.nextVisitTime;
      if (!obj || !nextVisitTime) return;
      if (obj.getTime() > nextVisitTime.getTime()) {
        mui.toast("设置提醒 应小于下次回访时间!");
        this.visitInfo.visit.remindTime = "";
      }
    }
  },
  components: {
    SelectItems,
    InputFullLayer
  }
};
</script>

<style lang="scss" scoped>
$wrapperColor: #fff;
$titleColor: #777;
$contentColor: #999;
.scroll-container {
  // position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.visit-info-wrapper {
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: $backgroundColor;
  font-size: torem(14);
  color: $titleColor;
  .item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: torem(50);
    line-height: torem(50);
    border-bottom: 1px solid rgba(239, 239, 244, 0.5);
    .item-left {
      padding-left: torem(10);
    }
    .item-right {
      position: absolute;
      right: torem(25);
      flex: 1;
      text-align: right;
      color: $contentColor;
    }
  }
  .edit {
    &:after {
      margin: 0 5px;
      content: "\E583";
      font-family: Muiicons;
      -webkit-font-smoothing: antialiased;
      font-size: torem(14);
      color: $contentColor;
    }
  }
  .text-flow {
    p {
      width: torem(260);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-bottom: 0;
    }
  }
  .active {
    height: torem(120);
    padding: torem(10) 0;
    overflow: hidden;
    div.text-flow {
      max-height: torem(100);
      //overflow-y: scroll;
      p {
        line-height: torem(20);
        white-space: normal;
      }
    }
  }
}

.margin-top-15 {
  margin-top: torem(15);
}

.margin-bottom-15 {
  margin-bottom: torem(15);
}

.wrapper-color {
  background-color: $wrapperColor;
}
</style>