﻿<template>
  <div class="visit-info-wrapper" v-if="this.meetingInfo.customerMeeting" id="wrap">
    <div class="visit-con" v-if="viewCon">
      <div class="visit-info margin-top-15 margin-bottom-15 wrapper-color">
        <ul class="list-group">
          <li
            class="item"
            :class="{'edit': actionType=='create'}"
            @tap.prevent.stop="action('meetingTime')"
          >
            <div class="item-left">会议开始时间</div>
            <div
              class="item-right"
            >{{meetingInfo.customerMeeting.meetingTime | cast | dateTimeFormat}}</div>
          </li>
          <li
            class="item"
            :class="{'edit': actionType=='create'}"
            @tap.prevent.stop="action('meetingEndTime')"
          >
            <div class="item-left">会议结束时间</div>
            <div
              class="item-right"
            >{{meetingInfo.customerMeeting.meetingEndTime | cast | dateTimeFormat}}</div>
          </li>
          <li class="item">
            <div class="item-left">学员姓名</div>
            <div class="item-right">{{meetingInfo.customerMeeting.customerName}}</div>
          </li>
          <li class="item">
            <div class="item-left">会议组织人</div>
            <div class="item-right">{{meetingInfo.customerMeeting.creatorName}}</div>
          </li>
          <li class="item" :class="{'edit': isEdit}" @click="selTimeDur()">
            <div class="item-left">会议时长</div>
            <div class="item-right">{{meetingInfo.customerMeeting.meetingDuration}}</div>
          </li>
          <li
            class="item"
            :class="{'edit': actionType=='create'}"
            @click.prevent.stop="selectItem('meetingType')"
          >
            <div class="item-left">会议类型</div>
            <div class="item-right">{{meetingInfo.customerMeeting.meetingType | meetingType}}</div>
          </li>
          <li
            class="item"
            :class="{'edit': actionType=='create'}"
            @click.prevent.stop="selectItem('meetingTitle')"
          >
            <div class="item-left">会议主题</div>
            <div class="item-right">{{meetingInfo.customerMeeting.meetingTitle | meetingTitle}}</div>
          </li>
          <li
            class="item"
            :class="{'edit': actionType=='create'}"
            @click.prevent.stop="editContent()"
          >
            <div class="item-left">会议参与人</div>
            <div class="item-right meetingPerson">{{meetingInfo.customerMeeting.participants}}</div>
          </li>
        </ul>
      </div>
      <div class="visit-set" v-if="$route.query.actionType=='view'">
        <div
          class="wrapper-color"
          v-for="(prop,index) in meetingInfo.items"
          v-if="meetingInfo.items"
          :class="!(index%2)?'deep':''"
          :key="index"
        >
          <li class="item">
            <div class="item-left">参会对象</div>
            <div class="item-right text-flow">
              <p v-if="prop.objectType">
                <span>【{{prop.objectType | participants}}】</span>
                <span>{{prop.objectName}}</span>
              </p>
            </div>
          </li>
          <!--@click="viewContent(index)"-->
          <li
            class="item"
            :class="{'active': active==index,'edit': isEdit}"
            @click.prevent.stop="multipSelectItem('contentType')"
          >
            <span class="item-left">会议内容</span>
            <div class="item-right text-flow">
              <p v-if="prop.contentType">
                <span>【{{prop.contentType | contentType}}】</span>
                <span>{{prop.contentData}}</span>
              </p>
            </div>
          </li>
        </div>
      </div>
      <div :class="$route.query.actionType=='view'?'':'visit-set'" v-if="objectItems.length">
        <div
          class="wrapper-color"
          v-for="(prop,index) in objectItems"
          :class="!(index%2)?'deep':''"
          :key="index"
        >
          <li class="item edit" @click.prevent.stop="multipSelectItem('objectType')">
            <div class="item-left">参会对象</div>
            <div class="item-right text-flow">
              <p v-if="prop.objectType">
                <span>【{{prop.objectType | participants}}】</span>
                <span class="textHidden">{{prop.objectName}}</span>
              </p>
            </div>
          </li>
          <li class="item edit" @click.prevent.stop="multipSelectItem('contentType')">
            <span class="item-left">会议内容</span>
            <div class="item-right text-flow">
              <p v-if="prop.contentType">
                <span>【{{prop.contentType | contentType}}】</span>
                <span>{{prop.contentData}}</span>
              </p>
            </div>
          </li>
        </div>
      </div>
      <p class="visit-dd margin-bottom-15" v-if="meetingInfo.isEdit" @click="addObject()">
        添加参会对象及对应会议内容
        <i class="icon-add iconfont"></i>
      </p>
      <div class="visit-next wrapper-color">
        <li class="item" v-if="meetingInfo.isEdit">
          <span class="item-left">
            <span>附件</span>
            <span class="tips">(app端只能上传图片类附件,如需上传其他格式请到PPTS端)</span>
          </span>
        </li>
        <li class="item" v-for="(item,index) in objectFiles" :key="index">
          <span class="item-left">附件{{index+1}}</span>
          <span class="item-right file">
            <p
              v-if="item.title"
              style="display: flex;align-items:center;"
              @click="viewUploadImg(item.path,item)"
            >
              <i class="iconfont icon-file fileIcon"></i>
              <span class="fileName">{{item.title}}</span>
            </p>
            <p v-else>
              <i class="iconfont icon-up-img"></i>
              <input name="upImg" class="upImg" type="file" @change="upLoadImg($event)" />
            </p>
          </span>
        </li>
        <p class="visit-dd margin-bottom-15" v-if="meetingInfo.isEdit" @click="addfile()">
          添加附件
          <i class="icon-add iconfont"></i>
        </p>
        <li class="item" :class="{'edit': isEdit}" @click.prevent.stop="selectItem('satisficing')">
          <div class="item-left">家长满意度</div>
          <div class="item-right">{{meetingInfo.customerMeeting.satisficing | satisficing}}</div>
        </li>
        <li class="item" :class="{'edit': isEdit}" @tap="action('nextMeetingTime')">
          <div class="item-left">预计下次开会时间</div>
          <div
            class="item-right"
          >{{meetingInfo.customerMeeting.nextMeetingTime | cast | dateTimeFormat}}</div>
        </li>
      </div>
      <select-items
        v-show="itemsParams.isShow"
        :title="itemsParams.title"
        :model="itemsParams.model"
        :isShow="itemsParams.isShow"
        :category="itemsParams.category"
        :items="itemsParams.selectItems"
        @selectItem="selectVisitType"
      ></select-items>
      <multiple-select
        v-show="multipItemsParams.isShow"
        :inpSize="multipItemsParams.inpSize"
        :writable="multipItemsParams.writable"
        :title="multipItemsParams.title"
        :model="multipItemsParams.model"
        :isShow="multipItemsParams.isShow"
        :category="multipItemsParams.category"
        :items="multipItemsParams.selectItems"
        @multipSelectItem="multipSelectType"
      ></multiple-select>
      <inputFullLayer
        :isShow="layerParams.isShowLayer"
        :content="meetingInfo.customerMeeting.participants"
        title="请输入会议参与人"
        @completeAction="completeAction"
      ></inputFullLayer>
    </div>
    <div v-else class="viewImg" @click="viewUploadImg('scale',{id:''})">
      <img :src="viewImg" alt />
    </div>
  </div>
</template>
<script>
import { ACTION_TYPES, loadFormat } from "@/constants";
import { DATE_FORMAT } from "@/public/constant";
import { loadUserInfo } from "@/api/common/common-api";
import {
  postCustomerMeeting as $postCustomerMeeting,
  getMeeting as $getMeeting,
  getCreateMeetingModel as $getCreateMeetingModel
} from "@/api/customer/customer-api";
import SelectItems from "@/components/select-items/index";
import InputFullLayer from "@/components/input-full-layer/index";
import MultipleSelect from "@/components/multiple-select-items/index";

export default {
  data() {
    this.viewType = {
      CREATE: "create",
      VIEW: "view"
    };
    return {
      meetingInfo: {},
      itemsParams: {
        isShow: false,
        title: "",
        model: "",
        category: "",
        selectItems: []
      },
      multipItemsParams: {
        isShow: false,
        title: "",
        model: [],
        category: "",
        writable: true,
        inpSize: false,
        selectItems: []
      },
      layerParams: {
        isShowLayer: false
      },
      active: -1,
      _meeting: {},
      objectItems: [],
      objectFiles: [],
      viewCon: true,
      viewImg: ""
    };
  },
  created() {
    this.getActionData();
    this.enableAction();
    this.registerSubmit();
  },
  methods: {
    viewContent(index) {
      console.log(index);
      if (this.active == index) {
        this.active = -1;
        return;
      }
      this.active = index;
    },
    addObject() {
      this.objectItems.push({
        contentData: "",
        contentType: "",
        objectName: "",
        objectType: ""
      });
    },
    addfile() {
      this.objectFiles.push({
        title: "",
        path: ""
      });
    },
    download(data) {
      let url = process.env.APP_API_ROOT + "/api/Customer/DownloadMaterial";
      this.postcall(url, data);
    },
    viewUploadImg(path, filesObj) {
      if (!path && filesObj.id) {
        this.download(filesObj);
        return;
      }
      if (path == "scale" && !filesObj.id) {
        this.viewCon = true;
        document.querySelector(".xd-header").style.display = "block";
        return;
      }
      this.viewCon = false;
      document.querySelector(".xd-header").style.display = "none";
      var _this = this;
      var fileReader = new FileReader();
      //将用户上传的文件对象作为参数，传入文件读取器的方法readAsDataURL
      fileReader.readAsDataURL(path);
      //文件读取器方法执行完毕后调用函数
      fileReader.onload = function() {
        //文件读取器的result属性即fileReader.result，就是上传文件的dataURL
        _this.viewImg = fileReader.result;
      };
    },
    async getActionData() {
      await loadUserInfo();
      if (this.actionType == this.viewType.VIEW) {
        this.getVisitInfo();
      } else if (this.actionType == this.viewType.CREATE) {
        this.getVisitInfoForCreate();
      }
    },
    getVisitInfo() {
      $getMeeting(
        {
          meetingID: this.meetingID
        },
        res => {
          this.meetingInfo = res;
          this.objectFiles = res.customerMeeting.materials;
          this.disabledAction();
        }
      );
    },
    getVisitInfoForCreate() {
      $getCreateMeetingModel(
        {
          customerID: this.customerID
        },
        res => {
          this.meetingInfo = res;
          res.customerMeeting.meetingTime = "";
          res.customerMeeting.meetingEndTime = "";
          this._meeting = this._copy(res.customerMeeting);
        }
      );
    },
    upLoadImg(e) {
      let _this = this;
      console.log(e.target.files);
      var files = e.target.files[0];
      if (files.size / (1024 * 1024) > 20) {
        mui.toast("请参考本地网速，上传小于20M文件");
        return;
      }
      var reg = new RegExp(loadFormat);
      var result = /\.[^\.]+/.exec(files.name);
      if (!reg.test(result)) {
        mui.toast("上传的文件格式不正确，请重新选择!");
        return;
      }
      var data = new FormData();
      data.append(
        "materialUploadModel",
        JSON.stringify({
          materialClass: "新增会议上传",
          resourceID: this.meetingInfo.customerMeeting.resourceId,
          originalName: files.name,
          title: files.name,
          status: 1,
          rootPathName: ""
        })
      );
      data.append("file", files);
      var server = process.env.APP_API_ROOT + "/api/Customer/UploadMaterial";
      var request = new XMLHttpRequest();
      request.open("POST", server);
      request.setRequestHeader(
        "x-session-token",
        m2.cache.get("ppts-session-token")
      );

      request.send(data);
      request.onload = function(oEvent) {
        if (request.status == 200) {
          mui.toast("上传成功");
          var response = eval("(" + request.responseText + ")");
          _this.objectFiles.forEach(item => {
            if (!item.title) {
              item.title = files.name;
              item.path = files;
            }
          });
          _this.meetingInfo.customerMeeting.materials = [];
          _this.meetingInfo.customerMeeting.materials.push(response[0]);
        } else {
          mui.toast("上传失败");
        }
      };
    },
    postcall(url, params) {
      var reg = new RegExp(loadFormat);
      var result = /\.[^\.]+/.exec(params.title);

      plus.nativeUI.showWaiting("下载中...");
      /*if(!reg.test(result)) {
				plus.nativeUI.closeWaiting();
				mui.toast("app端暂不支持下载文件，可到PPTS端下载查看!");
				return;
			} else {
				plus.nativeUI.showWaiting('下载中...')
			}*/
      function createDownload() {
        var dtask = plus.downloader.createDownload(
          url,
          {
            method: "POST",
            data: JSON.stringify(params),
            filename: "_downloads/" + params.title
          },
          function(d, status) {
            // 下载完成
            if (status == 200) {
              plus.nativeUI.closeWaiting();

              if (!reg.test(result)) {
                plus.runtime.openFile("_downloads/" + params.title);
              } else {
                plus.gallery.save(
                  d.filename,
                  function() {
                    //保存到相册方法
                    plus.nativeUI.closeWaiting();
                    mui.toast("已保存到手机相册");
                  },
                  function() {
                    plus.nativeUI.closeWaiting();
                    mui.toast("请开启读取写入图库的权限！");
                  }
                );
              }
            } else {
              plus.nativeUI.closeWaiting();
              mui.toast("下载失败，请稍后重试!");
            }
          }
        );
        dtask.setRequestHeader("Content-Type", "application/json");
        dtask.setRequestHeader(
          "x-session-token",
          m2.cache.get("ppts-session-token")
        );
        dtask.setRequestHeader(
          "pptsCurrentJobID",
          m2.cache.get("ppts-current-job").id
        );

        dtask.start();
      }
      createDownload();
    },
    submit() {
      this.objectItems.forEach(item => {
        if (
          item.contentData ||
          item.contentType ||
          item.objectName ||
          item.objectType
        ) {
          this.meetingInfo.items.push(item);
        }
      });
      if (mui.os.ios) {
        this.meetingInfo.customerMeeting.fromSystemID = 1;
      } else if (mui.os.android) {
        this.meetingInfo.customerMeeting.fromSystemID = 2;
      } else {
        this.meetingInfo.customerMeeting.fromSystemID = 3;
      }
      $postCustomerMeeting(this.meetingInfo, res => {
        console.log(res);
        this.$router.go(-1);
      });
    },
    selectItem(category) {
      if (
        (category == "meetingTitle" && this.actionType == "view") ||
        (category == "meetingType" && this.actionType == "view") ||
        !this.isEdit
      )
        return;
      document.getElementById("wrap").style.overflowY = "hidden";
      this.itemsParams.isShow = true;
      this.itemsParams.category = category;
      switch (category) {
        case "meetingTitle":
          this.itemsParams.title = "会议主题";
          this.itemsParams.model = this.meetingInfo.customerMeeting.meetingTitle;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "meetingType":
          this.itemsParams.title = "会议类型";
          this.itemsParams.model = this.meetingInfo.customerMeeting.meetingType;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        case "satisficing":
          this.itemsParams.title = "家长满意度";
          this.itemsParams.model = this.meetingInfo.customerMeeting.satisficing;
          this.itemsParams.selectItems = this._getSelectItems(category);
          break;
        default:
          break;
      }
    },
    multipSelectItem(category) {
      if (
        (this.actionType == "view" && category == "objectType") ||
        !this.isEdit
      )
        return;
      document.getElementById("wrap").scrollTop = 0;
      setTimeout(() => {
        this.multipItemsParams.isShow = true;
        console.log(document.getElementById("wrap"));
        document.getElementById("wrap").style.overflowY = "hidden";
        this.multipItemsParams.category = category;
        switch (category) {
          case "objectType":
            this.multipItemsParams.title = "参会对象";
            this.multipItemsParams.model = this.meetingInfo.items;
            this.multipItemsParams.selectItems = this._getSelectItems(category);
            this.multipItemsParams.inpSize = false;
            break;
          case "contentType":
            this.multipItemsParams.title = "会议内容";
            this.multipItemsParams.model = this.meetingInfo.items;
            this.multipItemsParams.selectItems = this._getSelectItems(category);
            this.multipItemsParams.inpSize = true;
            break;
          default:
            break;
        }
      }, 0);
    },
    multipSelectType(obj) {
      this.multipItemsParams.isShow = false;
      document.getElementById("wrap").style.overflowY = "scroll";
      console.log(obj);
      if (obj /* && obj.category*/) {
        switch (obj.category) {
          case "objectType":
            this.objectItems.forEach(item => {
              if (!item.objectType || !item.contentType) {
                item.objectType = obj.key;
                item.objectName = obj.remark;
              }
            });
            break;
          case "contentType":
            this.objectItems.forEach(item => {
              if (!item.contentType) {
                item.contentType = obj.key;
                item.contentData = obj.remark;
              }
            });
            break;
          default:
            break;
        }
      }
    },
    selectVisitType(obj) {
      this.itemsParams.isShow = false;
      document.getElementById("wrap").style.overflowY = "scroll";
      if (obj && obj.category) {
        switch (obj.category) {
          case "meetingTitle":
            this.meetingInfo.customerMeeting.meetingTitle = obj.item.key;
            break;
          case "meetingType":
            this.meetingInfo.customerMeeting.meetingType = obj.item.key;
            break;
          case "satisficing":
            this.meetingInfo.customerMeeting.satisficing = obj.item.key;
            break;
          default:
            break;
        }
      }
    },
    editContent(category) {
      this._removeElementsByClass("mui-dtpicker");
      this.wrapH = document.getElementById("wrap").scrollTop;
      if (this.actionType == "view") return;
      this.layerParams.isShowLayer = true;
      document.getElementById("wrap").style.overflow = "hidden";
      document.getElementById("content-layer").style.marginTop =
        this.wrapH + "px";
    },
    completeAction(obj) {
      this.layerParams.isShowLayer = false;
      document.getElementById("wrap").style.overflow = "scroll";
      if (obj && obj.content) {
        this.meetingInfo.customerMeeting.participants = obj.content;
      }
    },
    selTimeDur() {
      if (!this.isEdit) return;
      var option = {
        type: "time"
      };
      let dtPicker = new mui.DtPicker(option);
      const _this = this;
      dtPicker.show(function(selectTime) {
        this.selectTimeArr = selectTime.value.split(":");
        this.selectTimeChinese =
          this.selectTimeArr[0] + "时" + this.selectTimeArr[1] + "分";
        _this.meetingInfo.customerMeeting[
          "meetingDuration"
        ] = this.selectTimeChinese;
      });
    },
    action(paramName) {
      if (
        this.viewType.VIEW == this.actionType &&
        (!this.meetingInfo.isEdit ||
          paramName == "meetingTime" ||
          paramName == "meetingEndTime")
      )
        return;
      let dtPicker = new mui.DtPicker(this.option);
      const _this = this;
      dtPicker.show(function(selectItems) {
        _this.$nextTick(() => {
          if (paramName === "nextMeetingTime") {
            let date = _this._getDate();
            let currDate = new Date(selectItems.value.replace(/-/g, "/"));
            if (currDate.getTime() < date.getTime()) {
              mui.toast("只能选择当前时间以后的日期");
            } else {
              _this.meetingInfo.customerMeeting[paramName] = new Date(
                selectItems.value.replace(/-/g, "/")
              );
            }
          } else if (paramName === "meetingTime") {
            let date = _this._getDate();
            let date_3 = _this._getDate(-3);
            let meetingTime = new Date(selectItems.value.replace(/-/g, "/"));
            let meetingEndTime =
              _this.meetingInfo.customerMeeting["meetingEndTime"];
            let currDate = new Date(selectItems.value.replace(/-/g, "/"));
            if (
              currDate.getTime() > date.getTime() ||
              currDate.getTime() < date_3.getTime()
            ) {
              mui.toast("只能选择当前日期及当前日期的前三天");
            } else {
              _this.meetingInfo.customerMeeting[paramName] = new Date(
                selectItems.value.replace(/-/g, "/")
              );
            }
          } else if (paramName === "meetingEndTime") {
            let date = _this._getDate();
            let date_3 = _this._getDate(-3);
            let meetingTime = _this.meetingInfo.customerMeeting["meetingTime"];
            let meetingEndTime = new Date(selectItems.value.replace(/-/g, "/"));
            let currDate = new Date(selectItems.value.replace(/-/g, "/"));
            if (
              currDate.getTime() > date.getTime() ||
              currDate.getTime() < date_3.getTime()
            ) {
              mui.toast("只能选择当前日期及当前日期的前三天");
            } else if (meetingTime) {
              if (!m2.date.isOneToday(meetingTime, meetingEndTime)) {
                mui.toast("会议开始时间和结束时间应为同一天!");
              } else if (m2.date.isTime(meetingTime, meetingEndTime)) {
                mui.toast("会议开始时间和结束时间不能相同!");
              } else if (!m2.date.isBigTime(meetingTime, meetingEndTime)) {
                mui.toast("会议结束时间应大于会议开始时间!");
              } else {
                _this.meetingInfo.customerMeeting[paramName] = new Date(
                  selectItems.value.replace(/-/g, "/")
                );
              }
            } else {
              _this.meetingInfo.customerMeeting[paramName] = new Date(
                selectItems.value.replace(/-/g, "/")
              );
            }
          }
          dtPicker.dispose();
        });
      });
    },
    enableAction() {
      if (this.actionType == this.viewType.VIEW) {
        xdapp.util.vue.commitActionStatus(true);
      }
    },
    registerSubmit() {
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    disabledAction() {
      this.$nextTick(() => {
        if (!this.isEdit) {
          let actions = document.getElementsByClassName("action");
          let actionList = Array.prototype.slice.call(actions);
          actionList.forEach(action => {
            action.style.display = "none";
          });
        }
      });
    },
    _copy(obj) {
      var newobj = {};
      for (var attr in obj) {
        newobj[attr] = obj[attr];
      }
      return newobj;
    },
    /*_checkIsChange() {
			return this._meeting.visitTime == this.meetingInfo.visit.visitTime &&
				this._meeting.visitType == this.meetingInfo.visit.visitType &&
				this._meeting.visitWay == this.meetingInfo.visit.visitWay &&
				this._meeting.satisficing == this.meetingInfo.visit.satisficing &&
				this._meeting.visitContent == this.meetingInfo.visit.visitContent &&
				this._meeting.nextVisitTime == obj.visit.nextVisitTime &&
				this._meeting.remindTime == obj.visit.remindTime;
		},*/
    _editType(category) {
      return category == "satisficing" || category == "objectType";
    },
    _getSelectItems(category) {
      let res = [];
      switch (category) {
        case "meetingType":
          res = this.meetingInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_MainServiceMeeting;
          break;
        case "meetingTitle":
          res = this.meetingInfo.dictionaries.c_codE_ABBR_MeetingTitle;
          break;
        case "satisficing":
          res = this.meetingInfo.dictionaries
            .C_CODE_ABBR_BO_Customer_Satisfaction;
          break;
        case "objectType":
          res = this.meetingInfo.dictionaries
            .C_CODE_ABBR_Customer_CRM_MeetingObject;
          break;
        case "contentType":
          res = this.meetingInfo.dictionaries.c_codE_ABBR_ContentType;
          break;
        default:
          break;
      }
      return res;
    },
    _getDate(d) {
      let date = new Date();
      if (typeof d !== "undefined") {
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);
        date.setMilliseconds(0);
        let targetday_milliseconds = date.getTime() + 1000 * 60 * 60 * 24 * d;
        date.setTime(targetday_milliseconds);
      }
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let day = date.getDate();
      let h = date.getHours();
      let m = date.getMinutes();
      let z = year + "-" + month + "-" + day + " " + h + ":" + m;
      let time = new Date(
        z.format(DATE_FORMAT["en-US"].dateTimeIos).replace(/-/g, "/")
      );
      return time;
    },
    // 1.封装了一个可以去除mui日历插件的方法  2. dtPicker.dispose();
    _removeElementsByClass(className) {
      var elements = document.getElementsByClassName(className);
      while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
      }
    }
  },
  beforeDestroy() {
    this._removeElementsByClass("mui-dtpicker");
  },
  computed: {
    meetingID() {
      return this.$route.query.meetingID;
    },
    customerID() {
      return this.$route.query.id;
    },
    actionType() {
      return this.$route.query.actionType;
    },
    isEdit() {
      if (this.actionType == this.viewType.VIEW) {
        return this.meetingInfo.isEdit;
      } else if (this.actionType == this.viewType.CREATE) {
        return true;
      }
    }
  },
  watch: {
    meetingInfo: {
      handler: function(obj) {
        if (
          this.actionType == this.viewType.CREATE &&
          (this._meeting.nextMeetingTime !=
            obj.customerMeeting.nextMeetingTime &&
            obj.customerMeeting.meetingDuration &&
            obj.customerMeeting.meetingType &&
            obj.customerMeeting.meetingTitle &&
            obj.customerMeeting.participants &&
            obj.customerMeeting.satisficing &&
            this._meeting.meetingTime != obj.customerMeeting.meetingTime)
        ) {
          this.meetingArr = true;
          xdapp.util.vue.commitActionStatus(true && this.objectArr);
          if (this.$route.query.actionType == "view") {
            xdapp.util.vue.commitActionStatus(true);
          }
        }
      },
      deep: true
    },
    objectItems: {
      handler: function(obj) {
        if (
          obj[0].contentType &&
          obj[0].contentData &&
          obj[0].objectType &&
          obj[0].objectName
        ) {
          this.objectArr = true;
          xdapp.util.vue.commitActionStatus(true && this.meetingArr);
          if (this.$route.query.actionType == "view") {
            xdapp.util.vue.commitActionStatus(true);
          }
        }
      },
      deep: true
    },
    "meetingInfo.customerMeeting.meetingTime"(obj) {
      var meetingEndTime = this.meetingInfo.customerMeeting.meetingEndTime;
      if (!obj || !meetingEndTime) return;
      if (!m2.date.isOneToday(obj, meetingEndTime)) {
        mui.toast("会议结束时间需和会议开始时间为同一天");
        this.meetingInfo.customerMeeting.meetingEndTime = "";
      } else {
        if (this.actionType == this.viewType.CREATE) {
          this.meetingInfo.customerMeeting.meetingDuration = m2.date.timeDuration(
            obj,
            meetingEndTime
          );
        }
      }
    },
    "meetingInfo.customerMeeting.meetingEndTime"(obj) {
      var meetingTime = this.meetingInfo.customerMeeting.meetingTime;
      if (!obj || !meetingTime) return;
      if (!m2.date.isOneToday(obj, meetingTime)) {
        mui.toast("会议结束时间需和会议开始时间为同一天");
        this.meetingInfo.customerMeeting.meetingTime = "";
      } else {
        if (this.actionType == this.viewType.CREATE) {
          this.meetingInfo.customerMeeting.meetingDuration = m2.date.timeDuration(
            meetingTime,
            obj
          );
        }
      }
    }
  },
  components: {
    SelectItems,
    InputFullLayer,
    MultipleSelect
  }
};
</script>

<style lang="scss" scoped>
$wrapperColor: #fff;
$titleColor: #777;
$contentColor: #999;
#wrap {
  overflow: auto;
}
.xdapp-feedback-container {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    // position: absolute;
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
}
.visit-info-wrapper {
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: $backgroundColor;
  font-size: torem(14);
  color: $titleColor;
  .item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: torem(50);
    line-height: torem(50);
    border-bottom: 1px solid rgba(239, 239, 244, 0.5);
    .item-left {
      padding-left: torem(10);
    }
    .item-right {
      position: absolute;
      right: torem(25);
      flex: 1;
      text-align: right;
      color: $contentColor;
    }
    p {
      margin-bottom: torem(0);
    }
  }
  .edit {
    &:after {
      margin: 0 5px;
      content: "\E583";
      font-family: Muiicons;
      -webkit-font-smoothing: antialiased;
      font-size: torem(14);
      color: $contentColor;
    }
  }
  .text-flow {
    p {
      width: torem(260);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-bottom: 0;
    }
  }
  .active {
    height: torem(120);
    padding: torem(10) 0;
    overflow: hidden;
    div.text-flow {
      max-height: torem(100);
      // overflow-y: scroll;
      p {
        line-height: torem(20);
        white-space: normal;
      }
    }
  }
  .meetDur {
    border: none;
    width: torem(100);
    margin-bottom: 0;
    text-align: right;
    padding: 0;
  }
}

.margin-top-15 {
  margin-top: torem(15);
}

.margin-bottom-15 {
  margin-bottom: torem(15);
}

.wrapper-color {
  background-color: $wrapperColor;
}

.visit-dd {
  text-align: right;
  display: flex;
  align-items: center;
  flex-direction: row-reverse;
  background: #f3f3f3;
  padding: torem(10) 0;
  padding-right: torem(15);
  i {
    color: #333;
    font-size: torem(20);
  }
}

.deep {
  background: #f3f3f3;
}

.visit-set {
  margin-top: torem(-15);
}

.tips {
  color: red;
  font-size: torem(10);
}

.icon-up-img {
  color: #ccc;
  font-size: torem(40);
  position: relative;
  top: torem(4);
  right: 0;
}

.fileIcon {
  color: #ccc;
  font-size: torem(40);
}

.upImg {
  opacity: 0;
  width: torem(40);
  height: torem(40);
  position: absolute;
  overflow: hidden;
  top: torem(4);
  right: 0;
}

.viewImg {
  position: absolute;
  top: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  img {
    width: auto;
    height: auto;
    max-width: 100%;
    max-height: 100%;
  }
}
.meetingPerson {
  width: torem(260);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>