<template>
	<div class='xueda-news'>
		<div class='xd-news'>
			<div>
				<p class="xueda-img"><img src="~@/public/asset/img/home/classBreak.png"></p>
				<p><span class="tit">课间小憩</span></p>
			</div>
			<span @tap='addClassBreak()'><i class="mui-icon mui-icon-compose"></i></span>
		</div>
		<div class='cont'>
			<div class="move" @tap="getLoadRandom()">
				<div v-if='content'>
					<img src="~@/public/asset/img/home/classBreak-bg.png" align='right' alt="" />
					{{content}}
				</div>
				<div v-if='!content' style="text-align: center">暂无课间小憩</div>
			</div>
		</div>
	</div>
</template>
<script>
	import Tip from '@/components/tip';
	import { loadRandom } from '@/api/classBreak/classBreak-api';
	export default {
		data() {
			return {
				content: '',
			}
		},
		mounted() {
			this.getLoadRandom()
		},
		methods: {
			getLoadRandom() {
				this.content = ''
				loadRandom({}, (res) => {
					if(res) {
						this.content = res.content;
					}
				})
			},
			addClassBreak() {
				this.$router.push({
					name: 'classBreak-share'
				})
			},
		},
		components: {
			Tip
		}
	}
</script>

<style scoped lang='scss'>
	.xueda-news {
		background: rgba(255, 255, 255, 0.89);
		width: 100%;
		padding: torem(10) 0;
	}
	
	.xd-news {
		padding-top: torem(20);
		display: flex;
		padding: 10px 0 0 10px;
		justify-content: space-between;
		padding: 0 torem(23);
		align-items: center;
		height: torem(40);
		div {
			display: flex;
			align-items: center;
		}
		.xueda-img {
			width: torem(20);
			height: torem(20);
			border-radius: 100%;
			margin-right: torem(10);
			img {
				width: 100%;
				height: 100%;
			}
		}
		p {
			margin-bottom: 0;
		}
		span {
			color: #8f8f94;
			font-size: torem(14)
		}
		span.tit {
			font-size: torem(15);
			font-weight: bold;
		}
	}
	.cont {
		margin: 0 torem(10) torem(10);
		font-size: torem(14);
		line-height: torem(25);
		color: #8f8f94;
		padding: torem(10) torem(15);
		border-radius: 5px;
		overflow: hidden;
	}
	
	.move {
		div{
			position: relative;
		}
		img {
			width: torem(80);
			height: torem(80);
		}
	}
</style>