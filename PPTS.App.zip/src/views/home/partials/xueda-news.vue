<template>
	<div class='xueda-news'>
		<div class='xd-news' @click='go()'>
			<div>
				<p class="xueda-img"><img src="~@/public/asset/img/home/news.png"></p>
				<span class="tit">学大资讯</span>
			</div>
			<span class="wh_jiantou2"></span>
		</div>
		<ul class="mui-table-view">
			<li v-if="newsList.length>0" v-for="(item,index) in newsList" :key="index" :class="index?'imgBox':'firstBox'" class="mui-table-view-cell mui-media" @tap="goDetail(item)">
				<p class='img' :class="!index?'firstImg':''"><img :src="item.subtitleIMGID" alt="" /></p>
				<p class='text' :class="!index?'firstText':''">{{item.title}}</p>
				<!--{{item.subtitle}}-->
			</li>
			<li v-if="!newsList.length" class="mui-table-view-cell mui-media" style="text-align: center">
				<p>暂无资讯</p>
			</li>
		</ul>
	</div>
</template>
<script>
	import { ACTION_TYPES } from '@/constants';
	import { pager } from '@/public/constant';
	import { loadUserInfo } from '@/api/common/common-api';
	import { $getTop3NewsList } from '@/api/news/news-api';
	export default {
		data() {
			return {
				newsList: []
			};
		},
		created() {
			this.getNewsList();
			// this.switchJob();
		},
		methods: {
			goDetail(item) {
				this.$router.push({
					name: 'message-news-detail',
					query: {
						newsId: item.newsID
					}
				})
			},
			go() {
				this.$router.push({
					name: 'message-xd-news'
				})
			},
			async getNewsList() {
				await loadUserInfo();

				$getTop3NewsList('?NewType=3', res => {
					if(res && res.length) this.newsList = res;						
				});
			},
			switchJob() {
				xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getNewsList);
			}
		},
	}
</script>
<style scoped lang='scss'>
	.xueda-news {
		background: #fff;
		width: 100%;
		margin-top: torem(-1);
		padding: torem(10) 0;
	}
	
	.xd-news {
		padding-top: torem(20);
		display: flex;
		padding: 10px 0 0 10px;
		justify-content: space-between;
		padding: 0 torem(23);
		align-items: center;
		height: torem(40);
		background-color: #fff;
		p {
			margin-bottom: 0;
		}
		div {
			display: flex;
			align-items: center;
		}
		.xueda-img {
			width: torem(22);
			height: torem(22);
			border-radius: 100%;
			margin-right: torem(6);
			border: 1px solid #fff;
			overflow: hidden;
			img {
				width: 100%;
				height: 100%;
			}
		}
		span {
			color: #8f8f94;
			font-size: torem(14)
		}
		span.tit {
			font-size: torem(15);
			font-weight: bold;
		}
	}
	
	.mui-table-view {
		background: rgba(255, 255, 255, 0.89) !important;
		li {
			margin: 11px torem(23);
			background: rgba(255, 255, 255, 0.89) !important;
			border-bottom: 1px solid #ccc;
		}
		li:last-child {
			border: none;
		}
		.img {
			width: torem(60);
			height: torem(43);
			margin-right: torem(15);
			img {
				width: 100%;
				height: 100%;
			}
		}
		.text {
			flex: 1;
			font-size: torem(15);
			margin-top: -4px;
		}
		.firstBox {
			margin-bottom: 0;
			margin-top: 0;
			padding: 0;
			position: relative;
			.firstImg {
				width: 100%;
				height: auto;
			}
			.firstText {
				position: absolute;
				bottom: 0;
				width: 100%;
				color: #fff;
				background: rgba(0, 0, 0, .5);
				line-height: 32px;
				font-size: torem(16);
				overflow: hidden;
				padding-left: torem(20);
				white-space: nowrap;
				text-overflow: ellipsis;
			}
		}
		.imgBox {
			display: flex;
			padding-left: 0;
			padding-right: 0;
			margin-bottom: 5px;
			margin-top: 5px;
		}
		.firstImg {
			width: torem(219);
			height: torem(100);
			margin: torem(10) auto;
			img {
				width: 100%;
				height: 100%;
			}
		}
	}
	
	.mui-table-view:before,
	.mui-table-view-cell:after,
	.mui-table-view:after {
		height: 0;
	}
</style>