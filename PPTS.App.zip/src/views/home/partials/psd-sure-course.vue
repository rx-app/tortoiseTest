﻿<template>
	<div class="wrap">
		<scroll :data="[]" :listen-scroll="true" :probe-type="3" :pulldown="true"  class="scroll-container" ref="listview">
			<div><div class='course-mess'>
					<p class='course-title'>确认课时内容如下</p>
					<p>
						<span class="dateMonth">{{courseMess.startTime | dateFormat({locale: 'zh-CN'})}}</span>
						<span class="dateTime">{{courseMess.startTime | timeRange(courseMess.endTime, {locale: 'zh-CN'})}}</span>
					</p>
					<div class='course'>
						<p><span>科目 : </span><span>{{courseMess.subjectName}} </span></p>
						<p><span>老师 : </span><span>{{courseMess.teacherName}} </span></p>
					</div>
					<div class='course'>
						<p><span>学员 : </span><span>{{courseMess.customerName}}</span></p>
						<p><span>编号 : </span><span>{{courseMess.customerCode}}</span></p>
					</div>
				</div>
				<div class="psdSure">
					<p class='title'><span>上课学员</span><span>输入签到密码</span></p>
					<div class='surePsd'>
						<p class='cusName'>{{courseMess.customerName}}</p>
						<p class='cusInp'>
							<input class="sureInp" maxlength=6 @focus="setPosition" @blur="setPosition2" :type="inpType" placeholder="输入6位签到密码" v-model="inpValue" />
							<i class="iconfont" :class="iconStatus" @click="toggleInpType()"></i>
						</p>
					</div>
					<button class="sureBtn" :class="inpValue.length<6?'off':''" @click="sureCourse" :disabled="btnStatus">确认签到</button>
				</div></div>
		</scroll>
	</div>
</template>

<script>
	import { getLessonInfo, passwordConfirm } from '@/api/course/course-api';
	import Scroll from '@/components/scroll/index';  
	import { setTimeout } from 'timers';

	function resize() {
		if(mui.os.ios){
			plus.webview.currentWebview().setStyle({
				'bottom': '-1px'
			})
		}
	}
	export default {
		data() {
			return {
				courseMess: {},
				btnStatus: false,
				inpType: 'password',
				inpValue: '',
				iconStatus: 'icon-close-eyes',
				showOne: false
			}
		},
		computed: {
			lessonID() {
				return this.$route.query.lessonID;
			},
			businessType() {
				return this.$route.query.businessType;
			},
			resultString() {
				return this.$route.query.resultString;
			}
		},
		methods: {
			sureCourse() {
				mui.confirm("签到后，该课时变为已上状态不能修改，是否继续确认？", "提示", (e) => {
					if(e.index) {
						passwordConfirm({
							password: this.inpValue,
							resultString: this.resultString
						}, (res) => {
							this.btnStatus = true;
							mui.toast(res.message);
							this.$nextTick(() => {
								this.goStudentDetail();
							})
						})
					}
				})
			},
			goStudentDetail() {
				if(this.showOne) {
					this.$router.replace({
						name: 'course-evaluate',
						query: {
							courseID: this.lessonID,
							businessType: this.businessType,
							type: this.businessType == 1 ? 1 : 0
						}
					})

				} else {
					this.$router.replace({
						name: 'course-other-evaluate',
						query: {
							courseID: this.lessonID,
							businessType: this.businessType,
							type: this.businessType == 1 ? 1 : 0
						}
					})
				}

			},
			toggleInpType() {
				if(this.inpType == 'text') {
					this.inpType = 'password';
					this.iconStatus = 'icon-close-eyes'
				} else {
					this.inpType = 'text';
					this.iconStatus = 'icon-eyes'

				}

			},
			setPosition() {
				console.log(1)
				// mui.toast('--------')
				var ua = navigator.userAgent.toLowerCase();
				// setTimeout(()=>{
				if(/iphone|ipad|ipod/.test(ua)) {
					// mui.toast('--test---')
					var header = document.getElementsByTagName('header')[0];
					header.setAttribute('style', 'position:absolute;top:' + 0 + 'px;left:0');

					// var attr =mui('header')[0].style['position']
					// var t =mui('header')[0].style['top']
					// var l =mui('header')[0].style['left']
					// mui.toast(attr+'l'+l+'t')
					var wv = plus.webview.currentWebview();
				
					let bottom = this.iosType == '4s' ? '315px' : '415px'
	
					wv.setStyle({
						'top': '0px'
					});
	
					wv.setStyle({
						bottom
					});
				}

			},
			setPosition2() {
				console.log(1)
				var ua = navigator.userAgent.toLowerCase();
				// setTimeout(()=>{
				if(/iphone|ipad|ipod/.test(ua)) {
					// alert(window.pageYOffset)
					var header = document.getElementsByTagName('header')[0];
					header.setAttribute('style', 'position:absolute;top:' + 0 + 'px;left:0');
					
					var wv = plus.webview.currentWebview();

					wv.setStyle({
						'top': '0px'
					});
					wv.setStyle({
						'bottom': '0px'
					});
					setTimeout(() => {
						// mui.toast(window.innerHeight)
					}, 1000);

				}
				// },200)

			},
		},
		watch:{
              inpValue(val){
                  this.inpValue=val.replace(/\s|\xA0/g,"");
			  }
		},
		created() {
			getLessonInfo({
				'courseID': this.lessonID,
				'businessType': this.businessType
			}, res => {
				this.courseMess = res.lessonInfo;
			});
			const currentJobType = m2.cache.get('ppts-current-job').jobType;
			if(currentJobType == 3) {
				this.showOne = true;
			}
			// plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
			if(mui.os.ios){
				if(window.innerHeight<500){
					// alert('4s')
					this.iosType='4s'
					plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
				}else{
					window.addEventListener('resize',resize)
				}
			}
		},
		destroyed() {
			window.removeEventListener('resize', resize)
		},
		components: {
			Scroll,
		},

	}
</script>
<style>
	.xd-header {
		/* transition: 0.223232s */
		position: fixed;
		top:0;
		left: 0;
	}
	html,body{
		height: 100%;
		overflow: hidden;
	}

	body {
		height: 100%;
		margin: 0px;
		padding: 0px;
		overflow: hidden;
		-webkit-touch-callout: none;
		-webkit-user-select: none;
	}
</style>
<style lang="scss" scoped>
	.wrap {
		// width: 100%;
		// height: 100%;
		// position: absolute;
		// top: 0;
		// bottom: 0;
		background-color: #F9F9FB;
	}

	.scroll-container {
			height: 100%;
			overflow: hidden;
			
		}
	
	.course-mess {
		width: 90%;
		margin-left: 5%;
		height: torem(153);
		background-color: #fff;
		margin-top: torem(15);
		box-shadow: 0 2px 4px 0 rgba(148, 148, 148, 0.25);
		border: 1px solid #eee;
		border-radius: 10px;
		padding: torem(10);
		.course-title {
			border-bottom: 1px dotted #DEDEDE;
			padding-bottom: torem(10);
		}
		.course {
			display: flex;
			justify-content: space-between;
			padding-right: 40px;
		}
	}
	
	.psdSure {
		width: torem(355);
		height: torem(320);
		width: 90%;
		margin-left: 5%;
		margin-top: torem(15);
		background: #FFFFFF;
		box-shadow: 0 2px 4px 0 rgba(148, 148, 148, 0.25);
		border-radius: 4px;
		padding: torem(10);
		.title {
			border-bottom: 1px dotted #DEDEDE;
			padding-bottom: torem(10);
			span {
				margin-right: torem(40)
			}
		}
		.surePsd {
			display: flex;
			.cusName {
				width: torem(80);
				height: torem(32);
				border: 1px solid #eee;
				border-radius: 4px;
				margin-right: torem(40);
				text-align: center;
				line-height: torem(32);
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
			}
			.cusInp {
				position: relative;
				.sureInp {
					width: torem(220);
					height: torem(32);
					padding: 10px 15px;
					border: 1px solid rgba(0, 0, 0, .2);
					margin-bottom: torem(15);
				}
				input::-webkit-input-placeholder {
					color: #c0c7de;
				}
				i {
					position: absolute;
					font-size: torem(24);
					color: #ddd;
					top: torem(8);
					right: torem(18);
				}
			}
		}
	}
	
	.sureBtn {
		width: 90%;
		margin-left: 5%;
		margin-top: torem(60);
		height: torem(40);
		border: none;
		background-image: linear-gradient(-90deg, #FF9900 0%, #FFB82A 100%);
		border-radius: 100px;
		color: #fff;
	}
	
	.off {
		background: #E4E4E4;
	}
</style>