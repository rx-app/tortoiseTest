<template>
  <div class="xdapp-home-guest">
    <router-link class="add-guest" tag="button" :to="{name:'addGuest'}" v-power="['睿学-新增潜客']">新增潜客</router-link>
    <swiper :options="swiperOption" v-if="PotentialCustomers && PotentialCustomers.length">
      <swiper-slide v-for="(item,index) in PotentialCustomers" :key="index">
        <div class="slide-list ribbon">
          <dl>
            <dt>
              <img v-if="item.gender == 1" src="~@/public/asset/img/user/boy.png" alt>
              <img v-else src="~@/public/asset/img/user/girl.png" alt>
            </dt>
            <dd>
              <h5>{{item.customerName}}</h5>
              <p>{{item.customerCode}}</p>
            </dd>
          </dl>
          <ul>
            <router-link
              v-power="['编辑潜客信息']"
              tag="li"
              :to="{name:'studentInfo',query:{id:item.customerID,cname:item.customerName}}"
            >编辑资料</router-link>
            <router-link
              v-power="['新增跟进记录']"
              tag="li"
              :to="{name:'follow-add', query:{customerID:item.customerID, cName: item.customerName,actionType: 'create',isPotential:true}}"
            >新增跟进记录</router-link>
            <router-link
              v-power="['添加孩子家长']"
              tag="li"
              :to="{name:'parentInfo',query:{id:item.customerID,cname:item.customerName}}"
            >添加家长</router-link>
          </ul>
          <div class="wrapper">
            <span class="inner-ribbon">近期潜客</span>
          </div>
        </div>
      </swiper-slide>
      <!-- <div class="swiper-pagination" slot="pagination"></div> -->
    </swiper>
    <div class="slide-list" v-else>
      <p class="tit">暂无30天内建档的潜客学员！</p>
    </div>
  </div>
</template>
<script>
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/qrcode/jquery.qrcode";
import "swiper/dist/css/swiper.css";
//import { randomPotentialCustomer } from "@/api/customer/customer-api";
import { swiper, swiperSlide } from "vue-awesome-swiper";
export default {
  props:['PotentialCustomers'],
  // data() {
  //   return {
  //     items: []
  //   };
  // },
  // created() {
  //   if (m2.util.getPermionLoad("睿学-新增潜客")) {
  //     randomPotentialCustomer({}, res => {
  //       this.items = res;
  //     });
  //   }
  // },
  computed: {
    swiperOption() {
      return {
        pagination: {
          el: ".swiper-pagination"
        },
        slidesPerView: "auto",
        centeredSlides: true,
        zoom: {
          maxRatio: 5, //最大倍数
          minRatio: 2, //最小倍数
          toggle: false, //不允许双击缩放，只允许手机端触摸缩放。
          containerClass: "my-zoom-container" //zoom container 类名
        }
      };
    }
  },
  components: {
    swiper,
    swiperSlide
  }
};
</script>
<style lang="scss" scoped>
.xdapp-home-guest {
  position: relative;
  .slide-list {
    width: torem(320);
    height: torem(170);
    padding: torem(20) torem(15) torem(15);
    background: rgba(255, 255, 255, 0.95);
    box-shadow: 0 2px 34px 0 rgba(125, 93, 39, 0.25);
    border-radius: 8px;
    margin: 5px auto 0;
    dl {
      display: flex;
      margin-bottom: torem(5);
      margin-top: torem(2);
      margin-left: 15px;
      dt {
        width: torem(48);
        height: torem(48);
        margin-right: torem(12);
        img {
          width: 100%;
          height: 100%;
          border-radius: 100%;
        }
      }
      dd {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        h5 {
          font-size: torem(16);
          font-weight: bold;
          color: #333;
        }
        p {
          margin-bottom: 0;
          color: #333;
        }
      }
    }
    ul {
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: torem(14);
      margin-top: torem(15);
      li {
        margin: torem(10);
      }
    }
    &.ribbon {
      position: relative;
      float: left;
      background-size: cover;
      text-transform: uppercase;
      .wrapper {
        width: 22%;
        height: torem(73);
        position: absolute;
        top: -8px;
        left: torem(256);
        overflow: hidden;
        color: #fff;
      }
      .wrapper:before {
        content: "";
        display: block;
        border-radius: 8px 8px 0px 0px;
        width: 20px;
        height: 8px;
        position: absolute;
        right: 50px;
        background: #4d6530;
      }
      .inner-ribbon {
        display: inline-block;
        text-align: center;
        width: 128px;
        height: 20px;
        line-height: 18px;
        position: absolute;
        top: 16px;
        text-indent: -8px;
        right: -46px;
        z-index: 2;
        overflow: hidden;
        transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -webkit-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        border: 1px dashed;
        -webkit-box-shadow: 0 0 0 3px #00b3ed,
          0px 21px 5px -18px rgba(0, 0, 0, 0.6);
        box-shadow: 0 0 0 3px #00b3ed, 0px 21px 5px -18px rgba(0, 0, 0, 0.6);
        background: #00b3ed;
      }
      .wrapper:after {
        content: "";
        display: block;
        border-radius: 0px 8px 8px 0px;
        width: 8px;
        height: 20px;
        position: absolute;
        right: 0px;
        top: 50px;
        background: #4d6530;
      }
    }
    .tit {
      text-align: center;
      font-size: 14px;
      margin-top: torem(50);
    }
  }
  .add-guest {
    position: absolute;
    left: 50%;
    bottom: 20px;
    margin-left: -60px;
    border: none;
    width: 120px;
    height: 30px;
    background: orange;
    color: #fff;
    border-radius: 7px;
    -webkit-transform: translate3d(
      0,
      0,
      0
    ); //可以解决新增那个按钮在ios上 因为过快滑动页面导致遮在下方 会出现闪动
    z-index: 5;
  }
  .swiper-slide {
    z-index: 1;
  }
}
</style>

