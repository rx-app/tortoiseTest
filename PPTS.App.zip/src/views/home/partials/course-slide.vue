<template>
  <div class="xd-course-list ribbon">
    <div class="t-c" v-if="!course">
      <p>今天没课喔~</p>
      <p>放心休息，关注近期课程。</p>
    </div>
    <div @tap="goStudentDetail(course)" v-if="course">
      <div class="xd-course-overview">
        <dl>
          <dt v-if="courseType==1">
            <!-- v-if="course.customerIcons" -->
            <span v-if="course.customerIcons" class="mui-media-object mui-pull-left">
              <img
                v-if="course.customerIcons.iconID"
                :src="getIconImg(course.customerIcons.userID)"
              />
              <img
                v-else-if="course.customerIcons.gender==2"
                src="~@/public/asset/img/user/girl.png"
                alt
              />
              <img v-else src="~@/public/asset/img/user/boy.png" alt />
            </span>
          </dt>
          <dt v-else>
            <!-- v-if="course.customerIcons" -->
            <span v-if="course.teacherIcons" class="mui-media-object mui-pull-left">
              <img v-if="course.teacherIcons.iconID" :src="getIconImg(course.teacherIcons.userID)" />
              <img
                v-else-if="course.teacherIcons.gender==2"
                src="~@/public/asset/img/user/teacher-woman.png"
                alt
              />
              <img v-else src="~@/public/asset/img/user/teacher-man.png" alt />
            </span>
          </dt>
          <dd v-if="courseType==1">
            <b>{{course.course.customerName}}</b>
            <span>学生</span>
          </dd>
          <dd v-else>
            <b>{{course.course.teacherName}}</b>
            <span>老师</span>
          </dd>
        </dl>
        <ul>
          <li>{{course.course.startTime | dateFormat({locale: 'zh-CN'})}}</li>
          <li>{{course.course.startTime | timeRange(course.course.endTime, {locale: 'zh-CN'})}}</li>
          <li>
            <div v-if="course.course.gradeName">
              <span class="mui-badge mui-badge-warning">{{course.course.gradeName}}</span>
            </div>
            <span
              class="mui-badge mui-badge-purple subjects"
              v-if="course.course.subjectName"
            >{{course.course.subjectName}}</span>
            <!-- <span
              class="mui-badge mui-badge-danger"
              v-if="course.course.businessType==2 && course.course.assignStatus==1 && course.course.isConfirmed"
            >已点名</span> -->
            <span
              class="mui-badge mui-badge-success"
              v-if="course.course.assignStatusName"
            >{{course.course.assignStatusName}}</span>
            <span
              class="mui-badge mui-badge-success"
              v-else
            >{{course.course.assignStatus | assignStatus}}</span>
          </li>
        </ul>
      </div>
      <!--班组已确认课时但课时状态未变-->
      <div
        class="xd-course-code"
        v-if="course.course.businessType !== 4 && course.course.isConfirmed && course.course.assignStatus==1 "
      >
        <!-- &&  peoples<=20 -->
        <img class="course-img" src="~@/public/asset/img/course/nam-sure-course.jpg" alt />
        <p class="desc" v-if="currentJobType==3">未到评价时间</p>
        <p class="desc" v-if="currentJobType==2">教师未到评价时间</p>
      </div>
      <!--排定-->
      <div class="xd-course-code" v-else-if="slideType==1 && course.course.businessType !== 4">
        <!-- &&  peoples<=20 -->
        <!---->
        <!--一对一课程排定  可扫二维码显示-->
        <div
          @tap.stop="getPsdSureCourse()"
          v-if="course.course.businessType== 1 &&  Date.parse(course.course.startTime) - 60*90*1000 < Date.parse(new Date()) && Date.parse(new Date()) < Date.parse(course.course.endTime)+ 60*90*1000"
        >
          <div
            :id="course.course.courseID"
            class="qr-canvas"
            @tap.stop="toChangeSize(course.resultString,course.course.startTime,course.course.endTime)"
          ></div>
          <p class="desc scanSure">
            <span>扫码确认</span>
            <span>|</span>
            <span class="psdSure">密码确认</span>
          </p>
        </div>
        <!--一对一课程排定  但未到时间  不显示二维码-->
        <div v-else-if="course.course.businessType==1">
          <img
            v-if="Date.parse(course.course.startTime)<Date.parse(new Date())"
            class="course-img"
            src="~@/public/asset/img/course/course-time-out.jpg"
            alt
          />
          <img
            v-if="Date.parse(course.course.startTime)>Date.parse(new Date())"
            class="course-img"
            src="~@/public/asset/img/course/course-no-start.jpg"
            alt
          />
          <p
            class="desc noneSure"
            v-if="Date.parse(course.course.startTime)<Date.parse(new Date())"
          >逾期，不可确认</p>
          <p
            class="desc noneSure"
            v-if="Date.parse(course.course.startTime)>Date.parse(new Date())"
          >未到确认时间</p>
        </div>
        <!--班组课程排定  可显示点名确认课时按钮-->
        <div
          v-else-if="(course.course.businessType== 2 || course.course.businessType== 3) && Date.parse(course.course.startTime) - 60*90*1000 < Date.parse(new Date()) && Date.parse(new Date()) < Date.parse(course.course.endTime)+ 60*90*1000"
        >
          <img class="course-img" src="~@/public/asset/img/course/nam-sure-course.jpg" alt />
          <p
            class="desc nameSure mui-badge mui-badge-primary"
            @tap.stop="getNamSureCourse(course)"
          >点名确认课时</p>
        </div>
        <!--班组课程排定  但未到时间  不显示点名确认课时按钮-->
        <div v-else-if="course.course.businessType== 2 || course.course.businessType== 3">
          <img
            v-if="Date.parse(course.course.startTime)<Date.parse(new Date())"
            class="course-img"
            src="~@/public/asset/img/course/course-time-out.jpg"
            alt
          />
          <img
            v-if="Date.parse(course.course.startTime)>Date.parse(new Date())"
            class="course-img"
            src="~@/public/asset/img/course/course-no-start.jpg"
            alt
          />
          <p
            class="desc noneSure"
            v-if="Date.parse(course.course.startTime)<Date.parse(new Date())"
          >逾期，不可确认</p>
          <p
            class="desc noneSure"
            v-if="Date.parse(course.course.startTime)>Date.parse(new Date())"
          >未到确认时间</p>
        </div>
      </div>
      <!--已上未评价-->
      <div class="xd-course-code" v-else-if="slideType==2 && course.course.businessType !== 4">
        <div class="course-comment" :class="currentJobType==2?'mt':''">
          <i class="star"></i>
          <span class="link" v-if="currentJobType==3">我要评价</span>
          <span class="link" v-if="currentJobType==2">暂未评价</span>
        </div>
        <p class="desc" v-if="currentJobType==3">谈谈对课程的感受吧</p>
      </div>
      <!--已上已评价-->
      <div class="xd-course-code" v-else-if="slideType==3 && course.course.businessType !== 4">
        <!-- &&  peoples<=20 -->
        <!---->
        <div class="course-comment">
          <i class="star on"></i>
          <span class="link" v-if="currentJobType==3">课后评价</span>
          <span class="link" v-if="currentJobType==2">已评价</span>
        </div>
        <p class="desc">查看课程的评价</p>
      </div>
      <div
        class="xd-course-code"
        v-else-if="!course.course.isConfirmed && course.course.businessType == 4"
      >
        <!-- || peoples>20 -->
        <!---->
        <img class="course-img" src="~@/public/asset/img/course/ppts-sure-course.jpg" alt />
        <p class="desc noneSure">该课程可到PPTS端确认</p>
      </div>
      <div class="wrapper" v-show="course && course.course.businessType">
        <span
          class="inner-ribbon"
          v-if="course.course.businessType && (course.course.categoryType != 8 && course.course.categoryTypeName != '集团新产品')"
        >{{course.course.businessType | businessTypeSup}}</span>
         <!-- course.course.categoryTypeName !== '集团新产品'------- 加这个条件是因为教师返回课表数据无 categoryType字段-->
        <span v-else class="inner-ribbon" >{{course.course.businessType | businessTypeCat}}</span>
      </div>
    </div>
  </div>
</template>
<script>
import store from "@/store";
import * as types from "@/store/mutation-types";
import { loadUserInfo } from "@/api/common/common-api";
import { getHead } from "@/api/user/user-api";
import {
  CACHE_KEYS,
  ASSIGN_STATUS,
  COURSE_EVALUATE_SCORE_CONFIG as scoreConfig
} from "@/constants";
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/qrcode/jquery.qrcodeReview";
export default {
  data() {
    return {
      scoreConfig: scoreConfig,
      showOne: false,
      currentJobType: "",
      icons: []
    };
  },
  props: ["course", "infoImg"],
  mounted() {
    if (m2.cache.get("ppts-current-job")) {
      this.currentJobType = m2.cache.get("ppts-current-job").jobType;
    }
  },
  methods: {
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserIcons() {
      if (
        (this.course.customerIcons &&
          this.course.customerIcons.iconID &&
          this.courseType == 1) ||
        (this.course.teacherIcons &&
          this.course.teacherIcons.iconID &&
          this.courseType != 1)
      ) {
        var userIcons = this.$store.state.headList.slice() || [];

        let curIcon = null;
        if (userIcons && userIcons.length) {
          if (this.courseType == 1) {
            curIcon = userIcons.find(
              i => i.userID === this.course.customerIcons.userID
            );
          } else {
            curIcon = userIcons.find(
              i => i.userID === this.course.teacherIcons.userID
            );
          }
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          if (this.courseType == 1) {
            this.icons.push({
              userID: this.course.customerIcons.userID,
              imgData: curIcon.imgData
            });
          } else {
            this.icons.push({
              userID: this.course.teacherIcons.userID,
              imgData: curIcon.imgData
            });
          }
        } else {
          getHead(
            {
              iconID:
                this.courseType == 1
                  ? this.course.customerIcons.iconID
                  : this.course.teacherIcons.iconID
            },
            res => {
              let obj = {
                userID:
                  this.courseType == 1
                    ? this.course.customerIcons.userID
                    : this.course.teacherIcons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      }
    },
    toChangeSize(content, startTime, endTime) {
      mui.plusReady(() => {
        plus.nativeUI.showWaiting();
      });
      var $container = $("#showSizeCode");
      this.generateQRCode($container, content, startTime, endTime);
      var wrapBox = document.getElementsByClassName("rx-sign-code")[0];
      wrapBox.style.display = "block";
      if (wrapBox.style.display == "block") {
        mui.plusReady(() => {
          plus.nativeUI.closeWaiting();
        });
      }
    },
    generateQRCode(container, content, startTime, endTime) {
      $("#showSizeCode canvas").remove();
      container.qrcodeReview({
        render: "canvas", //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
        text: content, //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
        width: 220, //二维码的宽度
        height: 220, //二维码的高度
        startTime: startTime,
        endTime: endTime,
        background: "#ffffff", //二维码的后景色
        foreground: "#000000", //二维码的前景色 //二维码中间的图片
        /*src: '@/public/asset/img/user/boy.png',*/ correctLevel: 1
      });
    },
    goStudentDetail(course, type) {
      if (course.course.assignStatus == 1 || course.course.assignStatus == 8) {
        this.$router.push({
          name: "course-detail",
          query: {
            courseID: course.course.courseID,
            businessType: course.course.businessType,
            customerID: course.course.customerID,
            teacherID: course.course.teacherID,
            type: course.course.businessType == 1 ? 1 : 0,
            entry: type
          }
        });
      } else {
        if (this.showOne) {
          if (course.isEvaluate) {
            this.$router.push({
              name: "course-even-evaluate",
              query: {
                courseID: course.course.courseID,
                businessType: course.course.businessType,
                customerID: course.course.customerID,
                teacherID: course.course.teacherID,
                type: course.course.businessType == 1 ? 1 : 0
              }
            });
          } else {
            this.$router.push({
              name: "course-evaluate",
              query: {
                courseID: course.course.courseID,
                businessType: course.course.businessType,
                customerID: course.course.customerID,
                teacherID: course.course.teacherID,
                type: course.course.businessType == 1 ? 1 : 0
              }
            });
          }
        } else {
          this.$router.push({
            name: "course-other-evaluate",
            query: {
              courseID: course.course.courseID,
              businessType: course.course.businessType,
              customerID: course.course.customerID,
              teacherID: course.course.teacherID,
              type: course.course.businessType == 1 ? 1 : 0
            }
          });
        }
      }
    },
    getPsdSureCourse() {
      this.$router.push({
        name: "psdSureCourse",
        query: {
          lessonID: this.course.course.courseID,
          businessType: this.course.course.businessType,
          resultString: this.course.resultString
        }
      });
    },
    getNamSureCourse(course) {
      if (course.isLessonSign || this.showOne) {
        //学管师必须满足isLessonSign为true  this.showOne为true代表教师
        this.$router.push({
          name: "namSureCourse",
          query: {
            lessonID: this.course.course.courseID,
            businessType: this.course.course.businessType
          }
        });
      } else {
        this.goStudentDetail(course, "sureCourseBtn");
      }
    },
    getCourseItems(evaluate) {
      let a = evaluate;
      return [
        {
          key: "goal",
          title: "辅导目标",
          score: evaluate.goal || 0,
          desc: this.getScoreDesc(evaluate.goal)
        },
        {
          key: "attitude",
          title: "授课态度",
          score: evaluate.attitude || 0,
          desc: this.getScoreDesc(evaluate.attitude)
        },
        {
          key: "atmosphere",
          title: "课堂氛围",
          score: evaluate.atmosphere || 0,
          desc: this.getScoreDesc(evaluate.atmosphere)
        },
        {
          key: "logic",
          title: "逻辑严谨",
          score: evaluate.logic || 0,
          desc: this.getScoreDesc(evaluate.logic)
        },
        {
          key: "style",
          title: "形式新颖",
          score: evaluate.style || 0,
          desc: this.getScoreDesc(evaluate.style)
        }
      ];
    },
    getScoreDesc(val) {
      let config = scoreConfig.find(item => item.value == val);
      if (!config) return undefined;
      return config.desc;
    }
  },
  computed: {
    slideType() {
      console.log('course',this.course.isEvaluate)
      if (!this.course) return 0;
      else if (!this.course.course.isConfirmed) return 1;
      else if (this.course.course.isConfirmed && !this.course.isEvaluate)
        return 2;
      else if (this.course.course.isConfirmed && this.course.isEvaluate)
        return 3;
    },
    courseType() {
      if (this.course.course.businessType == "1") return 1;
      else if (this.course.course.businessType == "2") return 2;
    },
    // peoples() {
    //   const currentJobType = m2.cache.get("ppts-current-job").jobType;
    //   if (currentJobType == 3) {
    //     return this.course.course.peoples;
    //   } else {
    //     return this.course.peoples;
    //   }
    // },
    // isLessonSign() {
    //   const currentJobType = m2.cache.get("ppts-current-job").jobType;
    //   if (currentJobType == 2) {
    //     return this.course.isLessonSign;
    //   } else {
    //     return true;
    //   }
    // },
    items() {
      if (
        this.course.assignStatus == ASSIGN_STATUS.Confirmed &&
        this.course.evaluate
      ) {
        return this.getCourseItems(this.course.evaluate);
      }
    }
  },
  created() {
    loadUserInfo();
    if (m2.cache.get("ppts-current-job")) {
      const currentJobType = m2.cache.get("ppts-current-job").jobType;
      if (currentJobType == 3) {
        this.showOne = true;
      }
    }
  },
  watch: {
    course: {
      handler: function() {
        this.getUserIcons();
      },
      deep: true
    }
  }
};
</script>
<style lang="scss">
i.star {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/star.png) no-repeat;
  background-size: 100%;
  width: torem(12);
  height: torem(12);
}

i.star.on {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/staron.png) no-repeat;
  background-size: 100%;
  width: torem(12);
  height: torem(12);
}

.xd-course-list {
  width:  torem(290);
  height: torem(180);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: torem(20) torem(15) torem(15);
  background: rgba(255, 255, 255, 0.95);
  box-shadow: 0 2px 34px 0 rgba(125, 93, 39, 0.25);
  border-radius: 8px;
  margin: 5px auto 0;
  &.ribbon {
    display: inline-flex;
    position: relative;
    float: left;
    background-size: cover;
    text-transform: uppercase;
    color: #fff;
    .wrapper {
      width: 22%;
      height: torem(73);
      position: absolute;
      top: -8px;
      left: torem(232);
      overflow: hidden;
    }
    .wrapper:before {
      content: "";
      display: block;
      border-radius: 8px 8px 0px 0px;
      width: 20px;
      height: 8px;
      position: absolute;
      right: 50px;
      background: #4d6530;
    }
    .inner-ribbon {
      display: inline-block;
      text-align: center;
      width: torem(120);
      height: torem(20);
      line-height: 18px;
      position: absolute;
      top: 16px;
      text-indent: -8px;
      right: torem(-46);
      z-index: 2;
      overflow: hidden;
      transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      -moz-transform: rotate(45deg);
      -webkit-transform: rotate(45deg);
      -o-transform: rotate(45deg);
      border: 1px dashed;
      -webkit-box-shadow: 0 0 0 3px #00b3ed,
        0px 21px 5px -18px rgba(0, 0, 0, 0.6);
      box-shadow: 0 0 0 3px #00b3ed, 0px 21px 5px -18px rgba(0, 0, 0, 0.6);
      background: #00b3ed;
    }
    .wrapper:after {
      content: "";
      display: block;
      border-radius: 0px 8px 8px 0px;
      width: 8px;
      height: 20px;
      position: absolute;
      right: 0px;
      top: 50px;
      background: #4d6530;
    }
  }
}

.xd-course-overview {
  margin-top: 0;
  //margin-right: torem(15);
  float: left;
  width: torem(140);
  dl {
    display: flex;
    margin-bottom: torem(5);
    margin-top: torem(2);
    dt {
      width: torem(48);
      height: torem(48);
      margin-right: torem(12);
      overflow: hidden;
      img {
        width: 100%;
        height: 100%;
        border-radius: 100%;
      }
    }
    dd {
      display: flex;
      flex-direction: column;
      justify-content: center;
      flex: 1;
      b {
        @include letterStyle(14, #333, -0.33, 28);
        @include overHidden(1);
      }
      span {
        @include letterStyle(13, #666, -0.2, 18);
      }
    }
  }
  ul {
    margin-top: torem(10);
    .subjects {
      display: inline-block;
    }
    margin-left: torem(10);
    li {
      @include letterStyle(13, #666, -0.27, 23);
      span {
        display: inline-block;
      }
    }
  }
}

.xd-course-code {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: transparent;
  flex: 1;
  div {
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: column;
  }
  .qr-canvas {
    width: torem(120);
    height: torem(120);
    text-align: center;
    padding-top: 10%;
    margin-right: torem(10);
  }
  .desc {
    @include letterStyle(10, #808080, 2, 19);
    margin-bottom: torem(5) !important;
    text-align: center;
  }
  .scanSure {
    @include letterStyle(10, #808080, 2, 31);
    margin-top: torem(10);
    i {
      color: #808080;
      font-size: torem(18);
    }
  }
  .nonesure {
    @include letterStyle(10, #808080, 2, 31);
  }
  .nameSure {
    color: #fff;
    margin-top: torem(6);
  }
  .course-img {
    width: torem(130);
    height: torem(130);
    border-radius: 12px;
  }
  .course-comment {
    background: rgba(255, 255, 255, 0.89);
    -webkit-box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    border-radius: 12px;
    height: torem(120);
    /*padding-top: 25%;*/
    bottom: 0;
    width: torem(120);
    text-align: center;
    color: #999;
    .star {
      display: inline-block;
      text-align: center;
      width: torem(40);
      height: torem(40);
    }
    .link {
      display: block;
      margin-top: torem(5);
      color: #777;
    }
  }
}

.swiper-wrapper {
  display: flex;
  .swiper-slide {
    width: 86% !important;
    margin-left: 2.3333%;
    margin-top: 4px;
    margin-bottom: 25px;
  }
  .swiper-slide-next,
  .swiper-slide-prev {
    height: torem(171);
    .xd-course-list {
      height: torem(171);
      margin-top: torem(15);
    }
  }
}

.psdSure {
  color: #00b3ed;
}

.mt {
  margin-top: torem(10);
}
</style>
