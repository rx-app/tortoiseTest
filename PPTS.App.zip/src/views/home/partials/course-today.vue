﻿<template>
  <div class="xd-course-today" :class="courses.length<1 || courses.length==1 ? 'mt':''">
    <course-slide :course="0" :infoImg="customerInfosCourse" v-if="courses.length<1"/>
    <course-slide
      :course="courses[0]"
      :infoImg="customerInfosCourse"
      v-else-if="courses.length==1"
    />
    <template v-else>
      <swiper v-if="flag" :options="swiperOption">
        <swiper-slide v-for="(course, index) in courses" :key="index">
          <course-slide :course="course" :infoImg="customerInfosCourse"/>
        </swiper-slide>
        <div class="swiper-pagination" slot="pagination"></div>
      </swiper>
    </template>
  </div>
</template>
<script>
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/qrcode/jquery.qrcode";
import "swiper/dist/css/swiper.css";

import { swiper, swiperSlide } from "vue-awesome-swiper";
import courseSlide from "./course-slide";
export default {
  data() {
    return {
      flag: true
    };
  },
  props: ["courseList", "filterDay", "customerInfosCourse"],
  computed: {
    swiperOption() {
      return {
        pagination: {
          el: ".swiper-pagination"
        },
        initialSlide: this.getNearestCourse(this.courses),
        slidesPerView: "auto",
        centeredSlides: true,
        on: {
          slideChangeTransitionEnd: function() {
            courseTodayThis.$emit("activeIndex", this.activeIndex); //切换结束时，告诉我现在是第几个slide
          }
        },
        zoom: {
          maxRatio: 5, //最大倍数
          minRatio: 2, //最小倍数
          toggle: true, //不允许双击缩放，只允许手机端触摸缩放。
          containerClass: "my-zoom-container" //zoom container 类名
        }
      };
    },
    courses() {
      if (this.courseList === null) return [];
      console.log(this.courseList);
      return this.courseList;
    }
  },
  watch: {
    courses() {
      window.courseTodayThis = this;
      this.flag = false;
      setTimeout(() => {
        this.flag = true;
        this.$nextTick(() => {
        this.renderCourseQRCode();
        });
      }, 10);
    }
  },
  methods: {
    getNearestCourse(list) {
      if (!m2.date.isOneDay(list[0].course.startTime, new Date())) {
        return 0;
      }
      let times = [];
      list.forEach((v, i) => {
        times.push(v.course.startTime.getTime());
        times.push(v.course.endTime.getTime());
      });
      let now = Date.now();
      let newList = times.map(v => {
        return v - now;
      });
      // debugger
      let clone = [...newList];
      let res = newList.sort((a, b) => Math.abs(a) - Math.abs(b) || b - a)[0];
      let index = clone.indexOf(res);
      console.log(index);
      console.log(newList);
      // debugger
      return Math.ceil((index + 1) / 2) - 1;
    },
    generateQRCode(container, content) {
      var ele = document.getElementById(container);
      var $container = $("#" + container);
      $container.qrcode({
        render: "canvas", //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
        text: content, //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
        width: ele ? ele.offsetWidth : 0, //二维码的宽度
        height: ele ? ele.offsetHeight : 0, //二维码的高度
        background: "#ffffff", //二维码的后景色
        foreground: "#000000", //二维码的前景色
        //src: 'ppts.App/src/assets/photo.jpg', 二维码中间的图片
        correctLevel: 1
      });
    },
    renderCourseQRCode() {
      $("canvas").remove();
      this.courses.forEach(item => {
        this.generateQRCode(item.course.courseID, item.resultString);
      });
    }
  },
  components: {
    swiper,
    swiperSlide,
    courseSlide
  }
};
</script>
<style lang="scss">
.xd-course-today {
  margin-top: torem(23);
  background: transparent;
  height: 60vw;
  display: flex;
}

.mt {
  margin-bottom: torem(21);
}

.swiper-pagination-bullets {
  bottom: 0px !important;
}

.swiper-pagination-fraction,
.swiper-pagination-custom,
.swiper-container-horizontal > .swiper-pagination-bullets {
  display: flex;
  padding: 0 torem(10);
  justify-content: center;
}

.swiper-slide-prev {
  margin-left: 1.555% !important;
}

@media only screen and (max-width: 320px) {
  .ppts-course-today {
    margin-bottom: torem(20);
  }
}

.swiper-container-horizontal
  > .swiper-pagination-bullets
  .swiper-pagination-bullet {
  margin: 0 2px;
}

.swiper-pagination-bullet {
  width: torem(4);
  height: torem(4);
}

.swiper-pagination-bullet-active {
  width: torem(8);
  height: torem(8);
  margin-top: torem(-2) !important;
}
</style>