<template>
  <div class="bg padding-10 margin-v-10">
    <p style="text-align: center;">休息一下，明天再来。</p>
  </div>
</template>
<script>

</script>
<style scoped>
  
</style>
