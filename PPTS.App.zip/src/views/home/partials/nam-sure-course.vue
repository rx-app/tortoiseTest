<template>
  <div class="wrap">
    <div class="course-mess">
      <p class="course-title">确认课时内容如下</p>
      <p>
        <span class="dateMonth">{{courseMess.startTime | dateFormat({locale: 'zh-CN'})}}</span>
        <span
          class="dateTime"
        >{{courseMess.startTime | timeRange(courseMess.endTime, {locale: 'zh-CN'})}}</span>
      </p>
      <div class="course">
        <p>
          <span>科目 :</span>
          <span>{{courseMess.subjectName}}</span>
        </p>
        <p>
          <span>老师 :</span>
          <span>{{courseMess.teacherName}}</span>
        </p>
      </div>
      <p class="customerNameList" ref="customerNameList">
        <span>学员 :</span>
        <span
          v-for="(item,index) in studentCheckList"
          :key="index"
          class="customerName"
        >{{item.customerName}}</span>
      </p>
      <div class="customerShowFlag" v-if="studentList.length>20">
        <p v-if="!customerShowFlag" @click="customerShowFun('all')">
          <i></i>
          <span>点击查看</span>
        </p>
        <p v-if="customerShowFlag" @click="customerShowFun('area')">
          <i></i>
          <span>点击收起</span>
        </p>
      </div>
    </div>
    <div class="psdSure">
      <div class="title">
        <span>点击学员姓名，确认课时</span>
        <span class="allBtn">全员到齐</span>
        <div
          class="mui-switch"
          :class="[status?'mui-active':'',businessType == 3?'mui-disabled':'']"
          @click="allCheck()"
        >
          <div class="mui-switch-handle" ref="handle"></div>
        </div>
        <!--<button class="btn btn-default shiny" @click="allCheck()" type="button">></button-->
      </div>
      <div class="surePsd">
        <button
          class="nameBtn"
          @click="addType(item.customerID)"
          v-for="(item,index) in studentShowList"
          :class="{'btn-checked':item.current }"
          :key="index"
        >
          <p>
            <span class="customerName">{{item.customerName}}</span>
            <span class="parentPhone">({{item.parentPhone}})</span>
          </p>
        </button>
      </div>
      <div class="showCustomerTit">
        <!-- <p>本节班组课共有{{studentList.length}}名学生。</p> -->
        <!-- 当前显示第 -->
        <!-- <p class="btn" @click="changePagesFun('cut')">-</p> -->
        <i class="iconfont icon-del" @click="changePagesFun('cut')"></i>
        <p class="inp">
          第
          <input type="text" v-model="showPages" />页
        </p>
        <i class="iconfont icon-addBorder" @click="changePagesFun('add')"></i>
        <!-- <p class="btn" @click="changePagesFun('add')">+</p> -->
        <!-- 页，每页最多显示20名学生，共有{{Math.ceil(studentList.length/20)}}页。 -->
      </div>
      <button class="sureBtn" @click="sureCourse()" :disabled="btnStatus">确认签到</button>
    </div>
  </div>
</template>

<script>
import {
  getLessonInfo,
  getCustomerListByLessonID,
  confirmForClassGroup,
  confirmForOneToMore,
  getCustomerListByGroupID
} from "@/api/course/course-api";
export default {
  data() {
    return {
      customerShowFlag: false,
      showPages: 1,
      isshow: true,
      btnStatus: false,
      studentList: [],
      studentShowList: [],
      courseMess: {},
      status: false,
      showOne: false
    };
  },
  methods: {
    customerShowFun(str) {
      if (str == "all") {
        this.$refs.customerNameList.style.maxHeight = "none";
        this.customerShowFlag = true;
      } else if (str == "area") {
        this.$refs.customerNameList.style.maxHeight = 55 + "px";
        this.customerShowFlag = false;
      }
    },
    changePagesFun(str) {
      if (
        (str == "cut" && this.showPages <= 1) ||
        (str == "add" &&
          this.showPages >= Math.ceil(this.studentList.length / 20))
      ) {
        return;
      }
      if (str == "cut") {
        this.showPages = --this.showPages;
      } else if (str == "add") {
        this.showPages = ++this.showPages;
      }
    },
    goStudentDetail() {
      if (this.showOne) {
        this.$router.replace({
          name: "course-evaluate",
          query: {
            courseID: this.lessonID,
            businessType: this.businessType,
            type: this.businessType == 1 ? 1 : 0
          }
        });
      } else {
        this.$router.replace({
          name: "course-other-evaluate",
          query: {
            courseID: this.lessonID,
            businessType: this.businessType,
            type: this.businessType == 1 ? 1 : 0
          }
        });
      }
    },
    //切换学员是否选中状态
    addType(status) {
      if (this.businessType == 3) {
        return;
      }
      for (var i = 0; i < this.studentCheckList.length; i++) {
        if (this.studentCheckList[i].customerID == status) {
          let obj = this.studentCheckList[i];
          obj.current = !obj.current;
          this.$set(this.studentCheckList, i, obj);
        }
      }
    },
    //设置全选 全不选  按钮
    allCheck() {
      if (this.businessType == 3) {
        return;
      }
      this.settingStatus();
    },
    settingStatus() {
      for (var i = 0; i < this.studentCheckList.length; i++) {
        let obj = this.studentCheckList[i];
        obj.current = this.statusCheck;
        this.$set(this.studentCheckList, i, obj);
      }
      this.status = !this.status;
    },
    //切换学员框显示隐藏
    toggle() {
      this.isshow = !this.isshow;
    },
    //确认课时
    sureCourse() {
      if (
        !this.studentCheckList.some(item => {
          return item.current;
        })
      ) {
        mui.alert("至少选择一名学员才能确认课时！", "提示");
      } else {
        this.confirmGroup();
      }
    },
    confirmGroup() {
      mui.confirm(
        "点名后,该课时变成已上状态不能修改，是否继续确认？",
        "提示",
        e => {
          if (e.index) {
            if (this.businessType == 2) {
              //常规班组点名确认课时
              var criteria = {
                lessonID: this.lessonID,
                ConfirmCustomerID: []
              };
              this.studentCheckList.forEach(item => {
                if (item.current) {
                  criteria.ConfirmCustomerID.push(item.customerID);
                }
              });
              confirmForClassGroup(criteria, res => {
                if (res == "") {
                  this.btnStatus = true;
                  mui.alert("课表确认成功！");
                  this.$nextTick(() => {
                    this.goStudentDetail();
                  });
                }
              });
            } else {
              //一对多点名确认课时
              var criteria = {
                groupID: this.lessonID,
                ConfirmCustomerID: []
              };
              this.studentCheckList.forEach(item => {
                if (item.current) {
                  criteria.ConfirmCustomerID.push(item.customerID);
                }
              });
              confirmForOneToMore(criteria, res => {
                if (res == "") {
                  this.btnStatus = true;
                  mui.alert("课表确认成功！");
                  this.$nextTick(() => {
                    this.goStudentDetail();
                  });
                }
              });
            }
          }
        }
      );
    }
  },
  computed: {
    lessonID() {
      return this.$route.query.lessonID;
    },
    businessType() {
      return this.$route.query.businessType;
    },
    studentCheckList() {
      if (this.businessType == 3) {
        for (var i = 0; i < this.studentList.length; i++) {
          let obj = this.studentList[i];
          if (this.businessType == 3) {
            obj.current = true;
          } else {
            obj.current = false;
          }
          this.$set(this.studentList, i, obj);
        }
      } else {
        this.studentList.forEach(item => {
          item = Object.assign({}, item, {
            current: false
          });
        });
      }
      this.studentShowList = this.studentList.slice(
        (this.showPages - 1) * 20,
        (this.showPages - 1) * 20 + 20
      );
      return this.studentList;
    },
    statusCheck() {
      return !this.status;
    }
  },
  watch: {
    showPages() {
      if (this.showPages >= Math.ceil(this.studentList.length / 20)) {
        this.showPages = Math.ceil(this.studentList.length / 20);
      }
      this.studentShowList = this.studentList.slice(
        (this.showPages - 1) * 20,
        (this.showPages - 1) * 20 + 20
      );
    },
    studentCheckList: {
      handler: function(obj) {
        var countTrue = 0,
          countFalse = 0;
        obj.forEach(item => {
          if (item.current) {
            countTrue++;
          } else {
            countFalse++;
          }
        });
        if (obj.length == countTrue) {
          this.status = true;
          this.$refs.handle.style.transform = "translate(43px, 0px)";
        }
        if (countFalse >= 1) {
          this.status = false;
          this.$refs.handle.style.transform = "translate(0px, 0px)";
        }
      },
      deep: true
    }
  },
  mounted() {
    mui(".mui-switch")["switch"]();
  },
  created() {
    if (this.businessType == 2) {
      getCustomerListByLessonID(this.lessonID, res => {
        this.studentList = res.customers;
      });
    } else {
      getCustomerListByGroupID(this.lessonID, res => {
        this.studentList = res.customers;
      });
    }

    getLessonInfo(
      {
        courseID: this.lessonID,
        businessType: this.businessType
      },
      res => {
        this.courseMess = res.lessonInfo;
      }
    );
    const currentJobType = m2.cache.get("ppts-current-job").jobType;
    if (currentJobType == 3) {
      this.showOne = true;
    }
  }
};
</script>

<style lang="scss" scoped>
.wrap {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  bottom: 0;
  background-color: #f9f9fb;
}

.course-mess {
  width: 90%;
  margin-left: 5%;
  /*height: torem(153);*/
  background-color: #fff;
  margin-top: torem(15);
  box-shadow: 0 2px 4px 0 rgba(148, 148, 148, 0.25);
  border: 1px solid #eee;
  border-radius: 10px;
  padding: torem(10);
  .course-title {
    border-bottom: 1px dotted #dedede;
    padding-bottom: torem(10);
  }
  .course {
    display: flex;
    justify-content: space-between;
    padding-right: 40px;
  }
  .customerName {
    margin-right: torem(10);
  }
  .customerNameList {
    max-height: 55px;
    overflow: hidden;
  }
  .customerShowFlag {
    text-align: center;
    color: skyblue;
    p {
      margin-bottom: 0;
      line-height: 28px;
    }
  }
}

.psdSure {
  width: torem(355);
  /*height: torem(320);*/
  width: 90%;
  margin-left: 5%;
  margin-top: torem(15);
  background: #ffffff;
  box-shadow: 0 2px 4px 0 rgba(148, 148, 148, 0.25);
  border-radius: 4px;
  padding: torem(10);
  .title {
    display: flex;
    align-items: center;
    border-bottom: 1px dotted #dedede;
    padding-bottom: torem(10);
    span {
      margin-right: torem(40);
    }
    .allBtn {
      margin-right: torem(10);
    }
    .mui-switch {
      display: inline-block;
    }
    .mui-switch.mui-disabled {
      opacity: 0.9;
    }
  }
  .showCustomerTit {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: torem(15);
    .iconfont {
      color: orange;
      font-size: torem(24);
    }
    .inp {
      width: torem(140);
      height: 30px;
      margin: 5px 10px;
      display: inline-block;
      text-align: center;
      input {
        width: 50%;
        height: 100%;
        margin-bottom: 0;
        padding: 0;
        text-align: center;
        margin: 0 6px;
      }
    }
  }
  .surePsd {
    .nameBtn {
      margin-left: torem(15);
      margin-right: torem(15);
      margin-top: torem(10);
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      -webkit-tap-highlight-color: transparent;
      width: 38%;
      p {
        margin-bottom: 0;
        display: flex;
        align-items: center;
        color: #333;
      }
      .parentPhone {
        margin-left: 3px;
      }
      .customerName {
        overflow: hidden;
        text-overflow: ellipsis; //文本溢出显示省略号
        white-space: nowrap; //文本不会换行（单行文本溢出）
        display: inline-block;
        width: 65%;
      }
    }
    .btn-checked p {
      color: #fff;
    }
  }
}

.btn-checked {
  background-image: linear-gradient(-90deg, #ff9900 0%, #ffb82a 100%);
  border-radius: 4px;
  color: #fff !important;
}

.sureBtn {
  width: 90%;
  margin-left: 5%;
  margin-top: torem(60);
  height: torem(40);
  border: none;
  background-image: linear-gradient(-90deg, #ff9900 0%, #ffb82a 100%);
  border-radius: 100px;
  color: #fff;
}
</style>