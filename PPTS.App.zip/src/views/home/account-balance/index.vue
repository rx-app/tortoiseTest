<template>
  <div class="list-area">
    <div class="hed">
      <div>
        <span class="tit">有效学员账户不足1000元</span>
      </div>
    </div>
    <tip v-if="!acountLessStudents.length" class="todayCourseList tip">
      <span>暂无有效学员账户不足1000元</span>
    </tip>
    <div class="todayCourseList" v-else>
      <div>
        <div v-for="(item,index) in acountLessStudents" class="list" :key="index">
          <div class="head">
            <div class="img mr33">
              <span v-if="item.customerIcons" class="mui-media-object mui-pull-left">
                <img v-if="item.customerIcons.iconID" :src="getIconImg(item.customerIcons.userID)">
                <img
                  v-else-if="item.customerIcons.gender==2"
                  src="~@/public/asset/img/user/girl.png"
                  alt
                >
                <img v-else src="~@/public/asset/img/user/boy.png" alt>
              </span>
              <img v-else src="~@/public/asset/img/user/boy.png" alt>
            </div>
            <a :href="'tel:'+item.parentPrimaryPhoneNumber">
              <i class="iconfont icon-phone"></i>
            </a>
          </div>
          <p>
            <span
              class="cusName-4-down cusName"
              v-if="item.customerName.length<=4"
            >{{item.customerName}}</span>
            <span class="cusName-4-up cusName" v-else>{{item.customerName}}</span>
            <span v-html="getPhone(item.parentPrimaryPhoneNumber)"></span>
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import { getAllStudents } from "@/api/customer/customer-api";
import { pager, orderBy } from "@/public/constant";
import Tip from "@/components/tip";
export default {
  props:['acountLessStudents'],
  data() {
    return {
      icons: [],
      isGetCustomerIDs: true,
      customerIDs: [],
    };
  },
  created() {
    this.customerIDsFun();
  },
  methods: {
    customerIDsFun() {
      if (this.acountLessStudents.length) {
        this.acountLessStudents.forEach(item => {
          var curStudent = {
            type: "2",
            userID: item.customerID
          };
          if (
            JSON.stringify(this.customerIDs).indexOf(
              JSON.stringify(curStudent)
            ) == -1
          ) {
            this.customerIDs.push(curStudent);
          }
        });
      }
    },
    getPhone(phone) {
      if (!phone) return;
      var zero = phone.substr(7);
      return "(" + zero + ")";
    },
    relishCustomerIDs() {
      if (this.customerIDs.length && this.isGetCustomerIDs) {
        this.isGetCustomerIDs = false;
        getHeadIDsByUserIDs(this.customerIDs, res => {
          this.acountLessStudents.forEach(item => {
            res.forEach(sel => {
              if (item.customerID == sel.userID) {
                this.$set(item, "customerIcons", sel);
              }
            });
          });
        });
      }
    },
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserCustomerIcons() {
      this.acountLessStudents.forEach(item => {
        if (!item.customerIcons || !item.customerIcons.iconID) return;
        var userIcons = this.$store.state.headList.slice() || [];
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === item.customerIcons.userID);
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: item.customerIcons.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: item.customerIcons.iconID
            },
            res => {
              let obj = {
                userID: item.customerIcons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      });
    }
  },
  watch: {
    customerIDs() {
      this.relishCustomerIDs();
    },
    acountLessStudents() {
      if (this.acountLessStudents.length) {
        this.getUserCustomerIcons();
      }
    }
  },
  components: {
    Tip
  }
};
</script>
<style lang="scss" scoped>
.todayCourse .hed span {
  margin-left: torem(15);
}
</style>
