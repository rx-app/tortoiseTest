<template>
  <div id="stu-main-content" class="xd-home">
    <mt-loadmore
      class="loadMore"
      :bottom-status.sync="bottomStatus"
      :auto-fill="false"
      :bottom-distance="-70"
      :bottom-all-loaded="allLoaded"
      :top-method="loadTop"
      :bottom-method="loadBottom"
      ref="loadmore"
    >
      <div slot="bottom" class="mint-loadmore-bottom">
        <span
          v-show="bottomStatus !== 'loading'"
          :class="{ 'rotate': bottomStatus === 'drop' }"
        >让手指休息一下，看看其他~~</span>
        <span v-show="bottomStatus === 'loading'">让手指休息一下，看看其他~~</span>
      </div>
      <!-- 新增潜客 -->
      <guest-slide
        v-power="['睿学-新增潜客']"
        v-if="jobType !== 2"
        :PotentialCustomers="PotentialCustomers"
      ></guest-slide>
      <!--今日课表-->
      <course-today
        :courseList="courseList"
        :customerInfosCourse="customerInfosCourse"
        :filterDay="filterDay"
        @activeIndex="activeIndex"
        v-power="['睿学-确认课时']"
      />
      <!--课表日历-->
      <course-calendar
        @switchDay="switchDay"
        @switchMonth="switchMonth"
        :markArray="markArray"
        :resetMonth="resetMonth"
        v-power="['睿学-确认课时']"
      />
      <div id="add-guest" v-power="['睿学-新增潜客']" v-if="jobType == 2">
        <router-link class="add-guest" tag="button" :to="{name:'addGuest'}">
          新增潜客
          <i class="iconfont icon-double-right"></i>
        </router-link>
      </div>
      <!--提示-->
      <!--<home-tip/>-->
      <!--首页页脚-->
      <!--<home-footer/>-->
      <div class="todayCourse">
        <account-balance v-if="jobType == 2" :acountLessStudents="acountLessStudents"></account-balance>
        <div v-power="['睿学-教师课表']" v-if="isFullTime" class="list-area">
          <div class="hed">
            <div>
              <p>
                <img src="~@/public/asset/img/home/today-teach.png" alt />
              </p>
              <span class="tit">今日上课教师</span>
            </div>
            <router-link :to="{name:'course'}" class="more" tag="p">查看更多</router-link>
          </div>
          <tip v-if="!teachTodayCourse.length" class="todayCourseList tip">
            <span>暂无今日上课教师</span>
          </tip>
          <div class="todayCourseList" v-else>
            <div>
              <div v-for="(item,index) in teachTodayCourse" class="list" :key="index">
                <div class="head">
                  <div class="img mr33">
                    <span v-if="item.teacherIcons" class="mui-media-object mui-pull-left">
                      <img
                        v-if="item.teacherIcons.iconID"
                        :src="getIconImg(item.teacherIcons.userID)"
                      />
                      <img
                        v-else-if="item.teacherIcons.gender==2"
                        src="~@/public/asset/img/user/teacher-woman.png"
                        alt
                      />
                      <img v-else src="~@/public/asset/img/user/teacher-man.png" alt />
                    </span>
                    <img v-else src="~@/public/asset/img/user/teacher-man.png" alt />
                  </div>
                  <a :href="'tel:'+item.phoneNumber">
                    <i class="iconfont icon-phone"></i>
                  </a>
                </div>
                <p>
                  <span
                    class="cusName-4-down cusName"
                    v-if="item.teacherName.length<=4"
                  >{{item.teacherName}}</span>
                  <span class="cusName-4-up cusName" v-else>{{item.teacherName}}</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div v-power="['睿学-学员课表']" v-if="isFullTime" class="list-area">
          <div class="hed">
            <div>
              <p>
                <img src="~@/public/asset/img/home/today-student.png" alt />
              </p>
              <span class="tit">今日上课学员</span>
            </div>
            <router-link :to="{name:'customer'}" class="more" tag="p">查看更多</router-link>
          </div>
          <tip v-if="!studentTodayCourse.length" class="todayCourseList tip">
            <span>暂无今日上课学员</span>
          </tip>
          <div class="todayCourseList" v-else>
            <div>
              <div v-for="(item,index) in studentTodayCourse" class="list" :key="index">
                <div class="head">
                  <div class="img" :class="jobType==2?'mr33':''">
                    <span v-if="item.customerIcons" class="mui-media-object mui-pull-left">
                      <img
                        v-if="item.customerIcons.iconID"
                        :src="getIconImg(item.customerIcons.userID)"
                      />
                      <img
                        v-else-if="item.customerIcons.gender==2"
                        src="~@/public/asset/img/user/girl.png"
                        alt
                      />
                      <img v-else src="~@/public/asset/img/user/boy.png" alt />
                    </span>
                    <img v-else src="~@/public/asset/img/user/boy.png" alt />
                  </div>
                  <a :href="'tel:'+item.parentPhone" v-power="['睿学-联系家长']">
                    <i class="iconfont icon-phone"></i>
                  </a>
                </div>
                <p>
                  <span
                    class="cusName-4-down cusName"
                    v-if="item.customerName.length<=4"
                  >{{item.customerName}}</span>
                  <span class="cusName-4-up cusName" v-else>{{item.customerName}}</span>
                  <span v-html="getPhone(item.parentPhone)"></span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <xueda-news></xueda-news>
      <class-break></class-break>
    </mt-loadmore>
  </div>
</template>
<script>
import store from "@/store";
import * as types from "@/store/mutation-types";
import { ACTION_TYPES, ASSIGN_STATUS } from "@/constants";
import { pager, orderBy } from "@/public/constant";
import {
  getTeacherCourses,
  getScopeTeacherCourse,
  monitorConfirmAsset
} from "@/api/course/course-api";
import {
  loadUserInfo,
  getCurrentJob,
  getUserId,
  getUserLoginName
} from "@/api/common/common-api";
import {
  getTodayHasCourseCustomers,
  getScopeAssignList,
  getScopeEveryDayTopOneAssign,
  randomPotentialCustomer,
  getAllStudents
} from "@/api/customer/customer-api";
import { getTodayHasCourseTeachers } from "@/api/teacher/teacher-api";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import CourseToday from "./partials/course-today";
import GuestSlide from "./partials/guest-slide";
import CourseCalendar from "./partials/course-calendar";
import HomeTip from "./partials/home-tip";
import ClassBreak from "./partials/class-break";
import XuedaNews from "./partials/xueda-news";
import Tip from "@/components/tip";
import AccountBalance from "./account-balance/index.vue";
//import HomeFooter from './partials/home-footer'

export default {
  data() {
    return {
      courseList: [],
      courseArray: [],
      markArray: [],
      PotentialCustomers: [], //咨询师登录存储 潜客轮播数据
      acountLessStudents: [], //学管师登录存储 账户不足一千元学员
      filterDay: m2.date.today(),
      today: m2.date.today(),
      currentIndex: 0,
      pageIndex: 1,
      pageSize: 10,
      teacherInfos: [],
      customerInfos: [],
      customerInfosCourse: [],
      teachTodayCourse: [],
      studentTodayCourse: [],
      customerIDs: [],
      teacherIDs: [],
      isFullTime: true,
      allLoaded: false,
      isDrop: false,
      jobType: getCurrentJob().jobType,
      icons: [],
      lessParams: {
        validCustomer: true,
        accountAmountEnd: 1000,
        ...pager({
          pageIndex: 0,
          pageSize: 0
        }),
        ...orderBy({
          dataField: "accountMoney",
          sortDirection: 0
        })
      },
      resetMonth: undefined // 用于下拉刷新、跨月时重置日历选中日期
    };
  },
  created() {
    xdapp.util.aiUtil.seting();
    console.log("home",3)
    this.getPermionLoad();
    this.switchJob();
    this.$staffHub.ensureConnection();
    this.$staffHub.$on("confirmStudentCourse", res => {
      //hub推送消息 判断登录名称以及当前岗位是否是教师或学管师（避免推送过来之前用户切换岗位）
      if (
        res.target == getUserLoginName() &&
        (getCurrentJob().jobType == 2 || getCurrentJob().jobType == 3)
      ) {
        this.pulldownRefresh();
      }
    });
    this.$staffHub.$on("signalr-closed", res => {
      //监测hub关闭重新开启轮询
      if (!res) {
        this.pollConfirmCourse();
      }
    });
    // plus.webview.currentWebview.setStyle({'top':'0px'});
  },
  mounted() {
    mui.plusReady(function () {
      plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
    })
    this.setHeight();
    if (m2.cache.get("ppts-current-job")) {
      this.isFullTime = m2.cache.get("ppts-current-job").isFullTime;
    }
    if (window.xdapp.scan) {
      window.xdapp.scan.close();
    }
  },
  activated() {
    this.setHeight();
  },
  beforeDestroy() {
    this.clearTimeoutFun();
  },
  watch: {
    currentIndex() {
      console.log("currentIndex", this.currentIndex);
      this.confirmDta();
    },
    courseList() {
      this.confirmDta();
      this.relishAgin();
    },
    studentTodayCourse() {
      this.getUserCustomerIcons();
    },
    teachTodayCourse() {
      this.getUserTeacherIcons();
    }
  },
  methods: {
    relishAgin() {
      /*传给子元素课表里学生ID 教师ID提取出来*/
      if (this.courseList.length) {
        this.courseList.forEach(item => {
          var curStudent = {
            type: "2",
            userID: item.course.customerID
          };
          var curTeach = {
            type: "1",
            userID: item.course.teacherID
          };
          if (
            JSON.stringify(this.customerIDs).indexOf(
              JSON.stringify(curStudent)
            ) == -1
          ) {
            this.customerIDs.push(curStudent);
          }
          if (
            JSON.stringify(this.teacherIDs).indexOf(JSON.stringify(curTeach)) ==
            -1
          ) {
            this.teacherIDs.push(curTeach);
          }
        });
      }
      if (this.studentTodayCourse.length) {
        this.studentTodayCourse.forEach(item => {
          var curStudent = {
            type: "2",
            userID: item.customerID
          };
          if (
            JSON.stringify(this.customerIDs).indexOf(
              JSON.stringify(curStudent)
            ) == -1
          ) {
            this.customerIDs.push(curStudent);
          }
        });
      }
      if (this.teachTodayCourse.length) {
        this.teachTodayCourse.forEach(item => {
          var curTeach = {
            type: "1",
            userID: item.teacherID
          };
          if (
            JSON.stringify(this.teacherIDs).indexOf(JSON.stringify(curTeach)) ==
            -1
          ) {
            this.teacherIDs.push(curTeach);
          }
        });
      }
      this.relishCusAddTeaIDs();
    },
    relishCusAddTeaIDs() {
      var cusAddTeaIDs = [...this.customerIDs, ...this.teacherIDs];
      if (cusAddTeaIDs.length) {
        getHeadIDsByUserIDs(cusAddTeaIDs, res => {
          this.courseList.forEach(item => {
            res.forEach(sel => {
              if (item.course.customerID == sel.userID) {
                this.$set(item, "customerIcons", sel);
              }
              if (item.course.teacherID == sel.userID) {
                this.$set(item, "teacherIcons", sel);
              }
            });
          });
          this.studentTodayCourse.forEach(item => {
            res.forEach(sel => {
              if (item.customerID == sel.userID) {
                this.$set(item, "customerIcons", sel);
              }
            });
          });
          this.teachTodayCourse.forEach(item => {
            res.forEach(sel => {
              if (item.teacherID == sel.userID) {
                this.$set(item, "teacherIcons", sel);
              }
            });
          });
        });
      }
    },
    confirmDta() {
      if (this.courseList === null) return;
      if (!this.courseList.length) return;
      var currentDate = this.courseList[0].course.startTime;
      if (m2.date.isToday(currentDate)) {
        this.clearTimeoutFun();
        this.pollConfirmCourse();
      } else {
        this.clearTimeoutFun();
      }
    },
    activeIndex: function(currentIndex) {
      this.currentIndex = currentIndex;
    },
    //下拉刷新  初始化加载
    loadTop(e) {
      if (this.jobType !== 2 && this.jobType !== 3) {
        this.PotentialRefresh();
        this.$refs.loadmore.onTopLoaded();
        return;
      }
      event.preventdefault;
      event.stopPropagation();
      this.pulldownRefresh();
      this.isDrop = false;
      this.$refs.loadmore.onTopLoaded(); //刷新完重新定位
    },
    loadBottom() {
      this.$refs.loadmore.onBottomLoaded();
    },
    bottomStatus() {
      console.log("上拉状态");
    },
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserCustomerIcons() {
      this.studentTodayCourse.forEach(item => {
        if (!item.customerIcons || !item.customerIcons.iconID) return;
        var userIcons = this.$store.state.headList.slice() || [];
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === item.customerIcons.userID);
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: item.customerIcons.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: item.customerIcons.iconID
            },
            res => {
              let obj = {
                userID: item.customerIcons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      });
    },
    getUserTeacherIcons() {
      this.teachTodayCourse.forEach(item => {
        if (!item.teacherIcons || !item.teacherIcons.iconID) return;
        var userIcons = this.$store.state.headList.slice() || [];
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === item.teacherIcons.userID);
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: item.teacherIcons.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: item.teacherIcons.iconID
            },
            res => {
              let obj = {
                userID: item.teacherIcons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      });
    },
    getPhone(phone) {
      if (!phone) return;
      var zero = phone.substr(7);
      return "(" + zero + ")";
    },
    async getPermionLoad() {
      await loadUserInfo("upd");
      if (m2.util.getPermionLoad("睿学-学员课表") && this.isFullTime) {
        this.getstudentTodayCourseList();
      }
      if (m2.util.getPermionLoad("睿学-教师课表") && this.isFullTime) {
        this.getTodayHasCourseTeachers();
      }
      if (m2.util.getPermionLoad("睿学-确认课时")) {
        this.getCourse();
      }
      if (m2.util.getPermionLoad("睿学-新增潜客")) {
        randomPotentialCustomer({}, res => {
          this.PotentialCustomers = res;
        });
      }
      if (this.jobType == 2) {
        getAllStudents(this.lessParams, res => {
          this.acountLessStudents = res.queryResult.pagedData.slice(0, 30);
        });
      }
    },
    switchJob() {
      // 订阅切换岗位事件
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getPermionLoad);
    },
    //获取岗位下今日上课教师
    async getTodayHasCourseTeachers() {
      await loadUserInfo();

      let params = {
        StartTimeBegin: m2.date.today(),
        StartTimeEnd: m2.date.today()
      };
      getTodayHasCourseTeachers(params, res => {
        if (res.teachers === null) return;
        this.teacherInfos = res.teacherInfos;
        this.teachTodayCourse = res.teachers;
      });
    },
    //获取岗位下今日上课学员
    async getstudentTodayCourseList() {
      await loadUserInfo();

      let params = {
        CustomerName: "",
        startDateBegin: m2.date.today(),
        startDateEnd: m2.date.today(),
        ...pager({
          pageIndex: 1,
          pageSize: 10
        })
      };
      getTodayHasCourseCustomers(params, res => {
        if (res.queryResult.pagedData === null) return;
        this.customerInfos = res.customerInfos;
        this.studentTodayCourse = res.queryResult.pagedData.slice(0, 9);
      });
    },
    async getData(startTime, endTime, callback) {
      await loadUserInfo();
      const criteria = {
        TeacherID: getUserId(), //getCurrentJob().id,
        startTimeBegin: startTime,
        startTimeEnd: endTime,
        ...orderBy({
          dataField: "startTime",
          sortDirection: 0
        }),
        //assignStatus: [ASSIGN_STATUS.Assigned, ASSIGN_STATUS.Confirmed],
        ...pager({
          pageIndex: 0,
          pageSize: 0
        })
      };
      const criteria1 = {
        startTimeBegin: startTime,
        startTimeEnd: endTime,
        ...orderBy({
          dataField: "startTime",
          sortDirection: 0
        }),
        //assignStatus: [ASSIGN_STATUS.Assigned, ASSIGN_STATUS.Confirmed],
        ...pager({
          pageIndex: 0,
          pageSize: 0
        })
      };
      if (this.jobType == 3) {
        getTeacherCourses(criteria, res => {
          console.log("c", res);
          this.courseArray = this.less0People(
            res.queryResult.pagedData,
            this.jobType
          );
          this.customerInfosCourse = res.customerInfos;
          if (callback) callback();
        });
      } else {
        getScopeEveryDayTopOneAssign(criteria1, res => {
          this.courseArray = this.less0People(
            res.queryEncryptorResult.pagedData,
            this.jobType
          );
          this.customerInfosCourse = res.customerInfos;
          if (callback) callback();
        });
      }
    },
    getCourse() {
      this.getData(m2.date.firstDay("m"), m2.date.endDay("m"), () => {
        this.filterCourseList(this.courseArray, this.today);
        this.filterMarkArray(this.courseArray);
      });
    },
    //轮循  检测是否有确认课时未更新
    pollConfirmCourse() {
      console.log("*********$staffHub.connected***********");
      console.log(this.$staffHub.connected);
      if (this.$staffHub.connected) return;
      var currentList = this.courseList[this.currentIndex];
      if (
        currentList.course.assignStatus == 1 &&
        currentList.course.businessType == 1 &&
        m2.date.isSureCourse(
          currentList.course.startTime,
          currentList.course.endTime
        )
      ) {
        var params = {
          AssignID: currentList.course.courseID
        };
        this.setTimeOut(params, currentList);
      }
    },
    setTimeOut(params, currentList) {
      this.interval = setTimeout(() => {
        mui.loading = false;
        monitorConfirmAsset(params, res => {
          if (
            res.isSuccess &&
            res.hasData &&
            currentList.course.courseID == res.data.assignID
          ) {
            this.pulldownRefresh();
            return;
          }
          this.setTimeOut(params, currentList);
        });
      }, 6000);
    },
    clearTimeoutFun() {
      if (this.interval) {
        clearTimeout(this.interval);
        mui.loading = true;
      }
    },
    switchDay(targetDay) {
      console.log(targetDay + "11");
      /*this.isGetTeacherIDs = true;
				this.isGetCustomerIDs = true;*/
      /*if(m2.date.isEqual(targetDay, this.filterDay))
					return;*/
      // 同月份直接筛选课表 不同月份重新请求
      if (m2.date.isOneMonth(targetDay, this.filterDay)) {
        if (
          m2.date.firstDay("m", targetDay).getTime() == targetDay.getTime() ||
          m2.date.endDay("m", targetDay).getTime() == targetDay.getTime() ||
          this.today.getTime() == targetDay.getTime() ||
          this.jobType == "3"
        ) {
          this.filterCourseList(this.courseArray, targetDay);
          this.filterMarkArray(this.courseArray);
          return;
        }
        const criteria1 = {
          startTimeBegin: targetDay,
          startTimeEnd: targetDay,
          ...orderBy({
            dataField: "startTime",
            sortDirection: 0
          }),
          ...pager({
            pageIndex: 0,
            pageSize: 0
          })
        };
        getScopeAssignList(criteria1, res => {
          
          this.courseList = res.queryEncryptorResult.pagedData;
          console.log('b',this.courseList)
          this.customerInfosCourse = res.customerInfos;
        });
        this.filterDay = targetDay;
      } else {
        this.filterDay = targetDay;
        this.courseList = [];
        this.markArray = [];
        this.getData(
          m2.date.firstDay("m", targetDay),
          m2.date.endDay("m", targetDay),
          () => {
            this.filterCourseList(this.courseArray, this.filterDay);
            this.filterMarkArray(this.courseArray);
          }
        );
      }
    },
    switchMonth(target) {
      const { current: targetMonth, calendar } = target;
      this.getData(
        m2.date.firstDay("m", targetMonth),
        m2.date.endDay("m", targetMonth),
        () => {
          this.courseList = [];
          this.markArray = [];
          if (!this.courseArray.length) return;
          // 切换月份找距离现在最近的课表
          if (m2.date.isOneMonth(targetMonth, this.today))
            this.filterDay = this.today;
          else if (targetMonth < this.today) {
            this.filterDay = m2.date.normalize(
              this.courseArray[0].course.startTime
            );
          } else {
            this.filterDay = m2.date.normalize(
              this.courseArray[this.courseArray.length - 1].course.startTime
            );
          }

          this.filterCourseList(this.courseArray, this.filterDay);
          this.filterMarkArray(this.courseArray);

          if (this.courseList[0] && this.courseList[0].course.startTime) {
            this.resetMonth = this.courseList[0].course.startTime;
          }
          // this.resetCalendar(calendar);
        }
      );
    },
    filterCourseList(courseList, filterDate) {
      // debugger
      if (m2.date.isOneMonth(filterDate, this.today)) {
        this.courseList = this.filterCurrentMonthCourse(courseList, filterDate);
      } else {
        this.courseList = this.filter(courseList, filterDate);
      }
      console.log('a',this.courseList)
    },
    filterMarkArray(courseList) {
      console.log("*******", courseList);
      // 计算需要被标记的月份
      if (!courseList.length) return;
      let dayNumberList = [];

      courseList.forEach(course => {
        let dayNumber = course.course.startTime.getDate();
        if (!dayNumberList.includes(dayNumber)) dayNumberList.push(dayNumber);
      });
      this.markArray = dayNumberList;
      console.log(this.markArray);
    },
    filterCurrentMonthCourse(courseList, filterDate) {
      let result = [];
      /*if(m2.date.isEqual(filterDate, this.today)) {
					let list = [];
					list = courseList.filter(course => course.course.startTime >= filterDate).reverse();
					if(!list.length)
						list = courseList.filter(course => course.course.startTime < filterDate);
					if(list.length) {
						result = this.filter(courseList, m2.date.normalize(list[0].course.startTime));
					}
				} else {}*/
      result = this.filter(courseList, m2.date.normalize(filterDate));

      return result;
    },
    filter(courseList, filterDate) {
      return courseList.filter(course => {
        return (
          course.course.startTime >= filterDate &&
          course.course.startTime < m2.date.addDays(filterDate, 1)
        );
      });
    },
    resetCalendar(calendar) {
      if (this.courseList[0] && this.courseList[0].course.startTime) {
        calendar.ChoseMonth(this.courseList[0].course.startTime);
      }
    },
    //filter出一对一课程及班组有学生课程
    less0People(course, jobType) {
      this.courseArr = [];
      this.courseArr = course.filter(item => {
        if (jobType == "3") {
          return (
            ((item.course.businessType == 2 || item.course.businessType == 3) &&
              item.course.peoples > 0) ||
            item.course.businessType == 1
          );
        } else {
          //如果是学管师  一定有学生  不用筛选item.course.peoples > 0
          return item.course.businessType !== 4;
        }
      });
      return this.courseArr;
    },
    pulldownRefresh() {
      //this.isDrop = true;
      this.getData(m2.date.firstDay("m"), m2.date.endDay("m"), () => {
        console.log(this.courseArray);
        this.filterCourseList(this.courseArray, this.today);
        this.filterMarkArray(this.courseArray);
        // 下拉刷新重置日期通知日历更新
        this.resetMonth = new Date();
      });
    },
    PotentialRefresh() {
      if (m2.util.getPermionLoad("睿学-新增潜客")) {
        randomPotentialCustomer({}, res => {
          this.PotentialCustomers = res;
        });
      }
      if (this.jobType == 2) {
        getAllStudents(this.lessParams, res => {
          this.acountLessStudents = res.queryResult.pagedData.slice(0, 30);
        });
      }
    },
    setHeight() {
      setTimeout(() => {
        let content = document.querySelector("#stu-main-content");
        if (content !== null && typeof content !== "undefined") {
          let windowHeight = window.innerHeight;
          let jHight = windowHeight + 65;
          content.style.height = "calc(" + jHight + "px - 0.4rem - 2.6rem)";
        }
      }, 100);
    }
  },
  components: {
    GuestSlide,
    CourseToday,
    CourseCalendar,
    Tip,
    //HomeTip,
    XuedaNews,
    ClassBreak,
    AccountBalance
    /*HomeFooter,*/
  }
};
</script>
<style lang="scss" scoped>
.container {
  background: url(~@/public/asset/img/bg/home-bg.png) repeat-x;
  background-size: 100% 260px;
}

.xd-home {
  width: 100%;
  overflow: auto;
  overflow-y: scroll;
}
#add-guest {
  text-align: right;
  padding: torem(15) 5% torem(15) 0;
  background-color: #fff;
  .add-guest {
    border: none;
    width: 120px;
    height: 30px;
    // background: orange;
    color: #8f8f94;
    font-weight: bold;
    font-size: torem(15);
    i {
      color: #8f8f94;
    }
  }
}
</style>
<style lang='scss'>
.todayCourse {
  background: #fff;
  width: 100%;
  padding-left: 5%;
  padding-right: 5%;
  margin-top: torem(-1);
  div.list-area {
    padding-top: torem(20);
    padding-bottom: torem(10);
  }
  .hed {
    div {
      display: flex;
      align-items: center;
      p {
        width: torem(20);
        height: torem(20);
        margin-right: torem(10);
        margin-bottom: 0;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
    span {
      color: #8f8f94;
    }
  }
  .todayCourseList > div {
    display: flex;
    flex-wrap: wrap;
    div.list {
      width: 33.3%;
      height: torem(80);
      justify-content: center;
      align-items: center;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    p {
      text-align: center;
      margin-top: torem(10);
      display: flex;
      .cusName {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      // .cusName-4-down {
      //   width: torem(57);
      // }
      // .cusName-4-up {
      //   width: torem(54);
      // }
    }
  }
  .todayCourseList {
    height: auto;
    border-radius: 20px;
    padding: torem(15) torem(10);
    position: relative;
    .more {
      text-align: right;
      margin-bottom: 0;
    }
  }
}

.head {
  display: flex;
  a {
    padding-top: torem(15);
    padding-left: torem(10);
    padding-right: torem(20);
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    text-align: right;
  }
  i {
    color: orange;
    font-size: torem(20);
  }
  .img {
    width: torem(40);
    height: torem(40);
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
    }
  }
}

.tip {
  margin: torem(20);
}

.hed {
  display: flex;
  align-items: center;
  justify-content: space-between;
  .tit {
    font-size: torem(15);
    font-weight: bold;
  }
}
.mr33 {
  margin-right: torem(33);
}
</style>
