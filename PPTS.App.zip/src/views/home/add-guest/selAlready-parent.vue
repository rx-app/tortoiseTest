<template>
  <div class="selAlreadyParent">
    <div class="search-head">
      <input type="text" placeholder="输入学员姓名" v-model="partials.customerName">
      <input type="text" placeholder="输入家长姓名" v-model="partials.parentName">
      <input type="text" placeholder="输入家长联系方式" v-model="partials.phoneNumber">
      <button class="search" @click="getSearchList()">查询</button>
    </div>
    <div
      id="stu-main-content"
      class="main-content"
      :style="{'-webkit-overflow-scrolling': scrollMode}"
    >
      <mt-loadmore
        class="loadMore"
        :bottom-all-loaded="allLoaded"
        :auto-fill="false"
        :bottom-method="loadBottom"
        :bottom-distance="-70"
        ref="loadmore"
      >
        <div class="wrap" id="stu-main-content" v-if="searchList.length">
          <li class="bg">
            <span>姓名</span>
            <span>性别</span>
            <span>联系方式</span>
          </li>
          <div class="mui-input-row mui-radio" v-for="(item,index) in searchList" :key="index">
            <label for="radio">
              <span>{{item.parentName}}</span>
              <span>{{item.gender | gender}}</span>
              <span>{{item.phoneNumber}}</span>
            </label>
            <input name="radio" type="radio" @click="selParentFun(item)">
          </div>
        </div>
      </mt-loadmore>
      <tip v-if="!searchList.length && isShow">没有查到相关内容，请检查输入是否正确!</tip>
    </div>
  </div>
</template>
<script>
import { ACTION_TYPES } from "@/constants";
import { pager, orderBy } from "@/public/constant";
import Tip from "@/components/tip";
import { getAllParents } from "@/api/customer/customer-api";
export default {
  data() {
    return {
      allLoaded: false,
      scrollMode: "auto",
      isShow: false,
      partials: {
        customerName: "",
        parentName: "",
        phoneNumber: "",
        ...pager({
          pageIndex: 1,
          pageSize: 10
        }),
        ...orderBy({
          dataField: "CreateTime",
          sortDirection: 1
        })
      },
      selectParent: null,
      searchList: []
    };
  },
  created() {
    this.registerSubmit();
  },
  mounted() {
    this.setHeight();
  },
  methods: {
    getSearchList() {
      if (
        !this.partials.customerName ||
        !this.partials.parentName ||
        !this.partials.phoneNumber
      ) {
        mui.alert("学员姓名、家长姓名、家长联系方式必须输入！");
        return;
      }
      this.searchList = [];
      this.getAllParentsFun();
    },
    getAllParentsFun() {
      for(var i in this.partials){
        if(i=='customerName' || i=='parentName' || i=='phoneNumber'){
          this.partials[i] =  this.partials[i].replace(/\s+/g,"");
        }
      }
      getAllParents(this.partials, res => {
        let pageIndex = res.queryResult.pageIndex;
        let pageSize = res.queryResult.pageSize;
        let totalCount = res.queryResult.totalCount;
        let pagedData = res.queryResult.pagedData;
        pagedData.length ? (this.isShow = false) : (this.isShow = true);
        pageIndex * pageSize >= totalCount
          ? (this.allLoaded = true)
          : (this.allLoaded = false);
        this.searchList = [...this.searchList, ...pagedData];
      });
    },
    loadBottom() {
      this.partials.pageParams.pageIndex++;
      this.getAllParentsFun();
      this.$refs.loadmore.onBottomLoaded();
    },
    selParentFun(item) {
      this.selectParent = item;
    },
    registerSubmit() {
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    submit() {
      this.$router.push({
        name: "addGuest",
        query: this.selectParent
      });
    },
    setHeight() {
      let content = document.querySelector("#stu-main-content");
      if (content !== null && typeof content !== "undefined") {
        let windowHeight = window.innerHeight;
        content.style.height = "calc(" + windowHeight + "px - 63px - 5.52rem)";
      }
    }
  },
  watch: {
    selectParent(obj) {
      if (obj !== null) {
        xdapp.util.vue.commitActionStatus(true);
      }
    }
  },
  components: {
    Tip
  }
};
</script>
<style lang="scss" scoped>
.selAlreadyParent {
  position: absolute;
  width: 100%;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch; /* 解决ios滑动不流畅问题 */
  .search-head {
    input,
    .search {
      width: 80%;
      height: 100%;
      padding: torem(5) torem(10);
      border-radius: 10px;
      margin: torem(10) 0;
      margin-left: 10%;
    }
    .search {
      background: #428bca;
      border-color: #428bca;
      color: #fff;
      font-size: torem(16);
    }
    input::-webkit-input-placeholder {
      font-size: torem(12);
    }
  }
  .wrap {
    li {
      width: 90%;
      margin-left: 5%;
      height: 40px;
      line-height: 40px;
      font-size: torem(16);
    }
    div.mui-input-row {
      width: 90%;
      margin-left: 5%;
      height: 40px;
      line-height: 40px;
      font-size: torem(16);
      display: flex;
      align-items: center;
      label {
        height: 40px;
        line-height: 40px;
        width: 100%;
        padding: 0;
      }
    }
    .bg {
      background: #eee;
    }
    span {
      width: 28%;
      text-align: center;
      display: inline-block;
    }
    input {
      width: 3%;
      text-align: center;
      font-size: torem(20);
    }
  }
  #stu-main-content {
    overflow: auto;
  }
}
</style>
