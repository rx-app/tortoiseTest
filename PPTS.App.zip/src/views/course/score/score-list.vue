﻿<template>
  <div class="wrap">
    <course-header></course-header>

    <ul class="mui-table-view ppts-course-score-main">
      <li class="mui-table-view-cell mui-collapse item">
        <a class="mui-navigate-right tit" href="#">
          <span class="left">中学2017-2018 第二学期</span>
          <span class="right">期末考试</span>
        </a>
        <div class="mui-collapse-content info">
          <div class="item-score">
            <div class="cname">数学</div>
            <div class="score-num">
              <span>91分</span>/100
            </div>
            <div class="teacher">教师：张婷芳</div>
            <div class="right">
              家长满意度:
              <i class="lv3"></i>
              <span>9分</span>
            </div>
          </div>
          <div class="item-score">
            <div class="cname">英语</div>
            <div class="score-num">
              <span>71分</span>/100
            </div>
            <div class="teacher">教师：张婷芳</div>
            <div class="right">
              家长满意度:
              <i class="lv2"></i>
              <span>7分</span>
            </div>
          </div>
          <div class="item-score">
            <div class="cname">语文</div>
            <div class="score-num">
              <span>51分</span>/100
            </div>
            <div class="teacher">教师：张婷芳</div>
            <div class="right">
              家长满意度:
              <i class="lv1"></i>
              <span>5分</span>
            </div>
          </div>
          <div class="item-score">
            <div class="cname">美术</div>
            <div class="score-num">
              <span>51分</span>/100
            </div>
            <div class="teacher">教师：张婷芳</div>
            <div class="right">
              家长满意度:
              <i class="edit" @click="editScore(id)"></i>
              <span>打分</span>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import courseHeader from "../partials/course-header.vue";
export default {
  components: {
    courseHeader
  }
};
</script>
<style lang="scss" scoped>
.ppts-course-score-main {
  .item {
    .tit {
      display: flex;
      .left {
        flex: 1;
      }
      .right {
        flex: 1;
        text-align: right;
        padding-right: 15px;
      }
    }
    .info {
      padding: 0;
      .item-score {
        height: 60px;
        position: relative;
        padding: 0 13px;
        border-bottom: 1px solid #e5e9f2;
        div {
          position: absolute;
        }
        .cname {
          top: 7px;
          left: 15px;
          font-size: torem(18);
          color: #1f2d3d;
        }
        .teacher {
          top: 36px;
          left: 15px;
          font-size: torem(13);
          color: #666666;
        }
        .score-num {
          top: 10px;
          left: 70px;
          font-size: torem(13);
          color: #666666;
          span {
            font-size: torem(16);
            color: #e03229;
          }
        }
        .right {
          vertical-align: bottom;
          top: 22px;
          right: 25px;
          font-size: torem(14);
          color: #1f2d3d;
          i {
            display: inline-block;
            background: url("~@/public/asset/img/course/level3.png");
            background-size: 100%;
            height: 20px;
            width: 20px;
            margin: 0 2px;
            vertical-align: bottom;
            &.lv3 {
              background: url("~@/public/asset/img/course/level3.png");
              background-size: 100%;
            }
            &.lv2 {
              background: url("~@/public/asset/img/course/level2.png");
              background-size: 100%;
            }
            &.lv1 {
              background: url("~@/public/asset/img/course/level1.png");
              background-size: 100%;
            }
            &.edit {
              background: url("~@/public/asset/img/course/edit.png");
              background-size: 100%;
            }
          }
          span {
            display: inline-block;
            width: 30px;
          }
          .num {
            color: #e03229;
          }
        }
      }
    }

    a:after {
    }
  }
}
.ppts-course-list-nav {
  .item {
    display: inline-block;
    width: torem(58);
    margin-right: torem(45);
    .icon {
      width: torem(50);
      height: torem(50);
    }
    .txt {
      display: block;
      margin-top: torem(7);
      font-size: torem(14);
      color: #4b5160;
      line-height: torem(20);
    }
  }
}
</style>
