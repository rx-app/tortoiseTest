﻿<template>
  <div class="container rx-account-statement" style="padding: 10px 0px;">
    <div class="rx-account-statement-header">
      <p class="user">
        <span class="account">当前账户
          <span class="mui-badge mui-badge-success">{{accountCode}}</span>
        </span>
        <span id="openPopover" @click="showBox" v-show="!isshow" class="classify fr">
          <i class="mui-icon iconfont icon-filter"></i>筛选
          <span class="mui-badge mui-badge-purple filter-type">{{typeName | substr()}}</span>
          <span class="mui-badge mui-badge-purple filter-type" v-if="time">{{time}}</span>
        </span>
        <span class="confirm fr" v-show="isshow" @click="confirm">
          <i class="mui-icon iconfont icon-check-mark"></i>确认
        </span>
      </p>
    </div>
    <ul
      class="rx-account-statement-main"
      v-infinite-scroll="loadMore"
      infinite-scroll-disabled="loading"
      infinite-scroll-distance="10"
    >
      <li v-for="(item,index) in accountList" :key="index" class>
        <p class="info">
          <span class="info-txt">
            <span class="action">{{item.recordTypeName}}</span>
            <br>
            <span class="time">{{item.sourceOPTime | dateFormat}} {{item.sourceOPTime | timeFormat}}</span>
          </span>
          <span class="cash-box">
            <span class="cash">+{{item.settledAmount}}</span>元
            <div>成功</div>
          </span>
        </p>
      </li>
    </ul>
    <div id="popover" ref="popover" v-show="isshow" style="height:auto" class="classifies">
      <div class="triangle"></div>
      <div class="input-group input-group-sm">
        <span class="input-group-addon">筛选月份</span>
        <input
          type="text"
          class="form-control time-picker"
          placeholder="选择历史月份"
          data-options="{&quot;type&quot;:&quot;month&quot;}"
          v-model="time"
        >
      </div>
      <button
        @click="addType(item.key,item.value)"
        class="btn btn-default shiny"
        v-for="(item,index) in typeList"
        :class="{'btn-checked':item.key ==currentIndex }"
        :key="index"
      >
        {{item.value}}
        <span :class="{'trangles':item.key ==currentIndex }"></span>
      </button>
    </div>
  </div>
</template>

<script>
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/mui/mui.pick";
import "@/public/asset/css/mui/mui.pick.css";

import { queryAccountFlowList } from "@/api/customer/customer-api";
import tab from "./account-tab";
import { Toast } from "mint-ui";
export default {
  data() {
    return {
      pageIndex: 1,
      accountList: [],
      typeList: [],
      isshow: false,
      typeName: "全部",
      recordType: [],
      total: 0,
      currentIndex: 0,
      isall: false, //判断筛选条件是全部的情况
      time: "",
      accountCode: this.$route.query.code,
      customerID: this.$route.query.id,
      loading: false
    };
  },
  mounted() {
    this.pickerInit();
  },
  watch: {
    async currentChild(a, b) {
      await GET_ACCOUNT_LIST(
        {
          customerID: this.customerID
        },
        res => {
          this.accountCode = res.accounts[0].accountCode;
          this.accountID = res.accounts[0].accountID;
        }
      );
      this.accountList = [];
      this.getAccountList();
    }
  },
  methods: {
    loadMore() {
      this.loading = true;
      this.getAccountList();
    },
    pickerInit() {
      var that = this;
      (function($) {
        $.init();
        var btns = $(".time-picker");
        btns.each(function(i, btn) {
          btn.addEventListener(
            "tap",
            function() {
              var optionsJson = this.getAttribute("data-options") || "{}";
              var options = JSON.parse(optionsJson);
              var picker = new $.DtPicker(options);
              picker.show(function(rs) {
                that.time = rs.text;
                picker.dispose();
              });
            },
            false
          );
        });
      })(mui);
    },
    showBox() {
      this.isshow = !this.isshow;
      this.recordType = [];
    },
    getmore() {
      if (this.recordType == 0) {
        this.getAccountList();
      } else {
        this.getAccountListByType(1);
      }
    },
    getAccountList() {
      queryAccountFlowList(
        {
          customerID: this.customerID,
          AccountID: this.$route.query.id,
          QueryDateType: this.time ? 2 : 1,
          month: this.time,
          data: "2018-04-25",
          pageParams: {
            pageIndex: this.pageIndex,
            pageSize: 10
          },
          orderby: [
            {
              DataField: "BillTime",
              SortDirection: 0
            }
          ],
          recordTypes: this.recordType
        },
        res => {
          this.accountList = [
            ...this.accountList,
            ...res.queryResult.pagedData
          ];
          this.typeList = [
            {
              key: 0,
              value: "全部"
            },
            ...res.dictionaries.RecordTypes
          ];
          this.pageIndex++;
          console.log(this.pageIndex);
          this.total = res.queryResult.totalCount;
          if (this.accountList.length < res.queryResult.totalCount) {
            this.loading = false;
          } else {
            if (this.accountList.length == 0) {
              Toast("当前条件下无账单信息...");
            } else {
              Toast({
                message: "全部账单已加载完毕...",
                position: "bottom"
              });
            }
          }
        }
      );
    },
    confirm() {
      this.pageIndex = 1;
      this.accountList = [];
      this.isshow = false;
      this.getAccountList();
    },
    addType(type, name) {
      this.currentIndex = type;

      this.recordType = type == 0 ? [] : [type];
      this.typeName = name;
      if (type == 0) {
        this.isall = true;
      }
    }
  },
  beforeDestroy() {
     console.log(11)
    function removeElementsByClass(className) {
      var elements = document.getElementsByClassName(className);
      while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
      }
    }
    removeElementsByClass("mui-dtpicker");
  },
  components: {
    tab
  }
};
</script>

<style lang="scss" scoped>
.rx-account-statement {
  .rx-account-statement-main {
    background: #fff;
    margin-top: 114px;
    li {
      padding: 12px 0 0;
      margin: 0 15px;
      background: #fff;
      &::after {
        margin-top: 12px;
        content: "";
        background: #c8c7cc;
        height: 1px;
        display: block;
        transform: scaleY(0.5);
      }
    }
  }
  .rx-account-statement-header {
    position: fixed;
    background: #fff;
    z-index: 990;
    width: 100%;
    p {
      padding: 13px 15px;
      line-height: 18px;
      margin-bottom: 0;
    }
    &::after {
      content: "";
      background: #c8c7cc;
      height: 1px;
      display: block;
      transform: scaleY(0.5);
    }
  }
  .mui-pull {
    bottom: 0px;
  }
  .mui-pull-bottom-pocket {
    bottom: -30px;
  }
  .classify i {
    font-size: torem(14);
  }
  .classify i,
  .confirm i {
    color: #999;
    margin-right: 2px;
  }
  .filter-type {
    margin-left: 2px;
  }
  .classifies {
    max-height: 55%;
    overflow: auto;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    position: fixed;
    top: torem(111);
    left: 0 !important;
    right: 0 !important;
    z-index: 990;
    width: 79%;
    margin-left: 18%;
    background: #eee;
    -webkit-box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    border-radius: 8px;
    padding-top: 10px;
    p {
      margin-left: 10px;
    }
    .input-group {
      display: flex;
      width: 100%;
      margin: 0 torem(5) torem(10);
      .input-group-addon {
        width: auto;
        border-color: #5db2ff !important;
        background-color: #5db2ff !important;
        background-image: none;
        color: #fff;
      }
    }
  }
  .triangle {
    width: 0px;
    height: 0px;
    border-width: 8px;
    border-style: solid;
    border-color: transparent transparent #eee transparent;
    position: absolute;
    top: -16px;
    right: 8px;
  }
  .classifies .btn {
    margin: 6px;
    flex: 1;
    color: #666;
    font-size: torem(12);
    border-color: #eee;
  }
  .fc {
    color: #8f8f94 !important;
  }
  .name {
    margin-right: 30px;
    font-size: torem(18);
    color: #1ce05d;
    letter-spacing: 2px;
  }
  .info .num {
    font-weight: 500;
    color: rgb(32, 145, 32);
    margin-right: 5px;
    letter-spacing: 1px;
  }
  label.item {
    color: #717175;
  }
  .info {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  i.icon {
    display: inline-block;
    margin-right: 8px;
    width: 50px;
    height: 50px;
    line-height: 50px;
    text-align: center;
    font-style: normal;
    color: #fff;
    font-weight: 600;
    border-radius: 50%;
    -webkit-box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    background-image: -webkit-gradient(
      linear,
      left top,
      right top,
      from(#00b3ed),
      to(#2badce)
    );
    background-image: linear-gradient(90deg, #00b3ed 0%, #2badce 100%);
  }
  span.action {
    color: #666;
    line-height: 22px;
    font-size: torem(16);
  }
  span.time {
    color: #999;
    line-height: 16px;
    font-size: torem(12);
  }
  .info-txt {
    display: inline-block;
    width: 80px;
    flex: 1;
  }
  .cash-box {
    width: 100px;
    height: 14px;
    display: block;
    text-align: right;
    line-height: 14px;
    color: #333;
    transform: translateY(-12px);
    .cash {
      color: #e03229;
    }
    div {
      font-size: torem(12);
      color: #999;
      margin-top: 10px;
    }
  }
}

.mui-pull {
  bottom: 0;
}

.mui-pull-caption {
  font-size: torem(12);
  font-weight: normal;
}

.btn-checked:after {
  content: "\2714" !important;
  font-size: torem(10);
  position: absolute;
  bottom: torem(-3);
  right: 0;
  color: #fff !important;
}

.trangles {
  width: 0px;
  height: 0px;
  border-color: transparent dodgerblue dodgerblue transparent;
  border-width: 8px;
  border-style: solid;
  position: absolute;
  bottom: torem(-1);
  right: torem(-1);
}

@media only screen and (max-width: 320px) {
  .rx-account-statement .rx-account-statement-main {
  }
  .rx-account-statement .classifies {
    top: torem(113) !important;
    width: 90% !important;
    margin-left: 8% !important;
  }
  .rx-account-statement .triangle {
    top: torem(-25) !important;
  }
}

@media only screen and (min-width: 321px) and (max-width: 384px) {
  .rx-account-statement .classifies {
    top: torem(110) !important;
  }
}
@media only screen and (min-width: 385px) and (max-width: 413px) {
  .rx-account-statement .classifies {
    top: torem(111) !important;
  }
}
</style>