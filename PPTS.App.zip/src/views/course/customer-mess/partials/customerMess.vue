<template>
	<div>
		<div class="students-list">
			<ul>
				<li class="header-icon"><span>头像：</span><span><img :src="img" alt="" /></span></li>
				<li><span>姓名：</span><span>{{customerMess.customerName}}</span></li>
				<li><span>性别：</span><span>{{customerMess.gender | gender}}</span></li>
				<li><span>学员编号：</span><span>{{customerMess.customerCode}}</span></li>
				<li><span>出生日期：</span><span>{{customerMess.birthday | dateFormat({locale: 'zh-CN'})}}</span></li>
				<li><span>资源所在地：</span><span>{{customerMess.campusName}}</span></li>
				<li><span>接触方式：</span><span>{{customerMess.contactType | contactType}}</span></li>
				<li><span>信息来源：</span><span>{{customerMess.sourceTypeName}}</span></li>
				<li><span>入学年级：</span><span>{{customerMess.entranceGrade | grade}}</span></li>
				<li><span>当前年级：</span><span>{{customerMess.grade | grade}}</span></li>
				<li><span>在读学校：</span><span>{{customerMess.schoolName}}</span></li>
			</ul>
		</div>
	</div>
</template>
<script>
	import { getHead } from '@/api/user/user-api'
	export default {
		props: ['customerMess'],
		computed: {
			img() {
				if(this.customerMess.iconID) {
					return getHead(this.customerMess.iconID, (res) => {
						return res;
					});
				} else {
					return require('@/public/asset/img/icons/head.png')
				}
			}
		}
	}
</script>