<template>
	<div>
		<tip v-if="!accountMess.length">
			<span>未找到该学生的账户信息！</span>
		</tip>
		<div class="rx-account-item" v-if="accountMess.length">
			<div class="account-code">
				当前账户 <span class="mui-badge mui-badge-success">{{accountDefault.accountCode}}</span>
				<button @click="showUserPicker()" class="btn btn-default btn-xs shiny fr" v-show="accountMess.length>1" id="showUserPicker"><i class="mui-icon iconfont icon-exchange"></i><span class="action">切换账户</span></button>
			</div>
			<div class="info">
				<div class="box-left">
					<div>账户价值</div>
					<div><span class="number">{{accountDefault.accountValue}}</span>元</div>
				</div>
				<div class="box-right">
					<div>可用金额</div>
					<div><span class="number">{{accountDefault.accountMoney}}</span>元</div>
				</div>
			</div>
			<div class="info">
				<div class="box-left">
					<div>订购余额</div>
					<div><span class="number">{{accountDefault.assetMoney}}</span>元</div>
				</div>
				<div class="box-right">
					<div>剩余排定课时</div>
					<div><span class="number">{{accountDefault.remainedAssignedAmount}}</span>个</div>
				</div>
			</div>
			<router-link tag="div" class="checkAccount" :to="{name:'accountStatement',query:{id:customerID,code:accountCode}}">
				<i class="iconfont icon-accountAtate"></i> 查看对账单
			</router-link>
		</div>

	</div>
</template>
<script>
	import Tip from '@/components/tip';
	import '@/public/asset/js/mui/mui.pick';
	import '@/public/asset/css/mui/mui.pick.css';

	export default {
		data() {
			return {
				picker: null,
				typeName: '全部',
				isshow: false,
				typeList: {
					key: 0,
					value: '全部'
				},
				accountList: null,
				currentIndex: 0,
				time: '',
				code: 0
			}
		},
		props: ['accountMess', 'customerID'],
		computed: {
			accountDefault() {
				return this.accountMess[this.code] || {}
			},
			accountCode() {
				return this.accountDefault.accountCode;
			}
		},
		created() {
			this.picker = new mui.PopPicker();
		},
		methods: {
			showUserPicker() {
				let that = this;
				this.picker.show(function(selectItems) {
					console.log(selectItems);
					that.code = selectItems[0].value;
				})
			},
			addType(type, name) {
				this.currentIndex = type;
			},
			showBox() {
				this.isshow = !this.isshow;
			},
		},
		watch: {
			accountMess() {
				if(this.accountMess.length) {
					this.accountList = [];
					this.accountMess.forEach((item, index) => {
						this.accountList.push({
							text: item.accountCode,
							value: index
						})
					});
				}

			},
			accountList() {
				if(this.accountList) {
					this.picker.setData(this.accountList)
				}
			}
		},
		components: {
			Tip
		}
	}
</script>
<style lang="scss" scoped>
	.account-list {
		padding: 0 20px;
	}
	
	.checkAccount {
		float: right;
		height: torem(50);
		line-height: torem(50);
		font-size: torem(14);
		padding-right: torem(15);
		vertical-align: middle;
		margin-top: torem(20);
		i {
			color: #ccc;
			font-size: torem(18);
			margin-right: torem(8)
		}
	}
	
	.mask {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		background: rgba($color: #000000, $alpha: 0.6);
		z-index: 50;
	}
	
	.pop-box {
		.close {
			width: torem(30);
			height: torem(30);
			background: #fff;
			position: absolute;
			right: torem(5);
			top: torem(-50);
		}
		.line {
			height: torem(20);
			width: 1px;
			background: #F0F4F8;
			z-index: 99;
			position: absolute;
			right: torem(20);
			bottom: 100%;
		}
		position: fixed;
		z-index: 100;
		top: torem(144);
		left: torem(28);
		width: torem(320);
		background: #fff;
		border-radius: torem(5);
		.main {
			padding: torem(26) torem(23) torem(34);
			.alist {
				div {
					height: 30px;
					line-height: 30px;
					font-size: torem(20);
					text-align: center;
					color: #f3e418;
				}
			}
		}
	}
	
	.rx-account-item {
		margin:torem(15);
		background: rgba(255, 255, 255, 0.89);
		box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
		border-radius: 0 0 12px 12px;
		padding: torem(10) torem(10);
		.account-code {
			padding-bottom: torem(10);
			line-height: torem(22);
			border-bottom: 1px dashed #ccc;
			color: #999;
			.mui-icon {
				margin-right: torem(5);
				color: #999;
			}
			.action {
				display: inline-block;
				vertical-align: top;
			}
		}
		.info {
			overflow: hidden;
			.box-left,
			.box-right {
				width: torem(162);
				padding: torem(22) 0;
				text-align: center;
				float: left;
				div {
					@include letterStyle(13, #999, 1, 22);
					margin-bottom: 5px;
					span.number {
						@include letterStyle(18, #E03229, 0, 22);
						margin-right: 5px;
					}
				}
			}
			.box-left {
				border-right: 1px dashed #ccc;
			}
			.box-right {
				margin-left: -1px !important;
			}
		}
		.bottom {
			padding: torem(15) 0;
			overflow: hidden;
			text-align: center;
			div {
				width: 50%;
				height: torem(35);
				line-height: torem(35);
				float: left;
				color: #666;
				vertical-align: bottom;
				text-align: center;
				i {
					vertical-align: bottom;
					width: torem(35);
					height: torem(35);
					border: 1px solid #A7B4BF;
					color: #A7B4BF;
					border-radius: 100%;
					display: inline-block;
					margin-right: torem(8);
					font-size: torem(19)
				}
			}
		}
	}
	
	.rx-account-statement-header {
		position: fixed;
		background: #fff;
		z-index: 990;
		width: 100%;
		margin-top: torem(10);
		i {
			color: #ccc;
		}
		p {
			padding: 13px 15px;
			line-height: 18px;
			margin-bottom: 0
		}
		&::after {
			content: '';
			background: #c8c7cc;
			height: 1px;
			display: block;
			transform: scaleY(0.5)
		}
	}
</style>