<template>
	<div>
		<mt-navbar v-model="selected">
			<mt-tab-item id="1" @click.stop.prevent="switchTabs('1')">近期未上</mt-tab-item>
			<mt-tab-item id="2" @click.stop.prevent="switchTabs('2')">已上</mt-tab-item>
		</mt-navbar>
		<!-- tab-container  -->
		<div id="stu-main-content" class="main-content" :style="{'-webkit-overflow-scrolling': scrollMode}">
			<mt-loadmore class="loadMore" :top-method="loadTop" :bottom-method="loadBottom" :auto-fill="false" :bottom-all-loaded="allLoaded" :bottom-distance=-70 ref="loadmore">
				<mt-tab-container v-model="selected">
					<mt-tab-container-item id="1">
						<div class="customer-list">
							<tip v-if="!assignMess.length">
								<span>没有查询到任何记录</span>
							</tip>
							<ul class="rx-course-list-clist" v-if="assignMess.length">
								<li v-for="(course,index) in assignMess" :key="index" class="item">
									<img :src="course.subject?require(`@/public/asset/img/course/${course.subject}.png`):require(`@/public/asset/img/course/none.png`)" alt="">
									<div class="desc">
										<div class="name">{{course.subjectName}}</div>
										<div class="teacher">教师：{{course.teacherName}}</div>
									</div>
									<div class="time">
										{{course.startTime | dateFormat}}&nbsp;&nbsp; {{course.startTime | timeFormat }}-{{course.endTime | timeFormat }}
									</div>
									<span class="mui-badge">{{course.amount}}课时</span>
								</li>
							</ul>
						</div>
					</mt-tab-container-item>
					<mt-tab-container-item id="2">
						<div class="customer-list">
							<tip v-if="!confirmedList.length">
								<span>没有查询到任何记录</span>
							</tip>
							<ul class="rx-course-list-clist" v-if="confirmedList.length">
								<li v-for="(course,index) in confirmedList" :key="index" class="item">
									<img :src="course.subject?require(`@/public/asset/img/course/${course.subject}.png`):require(`@/public/asset/img/course/none.png`)" alt="">
									<div class="desc">
										<div class="name">{{course.subjectName}}</div>
										<div class="teacher">教师：{{course.teacherName}}</div>
									</div>
									<div class="time">
										{{course.startTime | dateFormat}}&nbsp;&nbsp; {{course.startTime | timeFormat }}-{{course.endTime | timeFormat }}
									</div>
									<span class="mui-badge">{{course.amount}}课时</span>
								</li>
							</ul>
						</div>
					</mt-tab-container-item>
				</mt-tab-container>
			</mt-loadmore>
		</div>
	</div>
</template>
<script>
	import Tip from '@/components/tip';
	import { pager } from '@/public/constant';
	import { ASSIGN_STATUS } from '@/constants';
	import { getAssignList } from '@/api/customer/customer-api'
	export default {
		data() {
			return {
				assignMess: [],
				confirmedList: [],
				pageIndex: 1,
				pageSize: 10,
				selected: null,
				allLoaded: false,
				scrollMode: "auto"
			}
		},
		props: ['customerID'],
		methods: {
			getAssignList(noneClass) {
				let params = {
					customerID: this.customerID,
					assignStatus: noneClass ? ASSIGN_STATUS.Assigned : ASSIGN_STATUS.Confirmed,
					...pager({
						pageIndex: this.pageIndex,
						pageSize: this.pageSize
					}),
				};
				if(noneClass) {
					getAssignList(params, (res) => {
						this.assignMess = this.assignMess.concat(res.queryResult.pagedData);
						const len = res.queryResult.pagedData.length;
						if(this.pageSize*this.pageIndex >= res.queryResult.totalCount) {
							this.allLoaded = true;
						}else{
							this.allLoaded = false;
						}
					})
				} else {
					getAssignList(params, (res) => {
						this.confirmedList = this.confirmedList.concat(res.queryResult.pagedData);
						if(this.pageSize*this.pageIndex >= res.queryResult.totalCount) {
							this.allLoaded = true;
						}else{
							this.allLoaded = false;
						}
					})
				}

			},
			switchTabs(Id) {
				this.selected = Id;
			},
			//下拉刷新  初始化加载
			loadTop() {
				this.$refs.loadmore.onTopLoaded(); //刷新完重新定位
				this.topBack();
			},
			loadBottom() {
				this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
				this.bottomBack();
			},
			topBack() {
				this.pageIndex = 1;
				this.clearData();
				this.chooseCourse();
			},
			bottomBack() {
				this.pageIndex++;
				this.chooseCourse();
			},
			navKind() {
				if(this.selected == '1') {
					this.getAssignList(1);
				} else {
					this.getAssignList();
				}
			},
			chooseCourse() {
				this.navKind();
			},
			clearData() {
				this.pageIndex = 1;
				if(this.selected == '1') {
					this.assignMess = [];
				} else {
					this.confirmedList = [];
				}
			},
			setHeight() {
				let content = document.querySelector('#stu-main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 85 - 34 - 10 - 32 - 50 + 23;
					let headHight = document.querySelector('#course-head');
					console.log('stu-#course-head：' + headHight)
					if(headHight !== null) {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem - 2.88rem)'
					} else {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem)'
					}
				}
			}
		},
		watch: {
			selected() {
				this.chooseCourse();
				this.clearData();
				this.allLoaded = false;
			}
		},
		mounted() {
			this.selected = '1';
			this.setHeight()
		},
		components: {
			Tip
		}
	}
</script>
<style lang="scss">
	.main-content {
		overflow: auto;
	}
	
	.rx-course-list-clist {
		.item {
			position: relative;
			height: 70px;
			border-bottom: 1px dashed #eee;
			padding: 15px 0 0 20px;
			img {
				width: 40px;
				height: 40px;
				margin-right: 14px;
				vertical-align: middle;
			}
			.desc {
				display: inline-block;
				vertical-align: middle;
				.name {
					font-size: torem(14);
					color: #1f2d3d;
					line-height: 20px;
				}
				.teacher {
					font-size: torem(12);
					color: #888;
					line-height: 16px;
					margin-top: 5px;
				}
			}
			.time {
				position: absolute;
				right: 16px;
				top: 15px;
				font-size: torem(12);
				color: #999999;
			}
		}
		.mui-badge {
			position: absolute;
			right: torem(20);
			top: torem(40);
		}
	}
</style>