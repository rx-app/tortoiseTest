<template>
	<div class="xd-customer-list">
		<div class="customer-header">
			<p>学员姓名 : <span>{{customerMess.customerName}}</span></p>
			<p>学员编号 : <span>{{customerMess.customerCode}}</span></p>
		</div>
		<mt-navbar v-model="selected">
			<mt-tab-item id="1" @click="switchTabs('1')">基本信息</mt-tab-item>
			<mt-tab-item id="2" @click="switchTabs('2')">家长信息</mt-tab-item>
			<!--<mt-tab-item id="3" @click="switchTabs('3')">账户信息</mt-tab-item>-->
			<mt-tab-item id="4" @click="switchTabs('4')">课表信息</mt-tab-item>
		</mt-navbar>
		<mt-tab-container v-model="selected">
			<mt-tab-container-item id="1">
				<customer-mess :customerMess='customerMess'></customer-mess>
			</mt-tab-container-item>
			<mt-tab-container-item id="2">
				<parent-mess :parentMess='parentMess'></parent-mess>
			</mt-tab-container-item>
			<mt-tab-container-item id="3">
				<account-mess :accountMess='accountMess' :customerID='customerID'></account-mess>
			</mt-tab-container-item>
			<mt-tab-container-item id="4">
				<assign-mess class='mt':customerID='customerID'></assign-mess>
			</mt-tab-container-item>
		</mt-tab-container>

	</div>
</template>

<script>
	import { loadUserInfo } from '@/api/common/common-api'
	import { getCustomer, getParentList, getAccountList} from '@/api/customer/customer-api'
	import { pager } from '@/public/constant';
	import { ASSIGN_STATUS } from '@/constants';
	import customerMess from './partials/customerMess.vue'
	import parentMess from './partials/parentMess.vue'
	import accountMess from './partials/accountMess.vue'
	import assignMess from './partials/assignMess.vue'
	import { Navbar as mtNavbar, TabItem as mtTabItem } from 'mint-ui';
	export default {
		data() {
			return {
				customerMess: {},
				parentMess: {},
				accountMess: {},
				selected: null
			}
		},
		methods: {
			async getCustomerMess() {
				await loadUserInfo();

				getCustomer(this.customerID, (res) => {
					this.customerMess = res.customer;
				})

			},
			getParentList() {
				getParentList(this.customerID, (res) => {
					this.parentMess = res.parentRelations[0];
				})
			},
			getAccountList() {
				getAccountList(this.customerID, (res) => {
					this.accountMess = res.accounts;
				})
			},
			switchTabs(Id) {
				this.selected = Id;
			},
		},
		computed: {
			customerID() {
				return this.$route.query.customerID
			}
		},
		created() {
			this.getCustomerMess();
			this.selected = '1';
		},
		watch: {
			selected(Id) {
				switch(Id) {
					case '2':
						this.getParentList();
						break;
					case '3':
						this.getAccountList();
						break;
				}

			}

		},
		components: {
			customerMess,
			parentMess,
			accountMess,
			assignMess,
			mtNavbar,
			mtTabItem,
		}
	}
</script>

<style lang="scss">
	.xd-customer-list {
		.customer-header {
			display: flex;
			align-items: center;
			justify-content: space-around;
			height: torem(45);
			span {
				margin-left: torem(10)
			}
		}
		.students-list {
			padding:torem(20);
			ul>li {
				height: torem(55);
				line-height: torem(40);
				width: 100%;
				display: flex;
				align-items: center;
				font-size: torem(14);
				span {
					flex: 1;
				}
				span:nth-child(1) {
					text-align: left
				}
			}
			.header-icon {
				span:nth-child(2) {
					display: inline-block;
					height: torem(60);
					img {
						width: torem(60);
						height: torem(60);
					}
				}
			}
		}
	}
	.mt{
		margin-top: torem(15);
	}
</style>