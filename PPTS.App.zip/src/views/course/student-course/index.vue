<template>
  <div class="xd-student-course">
    <course-header></course-header>
    <div class="course-main" v-power="['睿学-学员课表']">
      <div class="course-content">
        <p class="inp">
          <input
            type="text"
            placeholder="输入学员姓名进行查询"
            v-model="inpVal"
            @click="inpFocus()"
            @blur="inpBlur()"
          />
          <i class="iconfont icon-found" @click="searchCourse()"></i>
        </p>
        <mt-navbar v-model="selected">
          <mt-tab-item id="1" @click.stop.prevent="switchTabs('1')">今日课表</mt-tab-item>
          <mt-tab-item id="2" @click.stop.prevent="switchTabs('2')">本月课表</mt-tab-item>
        </mt-navbar>
        <!-- tab-container  -->
        <div
          id="stu-main-content"
          class="main-content"
          :style="{'-webkit-overflow-scrolling': scrollMode}"
        >
          <mt-loadmore
            class="loadMore"
            :top-method="loadTop"
            :bottom-method="loadBottom"
            :auto-fill="false"
            :bottom-all-loaded="allLoaded"
            :bottom-distance="-70"
            ref="loadmore"
          >
            <mt-tab-container v-model="selected">
              <mt-tab-container-item id="1">
                <div class="customer-list">
                  <tip v-if="!teachTodayCourse.length">
                    <span>没有查询到任何记录</span>
                  </tip>
                  <course-item :courseList="teachTodayCourse" :type="1" :tab="'1'"></course-item>
                </div>
              </mt-tab-container-item>
              <mt-tab-container-item id="2">
                <div class="customer-list">
                  <tip v-if="!teachMonthCourse.length">
                    <span>没有查询到任何记录</span>
                  </tip>
                  <course-item :courseList="teachMonthCourse" :type="1" :tab="'2'"></course-item>
                </div>
              </mt-tab-container-item>
            </mt-tab-container>
          </mt-loadmore>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import courseHeader from "../partials/course-header.vue";
import Tip from "@/components/tip";
import { ACTION_TYPES } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import { getScopeAssignList } from "@/api/customer/customer-api";
import { pager, orderBy } from "@/public/constant";
import courseItem from "../partials/course-items";
import {
  Navbar as mtNavbar,
  TabItem as mtTabItem,
  Loadmore as mtLoadmore
} from "mint-ui";
import resize from "@/public/lib/resize";
export default {
  mixins: [resize],
  data() {
    return {
      inpVal: "",
      selected: null,
      pageIndex: 1,
      pageSize: 20,
      teachTodayCourse: [],
      teachMonthCourse: [],
      allLoaded: false,
      scrollMode: "auto",
      backObj: {}
    };
  },
  methods: {
    inpFocus() {
      xdapp.footer.style.display = "none";
    },
    inpBlur() {
      xdapp.footer.style.display = "block";
    },
    //获取岗位下学员课表
    async getTeachCourseList(startTime, endTime, order) {
      await loadUserInfo();

      let params = {
        campusID: "",
        customerName: this.inpVal.trim(),
        StartTimeBegin: startTime ? startTime : m2.date.today(),
        StartTimeEnd: endTime ? endTime : m2.date.today(),
        ...orderBy({
          dataField: "StartTime",
          sortDirection: order ? order : 0
        }),
        ...pager({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize
        })
      };
      this.backObj = {
        inpVal: this.inpVal,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        tab: this.selected
      };
      console.log(JSON.stringify(this.backObj, null, 2));
      getScopeAssignList(params, res => {
        if (startTime && endTime) {
          this.teachMonthCourse = this.teachMonthCourse.concat(
            res.queryEncryptorResult.pagedData
          );
          if (
            this.pageSize * this.pageIndex >=
            res.queryEncryptorResult.totalCount
          ) {
            this.allLoaded = true;
          } else {
            this.allLoaded = false;
          }
        } else {
          if (res.queryEncryptorResult.pagedData === null) return;
          this.teachTodayCourse = this.teachTodayCourse.concat(
            res.queryEncryptorResult.pagedData
          );
          if (
            this.pageSize * this.pageIndex >=
            res.queryEncryptorResult.totalCount
          ) {
            this.allLoaded = true;
          } else {
            this.allLoaded = false;
          }
        }
      });
    },
    searchCourse() {
      if (!this.inpVal) {
        mui.toast("请输入查询学员！");
        return;
      } else if (this.inpVal.length < 2) {
        mui.toast("请输入长度不小于2位的搜索信息！");
        return;
      }
      this.clearData();
      this.navKind();
    },
    switchJob() {
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getTeachCourseList);
    },
    switchTabs(Id) {
      this.selected = Id;
    },
    //下拉刷新  初始化加载
    loadTop() {
      this.$refs.loadmore.onTopLoaded(); //刷新完重新定位
      this.topBack();
    },
    loadBottom() {
      this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
      this.bottomBack();
    },
    navKind() {
      if (this.selected == "1") {
        this.getTeachCourseList();
      } else {
        this.getTeachCourseList(m2.date.firstDay("m"), m2.date.endDay("m"), 1);
      }
    },
    topBack() {
      this.pageIndex = 1;
      this.clearData();
      this.chooseCourse();
    },
    bottomBack() {
      this.pageIndex++;
      this.chooseCourse();
    },
    chooseCourse() {
      /*var ele = document.getElementById('main-content');
				if(ele) {
					ele.scrollTop = 0;
				}*/
      this.navKind();
    },
    clearData() {
      this.pageIndex = 1;
      if (this.selected == "1") {
        this.teachTodayCourse = [];
      } else {
        this.teachMonthCourse = [];
      }
    },
    setHeight() {
      let content = document.querySelector("#stu-main-content");
      if (content !== null && typeof content !== "undefined") {
        let windowHeight = window.innerHeight;
        let jHight = windowHeight - 85 - 34 - 10 - 32 + 23;
        let headHight = document.querySelector("#course-head");
        console.log("stu-#course-head：" + headHight);
        if (headHight !== null) {
          content.style.height = "calc(" + jHight + "px - 0.4rem - 2.88rem)";
        } else {
          content.style.height = "calc(" + jHight + "px - 0.4rem)";
        }
      }
    }
  },
  created() {
    loadUserInfo("upd");
  },
  mounted() {
    this.switchJob();
    if (typeof this.$route.query.tab !== "undefined") {
      this.selected = this.$route.query.tab + "";
    } else {
      this.selected = "1";
    }
    this.setHeight();
  },
  watch: {
    selected() {
      this.chooseCourse();
      this.pageIndex = 1;
      this.clearData();
      this.allLoaded = false;
    },
    inpVal() {
      if (!this.inpVal) {
        this.clearData();
        this.navKind();
      }
    }
  },
  components: {
    courseHeader,
    Tip,
    courseItem,
    mtNavbar,
    mtTabItem,
    mtLoadmore
  }
};
</script>
<style lang="scss" scoped>
.main-content {
  overflow: auto;
}
.inp {
  width: 90%;
  margin-left: 5%;
  border: 1px solid #d8d8d8;
  border-radius: 100px;
  height: 32px;
  position: relative;
  margin-top: torem(15);
  input {
    width: 90%;
    height: 100%;
    border: none;
    margin-left: 1%;
    border-radius: 100px;
  }
  input::-webkit-input-placeholder {
    font-size: torem(12);
  }
  i {
    position: absolute;
    right: torem(10);
    top: torem(5);
    color: #eee;
    font-size: torem(24);
  }
}

.customer-list-box {
  .item {
    position: relative;
    height: 70px;
    border-bottom: 1px dashed #eee;
    padding: 15px 0 0 20px;
    img {
      width: 40px;
      height: 40px;
      margin-right: 14px;
      vertical-align: middle;
    }
    .desc {
      display: inline-block;
      vertical-align: middle;
      .name {
        font-size: torem(14);
        color: #1f2d3d;
        line-height: 20px;
      }
      .teacher {
        font-size: torem(12);
        color: #888;
        line-height: 16px;
        margin-top: 5px;
      }
    }
    .time {
      position: absolute;
      right: 16px;
      top: 15px;
      font-size: torem(12);
      color: #999999;
    }
    .type {
      line-height: 20px !important;
      position: absolute;
      right: 16px;
      bottom: 10px;
      font-size: torem(14);
    }
  }
}
</style>