<template>
	<div class="xd-student-course">
		<course-header></course-header>
		<div class="course-main">
			<div class="course-content">
				<p class="inp" v-power="['睿学-教师课表']"><input type="text" placeholder="输入教师姓名进行查询" v-model="inpVal" @click='inpFocus()' @blur='inpBlur()' />
					<i class="iconfont icon-found" @click="searchCourse()"></i></p>
				<mt-navbar v-model="selected">
					<mt-tab-item id="1" @click.stop.prevent="switchTabs('1')">今日课表</mt-tab-item>
					<mt-tab-item id="2" @click.stop.prevent="switchTabs('2')">本月课表</mt-tab-item>
				</mt-navbar>
				<!-- tab-container  -->
				<div id="stu-main-content" class="main-content" :style="{'-webkit-overflow-scrolling': scrollMode}">
					<mt-loadmore class="loadMore" :top-method="loadTop"  :bottom-method="loadBottom" :auto-fill="false" :bottom-all-loaded="allLoaded" :bottom-distance=-70 ref="loadmore">
						<mt-tab-container v-model="selected">
							<mt-tab-container-item id="1">
								<div class="customer-list">
									<tip v-if="!teachTodayCourse.length">
										<span>没有查询到任何记录</span>
									</tip>
									<course-item :courseList='teachTodayCourse' :type="isTeachWatch" :tab="'1'"></course-item>
								</div>
							</mt-tab-container-item>
							<mt-tab-container-item id="2">
								<div class="customer-list">
									<tip v-if="!teachMonthCourse.length">
										<span>没有查询到任何记录</span> </tip>
									<course-item :courseList='teachMonthCourse' :type="isTeachWatch" :tab="'2'"></course-item>
								</div>
							</mt-tab-container-item>
						</mt-tab-container>
					</mt-loadmore>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import courseHeader from '../partials/course-header.vue'
	import Tip from '@/components/tip';
	import { ACTION_TYPES, COURSE_INDEX_ALL } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api'
	import { getScopeTeacherCourse, getTeacherCourses } from '@/api/course/course-api'
	import { pager, orderBy } from '@/public/constant'
	import courseItem from "../partials/course-items"
	import { Navbar as mtNavbar, TabItem as mtTabItem, Loadmore as mtLoadmore } from 'mint-ui';
	import resize from '@/public/lib/resize'
	export default {
		mixins:[resize],
		data() {
			return {
				showObjs: [],
				items: COURSE_INDEX_ALL,
				inpVal: '',
				selected: null,
				pageIndex: 1,
				pageSize: 20,
				isTeachWatch: 0,//0代表学管师获取教师课表  1代表教师获取课表
				teachTodayCourse: [],
				teachMonthCourse: [],
				isAutoFill: false,
				allLoaded: false,
				scrollMode: "auto"
			}
		},
		methods: {
			isShowNav(functions) {
				return m2.util.getPermionLoad(functions);
			},
			inpFocus() {
				xdapp.footer.style.display = 'none';
			},
			inpBlur() {
				xdapp.footer.style.display = 'block';
			},
			//获取岗位下教师课表
			async getTeachCourseList(startTime, endTime, order) {
				await loadUserInfo();

				let params = {
					campusID: '',
					teacherName: this.inpVal.trim(),
					StartTimeBegin: startTime ? startTime : m2.date.today(),
					StartTimeEnd: endTime ? endTime : m2.date.today(),
					...orderBy({
						dataField: 'StartTime',
						sortDirection: order ? order : 0,
					}),
					...pager({
						pageIndex: this.pageIndex,
						pageSize: this.pageSize,
					}),
				}
				if(!this.isTeachPerson()) {
					this.isTeachWatch = 1;
					getTeacherCourses(params, (res) => {
						if(startTime && endTime) {
							this.teachMonthCourse = this.teachMonthCourse.concat(res.queryResult.pagedData);
							console.log(this.teachMonthCourse)
							if(this.pageSize*this.pageIndex >= res.queryResult.totalCount) {
								this.allLoaded = true;
							}else{
								this.allLoaded = false;
							}
						} else {
							this.teachTodayCourse = this.teachTodayCourse.concat(res.queryResult.pagedData);
							console.log(this.teachTodayCourse)
							if(this.pageSize*this.pageIndex >= res.queryResult.totalCount) {
								this.allLoaded = true;
							}else{
								this.allLoaded = false;
							}
						}

					})
				} else {
					this.isTeachWatch = 0;
					getScopeTeacherCourse(params, (res) => {
						if(startTime && endTime) {
							this.teachMonthCourse = this.teachMonthCourse.concat(res.queryResult.pagedData);
							if(this.pageSize*this.pageIndex >= res.queryResult.totalCount) {
								this.allLoaded = true;
							}else{
								this.allLoaded = false;
							}
						} else {
							this.teachTodayCourse = this.teachTodayCourse.concat(res.queryResult.pagedData);
							if(this.pageSize*this.pageIndex >= res.queryResult.totalCount) {
								this.allLoaded = true;
							}else{
								this.allLoaded = false;
							}
						}

					})

				}
				this.backObj = {
					inpVal: this.inpVal,
					pageIndex: this.pageIndex,
					pageSize: this.pageSize,
					tab: this.selected
				}
				console.log(JSON.stringify(this.backObj, null, 2))

			},
			searchCourse() {
				if(!this.inpVal) {
					mui.toast('请输入查询教师！');
					return;
				} else if(this.inpVal.length < 2) {
					mui.toast('请输入长度不小于2位的搜索信息！')
					return;
				}
				this.clearData();
				this.navKind();
			},
			switchJob() {
				xdapp.util.vue.on(ACTION_TYPES.SWITCH_JOB, this.getTeachCourseList);
			},
			switchTabs(Id) {
				this.selected = Id;
			},
			//下拉刷新  初始化加载
			loadTop() {
				this.$refs.loadmore.onTopLoaded(); //刷新完重新定位
				this.topBack();
			},
			loadBottom() {
				this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
				this.bottomBack();
			},
			navKind() {
				if(this.selected == '1') {
					this.getTeachCourseList();
				} else {
					this.getTeachCourseList(m2.date.firstDay('m'), m2.date.endDay('m'), 1);
				}
			},
			topBack() {
				this.pageIndex = 1;
				this.clearData();
				this.chooseCourse();
			},
			bottomBack() {
				this.pageIndex++;
				this.chooseCourse();
			},
			chooseCourse() {
				/*var ele = document.getElementById('main-content');
				if(ele) {
					ele.scrollTop = 0;
				}*/
				this.navKind();
			},
			clearData() {
				this.pageIndex = 1;
				if(this.selected == '1') {
					this.teachTodayCourse = [];
				} else {
					this.teachMonthCourse = [];
				}
			},
			setHeight () {
				let content = document.querySelector('#stu-main-content');
				if (content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 85 - 34 - 10 - 32  + 23;
					let headHight = document.querySelector('#course-head');
					console.log('stu-#course-head：' + headHight)
					if (headHight !== null) {
						content.style.height = 'calc('+ jHight + 'px - 0.4rem - 2.88rem)'
					} else {
						content.style.height = 'calc('+ jHight + 'px - 0.4rem)'
					}
				}
			},
			initPage() {
				this.showObjs = []
				this.items.map(one => {
					if(this.isShowNav(one.functions)) {
						this.showObjs.push(one)
					}
				})
				if(this.showObjs.length === 1) {
					this.$router.push({
						name: this.showObjs[0].pathname
					})
				} else {
					this.switchJob();
					this.selected = '1';
				}
				let content = document.querySelector('#main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 85 - 34 - 10 - 32 - 50 + 35;
					let headHight = document.querySelector('#course-head');
					console.log('teach-#course-head：' + headHight)
					if(headHight !== null) {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem - 2.88rem)'
					} else {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem)'
					}
				}
			},
			isTeachPerson() {
				var result = undefined;
				var functions = m2.cache.get('ppts-current-job').functions;
				functions.forEach(item => {
					if(item == "睿学-教师课表") {
						result = true;
					}
				})
				return result;
			}
		},
		mounted() {
			this.setHeight()
			if (typeof this.$route.query.tab  !== 'undefined') {
				this.selected = this.$route.query.tab + ''
			} else {
				this.selected = '1'
			}
			/*if (typeof window.bbObj !== 'undefined') { 
				let backObj = window.bbObj
				this.selected = backObj.tab
			}*/
		},
		created(){
			loadUserInfo('upd');
			if(m2.cache.get('ppts-current-job').jobType == 3) {
				this.$route.meta.title = "课表";
			}else{
				this.$route.meta.title = "教师课表";
			}
			mui.plusReady(function() {
				plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
			})
		},
		watch: {
			selected() {
				this.chooseCourse();
				this.clearData();
				this.allLoaded = false;
			},
			inpVal() {
				if(!this.inpVal) {
					this.clearData();
					this.navKind();
				}
			}
		},
		components: {
			courseHeader,
			Tip,
			courseItem,
			mtNavbar,
			mtTabItem,
			mtLoadmore
		}
	}
</script>
<style lang="scss" scoped>
	/*.loadMore,
	.searchLoad {
		overflow-y: scroll
	}
	*/
	
	.main-content {
		overflow: auto;
		// height: torem(350);
	}
	
	.inp {
		width: 90%;
		margin-left: 5%;
		border: 1px solid #D8D8D8;
		border-radius: 100px;
		height: 32px;
		position: relative;
		margin-top: torem(15);
		input {
			width: 90%;
			height: 100%;
			border: none;
			margin-left: 1%;
			border-radius: 100px;
		}
		input::-webkit-input-placeholder{
			font-size: torem(12);
		}
		i {
			position: absolute;
			right: torem(10);
			top: torem(5);
			color: #eee;
			font-size: torem(24)
		}
	}
	
	.customer-list-box {
		.item {
			position: relative;
			height: 70px;
			border-bottom: 1px dashed #eee;
			padding: 15px 0 0 20px;
			img {
				width: 40px;
				height: 40px;
				margin-right: 14px;
				vertical-align: middle;
			}
			.desc {
				display: inline-block;
				vertical-align: middle;
				.name {
					font-size: torem(14);
					color: #1f2d3d;
					line-height: 20px;
				}
				.teacher {
					font-size: torem(12);
					color: #888;
					line-height: 16px;
					margin-bottom: 5px;
				}
			}
			.time {
				position: absolute;
				right: 16px;
				bottom: 15px;
				font-size: torem(12);
				color: #999999;
			}
			.type {
				line-height: 20px!important;
				position: absolute;
				right: 16px;
				bottom: 10px;
				font-size: torem(14);
			}
		}
	}
</style>