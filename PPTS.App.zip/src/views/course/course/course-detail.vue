﻿<template>
  <div class="xdapp-feedback-container">
    <div @tap.native='fnTap'

      class="scroll-container"

    >
      <div style="background: #fff;">
        <div class="pop-box" style="background: #fff;">
          <div class="main">
            <course-info
              :courseInfo="courseInfo"
              :isLessonSign="isLessonSign"
              :isLessonSignFalseReason="isLessonSignFalseReason"
              :entry="entry"
              :teacherInfoImg="teacherInfoImg"
              :customerInfoImg="customerInfoImg"
              :type="type"
              :customerID="customerID"
              :teacherID="teacherID"
            ></course-info>
            <div v-if="showEvaluate && (businessType==2 || businessType==3)">
              <h5 class="students">学员列表（点击学员姓名进行点评）</h5>
              <div class="studentList">
                <button
                  @click="evalStudent(index)"
                  class="btn"
                  v-for="(item,index) in courseInfo.customers"
                  :class="[{'checked':(code==index)},{'aleardy':item.evaluate || item.teacherEvaluate}]"
                  :key="index"
                >{{item.customerName}}</button>
              </div>
            </div>
            <course-evaluate
              v-power="['睿学-查看教师点评']"
              v-if="showEvaluate"
              :courseInfo="courseInfo"
              :evaluateConfig="evaluateConfig_teachTo"
              :evaluate="evaluate_teachTo"
              :items="items_teachTo"
              :code="code"
              type="evaluate"
            ></course-evaluate>
            <course-evaluate
              v-power="['睿学-查看学员评价']"
              v-if="showEvaluate "
              :courseInfo="courseInfo"
              :evaluateConfig="evaluateConfig_studentTo"
              :evaluate="evaluate_studentTo"
              :items="items_studentTo"
              :code="code"
              type="teacherEvaluate"
            ></course-evaluate>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import courseInfo from "./partials/course-info";
import courseEvaluate from "./partials/course-evaluate";
import * as types from "@/store/mutation-types";
import {
  ACTION_TYPES,
  ASSIGN_STATUS as assignStatus,
  COURSE_EVALUATE_SCORE_CONFIG as scoreConfig
} from "@/constants";
import { getLessonInfo, postLessonEvaluation } from "@/api/course/course-api";
import Scroll from "@/components/scroll/index";

export default {
  beforeRouteLeave: (to, from, next) => {
    if (typeof from.query.tab !== "undefined" && !to.query.tab) {
      let append = "?";
      if (/\?/.test(to.fullPath)) {
        append = "&";
      }
      return next(to.fullPath + append + "tab=" + from.query.tab);
    }
    if (
      typeof from.query.tab !== "undefined" &&
      to.query.tab !== from.query.tab
    ) {
      // this.$nextTick(()=>{
      to.query.tab = from.query.tab;
      // })
    }
    next();
  },
  data() {
    return {
      courseInfo: {},
      isLessonSign:null,
      isLessonSignFalseReason:null,
      allData: {},
      teacherInfoImg: [],
      customerInfoImg: [],
      evaluate_teachTo: [],
      evaluate_studentTo: {},
      code: 0,
      evaluateConfig_teachTo: {
        title: "教师点评",
        scoreConfig: scoreConfig
      },
      evaluateConfig_studentTo: {
        title: "学生评价",
        scoreConfig: scoreConfig
      },
      items_teachTo: [],
      items_studentTo: []
    };
  },
  created() {
    this.getCourseDetail(this.courseID, this.businessType, this.assignID);
  },
  methods: {
	fnTap(e){
		if(!mui.os.ios){
			if( e.target.tagName=='TEXTAREA' ||  e.target.tagName=='INPUT' ){
				return
			}
			if( document.activeElement.tagName=='TEXTAREA' ||  document.activeElement.tagName=='INPUT' ){
				document.activeElement.blur();
			}
		}
	},
    evalStudent(index) {
      this.code = index;
      this.callback(this.allData);
      //this.getCourseDetail(this.courseID, this.businessType);
    },
    submit() {
      //this.items_teachTo.forEach(item => this.evaluate_teachTo[item.key] = item.score);
      this.params = [];
      this.evaluate_teachTo.forEach((item, index) => {
        if (
          item.assignID ||
          !item.guidanceObjective ||
          !item.learningAttitude ||
          !item.concentrate ||
          !item.previewReview ||
          !item.homework
        )
          return;
        delete item.isEdit;
        this.params.push({
          ...item,
          ...this.courseMess(index)
        });
      });
      console.log(this.params);
      postLessonEvaluation(this.params, () => {
        mui.toast("评价成功！");
        this.$store.commit(types.ENABLE_STATUS, false);
        this.$router.push({ name: "home" });
      });
    },
    getCourseDetail(courseID, businessType, assignID) {
      if (this.assignID) {
        var parameter = {
          assignID: assignID,
          courseID: courseID,
          businessType: businessType
        };
      } else {
        var parameter = {
          courseID: courseID,
          businessType: businessType
        };
      }
      getLessonInfo(parameter, res => this.callback(res));
    },
    courseMess(code) {
      return {
        assignID: this.courseInfo.customers[code].assignID,
        customerID: this.courseInfo.customers[code].customerID,
        teacherID: this.courseInfo.teacherID
      };
    },
    callback(res) {
      this.evaluate_teachTo.forEach((item, index) => {
        this.courseInfo.customers.forEach((items, indexs) => {
          if (
            index == indexs &&
            item.guidanceObjective &&
            item.learningAttitude &&
            item.concentrate &&
            item.previewReview &&
            item.homework
          ) {
            items.evaluate = item;
          }
        });
      });
      this.allData = res;
      this.teacherInfoImg = res.teacherInfos;
      this.customerInfoImg = res.customerInfos;
      this.courseInfo = res.lessonInfo;
      this.isLessonSign = res.isLessonSign;
      this.isLessonSignFalseReason = res.isLessonSignFalseReason
      this.evaluate_teachTo[this.code] =
        res.lessonInfo.customers[this.code].evaluate || {};

      this.evaluate_studentTo[this.code] =
        res.lessonInfo.customers[this.code].teacherEvaluate || {};
      this.items_teachTo = this.getTeacherCourseItems(
        this.evaluate_teachTo[this.code]
      );
      this.items_studentTo = this.getStudentCourseItems(
        this.evaluate_studentTo[this.code]
      );
      // 订阅右上角提交课后评价事件
      if (
        this.courseInfo.assignStatus == assignStatus.Confirmed &&
        !this.courseInfo.customers[this.code].evaluate
      )
        xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    getStudentCourseItems(evaluate) {
      return [
        {
          key: "goal",
          title: "辅导目标",
          score: evaluate.goal || 0,
          desc: this.getScoreDesc(evaluate.goal)
        },
        {
          key: "attitude",
          title: "授课态度",
          score: evaluate.attitude || 0,
          desc: this.getScoreDesc(evaluate.attitude)
        },
        {
          key: "atmosphere",
          title: "课堂氛围",
          score: evaluate.atmosphere || 0,
          desc: this.getScoreDesc(evaluate.atmosphere)
        },
        {
          key: "logic",
          title: "逻辑严谨",
          score: evaluate.logic || 0,
          desc: this.getScoreDesc(evaluate.logic)
        },
        {
          key: "style",
          title: "形式新颖",
          score: evaluate.style || 0,
          desc: this.getScoreDesc(evaluate.style)
        }
      ];
    },
    getTeacherCourseItems(evaluate) {
      return [
        {
          key: "guidanceObjective",
          title: "辅导目标",
          score: evaluate.guidanceObjective || 0,
          desc: this.getScoreDesc(evaluate.guidanceObjective)
        },
        {
          key: "learningAttitude",
          title: "学习态度",
          score: evaluate.learningAttitude || 0,
          desc: this.getScoreDesc(evaluate.learningAttitude)
        },
        {
          key: "concentrate",
          title: "精力集中",
          score: evaluate.concentrate || 0,
          desc: this.getScoreDesc(evaluate.concentrate)
        },
        {
          key: "previewReview",
          title: "预习复习",
          score: evaluate.previewReview || 0,
          desc: this.getScoreDesc(evaluate.previewReview)
        },
        {
          key: "homework",
          title: "课后作业",
          score: evaluate.homework || 0,
          desc: this.getScoreDesc(evaluate.homework)
        }
      ];
    },
    getScoreDesc(val) {
      let config = scoreConfig.find(item => item.value == val);
      if (!config) return undefined;
      return config.desc;
    }
  },
  watch: {
    items_teachTo: {
      handler: function(val) {
        xdapp.util.vue.commitActionStatus(
          val.every(item => item.score) &&
            this.evaluate_teachTo[this.code].isEdit
        );
        /*if(val.every(item => item.score) && !this.courseInfo.customers[this.code].evaluate) {
						xdapp.util.vue.commitActionStatus(val.every(item => item.score) && !this.courseInfo.customers[this.code].evaluate, val, this.code);
					}*/
      },
      deep: true
    }
    /*items_studentTo: {
				handler: function(val) {
					xdapp.util.vue.commitActionStatus(val.every(item => item.score) && !this.courseInfo.customers[this.code].teacherEvaluate);
					if(val.every(item => item.score) && !this.courseInfo.customers[this.code].teacherEvaluate) {
						xdapp.util.vue.commitActionStatus(val.every(item => item.score) && !this.courseInfo.customers[this.code].teacherEvaluate, val, this.code);
					}
				},
				deep: true
			}*/
  },
  computed: {
    courseID() {
      return this.$route.query.courseID;
    },
    assignID() {
      return this.$route.query.assignID;
    },

    businessType() {
      return this.$route.query.businessType;
    },
    showEvaluate() {
      return (
        this.courseInfo.assignStatus == assignStatus.Confirmed &&
        this.courseInfo.businessType !== 4
      );
    },
    type() {
      return this.$route.query.type;
    },
    entry() {
      return this.$route.query.entry;
    },
    customerID() {
      return this.$route.query.customerID;
    },
    teacherID() {
      return this.$route.query.teacherID;
    }
  },
  components: {
    courseInfo,
    courseEvaluate,
    Scroll
  }
};
</script>
<style>
.xd-header {
  position: fixed;
  top: 0;
  left: 0;
}
/* html,
body {
  height: 100%;
  overflow: hidden;
  background: #fff;
} */
</style>
<style lang="scss" scoped>
.xdapp-feedback-container {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: scroll;
    background: #fff;
  }
}

.ppts-header {
  background: url(~@/public/asset/img/home/bj-pic.png) repeat-x;
  padding-top: torem(-100);
  .mui-icon {
    color: #fff;
    img {
      width: 24px;
      height: 24px;
      margin-left: torem(-150);
    }
  }
  .mui-pull-right {
    color: #fff;
    padding-right: torem(10);
  }
}

.pop-box {
  /*position: fixed;*/
  width: 100%;
  height: 100%;
  background: #fff;
  border-radius: torem(5);
  .main {
    padding: torem(26) torem(23) 0 torem(23);
    background: #fff;
  }
}

.studentList {
  display: flex;
  overflow-x: scroll;
  width: calc( 100vw - 1.22666rem )
}

.studentList::-webkit-scrollbar {
  display: none;
}

.btn {
  margin: 0 3px;
  border: none;
}

.checked {
  color: skyblue;
  border-bottom: 1px solid skyblue;
}

.aleardy:after {
  content: "\2714";
}

.students {
  line-height: torem(30);
}
</style>