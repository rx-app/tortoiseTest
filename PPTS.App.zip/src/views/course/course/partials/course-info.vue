<template>
  <div>
    <div class="top" v-if="courseInfo.businessType">
      <div v-if="type" class="left">
        <img v-if="imgSrc" :src="imgSrc" />
        <img v-else-if="userGender==1" src="~@/public/asset/img/user/boy.png" alt />
        <img v-else-if="userGender==2" src="~@/public/asset/img/user/girl.png" alt />
      </div>
      <div v-if="!type" class="left">
        <img v-if="imgSrc" :src="imgSrc" />
        <img v-else-if="userGender==1" src="~@/public/asset/img/user/teacher-man.png" alt />
        <img v-else-if="userGender==2" src="~@/public/asset/img/user/teacher-woman.png" alt />
      </div>
      <div class="right">
        <div class="name">
          <span
            class="mui-badge mui-badge-warning"
            v-if="courseInfo.gradeName"
          >{{courseInfo.gradeName}}</span>
          <span
            class="mui-badge mui-badge-purple"
            v-if="courseInfo.subjectName"
          >{{courseInfo.subjectName}}</span>
          <!-- <span
            class="mui-badge mui-badge-danger"
            v-if="courseInfo.businessType==2 && courseInfo.assignStatus==1 && courseInfo.isConfirmed"
          >已点名</span> -->
          <span
            class="mui-badge mui-badge-success"
            v-if="courseInfo.assignStatus"
          >{{courseInfo.assignStatus | assignStatus}}</span>
          <span class="mui-badge mui-badge-blue" v-if="courseInfo.amount">{{courseInfo.amount}}课时</span>
        </div>
        <div class="teachar">
          <!--v-if="courseInfo.categoryType==1 || courseInfo.assignStatus==1"-->
          <div v-if="currentJobType!==3 && courseInfo.teacherName">
            <span>教师</span>
            <span>:</span>
            <b>{{courseInfo.teacherName}}</b>
          </div>
          <span v-if="courseInfo.customers">学生</span>
          <span>:</span>
          <b
            v-for="(item,index) in courseInfo.customers"
            :key="index"
          >{{item.customerName | substr(4)}}</b>
        </div>
        <div
          class="time"
        >{{courseInfo.startTime | dateFormat({locale: 'zh-CN'})}} {{courseInfo.startTime | timeRange(courseInfo.endTime, {locale: 'zh-CN'})}}</div>
      </div>
    </div>
    <h5 v-if="courseInfo.businessType && !isLessonSign && entry=='sureCourseBtn'">{{isLessonSignFalseReason}}</h5>
  </div>
</template>
<script>
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import store from "@/store";
import * as types from "@/store/mutation-types";
export default {
  data() {
    return {
      currentJobType: 1,
      userGender: 1,
      imgSrc: ""
    };
  },
  props: [
    "courseInfo",
    "customerInfoImg",
    "teacherInfoImg",
    "type",
    "customerID",
    "teacherID",
    "isLessonSign",
    "isLessonSignFalseReason",
    "entry"
  ],
  methods: {
    getUserIcons() {
      console.log("重新执行");
      console.log(this.imgSrc);
      var userIcons = this.$store.state.headList.slice() || [];
      var curIcon = null;
      var _this = this;
      if (this.type) {
        curIcon = userIcons.find(i => i.userID === this.customerID);
        if (curIcon) {
          this.imgSrc = curIcon.imgData;
        } else if (this.customerInfoImg[0] && this.customerInfoImg[0].iconID) {
          getHead(
            {
              iconID: this.customerInfoImg[0].iconID
            },
            result => {
              let obj = {
                userID: _this.customerID,
                imgData: result
              };
              userIcons.push(obj);
              this.imgSrc = result;
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        } else {
          this.userGender = this.customerInfoImg[0].gender;
        }
      } else {
        curIcon = userIcons.find(i => i.userID === this.teacherID);
        if (curIcon) {
          this.imgSrc = curIcon.imgData;
        } else if (this.customerInfoImg[0] && this.teacherInfoImg[0].iconID) {
          getHead(
            {
              iconID: this.teacherInfoImg[0].iconID
            },
            result => {
              let obj = {
                userID: _this.teacherID,
                imgData: result
              };
              userIcons.push(obj);
              this.imgSrc = result;
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        } else {
          this.userGender = this.teacherInfoImg[0].gender;
        }
      }
    }
  },
  updated() {
    this.currentJobType = m2.cache.get("ppts-current-job").jobType;
  },
  watch: {
    courseInfo() {
      this.getUserIcons();
    }
  }
};
</script>
<style lang="scss" scoped>
.top {
  padding-bottom: torem(26);
  border-bottom: 1px dashed #ddd;
  display: flex;
  .subject-container {
    display: inline-block;
    width: torem(60);
    height: torem(60);
    margin-right: torem(15);
    border-radius: 50%;
    text-align: center;
    color: #fff;
    font-size: torem(16);
    .subject-name {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100%;
      .other {
        font-size: torem(14);
      }
    }
  }
  .left {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: torem(10);
    img {
      height: torem(80);
      width: torem(80);
      vertical-align: top;
      border-radius: 50%;
    }
  }
  .right {
    vertical-align: top;
    display: inline-block;
    display: flex;
    flex-direction: column;
    justify-content: center;
    .name {
      margin-bottom: torem(10);
      font-size: torem(16);
      color: #666666;
    }
    .teachar {
      margin-bottom: torem(10);
      font-size: torem(16);
      color: #666666;
      line-height: torem(24);
      b {
        padding-left: torem(5);
        margin-right: torem(10);
      }
      span {
        font-size: torem(14);
        color: #2a2a2a;
        margin: 0 torem(2);
      }
    }
    .time {
      font-size: torem(13);
      color: #666666;
    }
  }
}

.checked {
  background: green;
  color: #fff;
}
h5 {
  line-height: torem(40);
  color: red;
  text-align: center;
}
</style>