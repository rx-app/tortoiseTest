﻿<template>
  <div class="bottom">
    <div class="tit">{{evaluateConfig.title}}</div>
    <template v-if="!courseInfo.customers[code][type] || evaluate[code]['isEdit']">
      <ul>
        <li v-for="(item,index) in this.items" :key="index">
          <span class="title">{{item.title}}</span>
          <i
            class="star"
            v-for="(score,index) in evaluateConfig.scoreConfig"
            :class="{on: score.value <= item.score}"
            v-if="showOne"
            @click="evaluateHandle(item.key, score.value, score.desc)"
            :key="index"
          ></i>
          <i
            class="star"
            v-for="(score,index) in evaluateConfig.scoreConfig"
            v-if="!showOne"
            :class="{on: score.value <= item.score}"
            :key="index"
          ></i>
          <span class="tip">{{item.desc}}</span>
        </li>
      </ul>
      <div class="comment">
        <div class="tit">其它评论</div>
        <textarea
          v-if="!showOne"
          class="other-comment otherText"
          :disabled="!showOne"
          @focus="fnFocus"
          @blur="fnBlur"
        ></textarea>
        <textarea
          v-else
          v-model="evaluate[code].content"
          class="other-comment yoText"
          :disabled="!showOne"
          @focus="fnFocus"
          @blur="fnBlur"
        ></textarea>
      </div>
    </template>
    <template v-if="courseInfo.customers[code][type] && !(evaluate[code]['isEdit'])">
      <ul>
        <li v-for="(item,index) in this.items" :key="index">
          <span class="title">{{item.title}}</span>
          <i
            class="star"
            v-for="(score,index) in evaluateConfig.scoreConfig"
            :class="{on: score.value <= item.score}"
            :key="index"
          ></i>
          <span class="tip">{{item.desc}}</span>
        </li>
      </ul>
      <div class="comment">
        <div class="tit">其它评论</div>
        <textarea
          v-if="!showOne && !evaluate[code].content"
          class="other-comment otherText"
          :disabled="!showOne"
          @focus="fnFocus"
          @blur="fnBlur"
        ></textarea>
        <textarea

          class="other-comment other"
          v-model="evaluate[code].content"
          :disabled="true"

          @click="fnWheel"
          @focus.prevent.stop="fnFocus"
          @blur.prevent.stop="fnBlur"
          
        ></textarea>
        <!--<div class="" style="border:none">
					<p>{{evaluate.content}}</p>
        </div>-->
      </div>
    </template>
  </div>
</template>
<script>
import { ASSIGN_STATUS } from "@/constants";
import Scroll from "@/components/scroll/index";

function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
    // 这行本来是解决--消除小键盘和输入框之间的间隙的
    // 但是，这个页面加这行代码会造成顶部会出现白条
    // 去掉之后，反而不会有bug，原因不明

    // 顶部白边问题的产生原因是focus和blur事件没有加上，上面有4处textarea
    // better-scroll要加在父组件上
    // 底部黑边是better-scroll产生的,如果better-scroll不放在最外层，就会有底部黑边,这个黑色是通过css可以修改，并非app的背景色
    // 如果页面高度太小，页会产生底部黑边，可padding-bottom: 400px;解决
    // absolute元素可以覆盖在黑边上面，达到消除黑边的作用，给wrap容器设置一个postion：absolute；可以消除底部黑边
    //主页面在点击输入框之后上移是因为页面里用了position:absolute
  }
}
function resize2() {
  //*12*点击输入框时，小键盘挡住了输入框
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
export default {
  data() {
    return {
      showOne: false
    };
  },
  props: ["courseInfo", "evaluateConfig", "evaluate", "items", "code", "type"],
  methods: {
    fnWheel(){
      console.log(1)
      mui.toast(1)
    },
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "765px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
        //mui.alert('---tttt----')
        //mui('header')[0].style.transform='translateY(-10px)'
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    evaluateHandle(key, value, desc) {
      console.log(key, value, desc);
      let item = this.items.find(item => item.key == key);
      item.score = value;
      item.desc = desc;

      this.evaluate[this.code][key] = value;
      this.evaluate[this.code]["isEdit"] = true;
      //this.courseInfo.customers[this.code].evaluate[key]=value;
    }
  },
  created() {
    const currentJobName = m2.cache.get("ppts-current-user").displayName;
    if (currentJobName == this.courseInfo.teacherName) {
      this.showOne = true;
    }
    console.log(this.evaluate[this.code]);

    if (this.evaluate[this.code] === "undefined") {
      this.evaluate[this.code] = {};
      this.evaluate[this.code].content = "";
    }
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
    // document.body.style.overflow = "scroll";
    // document.querySelector("html").style.overflow = "scroll";
  },
  components: {
    Scroll
  }
};
</script>

<style lang="scss" scoped>
i.star {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/star.png) no-repeat;
  background-size: 100%;
  width: torem(20);
  height: torem(20);
  margin-right: torem(5);
}

i.star.on {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/staron.png) no-repeat;
  background-size: 100%;
  width: torem(20);
  height: torem(20);
  margin-right: torem(5);
}

.bottom {
  .tit {
    font-size: torem(15);
    font-weight: bold;
    color: #666;
    padding-top: torem(15);
  }
  ul {
    font-size: torem(13);
    color: #666;
    padding: 0 torem(10);
    li {
      margin-top: torem(10);
      height: torem(30);
      line-height: torem(30);
      span.title {
        width: 25%;
        display: inline-flex;
      }
      span.tip {
        padding-left: torem(16);
      }
    }
  }
  .comment {
    .tit {
      font-size: torem(13);
      font-weight: normal;
      color: #666;
      margin: torem(16) 0;
      padding: 0 torem(10);
    }
    .other-comment {
      width: torem(272);
      height: torem(95);
      margin: 0 torem(10);
      color: #666;
      border: none !important;
    }
    .yoText {
      /*border: none!important;*/
      border: 1px #eee solid !important;
      // overflow-y: hidden;
    }
    .other,
    .yoText {
      padding: torem(5) torem(10);
      font-size: torem(15);
    }
  }
}

.otherText {
  border: none !important;
  text-align: center;
  line-height: 80px;
  overflow-y: hidden;
}

input:disabled,
textarea:disabled {
  -webkit-text-fill-color: #000 !important;
  -webkit-opacity: 1 !important;
  color: #000 !important;
}
</style>