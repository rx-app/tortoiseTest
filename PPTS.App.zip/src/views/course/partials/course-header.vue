{<template>
	<div class="xd-customer-list-nav" v-if="showHeader" id="course-head">
		<router-link v-for="(item,index) in items" :to="{name:item.pathname}" :key="index" class="item" tag="div" v-if='isShowNav(item.functions)'>
			<img :src="$route.name == item.pathname ? item.icon_active : item.icon" alt="" class="icon">
			<span class="txt">{{item.title}}</span>
		</router-link>
	</div>
</template>
<script>
	import { COURSE_INDEX_ALL} from '@/constants'

	export default {
		data() {
			return {
				showHeader: true,
				items: COURSE_INDEX_ALL
			}
		},
		activated () {
			this.initPage()
		},
		created () {
			this.initPage()
		},
		methods:{
			initPage () {
				let showObjs = []
				this.items.map(one => {
					if (this.isShowNav(one.functions)) {
						showObjs.push(one)
					}
				})
				if (showObjs.length === 1) {
					this.showHeader = false
				}
			},
			isShowNav(functions){
				return m2.util.getPermionLoad(functions);
			}
		}
	}
</script>
<style lang="scss" scoped>
	.xd-customer-list-nav {
		height: torem(72);
		display: flex;
		align-items: center;
		text-align: center;
		background: #fff;
		margin-bottom: -0.32rem;
		.item {
			display: inline-block;
			width: torem(58);
			flex: 1;
			.icon {
				width: torem(28);
				height: torem(28);
			}
			.txt {
				display: block;
				font-size: torem(14);
				color: #4b5160;
				line-height: torem(20);
			}
		}
	}
</style>