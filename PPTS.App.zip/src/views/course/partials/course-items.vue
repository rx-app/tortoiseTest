﻿<template>
	<div class="ppts-course-list">
		<ul class="course-list" v-if="!type">
			<li v-for="(course,index) in courseList" @tap="goTeacherDetail(course)" :key="index" class="item" v-if="(course.peoples>0 && (course.businessType == 2 || course.businessType == 3))|| course.businessType == 1">
				<!--<img :src="course.subject?require(`@/public/asset/img/course/${course.subject}.png`):require(`@/public/asset/img/course/none.png`)" alt="">-->
				<div class="subject-container" :class="(!course.subject || course.subject>7) ? 'subject' :'subject'+course.subject">
					<span class="subject-name" v-if="course.subject" :style="course.subjectName.length<=4 ? 'font-size:14px' : 'font-size:12px'"><strong>{{course.subjectName}}</strong></span>
					<span class="subject-name other" v-else>
                <strong>不限科目</strong>
              </span>
				</div>
				<div class="course-info">
					<div class="top">
						<div class="category">{{course.categoryTypeName}}</div>
						<div class="time">
							{{course.startTime | dateFormat}}&nbsp;{{course.startTime | timeFormat}}-{{course.endTime | timeFormat}}
						</div>
					</div>
					<div class="bottom">
						<div class="teacher">教师：{{course.teacherName}}</div>

						<div class="text">

							<div class="evaluate amount" v-if="course.amount">
								<span class="rate go">{{course.amount}}课时</span>
							</div>

							<div class="evaluate assign" v-if="course.assignStatusName">
								<span class="rate go assign">{{course.assignStatusName}}</span>
							</div>
							<div class="evaluate assign" v-else>
								<span class="rate go assign">{{course.assignStatus | assignStatus}}</span>
							</div>
							<!-- <div class="evaluate assign" v-if="course.businessType==2 && course.assignStatus==1 && course.isConfirmed">
								<span class="rate go assign">已点名</span>
							</div> -->

							<div class="evaluate" v-if="showOne">
								<span class="rate" v-if="course.isEvaluate || course.assignStatus==1"></span>
								<span class="rate gos" v-else>待评价</span>
							</div>
							<div class="evaluate" v-if="!showOne">
								<span class="rate" v-if="course.isEvaluate"><i class="star on"></i></span>
								<span class="rate" v-else></span>
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
		<ul class="course-list" v-if="type">
			<li v-for="(course,index) in courseList" @tap="goStudentDetail(course)" :key="index" class="item" v-if="((course.course.peoples>0 || !showOne) && (course.course.businessType == 2 || course.course.businessType == 3))|| course.course.businessType == 1">
				<div class="subject-container" :class="(!course.course.subject || course.course.subject>7) ? 'subject' :'subject'+course.course.subject">
					<span class="subject-name" v-if="course.course.subject" :style="course.course.subjectName.length<=4 ? 'font-size:14px' : 'font-size:12px'"><strong>{{course.course.subjectName}}</strong></span>
					<span class="subject-name other" v-else>
                <strong>不限科目</strong>
              </span>
				</div>
				<div class="course-info">
					<div class="top">
						<div class="category">{{course.course.categoryTypeName}}</div>
						<div class="time">
							{{course.course.startTime | dateFormat}}&nbsp;{{course.course.startTime | timeFormat}}-{{course.course.endTime | timeFormat}}
						</div>
					</div>
					<div class="bottom">
						<div class="teacher">学生：{{course.course.customerName}}</div>

						<div class="text">
							<div class="evaluate amount" v-if="course.course.amount">
								<span class="rate go">{{course.course.amount}}课时</span>
							</div>

							<div class="evaluate assign" v-if="course.course.assignStatusName">
								<span class="rate go assign">{{course.course.assignStatusName}}</span>
							</div>
							<div class="evaluate assign" v-else>
								<span class="rate go assign">{{course.course.assignStatus | assignStatus}}</span>
							</div>
                            <!-- <div class="evaluate assign" v-if="course.course.businessType==2 && course.course.assignStatus==1 && course.course.isConfirmed">
								<span class="rate go assign">已点名</span>
							</div> -->
							<div class="evaluate" v-if="showOne">
								<span class="rate" v-if="course.isEvaluate ||  course.course.assignStatus==1"></span>
								<span class="rate gos" v-else>待评价</span>
							</div>
							<div class="evaluate" v-if="!showOne">
								<span class="rate" v-if="course.isEvaluate"><i class="star on"></i></span>
								<span class="rate" v-else></span>
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				showOne: false
			}
		},
		props: ['courseList', 'type', 'tab'],
		methods: {
			goTeacherDetail(course) {
				if(course.assignStatus == 1 || course.assignStatus == 8) {
					this.$router.push({
						name: 'course-detail',
						query: {
							assignID: course.assignID,
							courseID: course.courseID,
							businessType: course.businessType,
							teacherID:course.teacherID,
							customerID:course.customerID,
							type: this.type,
							tab: this.tab
						}
					})
				} else {
					if(this.showOne) {
						if(course.isEvaluate) {
							this.$router.push({
								name: 'course-even-evaluate',
								query: {
									courseID: course.courseID,
									businessType: course.businessType,
									teacherID:course.teacherID,
							        customerID:course.customerID,
									type: this.type,
									tab: this.tab
								}
							})

						} else {
							this.$router.push({
								name: 'course-evaluate',
								query: {
									courseID: course.courseID,
									businessType: course.businessType,
									teacherID:course.teacherID,
							        customerID:course.customerID,
									type: this.type,
									tab: this.tab
								}
							})
						}
					} else {
						this.$router.push({
							name: 'course-other-evaluate',
							query: {
								courseID: course.courseID,
								businessType: course.businessType,
								teacherID:course.teacherID,
							    customerID:course.customerID,
								type: this.type,
								tab: this.tab
							}
						})
					}

				}

			},
			goStudentDetail(course) {
				// window.bbObj = this.backObj
				if(course.course.assignStatus == 1 || course.course.assignStatus == 8) {
					this.$router.push({
						name: 'course-detail',
						query: {
							assignID: course.course.assignID,
							courseID: course.course.courseID,
							businessType: course.course.businessType,
							teacherID:course.course.teacherID,
							customerID:course.course.customerID,
							type: this.type,
							tab: this.tab
						}
					})
				} else {
					if(this.showOne) {
						if(course.isEvaluate) {
							this.$router.push({
								name: 'course-even-evaluate',
								query: {
									courseID: course.course.courseID,
									businessType: course.course.businessType,
									teacherID:course.course.teacherID,
							        customerID:course.course.customerID,
									type: this.type,
									tab: this.tab
								}
							})

						} else {
							this.$router.push({
								name: 'course-evaluate',
								query: {
									courseID: course.course.courseID,
									businessType: course.course.businessType,
									teacherID:course.course.teacherID,
							        customerID:course.course.customerID,
									type: this.type,
									tab: this.tab
								}
							})
						}
					} else {
						this.$router.push({
							name: 'course-other-evaluate',
							query: {
								courseID: course.course.courseID,
								businessType: course.course.businessType,
								teacherID:course.course.teacherID,
							    customerID:course.course.customerID,
								type: this.type,
								tab: this.tab
							}
						})
					}
				}
			}

		},
		created() {
			const currentJobName = m2.cache.get('ppts-current-job').jobType;
			if(currentJobName == 3) {
				this.showOne = true;
			}
		}
	}
</script>
<style lang="scss" scoped>
	.ppts-course-list {
		.subject-container {
			display: inline-block;
			width: torem(40);
			height: torem(40);
			margin-right: torem(15);
			border-radius: 50%;
			text-align: center;
			color: #fff;
			font-size: torem(16);
			.subject-name {
				display: flex;
				justify-content: center;
				align-items: center;
				height: 100%;
				.other {
					font-size: torem(14);
				}
			}
		}
		.item {
			position: relative;
			height: 70px;
			border-bottom: 1px dashed #eee;
			padding: 15px 0 0 20px;
			display: flex;
			img {
				width: 40px;
				height: 40px;
				margin-right: 14px;
				vertical-align: middle;
			}
			.desc {
				display: inline-block;
				vertical-align: middle;
				.name {
					font-size: 14px;
					color: #1f2d3d;
					line-height: 20px;
				}
				.teacher {
					font-size: 12px;
					color: #888;
					line-height: 16px;
					margin-top: 5px;
				}
			}
			.time {
				position: absolute;
				right: 16px;
				top: 15px;
				font-size: 12px;
				color: #999999;
			}
			.type {
				line-height: 20px!important;
				position: absolute;
				right: 16px;
				bottom: 10px;
				font-size: 14px;
			}
		}
	}
	
	.course-info {
		flex: 1;
		height: 80%;
		.top {
			font-size: torem(13);
			display: flex;
			justify-content: space-between;
			height: 50%;
			align-items: center;
		}
		.bottom {
			display: flex;
			height: 50%;
			width: 100%;
			align-items: center;
			font-size: torem(13);
			.teacher {
				width: torem(96);
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}
			.evaluate {
				line-height: 20px !important;
				/*position: absolute;*/
				right: torem(15);
				bottom: 10px;
				font-size: 14px;
				.rate {
					background-color: #fff;
					font-size: torem(12);
					line-height: 1;
					display: inline-block;
					padding: 3px 6px;
					border-radius: 100px;
				}
				.go {
					color: #6D6D72;
					border: 1px solid #6D6D72;
					/*#fd9106*/
				}
				.gos {
					color: #fd9106;
					border: 1px solid #fd9106;
					/*#fd9106*/
				}
				span.assign{
					margin-right: 0;
				}
				i.star {
					display: inline-block;
					vertical-align: top;
					background: url(~@/public/asset/img/course/star.png) no-repeat;
					background-size: cover;
					width: torem(18);
					height: torem(18);
					margin-right: torem(5);
				}
				i.star.on {
					display: inline-block;
					vertical-align: top;
					background: url(~@/public/asset/img/course/staron.png) no-repeat;
					background-size: cover;
					width: torem(18);
					height: torem(18);
				}
			}
			.assign {
				margin-right: torem(5);
			}
			.amount {
				margin-right: torem(10);
			}
		}
		.text {
			display: flex;
			align-items: center;
			width: 68%;
			height: 100%;
			padding-right: 14px;
			justify-content: flex-end;
		}
	}
</style>