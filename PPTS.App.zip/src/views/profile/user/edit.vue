template>
  <div  class="user-edit-box">
    <div v-if="canEdit('profile-user-edit-name')" class="form-input">
      <input type="text" v-model="form.alias" class="mui-input-clear" placeholder="请输入昵称" data-input-clear="5"><span class="mui-icon mui-icon-clear " @click="clear" :style="form.alias.length ? '' : 'display:none'" ></span>

    </div>
    <div v-if="canEdit('profile-user-edit-sex')">
        <ul class="mui-table-view mui-table-view-radio">
          <li v-for="item in sexList" class="mui-table-view-cell" @click="selectedSex(item)" :class="form.gender === item.key ? 'mui-selected' : ''">
            <a class="mui-navigate-right">{{item.value}}</a>
          </li>
        </ul>
    </div>
    <div v-if="canEdit('profile-user-edit-area')">
      <v-distpicker type="mobile" @selected="getArea" :province="userInfo.provinceName" :city="userInfo.cityName" :area="userInfo.countyName"></v-distpicker>
    </div>
  </div>
</template>
<script>
  import {mapState} from 'vuex';
  import {loadUserInfo} from '@/api/common/common-api';
  import {updateUserInfo} from '@/api/user/user-api';
  import VDistpicker from 'v-distpicker'
  import {ACTION_TYPES} from '@/constants';

  export default{
    computed: {
      ...mapState({
        userInfo: state => state
      })
    },
    watch: {
      'form.alias': {
        handler: function (val) {
          this.validateForm('profile-user-edit-name', val)
        },
        deep: true
      },
      'form.gender': {
        handler: function (val) {
          this.validateForm('profile-user-edit-sex', val)
        },
        deep: true
      }
    },
    created(){
      this.getUserInfo()
    },
    data(){
      return {
        form: {
          alias: '',
          userId:'',
          gender: '',
          provinceCode: '',
          cityCode: '',
          countyCode: ''
        },
        sexList: [{
          key: 1,
          value: '男'
        }, {
          key: 2,
          value: '女'
        }]
        }
    },
    methods: {
      selectedSex (item) {
        this.form.gender = item.key
      },
      getArea(area){
        this.form.provinceCode = area.province.code
        this.form.cityCode = area.city.code
        this.form.countyCode = area.area.code
        xdapp.util.vue.commitActionStatus(true);
      },
      validateForm (editName, val) {
        if (this.canEdit(editName)) {
          xdapp.util.vue.commitActionStatus(val !== '' && val !== null);
        }
      },
      clear(){
        this.form.alias=''
      },
      canEdit (editName) {
        if (this.$route.name === editName) {
          return true
        }
        return false
      },
      getUserInfo () {
        loadUserInfo()
        this.form.alias = this.userInfo.displayName;
        this.form.userId = this.userInfo.userId;
        this.form.gender = this.userInfo.gender;
        xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
      },
      submit () {
        xdapp.util.vue.commitActionStatus(false);
        // updateUserInfo(this.form, () => {
          loadUserInfo('upd')
          mui.toast("修改成功");
          setTimeout(() => {
            this.$router.push({name: 'profile-user-userInfo'});
          }, 3000)
        // });
      }
    },
    components: {
      VDistpicker
    }
  }
</script>

<style scoped>
  .sex {
    padding: 5px 10px;
    background: #fff;
    margin: 5px;
    color: #888;
  }

  .sex.on {
    color: rgb(216, 203, 21)
  }

  .sex.on::after {
    content: '√';
    position: absolute;
    right: 10px;
    transform: scaleX(1.6);
    color: rgb(56, 199, 127)
  }

</style>
<style>
.user-edit-box .mui-icon{
  position: absolute;
  right: 2%;
  top: 10%;
  transform: translateY(10%);
}
.user-edit-box .form-input{
  position: relative;
}
</style>
