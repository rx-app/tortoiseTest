﻿<template>
	<div class="mui-content" id="home">
		<list-items :items="items"></list-items>
	</div>
</template>
<script>
	import { mapState } from 'vuex';
	import { loadUserInfo } from '@/api/common/common-api';
	import ListItems from '@/components/list-items/';
	import { ACTION_TYPES } from '@/constants';

	export default {
		data() {
			return {}
		},
		async created() {
			await loadUserInfo();
			xdapp.util.user.getCurrentHead();
		},
		computed: {
			...mapState({
				userInfo: state => state,
			}),
			items() {
				return [{
						title: '头像',
						routerLink: true,
						pathname: {
							//name: "profile-edit-avatar",
							params: {
								id: this.userId
							}
						},
						img: true
					},
					{
						title: '名字',
						value: this.userInfo.displayName
					},
					{
						title: 'OA',
						value: this.userInfo.logOnName
					},
					{
						title: '联系方式',
						value: this.userInfo.userInfo.mp
					},
					{
						title: '当前岗位',
						value: this.userInfo.currentJob.name,
						id:this.userInfo.currentJob.id,
						//sel:true
					}
				];
			}
		},
		components: {
			ListItems
		}
	}
</script>

<style scoped>

</style>