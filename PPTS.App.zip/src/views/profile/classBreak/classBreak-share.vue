<template>
		<scroll @tap.native='fnTap' :data="messages" :listen-scroll="true" :probe-type="3" :pulldown="true"  class="scroll-container" ref="listview">

	<div class="wrap" >
			<p  class="top">生活很平凡，但我们不平凡，把激励你的话分享给大家吧！</p>
			<div  class="suggest">
				<textarea @input="setNum" maxlength="200" v-model='inpVal' @focus="fnFocus" @blur="fnBlur" placeholder="请输入不少于十个字" id="" cols="30" rows="10"></textarea>
				<span class="count"><span class="num">{{num}}</span>/{{maxNum}}</span>
			</div>
			<p class="bottom">您的分享被录用后，会在掌上学大首页显示，请注意文明发言。分享不限风格，转载自创均可，最好能引发共鸣，激人上进。孩子们也能看到哦！</p>
	</div>
		</scroll>

</template>

<script>
	import { send } from '@/api/classBreak/classBreak-api'
	import { ACTION_TYPES } from '@/constants';
	import Scroll from '@/components/scroll/index';

	function resize(){
		if(mui.os.ios){
			plus.webview.currentWebview().setStyle({'bottom':'-1px'})
		}
	}
	export default {
		data() {
			return {
				inpVal: '',
				num: 0,
				maxNum: 200,
			}
		},
		methods: {
			fnTap(e){
				if(!mui.os.ios){
				if( e.target.tagName=='TEXTAREA' ||  e.target.tagName=='INPUT' ){
					return
				}
				if( document.activeElement.tagName=='TEXTAREA' ||  document.activeElement.tagName=='INPUT' ){
					document.activeElement.blur();
				}
				}
			},
			fnFocus(){
				var ua = navigator.userAgent.toLowerCase();
				if(/iphone|ipad|ipod/.test(ua)) {
				var wv=plus.webview.currentWebview();
				let bottom=this.iosType=='4s'?'315px':'655px'
				
				wv.setStyle({'top':'0px'});
				wv.setStyle({bottom});
				plus.webview.currentWebview().setStyle({'background':'#fff'});
				

				}
			},
			fnBlur(){
				var ua = navigator.userAgent.toLowerCase();
				if(/iphone|ipad|ipod/.test(ua)) {
				// mui.toast(window.innerHeight)

				var wv=plus.webview.currentWebview();
				wv.setStyle({'top':'0px'});
				wv.setStyle({'bottom':'0px'});
				}
			},
			setNum(e) {
				this.num = this.calcLength(e.target.value);
				if(this.num > this.maxNum) {
					e.target.value = this.visitContent;
					this.num = this.maxNum;
				} else {
					this.visitContent = e.target.value;
				}
			},
			calcLength(str) {
				return str.length;
			},
			submit() {
				send({
					content: this.inpVal
				}, (res) => {
					mui.toast('已投妥，感谢您的分享!');
					var _this = this;
					setTimeout(function() {
						_this.$router.go(-1);
					}, 1000)
				})
			}

		},
		watch: {
			inpVal() {
				if(this.inpVal.length >= 10) {
					xdapp.util.vue.commitActionStatus(true);
				} else {
					xdapp.util.vue.commitActionStatus(false);
				}
			}
		},
		mounted() {
			xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
		},
		created(){
			// plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
			if(window.innerHeight<500){
						this.iosType='4s'
			}
			window.addEventListener('resize',resize)
		},
		destroyed(){
				window.removeEventListener('resize',resize)
		},
		components: {
			Scroll,
		},
	}
</script>
<style>
	.xd-header {
		position: fixed;
		top:0;
		left: 0;
	}
	html,body{
		height: 100%;
		overflow: hidden;
		background: #fff;
	}
</style>
<style lang='scss' scoped>
	.scroll-container {
		height: 100%;
		overflow: hidden;
		background: #fff;
	}
	.wrap {
		// position: absolute;
		background: rgb(239, 239, 244);
		width: 100%;
		height: 100%;
		overflow: hidden;
		box-sizing: border-box;
		padding-bottom: 1000px;
		.top {
			padding: 0px 18px;
			color: #333!important;
		}
		.bottom {
			padding: 0 18px;
			color: #333!important;
		}
		.suggest {
			margin: 10px 18px;
			display: block;
			text-align: right;
			box-sizing: border-box;
			background: #fff;
			border-radius: 5px;
			textarea {
				margin: 0;
				border: 0px;
				height: 100px;
				padding: torem(10);
				border: none;
				border-radius: 5px;
				font-size: torem(14)
			}
			>span {
				display: block;
				padding: 0 15px 5px;
			}
		}
	}
	
	.wrap p.top{
		margin-top: torem(15)
	}
</style>