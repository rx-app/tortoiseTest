<template>
	<div class="xd-mail-list">
		<router-link :to="{name:'adminParent'}" tag='h5' v-if='managParent'>管理家长分享<i class='iconfont icon-turn-right'></i></router-link>
		<mt-navbar v-model="selected" v-if='managParent'>
			<mt-tab-item id="1" @click.stop.prevent="switchTabs('1')">家长分享</mt-tab-item>
			<mt-tab-item id="2" @click.stop.prevent="switchTabs('2')">我的分享 </mt-tab-item>
		</mt-navbar>
		<!-- tab-container  -->
		<div id="cus-main-content" class="main-content">
			<mt-loadmore class="loadMore" :bottom-method="loadBottom" :auto-fill="false" :bottom-all-loaded="allLoaded" :bottom-distance=-70 ref="loadmore">
				<mt-tab-container v-model="selected">
					<mt-tab-container-item id="1" v-if='managParent'>
						<div class="students-list">
							<tip v-if="!parentList.length">
								<span>暂无家长分享</span>
							</tip>
							<ul class='list'>
								<li v-for='(item,index) in parentList' :class="[{activeLi:item.show}]" @click="changeLi(index,item)">
									<p><span>{{item.periodOfRelaxing.createTime | dateFormat({locale: 'zh-CN'})}}</span><b>{{item.userName}}</b></p>
									<p class="perContent">{{item.periodOfRelaxing.content}}</p>
								</li>
							</ul>
						</div>
					</mt-tab-container-item>
					<mt-tab-container-item id="2">
						<div class="students-list">
							<router-link :to="{name:'classBreak-share'}" tag='p' class="btn-box">我要分享</router-link>
							<tip v-if="!myList.length">
								<span>你还没分享哦！试试一键分享吧~~</span>
							</tip>
							<ul class='list'>
								<li v-for='(item,index) in myList' :class="[{activeLi:item.show}]" @click="changeLi(index,item)">
									<h6>{{item.createTime | dateFormat({locale: 'zh-CN'})}}</h6>
									<p class="perContent">{{item.content}}</p>
								</li>
							</ul>
						</div>
					</mt-tab-container-item>
				</mt-tab-container>
			</mt-loadmore>
		</div>
	</div>
</template>

<script>
	import Tip from '@/components/tip';
	import { load, loadParentPeriodOfRelaxing } from '@/api/classBreak/classBreak-api'
	export default {
		data() {
			return {
				selected: null,
				allLoaded: false,
				parentList: [],
				myList: [],
				count: 10,
				managParent: true
			}
		},
		methods: {
			changeLi(index, item) {
				var arrList = null;
				if(this.selected == 1) {
					arrList = this.parentList;
				} else {
					arrList = this.myList;
				}
				for(var i = 0; i < arrList.length; i++) {
					if(i !== index) {
						arrList[i].show = false;
					}
					if(i == index) {
						let obj = arrList[i];
						obj.show = !obj.show;
						this.$set(arrList, i, obj);
					}
				}
			},
			loadParentShare(time) {
				const params = {
					CreateTime: time ? time : m2.date.now(),
					count: this.count,
					sort: 1
				};
				loadParentPeriodOfRelaxing(params, (res) => {
					if(res.length < this.count) {
						this.allLoaded = true;
					} else {
						this.allLoaded = false;
					}
					this.parentList = this.parentList.concat(res);
				})
			},
			loadMyShare(time) {
				const params = {
					CreateTime: time ? time : m2.date.now(),
					count: this.count,
					sort: 1
				};
				load(params, (res) => {
					if(res.length < this.count) {
						this.allLoaded = true;
					} else {
						this.allLoaded = false;
					}
					this.myList = this.myList.concat(res);
				})
			},
			loadBottom() {
				if(this.selected == '1') {
					this.loadParentShare(this.parentList[this.parentList.length - 1].periodOfRelaxing.createTime);
				} else {
					this.loadMyShare(this.myList[this.myList.length - 1].createTime);
				}
				this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
			},
			setHeight() {
				let content = document.querySelector('#cus-main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 32 + 23;
					let headHight = document.querySelector('#course-head');
					console.log('stu-#course-head：' + headHight)
					if(headHight !== null) {
						content.style.height = 'calc(' + jHight + 'px)'
					} else {
						content.style.height = 'calc(' + jHight + 'px)'
					}
				}
			},
		},
		mounted() {
			this.selected = '1';
			this.setHeight();
			var currentJobType = m2.cache.get('ppts-current-job').jobType;
			if(currentJobType == 2) {
				this.managParent = true;
			} else {
				this.managParent = false;
				this.selected = '2';
			}

		},
		watch: {
			selected() {
				if(this.selected == 2) {
					this.parentList = [];
					this.loadMyShare();
				} else {
					this.myList = [];
					this.loadParentShare();
				}
			}
		},
		components: {
			Tip,
		}
	}
</script>

<style lang='scss' scoped>
	.main-content {
		overflow: auto;
	}
	
	.xd-mail-list {
		h5 {
			height: torem(40);
			line-height: torem(40);
			float: right;
			margin-right: torem(15);
			i {
				color: #ddd;
			}
		}
		.list {
			.activeLi {
				height: auto;
				.perContent {
					overflow: auto;
					white-space: normal;
				}
			}
			li {
				border-bottom: 1px solid #eee;
				padding: torem(10) torem(20);
				.perContent {
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
					margin-bottom: 0;
					margin-right: torem(16);
					width: 100%;
					word-wrap: break-word;
				}
				b {
					margin-left: torem(15);
					font-size: torem(14);
					font-weight: bold;
				}
			}
		}
	}
	
	.btn-box {
		background: #ff9966;
		color: #fff;
		border: none;
		width: 90%;
		height: torem(35);
		line-height: torem(35);
		text-align: center;
		margin: 10px auto;
		border-radius: 10px;
	}
	
	.list {
		padding-left: torem(10);
		padding-right: torem(10);
	}
</style>