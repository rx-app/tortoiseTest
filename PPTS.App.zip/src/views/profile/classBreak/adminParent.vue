<template>
	<div class="wrap">
		<div class='head'>
			<button :class="isShow?'active':''" :disabled="!isShow" @click='adopt()'>审核通过</button>
			<button :class="isShow?'active':''" :disabled="!isShow" @click='pass()'>取消显示</button>
		</div>
		<!--<button>全选</button>-->
		<div id="cus-main-content" class="main-content">
			<mt-loadmore class="loadMore" :bottom-method="loadBottom" :auto-fill="false" :bottom-all-loaded="allLoaded" :bottom-distance=-70 ref="loadmore">
				<tip v-if="!parentList.length">
					<span>暂无家长分享</span>
				</tip>
				<ol class='list' v-else>
					<li v-for='(item,index) in parentList' :class="[{activeLi:item.show}]" @click="changeLi(index,item)">
						<p><span>{{item.periodOfRelaxing.createTime | dateFormat({locale: 'zh-CN'})}}</span><b>{{item.customerName}}</b></p>
						<p class="perContent">{{item.periodOfRelaxing.content}}</p>
						<div class="mui-right" @click='checkedList(index)'>
							<input name="checkbox1" value="Item 1" type="checkbox">
						</div>
					</li>
				</ol>
			</mt-loadmore>
		</div>
	</div>
</template>

<script>
	import Tip from '@/components/tip';
	import { loadParentPeriodOfRelaxing, approve } from '@/api/classBreak/classBreak-api'
	export default {
		data() {
			return {
				parentList: [],
				count: 10,
				isShow: false,
				allLoaded: false,
			}
		},
		methods: {
			changeLi(index, item) {
				for(var i = 0; i < this.parentList.length; i++) {
					if(i !== index) {
						this.parentList[i].show = false;
					}
					if(i == index) {
						let obj = this.parentList[i];
						obj.show = !obj.show;
						this.$set(this.parentList, i, obj);
					}
				}
			},
			adopt() {
				var adopt = {};
				this.parentList.forEach(item => {
					if(item.current) {
						adopt[item.periodOfRelaxing.id] = true;
					}
				})
				approve(adopt, (res => {
					mui.toast('审核通过成功')
				}))
			},
			pass() {
				var adopt = {};
				this.parentList.forEach(item => {
					if(item.current) {
						adopt[item.periodOfRelaxing.id] = false;
					}
				})
				mui.confirm("取消显示后,不会在首页显示", "提示", (e) => {
					if(e.index) {
						approve(adopt, (res => {
							mui.toast('取消显示成功')
						}))
					}
				})
			},
			loadParentShare(time) {
				const params = {
					CreateTime: time ? time : m2.date.now(),
					count: this.count,
					sort: 1
				};
				loadParentPeriodOfRelaxing(params, (res) => {
					if(res.length < this.count) {
						this.allLoaded = true;
					} else {
						this.allLoaded = false;
					}
					this.parentList = this.parentList.concat(res);
				})
			},
			loadBottom() {
				this.loadParentShare(this.parentList[this.parentList.length - 1].periodOfRelaxing.createTime);
				this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
			},
			checkedList(index) {
				for(var i = 0; i < this.parentList.length; i++) {
					if(i == index) {
						let obj = this.parentList[i];
						obj.current = !obj.current;
						this.$set(this.parentList, i, obj);
					}
				}

			},
			setHeight() {
				let content = document.querySelector('#cus-main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight - 85 - 45 + 26;
					let headHight = document.querySelector('#course-head');
					console.log('stu-#course-head：' + headHight)
					if(headHight !== null) {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem - 2.88rem)'
					} else {
						content.style.height = 'calc(' + jHight + 'px - 0.4rem)'
					}
				}
			},
		},
		mounted() {
			this.setHeight();
			this.loadParentShare();
		},
		watch: {
			'parentList': {
				handler: function() {
					this.isShow = this.parentList.some((item, index) => {
						return item.current;

					})
					console.log(this.isShow)
				},
				deep: true
			}

		},
		components: {
			Tip,
		}
	}
</script>

<style lang='scss' scoped>
	.main-content {
		overflow: auto;
	}
	
	.head {
		width: 100%;
		line-height: torem(30);
		display: flex;
		button {
			flex: 1;
			text-align: center;
			background: #D5D5D5;
			height: 100%;
			color: #fff;
			margin: torem(10);
			border: none;
		}
		.active {
			background: orange;
			border: none;
		}
		li.on {
			background-image: linear-gradient(90deg, #FF9900 0%, #FFB82A 100%);
		}
	}
	
	.list {
		.activeLi {
			height: auto;
			.perContent {
				overflow: auto;
				white-space: normal;
			}
		}
		li {
			border-bottom: 1px solid #eee;
			padding: torem(10) torem(20);
			position: relative;
			.perContent {
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				margin-bottom: 0;
				margin-right: torem(16);
				width: 80%;
				word-wrap: break-word;
			}
			b {
				margin-left: torem(15);
				font-size: torem(14);
				font-weight: bold;
			}
			.mui-right {
				position: absolute;
				top: 50%;
				margin-top: -10px;
				right: 25px;
				input {
					width: torem(18);
					height: torem(18)
				}
			}
		}
	}
</style>