<template>
	<div class="xd-mail-list" v-if='detailList'>
		<h4>{{detailList.createTime  | dateFormat({locale: 'zh-CN'}) }}</h4>
		<p>{{detailList.content}}</p>
	</div>
</template>

<script>
	import { loadByID } from '@/api/classBreak/classBreak-api'
	export default {
		data() {
			return {
               detailList: null
			}
		},
		mounted(){
			loadByID(this.$route.query.id,(res)=>{
				this.detailList=res;
			})
		}

	}
</script>

<style lang='scss' scoped>
.xd-mail-list{
	padding: torem(0) torem(15);
	h4{
		margin-top: torem(20);
		margin-bottom: torem(15);
	}
}
</style>