<template>
	<div class="mui-content rx-profile">
		<ul class="mui-table-view header">
			<router-link :to="{name:'profile-user-userInfo'}">
				<li class="setting">
					<!--<a class="iconfont icon-setting"></a>-->
				</li>
				<li class="mui-table-view-cell mui-media">
					<p id="head-img" v-if="this.$store.state">
						<img v-if="currentHeadImg" :src="currentHeadImg">
						<img v-else-if='currentUserGender==2' src="~@/public/asset/img/user/teacher-woman.png" alt="" />
						<img v-else src="~@/public/asset/img/user/teacher-man.png" alt="" />
					</p>
					<div class="mui-media-body">
						<p><span class="name">{{alias}}({{loginNum}})</span>
							<span class="mui-ellipsis">当前岗位:<span class="account">{{userId}}</span></span>
						</p>
						<a class="iconfont icon-turn-right"></a>
					</div>
				</li>
			</router-link>
		</ul>
		<list-items :items="items"></list-items>
	</div>
</template>
<script>
	import { mapState } from 'vuex';
	import ListItems from '@/components/list-items/';
	import { PROFILE_INDEX, CACHE_KEYS } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api';
	export default {
		data() {
			return {
				items: PROFILE_INDEX,
			}
		},
		async created() {
			await loadUserInfo();
			xdapp.util.user.getCurrentHead();
		},
		computed: {
			...mapState({
				alias: state => state.displayName,
				loginNum: state => state.logOnName,
				userId: state => state.currentJob.name,
				//currentHeadImg: state => state.currentHeadImg.imgData,
				currentUserGender: state => state.currentUserGender,
			}),
			currentHeadImg() {
				if(this.$store.state.currentHeadImg && m2.cache.get(CACHE_KEYS.CURRENT_ICONARR)) {
					return this.$store.state.currentHeadImg.imgData || m2.cache.get(CACHE_KEYS.CURRENT_ICONARR).imgData
				}
			}
		},
		components: {
			ListItems
		}
	}
</script>
<style lang="scss" scoped>
	.rx-profile {
		padding-top: 0 !important;
		background: transparent !important;
		>.rx-list-items {
			margin-top: 15px;
		}
		.header {
			height: 149px;
			padding-top: 20px;
			color: #fff;
			background: url(~@/public/asset/img/bg/home-bg.png) repeat-x;
			background-size: 100% 260px;
		}
	}
	
	.setting {
		height: 20px;
		text-align: right;
		margin-right: 20px;
		.icon-setting {
			font-size: torem(25);
		}
	}
	
	#head-img {
		width: torem(64);
		height: torem(64);
		img {
			width: 100%;
			height: 100%;
			border-radius: 100%;
		}
	}
	
	.mui-media {
		display: flex;
	}
	
	.mui-media-body {
		display: flex;
		flex: 1;
		align-items: center;
		justify-content: space-between;
		color: #fff;
		margin-left: 15px;
		p {
			display: flex;
			flex-direction: column;
			span {
				color: #fff;
			}
		}
	}
	
	.icon-turn-right {
		font-size: torem(18);
	}
	
	.name {
		font-size: torem(17);
	}
	
	.mui-ellipsis {
		font-size: torem(14);
	}
	
	.mui-content>.mui-table-view:first-child {
		margin-top: 0;
	}
	
	.item {
		margin-top: 10px !important;
	}
	
	.rx-profile {
		.rx-list-items {
			margin-top: 0;
		}
	}
</style>