﻿<template>
  <div class="mui-content" id="home">
    <img ref="img" :src="avatar" alt="" class="avatar">
    <div class="input-wrap">
      <!-- 上传 -->
      <input type="file" @change="upload2()" capture="camera" ref="file" accept="image/*">
    </div>
    <div id="popove" ref='popover' class="mui-popover classifies mui-active" v-show="on">
      <my-text txt="拍照"></my-text>
      <my-text txt="从手机相册中选择"></my-text>
      <my-text txt="保存图片"></my-text>
      <my-text txt="取消" @click.native="on=false"></my-text>
    </div>
    <div class="mui-backdrop mui-active" style="" v-show="on"></div>
  </div>
</template>

<script>
import myText from "@/components/myText";
import { modifyHead } from "@/api/user/user-api";
import { CACHE_KEYS } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import { getHead } from "@/api/user/user-api";
export default {
  data() {
    return {
      on: false,
      task: null,
      avatar:'',
    };
  },
  components: {
    myText
  },
  async created() {
    await loadUserInfo();
    this.getAvatar();
  },
  mounted() {
    if (this.$route.query.done == 1) {
      this.$refs.img.src = localStorage.getItem("img");
    }
  },
  methods: {
    upload2(){
      let obj=new FileReader();
      obj.readAsDataURL(document.querySelector('input').files[0]);
      obj.onload =function(){
        window.$mysrc=this.result;
        $vue.$router.push({name:'profile-cropper'})
      }
    },
    getAvatar() {
      if (this.$route.query.done == 1) {
        return
      }
      if(m2.cache.get("rx-user-head") || m2.cache.get("rx-current-user").iconID){
        getHead(
          {
            iconID:
              m2.cache.get("rx-user-head") ||
              m2.cache.get("rx-current-user").iconID
          },
          (res => {
            this.avatar = res;
            // m2.cache.set('rx-user-head',res)
          })
        );
      }else{
        this.avatar=require('@/public/asset/img/home/head.png')
        return
      }
    },
    initBtn() {
      plus.nativeUI.actionSheet(
        {
          cancel: "取消",
          buttons: [{ title: "拍照" }, { title: "从相册中选择" }]
        },
        e => {
          //1 是拍照  2 从相册中选择
          switch (e.index) {
            case 1:
              this.appendByCamera();
              break;
            case 2:
              this.appendByGallery();
              break;
          }
        }
      );
    },
    appendByCamera() {
      var that = this;
      plus.camera.getCamera().captureImage(function(e) {
        console.log("e is" + e);
        plus.io.resolveLocalFileSystemURL(
          e,
          function(entry) {
            var path = entry.toLocalURL();

            document.querySelector(".avatar").src = path;
          },
          function(e) {
            mui.toast("读取拍照文件错误：" + e.message);
          }
        );
      });
    },
    appendByGallery() {
      plus.gallery.pick(path => {
        document.querySelector(".avatar").src = path;
        //cutImage(path)
        this.$router.push({ name: "profile-cropper", query: { path } });
      });
    },
    upload() {
      var mimeType = "jpg";
      function dataURLtoBlob(dataurl) {
        var arr = dataurl.split(","),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        mimeType = mime;
        return new Blob([u8arr], { type: mime });
      }
      //服务端接口路径
      var server = modifyHead()//"http://10.1.55.88/RxApp/Rx.Api/api/User/ModifyHead";

      //获取图片元素
      var files = document.querySelector(".avatar");
      var stream = dataURLtoBlob(files.src);

      var task;
      this.task = task;
      task = plus.uploader.createUpload(server, { method: "POST" }, function(
        t,
        status
      ) {
        //上传完成
        if (status == 200) {
          alert("上传成功：" + t.responseText);
        } else {
          alert("上传失败：" + t.responseText + status);
        }
      });

      var formData = new FormData();
      formData.append("headupload", stream, Date.parse(new Date()) + ".jpg");

      var request = new XMLHttpRequest();
      request.open("POST", server);
      request.setRequestHeader(
        "x-session-token",
        m2.cache.get(CACHE_KEYS.SESSION_TOKEN)
      );

      request.send(formData);

      request.onload = function(oEvent) {
        if (request.status == 200) {
          mui.alert("上传成功" );
          m2.cache.set("rx-user-head", request.responseText);
          let user = m2.cache.get('rx-current-user');
 
          user.iconID = request.responseText;
          m2.cache.set('rx-current-user',user);
          wt.close(); //关闭等待提示按钮
        } else {
          mui.alert("上次失败" + request.responseText);
          wt.close(); //关闭等待提示按钮
        }
      };
      task.addFile(stream, { key: "headupload" });
    },

    //裁剪图片
    cutImage(path) {
      mui.openWindow({
        url: "/profile/cropper",
        id: "cropper",
        extras: {
          path: path
        },
        show: {
          aniShow: "zoom-fade-in",
          duration: 800
        },
        waiting: {
          autoShow: true
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.input-wrap{
  position: absolute;
  width: 35px;
  height: 20px;
  top:32px;
  right:14px;
  color:#fff;
  font-size: torem(15);
  z-index:1000;
  input{
    opacity: 0;
  }
}
.upload{
  position: fixed;
  top:27px;
  right:15px;
  color:#fff;
  font-size: torem(15);
  z-index:1000;
}
.avatar {
  width: 100%;
  height: 90%;
}

.mui-table-view-cell {
  position: fixed;
  width: 100%;
  bottom: 0;
}

#openPopover {
  text-align: center;
  color: #fff;
  font-weight: 600;
  display: block;
  background: rgb(92, 94, 211);
  letter-spacing: 5px;
}
</style>
