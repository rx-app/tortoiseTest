<template>
  <div class="wrap">
    <list-items :items="items1"></list-items>
    <button type="button" class="mui-btn mui-btn-block btn signOut" @click="sign_out()">退出登录</button>
    <div class="mui-popup-backdrop mui-active" v-if="flag">
      <div class="inner" v-if="flag">
        <div class="title">退出登录后不会删除历史记录，下次登录依然可以使用本账号。</div>
        <div class="buttons">
          <p class="sign btn mui-btn" @click="logOff">确认退出</p>
          <p class="cancel btn mui-btn" @click="cancel()">取消</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { logOff } from "@/api/ids/ids-api";
import ListItems from "@/components/list-items/";
import { PROFILE_SETTING, PROFILE_PPTS } from "@/constants";
import { fingerPsdStatus } from "@/api/common/common-api";
import { CACHE_KEYS } from "@/constants";
import { FINGERPSDSTATUS } from "@/store/mutation-types";
import * as types from "@/store/mutation-types";
import store from "@/store";
export default {
  data() {
    return {
      userInfo: {},
      flag: false,
      items1: PROFILE_SETTING,
      items2: PROFILE_PPTS
    };
  },
  methods: {
    sign_out: function() {
      this.flag = true;
    },
    cancel: function() {
      this.flag = false;
    },
    logOff() {
      logOff(res => {
        // 清除ai监控
        xdapp.util.aiUtil.seting("loginOut");
        console.log("loginOut", 4);
        let loginStatus = fingerPsdStatus();
        console.log("loginStatus:" + loginStatus);
        if (loginStatus && typeof loginStatus !== "undefiend") {
          $vue.$router.push({
            name: "unlock"
          });
        } else {
          let accountList = m2.cache.get("accountList");
          let pptsUserIcons = m2.cache.get("ppts-user-icons");
          m2.cache.clear();
          m2.cache.set("accountList", accountList);
          m2.cache.set("ppts-user-icons", pptsUserIcons);

          store.commit(types.CURRENT_USER_GDENDER, 1);
          store.commit(types.CURRENT_USER_HEAD, {});

          this.$router.push({
            name: "login"
          });
        }
      });
    }
  },
  components: {
    ListItems
  }
};
</script>

<style lang="scss" scoped>
.item {
  margin-top: 25px;
}

.btn {
  margin-top: torem(20);
  background: rgb(226, 85, 85);
  border-radius: 100px;
  height: torem(44);
  line-height: torem(11);
  color: #fff;
}

.signOut {
  position: absolute;
  bottom: torem(20);
}

.cancel,
.sign {
  background: rgb(226, 85, 85);
  line-height: torem(28);
}

.cancel {
  background: #ccc;
}

.titlt {
  font-size: torem(14) !important;
  padding: 10px 15px;
  border-bottom: 1px solid #ccc;
}

.inner {
  position: fixed;
  bottom: 0;
  width: 100%;
  background-color: #fff;
  padding: 15px 10px;
}

.btn {
  width: 100%;
  display: block;
  text-align: center;
}
</style>