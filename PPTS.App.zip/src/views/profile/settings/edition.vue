<template>
  <div class="edition-wrap">
    <!-- <tip v-if="!introduction.length">
			<span>暂无功能介绍</span>
    </tip>-->
    <div class="wrap rx-edition" v-if="this.$route.query.time==20180726">
      <div class="txt-large">专职教师主要功能：</div>
      <div class="txt-large">一、三种确认课时方式：</div>
      <table
        class="MsoTable15Grid5DarkAccent1"
        border="1"
        cellspacing="0"
        cellpadding="0"
        width="0"
        style="width: 80vw; border-width: initial; border-style: none;"
      >
        <tbody>
          <tr>
            <td
              width="130"
              valign="top"
              style="width:97.35pt;border:solid white 1.0pt;
          mso-border-themecolor:background1;border-right:none;mso-border-top-alt:solid white .5pt;
          mso-border-top-themecolor:background1;mso-border-left-alt:solid white .5pt;
          mso-border-left-themecolor:background1;mso-border-bottom-alt:solid white .5pt;
          mso-border-bottom-themecolor:background1;background:#5B9BD5;mso-background-themecolor:
          accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal" align="center" style="text-align:center;mso-yfti-cnfc:5">
                <b>
                  <span
                    style="font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;mso-themecolor:
          background1"
                  >
                    确认类型
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="width:97.35pt;border-top:solid white 1.0pt;
          mso-border-top-themecolor:background1;border-left:none;border-bottom:solid white 1.0pt;
          mso-border-bottom-themecolor:background1;border-right:none;mso-border-top-alt:
          solid white .5pt;mso-border-top-themecolor:background1;mso-border-bottom-alt:
          solid white .5pt;mso-border-bottom-themecolor:background1;background:#5B9BD5;
          mso-background-themecolor:accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal" align="center" style="text-align:center;mso-yfti-cnfc:1">
                <b>
                  <span
                    style="font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;mso-themecolor:
          background1"
                  >
                    适用课时类型
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="width:97.35pt;border-top:solid white 1.0pt;
          mso-border-top-themecolor:background1;border-left:none;border-bottom:solid white 1.0pt;
          mso-border-bottom-themecolor:background1;border-right:none;mso-border-top-alt:
          solid white .5pt;mso-border-top-themecolor:background1;mso-border-bottom-alt:
          solid white .5pt;mso-border-bottom-themecolor:background1;background:#5B9BD5;
          mso-background-themecolor:accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal" align="center" style="text-align:center;mso-yfti-cnfc:1">
                <b>
                  <span
                    style="font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;mso-themecolor:
          background1"
                  >
                    使用场景
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
            <td
              width="262"
              valign="top"
              style="width:196.75pt;border:solid white 1.0pt;
          mso-border-themecolor:background1;border-left:none;mso-border-top-alt:solid white .5pt;
          mso-border-top-themecolor:background1;mso-border-bottom-alt:solid white .5pt;
          mso-border-bottom-themecolor:background1;mso-border-right-alt:solid white .5pt;
          mso-border-right-themecolor:background1;background:#5B9BD5;mso-background-themecolor:
          accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal" align="center" style="text-align:center;mso-yfti-cnfc:1">
                <b>
                  <span
                    style="font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;mso-themecolor:
          background1"
                  >
                    备注
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
          </tr>
          <tr>
            <td
              width="130"
              valign="top"
              style="width:97.35pt;border:solid white 1.0pt;
          mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
          mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
          mso-border-themecolor:background1;background:#5B9BD5;mso-background-themecolor:
          accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <b>
                  <span
                    style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;
          mso-themecolor:background1"
                  >
                    扫码确认
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="background: #b5daea;width:97.35pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #BDD6EE;mso-background-themecolor:accent1;mso-background-themetint:102;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  一对一
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="background: #b5daea;width:97.35pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #BDD6EE;mso-background-themecolor:accent1;mso-background-themetint:102;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  学员有手机
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
            <td
              width="262"
              valign="top"
              style="background: #b5daea;width:196.75pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #BDD6EE;mso-background-themecolor:accent1;mso-background-themetint:102;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  双方均可扫码
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
          </tr>
          <tr>
            <td
              width="130"
              valign="top"
              style="width:97.35pt;border:solid white 1.0pt;
          mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
          mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
          mso-border-themecolor:background1;background:#5B9BD5;mso-background-themecolor:
          accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <b>
                  <span
                    style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;
          mso-themecolor:background1"
                  >
                    密码确认
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="background: #d2e2e8;width:97.35pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #DEEAF6;mso-background-themecolor:accent1;mso-background-themetint:51;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;
          font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  一对一
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="background: #d2e2e8;width:97.35pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #DEEAF6;mso-background-themecolor:accent1;mso-background-themetint:51;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;
          font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  学员无手机
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
            <td
              width="262"
              valign="top"
              style="background: #d2e2e8;width:196.75pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #DEEAF6;mso-background-themecolor:accent1;mso-background-themetint:51;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;
          font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  学员签约后系统自动生成
                  <span lang="EN-US">6</span>位数字密码，主监护人手机号注册掌上学大后，可在“我的
                  <span lang="EN-US">-</span>学员信息”中获取密码。
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
          </tr>
          <tr>
            <td
              width="130"
              valign="top"
              style="width:97.35pt;border:solid white 1.0pt;
          mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
          mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
          mso-border-themecolor:background1;background:#5B9BD5;mso-background-themecolor:
          accent1;padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <b>
                  <span
                    style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif;color:white;
          mso-themecolor:background1"
                  >
                    点名确认
                    <span lang="EN-US"></span>
                  </span>
                </b>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="background: #b5daea;width:97.35pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #BDD6EE;mso-background-themecolor:accent1;mso-background-themetint:102;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  style="font-size:11.0pt;
          mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  班组
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
            <td
              width="130"
              valign="top"
              style="background: #b5daea;width:97.35pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #BDD6EE;mso-background-themecolor:accent1;mso-background-themetint:102;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  lang="EN-US"
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >20</span>
                <span
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  人以下班组
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
            <td
              width="262"
              valign="top"
              style="background: #b5daea;width:196.75pt;border-top:none;border-left:
          none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
          border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
          mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
          mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
          mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
          #BDD6EE;mso-background-themecolor:accent1;mso-background-themetint:102;
          padding:0cm 5.4pt 0cm 5.4pt"
            >
              <p class="MsoNormal">
                <span
                  lang="EN-US"
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >20</span>
                <span
                  style="font-size:11.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;微软雅黑&quot;,sans-serif"
                >
                  人以上班组在
                  <span lang="EN-US">PPTS</span>上确认
                  <span lang="EN-US"></span>
                </span>
              </p>
            </td>
          </tr>
        </tbody>
      </table>
      <div style="height:30px"></div>
      <img :src="require('@/public/asset/img/version/20180726/1.jpg')" alt>
      <div class="txt-small">图1 可确认课表</div>
      <img :src="require('@/public/asset/img/version/20180726/2.jpg')" alt>
      <div class="txt-small">图2 扫码确认课时</div>
      <img :src="require('@/public/asset/img/version/20180726/3.jpg')" alt>
      <div class="txt-small">图3 输入密码确认课时</div>

      <img :src="require('@/public/asset/img/version/20180726/4.jpg')" alt>
      <div class="txt-small">图4 点名确认课时</div>

      <div class="txt-large">二、查看课表</div>
      <div class="txt-large">教师可查看自己的课表，确认课时后，可为学员操作课后点评。</div>
      <img :src="require('@/public/asset/img/version/20180726/5.jpg')" alt>
      <div class="txt-small">图5 查看课表</div>
      <img :src="require('@/public/asset/img/version/20180726/6.jpg')" alt>
      <div class="txt-small">图6 课后点评</div>
      <div class="txt-large">学管师主要功能：</div>
      <div class="txt-large">1、确认课时：三种确认方式同教师确认课时</div>
      <div class="txt-large">2、管理学员，查看学员信息</div>
      <img :src="require('@/public/asset/img/version/20180726/7.jpg')" alt>
      <div class="txt-small">图7 管理学员</div>
      <img :src="require('@/public/asset/img/version/20180726/8.jpg')" alt>
      <div class="txt-small">图8 查看学员信息</div>
      <div class="txt-large">3、查看成绩，录入回访、家长会</div>
      <img :src="require('@/public/asset/img/version/20180726/9.jpg')" alt>
      <div class="txt-small">图9 成绩</div>
      <img :src="require('@/public/asset/img/version/20180726/10.jpg')" alt>
      <div class="txt-small">图10 回访</div>
      <img :src="require('@/public/asset/img/version/20180726/11.jpg')" alt>
      <div class="txt-small">图11 家长会</div>
      <div class="txt-large">4、查看课表</div>
      <img :src="require('@/public/asset/img/version/20180726/12.jpg')" alt>
      <div class="txt-small">图12 教师课表</div>
      <img :src="require('@/public/asset/img/version/20180726/13.jpg')" alt>
      <div class="txt-small">图13 学员课表</div>
      <div class="txt-large">5、管理家长分享的课间小憩</div>
      <div class="txt-large">审核通过会在首页下方显示（每日前条随机显示），取消显示则不会在首页显示。</div>
      <img :src="require('@/public/asset/img/version/20180726/14.jpg')" alt>
      <div class="txt-small">图14 管理家长分享</div>
    </div>
    <div class="wrap rx-edition" v-if="this.$route.query.time==20190326">
      <div class="txt-large">新增讨论组和群发消息功能：</div>
      <div class="txt-large">一、讨论组：</div>
      <div class="txt-large">
        <span class="red">功能说明：</span>学管师可为学员创建讨论组，把学员归属咨询师、任课教师拉入组内进行交流讨论，学管师可以对讨论组进行管理（修改名称、添加/移除成员）。
        <br>
        <span class="red">功能位置：</span>消息——家校互动——学员讨论组。
      </div>
      <div class="txt-large">
        <span class="red">界面示意图：</span>
      </div>

      <img :src="require('@/public/asset/img/version/20190326/1.jpg')" alt>
      <div class="txt-small">图1 消息-家校互动-学员讨论组</div>
      <img :src="require('@/public/asset/img/version/20190326/2.jpg')" alt>
      <div class="txt-small">图2 讨论组会话界面</div>
      <img :src="require('@/public/asset/img/version/20190326/3.jpg')" alt>
      <div class="txt-small">图3 讨论组会话界面</div>

      <div class="txt-large">
        <span class="red">注意：</span>
        <br>1、每个学员只能创建一个讨论组；
        <br>2、只有当前归属学管师可对组内成员进行管理，包括添加、移除操作（家长和学管师不可移除）；
        <br>3、历史学管师看不到当前不归属学员的讨论组；
        4、其它成员可在消息-家校互动中看到“学员讨论组”；
      </div>
      <div class="txt-large">二、群发消息：</div>
      <div class="txt-large">
        <span class="red">功能说明：</span>学管师可按状态，或年级选择相应学员，群发站内消息。学员家长会在学管师的日常维护中收到该消息。
        <br>
        <span class="red">功能位置：</span>消息——家校互动——日常维护——群发消息。
      </div>
      <div class="txt-large">
        <span class="red">界面示意图：</span>
      </div>

      <img :src="require('@/public/asset/img/version/20190326/4.jpg')" alt>
      <div class="txt-small">图4 消息-家校互动-群发消息</div>
      <img :src="require('@/public/asset/img/version/20190326/5.jpg')" alt>
      <div class="txt-small">图5 按状态选择接收群消息学员范围</div>
      <img :src="require('@/public/asset/img/version/20190326/6.jpg')" alt>
      <div class="txt-small">图6 按年级选择接收群消息学员范围</div>
    </div>
    <div class="wrap rx-edition" v-if="this.$route.query.time==20190611">
      <div class="txt-large font-s" >本次更新了咨询师相关功能，包括“首页、学员、消息、我的”四个模块，主要功能为“新增/编辑潜客、编辑学员信息、新增跟进记录、家校互动”等。
界面样式及内容请查看登录后界面，其它注意事项及说明如下：</div>
      <div class="txt-large font-s">1、	切岗：点击右上角可切换岗位，页面显示当前岗位相关内容；</div>
      <div class="txt-large font-s">2、	新增潜客：PPTS与APP数据实时同步，在一端添加后，另一端即可显示，无需重复添加；</div>
      <div class="txt-large font-s">3、	学员：包括潜客和签约学员；</div>
      <div class="txt-large font-s">4、	消息-家校互动：与PPTS上功能一致，内容实时同步；</div>
      <div class="txt-large font-s">5、	消息-家校互动-学员讨论组：由学管师创建，咨询师可参与讨论；</div>
      <div class="txt-large font-s">6、	我的：个人信息页面的岗位只是展示，不能切换，如需切换可点击到其它页面进行切换。</div>
    </div>

    <div class="wrap rx-edition" v-if="this.$route.query.time==20191126">
      <div class="txt-large">新增主要功能：在线支付</div>
      <div class="txt-large">
        <span class="red">功能说明：</span>咨询师、学管师可以在PPTS发起“在线支付”，家长在掌上学大APP家长端会收到付款通知，家长操作付款成功后，自动生成已付款状态缴费单。该功能详见PPTS。
        <span class="red">
          <br />功能位置：
        </span>缴费——待缴费——已缴费。
      </div>
      <div class="txt-large">
        <span class="red">界面示意图：</span>
      </div>
      <img :src="require('@/public/asset/img/version/20190910/1.jpg')" alt />
      <div class="txt-small">图1 缴费——待缴费</div>
      <img :src="require('@/public/asset/img/version/20190910/2.jpg')" alt />
      <div class="txt-small">图2 缴费——已缴费</div>
      <img :src="require('@/public/asset/img/version/20190910/3.jpg')" alt />
      <div class="txt-small">图3 缴费付款页面</div>
      <div class="txt-large">
        <span class="red">注意:</span>
        <div class="txt-large">1.咨询师或学管师在PPTS系统中操作了转在线支付的缴费单后，家长会在首页收到待缴费提醒，家长通过链接直接付款即可。</div>
        <div class="txt-large">2.家长付款成功后，家长端的已缴费界面会立即显示该条缴费记录；PPTS缴费单有可能晚于家长端显示该内容，因为家长端显示的是付款记录，PPTS端显示的是付款后的缴费单相关信息，正常情况下，二者时间差不大。</div>
        <div class="txt-large">3.学管师或咨询师可以在付款同学的PPTS系统账户下查看付款过程。如果付款不成功，提醒家长重新点击立即付款即可；如果家长已收到付款成功通知，而PPTS未显示成功，可以第二天查看，也可以发support请相关老师帮忙核实。</div>
      </div>
    </div>
  </div>



</template>

<script>
import { getAppInfo } from "@/api/common/common-api";
import { getAppInfoByQuery } from "@/api/course/course-api";
import Tip from "@/components/tip";

export default {
  components: {
    Tip
  },
  data() {
    return {
      introduction: "",
      contents: { 20180726: `` }
    };
  },
  created() {},
  mounted() {},
  methods: {}
};
</script>

<style lang="scss">
.edition-wrap {
  overflow: auto;
  height: 100vh;
}
.rx-edition {
  padding: 10vw;
  font-size: 12pt;
  // line-height: 24pt;
  font-family: "微软雅黑", sans-serif;
  color: rgb(143, 143, 148);
  .font-s{
    font-size: 14px;
  }
  .txt-large {
    margin-bottom: 10px;
    .red {
      color: red;
    }
  }
  .txt-small {
    font-size: 14px;
    text-align: center;
    margin-bottom: 10px;
    margin-top: 5px;
  }
  img {
    width: 100%;
  }
}
</style>
