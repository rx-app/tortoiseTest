<template>
	<div class="wrap">
		<ul class="mui-table-view rx-list-items">
			<li @click="goUrl(item)" v-for="(item, index) in items" :key="index" class="item" :class="{'link-item':item.pathname}">
				<span v-if="item.icon" class="mui-icon iconfont" :class="item.icon"></span>
				<span class="name">{{item.title}}</span>
				<span class="value" :class="{'no-arrow':!item.pathname.name}">{{item.value}}
            <img v-if="item.img" :src="item.img" class="img-header"/></span>
			</li>
		</ul>
		<p class="con">版权信息</p>
	</div>
</template>
<script>
	import ListItems from '@/components/list-items/';
	import { PROFILE_RX_ABOUT } from '@/constants';
	import { getAppInfo } from '@/api/common/common-api';

	export default {
		data() {
			return {
				items: PROFILE_RX_ABOUT
			}
		},
		components: {
			ListItems
		},
		methods: {
			goUrl(item) {
				if(item.isGoUrl) {
					getAppInfo({}, (res) => {
						var ua = navigator.userAgent.toLowerCase();
						if(/iphone|ipad|ipod/.test(ua)) {
							this.screenType = "IOS";
						} else if(/android/.test(ua)) {
							this.screenType = "Android";
						}
						res.forEach((item, index) => {
							if(item.sysType == this.screenType) {
								mui.plusReady(function() {
									plus.runtime.openURL(item.evaluationInfo.evaluationUrl);
								});
							}
						})

					})
				} else {
					this.$router.push({
						name: item.pathname
					});
				}
			}
		}
	}
</script>
<style scoped>
	.con {
		text-align: center;
		position: absolute;
		bottom: 20px;
		width: 100%;
	}
</style>
<style lang="scss" scoped>
	.rx-list-items {
		.item {
			display: flex !important;
			justify-content: center;
			align-items: center;
			padding: torem(10);
			border-bottom: 1px solid #eee;
			margin: 0 torem(5);
		}
		.link-item:after {
			content: '\E583';
			font-family: Muiicons;
			color: #bbb;
			-webkit-font-smoothing: antialiased;
			margin-left: 5px;
		}
		.name {
			color: #777;
			font-size: torem(14);
		}
		.value {
			display: block;
			text-align: right;
			flex: 1;
			color: #aaa;
			.img-header {
				width: 1.70667rem;
				height: 1.70667rem;
			}
		}
		.no-arrow {
			margin-right: 3px;
		}
	}
	
	.mui-content>.mui-table-view:first-child {
		margin-top: 0;
	}
</style>