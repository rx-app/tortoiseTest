<template>
	<div class="wrap">
			<ul class="mui-table-view">
	            <li v-for="(item,index) in childList" :key="index" class="mui-table-view-cell">
	                <span>{{item.name}}</span>
	                <div class="mui-switch" @click="change(item)" :class="{'mui-active':item.isBind}" data-switch="1">
	                    <div class="mui-switch-handle"></div>
	                </div>
	            </li>
		    </ul>
			<div class="mui-content-padded">
				<p>若关闭，当收到睿学消息时，通知提示将不显示发信人和内容摘要</p>
			</div>

			<ul class="mui-table-view">
	            <li v-for="(item,index) in childListT" :key="index" class="mui-table-view-cell">
	                <span>{{item.name}}</span>
	                <div class="mui-switch" @click="change(item)" :class="{'mui-active':item.isBind}" data-switch="1">
	                    <div class="mui-switch-handle"></div>
	                </div>
	            </li>
		    </ul>
			<div class="mui-content-padded">
				<p>设置系统功能消息提示声音和震动的时段</p>
			</div>
			<ul class="mui-table-view">
	            <li v-for="(item,index) in childListS" :key="index" class="mui-table-view-cell">
	                <span>{{item.name}}</span>
	                <div class="mui-switch" @click="change(item)" :class="{'mui-active':item.isBind}" data-switch="1">
	                    <div class="mui-switch-handle"></div>
	                </div>
	            </li>
		    </ul>
			<div class="mui-content-padded">
				<p>当睿学在运行时，你可以设置是否需要声音或者震动</p>
			</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				childList:[
                    {name:'接收新消息通知',isBind:true},
                    {name:'通知显示消息详情',isBind:true}
                ],
				childListT:[
                    {name:'声音',isBind:false},
                    {name:'震动',isBind:true}
                ],
                childListS:[
                    {name:'接收手机短信',isBind:true}
                ]
			}

        },
        methods:{
            change(item){
            	item.isBind=!item.isBind;
                // if(item.isBind){
                //     mui.confirm('确定关闭指纹解锁？', '提示', ['取消','确定'], function(e) {
                //         if (e.index != 0) {
                //             item.isBind=!item.isBind;
                //         }
                //     })
                // }else{
                //     item.isBind=!item.isBind;
                // }


            }
        }
	}
</script>

<style scoped>

</style>
