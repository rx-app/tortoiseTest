﻿<template>
	<div class="wrap">
		<div class="img"><img src="~@/public/asset/img/profile/logo.png" alt="" /></div>
		<div id="list" v-if="versionInfo.length" v-html="versionInfo"></div>
		<div id="tip" v-else>掌上学大(员工版)&nbsp;&nbsp;{{version}}</div>

	</div>
</template>

<script>
	import { getAppInfoByQuery } from "@/api/course/course-api";
	export default {
		data() {
			return {
				versionInfo: [],
				version:''
			}
		},
		mounted() {
			this.getInfo();
		},
		methods: {
			getInfo() {
				/*设备类型*/
				var ua = navigator.userAgent.toLowerCase();
				if(/iphone|ipad|ipod/.test(ua)) {
					this.screenType = "IOS";
				} else if(/android/.test(ua)) {
					this.screenType = "Android";
				}
				var _this = this;
				/*plus.runtime.version   manifest.json中的版本号  官方解释--在编译环境中设置的apk的版本号*/
				
				/*应用中的版本号  官方解释--获取指定APPID对应的应用信息*/
				function plusReady() {
					plus.runtime.getProperty(plus.runtime.appid, function(inf) {
						_this.version = inf.version;
						console.log("当前应用版本：" + _this.version);
					});
				}
				if(window.plus) {
					plusReady();
				} else {
					document.addEventListener('plusready', plusReady, false);
				}
				
				setTimeout(function(){
					var params = {
						VersionNumber: _this.version,//1.0.1
						SysType: _this.screenType
					}
					getAppInfoByQuery(params, res => {
						if(res.length){
							_this.versionInfo = res[0].versionInfo;
						}
						
					})
				},200)

			},

		}
	}
</script>

<style lang="scss" scoped>
	.wrap {
		padding-top: torem(105) !important;
		line-height: torem(32);
		.img {
			text-align: center;
		}
		#list {
			padding-left: torem(20);
		}
		#tip{
			text-align: center;
		}
	}
</style>