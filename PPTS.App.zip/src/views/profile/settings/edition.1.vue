<template>
	<div>
		<tip v-if="!introduction.length">
			<span>暂无功能介绍</span>
		</tip>
		<div v-else class="wrap wrap-edition" v-html="introduction"></div>
	</div>
</template>

<script>
	import { getAppInfoByQuery } from "@/api/course/course-api";
	import '@/public/asset/js/jquery/jquery-1.8.0';
	import Tip from '@/components/tip'
	export default {
		data() {
			return {
				introduction: []
			}
		},
		mounted() {
			getAppInfoByQuery( {
						VersionNumber: '1.0.2',
						SysType: "Android"
					}, 
					res => {
						if(res.length){
							this.introduction = res[0].introduction;
						}
						
					})
		},
		updated() {
			let warp = document.querySelector('.wrap')
			// 获取table内容
			let tmp = $('table.MsoTable15Grid5DarkAccent1').html()
			// 获取style
			let style = $('table.MsoTable15Grid5DarkAccent1').attr('style')
			let ss = '<table class="MsoTable15Grid5DarkAccent1" border="1" cellspacing="0" cellpadding="0" width="0" style="' + style + '">' + tmp + '</table>'
			$('table.MsoTable15Grid5DarkAccent1').before('<div class="table-box"></div>')
			$('table.MsoTable15Grid5DarkAccent1').remove();
			$('div.table-box').html(ss)
		},
		methods: {
				getInfo() {
					/*设备类型*/
					var ua = navigator.userAgent.toLowerCase();
					if(/iphone|ipad|ipod/.test(ua)) {
						this.screenType = "IOS";
					} else if(/android/.test(ua)) {
						this.screenType = "Android";
					}
					var _this = this;
					/*app版本信息*/
					function plusReady() {
						plus.runtime.getProperty(plus.runtime.appid, function(inf) {
							_this.version = inf.version;
							console.log("当前应用版本：" + _this.version);
						});
					}
					if(window.plus) {
						plusReady();
					} else {
						document.addEventListener('plusready', plusReady, false);
					}
					setTimeout(function() {
						var params = {
							VersionNumber: '1.0.1',//_this.version,
							SysType: _this.screenType
						}
						getAppInfoByQuery(params, res => {
							if(res.length){
								_this.introduction = res[0].introduction;
							}
							
						})
					}, 200)

				},
		},
		components: {
			Tip
		}
	}
</script>
<style lang='scss'>
	.table-box {
		width: 100%;
		overflow-x: auto;
	}
	
	.wrap-edition table {
		max-width: 100%;
	}
	.wrap-edition img {
		width: torem(300);
	}
</style>

<style lang="scss" scoped>
	.wrap {
		/*text-align: center;*/
		padding: torem(50) torem(35);
	}
	
	.MsoTable15Grid5DarkAccent1 {
		width: 100%;
	}
</style>