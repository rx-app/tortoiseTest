<template>
	<div class="wrap">
		<ul class="mui-table-view">
			<li v-for="(item,index) in childList" :key="index" class="mui-table-view-cell">
				<span>{{item.name}}</span>
				<div class="mui-switch" @click="change(item)" :class="{'mui-active':item.isBind}" data-switch="1">
				<!-- <div class="mui-switch" @click="change(item)" data-switch="1"> -->
					<div class="mui-switch-handle"></div>
				</div>
			</li>
		</ul>
	</div>
</template>

<script>
	import { fingerPsdStatus } from '@/api/common/common-api';
	import { CACHE_KEYS } from '@/constants';
	import { FINGERPSDSTATUS } from '@/store/mutation-types'

	export default {
		data() {
			return {
				childList: [{
					name: '手势密码',
					isBind: fingerPsdStatus()
				}]
			}
		},
		created () {
			console.log('seting-fingerPsdStatus:' + fingerPsdStatus())
		},
		methods: {
			change(item) {
				if(item.isBind && item.isBind !== 'undefined') {
					mui.confirm('确定关闭指纹解锁？', '提示', ['取消', '确定'], function(e) {
						if(e.index != 0) {
							$vue.$router.push({
								name: 'profile-settings-lock',
								params: {
									type: 'setting_cancel'
								}
							})
						}
					})
				} else {
					this.$router.push({
						name: 'profile-settings-lock',
						params: {
							type: 'setting_create'
						}
					})
				}
			}
		}
	}
</script>

<style scoped>
	* {
		touch-action: none;
	}
</style>