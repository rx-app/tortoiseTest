<template>
	<div>
		<div class="xdapp-feedback-container">
			<scroll :data="feedbackList" :listen-scroll="listenScroll" :probe-type="probeType" :pullup="pullup" :pulldown="pulldown" @scrollToEnd="searchMore" @scrollToStart="refreshMore" class="scroll-container" ref="list-view">
				<div class="list-group">
					<ul class="feedback-list">
						<router-link class="list-group-item" :to="{name:'feedback-reply',query:{feedID:item.feedID,type:item.feedType}}" v-for="(item, index) in feedbackList" :key="index" tag="li">
							<img class="img" src="~@/public/asset/img/home/head.png">
							<div class="feedback-detail">
								<div class="feedback-sub">
									<div class="type">{{item.feedType | feedType}}</div>
									<div class="date">{{item.submitTime | dateTimeFormat}}</div>
								</div>
								<div class="feedback-content">{{item.content}}</div>
							</div>
						</router-link>
						<loading v-show="hasMore" title=""></loading>
						<tip v-if="!feedbackList.length">
							<span>您还没有留下意见，点击留言留下您的意见吧</span>
						</tip>
					</ul>
				</div>
			</scroll>
		</div>
	</div>
</template>
<script>
	import myText from '@/components/myText';
	import { pager, orderBy, defaultPageIndex, defaultPageSize } from '@/public/constant';
	import { ACTION_TYPES, CACHE_KEYS } from '@/constants';
	import { loadUserInfo, getToken } from '@/api/common/common-api';
	import { $getFeedbackList } from '@/api/settings/setting-api';
	import Scroll from '@/components/scroll/index';
	import Loading from '@/components/loading/index';
	import Tip from '@/components/tip'
	export default {
		data() {
			return {
				probeType: 3,
				listenScroll: true,
				pullup: true,
				pulldown: true,
				hasMore: false,
				params: {
					submitterID: m2.cache.get('ppts-current-user').userId,
					...pager({
						pageIndex: defaultPageIndex,
						pageSize: defaultPageSize
					}),
					...orderBy({
						dataField: 'submitTime',
						sortDirection: 1
					})
				},
				feedbackList: [],
				hasToken: false,
				isInit: true
			}
		},
		created() {
			this.getFeedbackList();
			this.enableEvent();
		},

		methods: {
			async getFeedbackList() {
				await loadUserInfo();
				$getFeedbackList(this.params, res => {
					this.feedbackList = this.feedbackList.concat(res.queryResult.pagedData);
					this._checkMore(res.queryResult.totalCount);
				});
			},
			searchMore() {
				if(!this.hasMore)
					return;

				this.params.pageParams.pageIndex++;
				this.getFeedbackList();
			},
			refreshMore() {
				console.log('refreshMore');
			},
			enableEvent() {
				xdapp.util.vue.commitActionStatus(true);
				xdapp.util.vue.on(ACTION_TYPES.GOTO_FEEDBACK, this._gotoFeedback);
			},
			_gotoFeedback() {
				this.$router.push({
					name: "feedback-add"
				});
			},
			_checkMore(totalCount) {
				if(this.params.pageParams.pageIndex * this.params.pageParams.pageSize >= totalCount)
					this.hasMore = false;
				else
					this.hasMore = true;
			},
		},
		components: {
			Scroll,
			Loading,
			Tip
		}
	}
</script>
<style lang="scss" scoped>
	$backgroundColor: #efeff4;
	$fontColor: #8e8e8e;
	.xdapp-feedback-container {
		position: fixed;
		width: 100%;
		height: 90%;
		.scroll-container {
			height: 100%;
			overflow: hidden;
			.list-group {
				.feedback-list {
					background-color: #fff;
					.list-group-item {
						display: flex;
						align-items: center;
						padding: torem(10);
						border-bottom: 1px solid $backgroundColor;
						.img {
							flex: 0 0 torem(50);
							width: torem(50);
							height: torem(50);
							margin-right: 10px;
						}
						.feedback-detail {
							display: flex;
							flex-direction: column;
							justify-content: center;
							flex: 1;
							overflow: hidden;
							.feedback-sub {
								display: flex;
								justify-content: space-between;
								height: torem(28);
								line-height: torem(28);
								font-size: torem(16);
								.type {}
								.date {
									color: $fontColor;
									font-size: torem(12);
								}
							}
							.feedback-content {
								height: torem(28);
								line-height: torem(28);
								font-size: torem(12);
								color: $fontColor;
								overflow: hidden;
								white-space: nowrap;
								text-overflow: ellipsis
							}
						}
					}
				}
			}
		}
	}
</style>