<template>
	<div class="wrap rx-profile-feedback-list">
		<router-link :to="{name:'feedbackAdd'}" class="send-btn">留言</router-link>
		<div class="f-list" v-infinite-scroll="getUserFeedback" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
			<router-link v-for="(item,index) in list" :key="index" tag="div" :to="{name:'feedback-reply',query:{feedid:item.feedID,type:item.feedType}}" class="f-item">
				<div class="f-left">{{item.feedType|feedbackType}}</div>
				<div class="f-center vipText">{{item.content}}</div>
			</router-link>
		</div>
	</div>
</template>
<script>
	import myText from '@/components/myText';
	import { pager, orderBy } from '@/public/constant';
	import { getUserTypeFeedback, getUserFeedback } from '@/api/settings/setting-api';

	export default {
		data() {
			return {
				list: [],
				pageIndex: 1,
				total: 0,
				loading: false,
			}
		},
		computed: {
			imgList() {
				return this.imgs.slice(0, 5)
			}
		},
		components: {
			myText
		},
		mounted() {
			this.getUserFeedback();
		},
		created() {
			this.getData();
			this.getType();
		},
		methods: {
			getUserFeedback() {
				this.loading = true;
				getUserFeedback({
					submitterID: m2.cache.get('ppts-current-user').userId,
					...pager({
						pageSize: 20
					}),
					...orderBy({
						dataField: 'submitTime'
					})
				}, res => {
					this.list = [...this.list, ...res.queryResult.pagedData];
					console.log(this.list)
					this.pageIndex++;
					// console.log(this.pageIndex)
					//this.typeName = '全部',
					this.total = res.queryResult.totalCount;
					if(this.list.length < res.queryResult.totalCount) {
						this.loading = false;
					} else {
						if(this.list.length == 0) {
							Toast('当前条件下无账单信息...')
						} else {
							Toast({
								message: '全部账单已加载完毕...',
								position: 'bottom'
							})
						}

					}
				})
			},
			getType() {
				// console.log(getUserTypeFeedback)
				getUserTypeFeedback({}, res => {
					// r.dictionaries
					//   console.log(res.dictionaries.C_CODE_ABBR_Feedbacks_FeedType)
					this.feedbackTypes = res.dictionaries.C_CODE_ABBR_Feedbacks_FeedType;

				});
			},
			getData() {

			}
		}
	}
</script>
<style lang="scss" scoped>
	.rx-profile-feedback-list {
		.f-list {
			padding: 10px;
			color: #aaa;
			.f-item {
				display: flex;
				margin-bottom: 12px;
				.f-left {
					padding: 0 4px;
					width: 40px;
					font-size: torem(14);
					line-height: 20px;
					letter-spacing: 2px;
					color: #fff;
					background: rgb(75, 181, 243);
					border-radius: 6px;
				}
				.f-center {
					flex: 1;
					padding: 0 5px 0;
					height: 40px;
					line-height: 20px;
				}
				.f-right {
					padding: 0 4px;
					width: 40px;
					font-size: torem(16);
					color: #fff;
					background: rgb(64, 238, 136)
				}
			}
		}
	}
	
	.vipText {
		height: .2rem;
		width: .97rem;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
	
	.send-btn {
		position: fixed;
		top: 27px;
		right: 15px;
		color: #fff;
		font-size:torem(15);
		z-index: 1000;
	}
</style>