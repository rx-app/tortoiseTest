﻿<template>
  <div class="xdapp-feedback-wrapper">
    <scroll @tap.native='fnTap' :data="[]" :listen-scroll="true" :probe-type="3" :pulldown="true"  class="scroll-container" ref="listview">
<ul>
      <li class="feedback-type" v-if="typeof feedID === 'undefined'">
        <div class="title require"> 请选择反馈问题的类型</div>
        <ul class="type" v-if="criteria.dictionaries && criteria.dictionaries.C_CODE_ABBR_Feedbacks_FeedType">
          <li v-for="(item,index) in criteria.dictionaries.C_CODE_ABBR_Feedbacks_FeedType" :key="index">
            <span class="category">{{item.value}}</span>
            <span class="desc">{{feedTypeDesc[index]}}</span>
            <input class="selected" type="radio" :id="item.key" name="feedback" @click="selectFeedType(item.key)"/>
            <label :for="item.key" :class="{'current':criteria.feedbackType==item.key}"></label>
            <span></span>
          </li>
        </ul>
      </li>
      <li class="feedback-suggest">
        <div class="title require"> 问题和意见</div>
        <div class="suggest">
          <textarea  name="" @input="setNum" class="txt" @focus="fnFocus" @blur="fnBlur" placeholder="请输入不少于5个字的描述并且描述您在使用该应用时遇到的问题和建议，若系统异常，上传页面截图，我们会及时解决！" id="" cols="30" rows="10"></textarea>
          <span class="count"><span class="num">{{num}}</span>/200</span>
          <!-- <textarea name="suggestion" v-model="criteria.content"
                    placeholder=""></textarea> -->
        </div>
      </li>
      <!-- <form class="feedback-upload" ref="uploadForm" name="uploadForm" method="post" 
            target="statusFrame" enctype="multipart/form-data"> -->
      <li class="feedback-upload">
          <div class="title">添加图片（请上传相关问题的截图或照片）</div>
          <div class="upload-wrapper">
            <div class="image-wrapper">
              <div class="img-item" v-for="(img, i) in imgList"  :key="i">
                <figure class="previewer-img" :style="{backgroundImage: 'url(' + img.Url + ')'}"></figure> 
                <div class="img-close" :class="img.delImg ? 'del-img' : ''" @click.stop="removeImg(i,img)">X</div>
              </div>
              <div class="img-item icon" v-if="imgList.length < 4">
                <a class="file">
                  <i class="iconfont icon-camera"></i>
                  <input type="file" @change="upload()" ref="file" accept="image/*">
                </a>
              </div>
            </div>
            
          </div>
        </li>
    
    
    
    
    
    </ul>
    </scroll>

    <!-- </form> -->
  </div>
</template>
<script>
  import {CACHE_KEYS, ACTION_TYPES} from '@/constants';
  import {$initSavePostFeedback,$submitFeedback, $saveReplyFeedback} from '@/api/settings/setting-api';
	import Scroll from '@/components/scroll/index';

  import uploadMixin from '@/public/lib/upload'
import { setTimeout } from 'timers';
function resize() {
		if(mui.os.ios){
			plus.webview.currentWebview().setStyle({
				'bottom': '-1px'
			})
		}
	}
  export default {
    mixins: [uploadMixin],
    data(){
      return {
        params: {},
        selectFiles: [],
        criteria: {},
        feedTypeDesc: ['不能使用现有功能', '用的不爽、功能建议', '通通都提出来吧'],
        localIdImgs: [],
        imgaesMaxLenght: 9,
        imgLenght:true,
        imgList: [],
        feedID: undefined,
				iosType:'normal',
        uploadImg: [],
        num: 0
      };
    },
    created(){
      mui.plusReady(()=>{
        plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
      })
     
      this.imgList = []
      this.uploadImg = []
      this.feedID = this.$route.query.feedID
      this.criteria.content = ''
      this.num = 0
      this.setParam();
      this.initSavePostFeedback();
      this.regSubmit();
      if(window.innerHeight<500){
				this.iosType='4s'
      }
      window.addEventListener('resize',resize)
    },
    destroyed(){
			window.removeEventListener('resize',resize)
		},
    activated(){
      this.imgList = []
      this.uploadImg = []
      this.feedID = this.$route.query.feedID
      document.querySelector('.txt').value = ''
      this.criteria.content = ''
      this.num = 0
      this.initData();
      this.regSubmit();
    },
    deactivated(){
      console.log('deactivated');
    },
    methods: {
      fnTap(e){
        if(!mui.os.ios){
          if( e.target.tagName=='TEXTAREA' ||  e.target.tagName=='INPUT' ){
            return
          }
          if( document.activeElement.tagName=='TEXTAREA' ||  document.activeElement.tagName=='INPUT' ){
            document.activeElement.blur();
          }
        }
      },
      fnFocus(){
        var ua = navigator.userAgent.toLowerCase();
        if(/iphone|ipad|ipod/.test(ua)) {
          var wv=plus.webview.currentWebview();
          let bottom=this.iosType=='4s'?'315px':'655px'
          
          wv.setStyle({'top':'0px'});
          wv.setStyle({bottom});
          plus.webview.currentWebview().setStyle({'background':'#fff'});
         

        }
      },
      fnBlur(){
        var ua = navigator.userAgent.toLowerCase();
        if(/iphone|ipad|ipod/.test(ua)) {
          // mui.toast(window.innerHeight)

          var wv=plus.webview.currentWebview();
          wv.setStyle({'top':'0px'});
          wv.setStyle({'bottom':'0px'});
        }
      },
      setNum(e){
        this.num=this.calcLength(e.target.value);
        if(this.num > 200) {
            e.target.value = this.criteria.content;
            this.num = 200;
        } else {
          this.criteria.content = e.target.value; 
        }
      },
      calcLength(str){
        return str.length
        //-Math.floor(str.length/2);
      },
      submit(){
        delete this.criteria.queryResult
        delete this.criteria.dictionaries
        this.criteria.screenShotIDs = this.uploadImg.map(one => {
          return one.id
        })
        this.criteria.Materials = this.uploadImg
        if (typeof this.feedID !== 'undefined') {
          delete this.criteria.feedbackType
          this.criteria.feedID = this.feedID
          $saveReplyFeedback(this.criteria, (res) => {
            this.resetForm()
            this.$router.push({
              name: 'feedback-reply',
              query:{
                feedID: this.$route.query.feedID             
              }
            })
          });
        } else {
          $submitFeedback(this.criteria, (res) => {
            mui.alert('谢谢您的反馈，我们会及时为您解决！', '提示', '确定', () => {
              this.resetForm()
              this.$router.push({
                name: "feedback-list"
              });
            });
          });
        }
      },
      resetForm () {
        this.imgList = []
        this.uploadImg = []
        this.feedID = ''
        document.querySelector('.txt').value = ''
        this.criteria.content = ''
        this.num = 0
      },
      regSubmit(){
        xdapp.util.vue.on(ACTION_TYPES.SUBMIT_FEEDBACK, this.submit);
      },
      initData(){
        this.initSavePostFeedback();
        let node = document.querySelector('input.selected:checked');
        if (node)
          node.checked = false;
      },
      selectFeedType(value){
        this.criteria.feedbackType = value;
      },
      initSavePostFeedback(){
        $initSavePostFeedback(res => {
          this.criteria = res;
          if (this.criteria.content === null) {
            this.criteria.content = ''
          }
        });
      },
      galleryImages(){
        let _this = this;
        plus.gallery.pick(function (e) {
          for (var i in e.files) {
            console.log(e.files[i]);
            _this.selectFiles.push(e.files[i]);
          }
        }, e => {
          console.log('取消选择图片');
        }, {
          filter: 'image', multiple: true, system: false
        });
      },
      uploadImages(file){
        let dataUrl = 'file:///storage/emulated/0/Huawei/MagazineUpdate/download/magazine-unlock-hi817204.downloading';

        // this.dataURLtoBlob(dataUrl);
        this.readFiles(dataUrl);
        /*
         console.log(e.target.files);
         this.$refs.uploadForm.submit();

         this.readFiles(e.target.files);
         console.log(document.getElementById('statusFrame').contentWindow.document);
         */
      },
      dataURLToBlob(dataUrl){
        var arr = dataUrl.split(',');
        var mime = arr[0].match(/:(.*?);/)[1];
        var bstr = atob(arr[1]);
        var n = bstr.length;
        var u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], {type: mime});
      },
      readFiles(files){
        console.log(files);
        if (!files) return;
        let _this = this;
        [...files].forEach((file) => {
          let read = new FileReader();
          read.readAsDataURL(file);
          read.onload = function (e) {
            console.log('load');
          };
        });
      },
      setParam(param){
        this.params =
          {
            'x-session-token': m2.cache.get(CACHE_KEYS.SESSION_TOKEN)
          };
      }
    },
    watch: {
      criteria: {
        handler: function (val) {
          if (typeof this.feedID !== 'undefined') {
            xdapp.util.vue.commitActionStatus(this.criteria.content.length >= 5);
          } else {
            xdapp.util.vue.commitActionStatus(this.criteria.feedbackType && this.criteria.content.length >= 5);
          }
        },
        deep: true
      }
    },
    components: {
			Scroll,
    },
   
  }
</script>
<style>
html,body{
  height: 100%;
  overflow: hidden;
}
.img-item figure{  
  position: relative;  
  width: 100%;  
  height: 0;  
  overflow: hidden;  
  margin: 0;  
  padding-bottom: 100%; 
  background-position: center;  
  background-repeat: no-repeat;  
  background-size: cover;  
} 
</style>

<style lang="scss" scoped>
  $fontColor: #8f8f94;
  $btnColor: #FFDD61;
 
  .img-item {
    float: left;
    width: torem(73.3);
    height: torem(73.3);
    margin: torem(10);
    // border: 1px solid #ccc;
    position: relative;
    .img-close{
      position: absolute;
      width: 20px;
      height: 20px;
      line-height: 20px;
      top: 0;
      right: 0;
      margin-top: -9px;
      margin-right: -9px;
      color: #ccc;
      font-size: torem(10);
      border-radius: 50%;
      border: 1px solid #ccc;
      text-align: center;
      background:#fff;
    }
    .del-img{
      border: 1px solid red;
      color: red;
    }
  }
  .xdapp-feedback-wrapper {
		position: fixed;
		width: 100%;
		height: 100%;
		.scroll-container {
			height: 100%;
			overflow: hidden;
			
		}
    background: #fff;
	}
  .xdapp-feedback-wrapper {
    font-size: torem(14);
    .title {
      position: relative;
      height: 40px;
      margin-left: 10px;
      line-height: 40px;
    }
    .require{
      padding-left: 5px;
      &:before{
        position:absolute;
        top: 3px;
        left: -3px;
        content: '*';
        color: red;
        font-style: normal;
        line-height: 40px;
      }
    }
    .feedback-type {
      .type {
        background-color: #fff;
        padding-left: 15px;
        li {
          position: relative;
          height: 40px;
          line-height: 40px;
          border-bottom: 1px solid #eee;
          .category {
            display: inline-block;
            text-align: center;
            //width: 20%;
          }
          .desc {
            color: $fontColor;
          }
          label {
            position: absolute;
            top: 50%;
            right: 10px;
            width: 20px;
            height: 20px;
            transform: translateY(-50%);
            border: 1px solid #999;
            border-radius: 50%;
          }
          .selected {
            float: right;
            width: 20px;
            height: 20px;
            opacity: 0;
            &:checked {
              + label {
                background-color: #fe6d32;
                border: 1px solid #fe6d32;
              }
              + label.current:after {
                position: absolute;
                content: "";
                width: 5px;
                height: 10px;
                top: 1px;
                left: 6px;
                border: 2px solid #fff;
                border-top: none;
                border-left: none;
                transform: rotate(45deg)
              }
            }
          }
        }
      }
    }
    .feedback-suggest {
      .suggest {
        display: block;
        text-align: right;
        box-sizing: border-box;
        background: #fff;
        textarea {
          margin: 0;
          border: 0px;
          height: 100px;
          // font-size: 14px;
          border: none;
          border-radius: none;
          font-size: torem(14)
        }
        >span {
           padding: 0 15px 5px;
        }
      }
    }
    .feedback-upload {
      .upload-wrapper {
        // display: flex;
        align-items: center;
        height: auto;
        background-color: #fff;
        overflow: hidden;
        .icon {
          position: relative;
          // width: torem(60);
          // height: torem(60);
          // margin: torem(10);
          border: 1px solid $fontColor;
          text-align: center;
          line-height: torem(60);
          overflow: hidden;
          .file {
            display: inline-block;
            overflow: hidden;
            text-decoration: none;
            text-indent: 0;
            i {
              display: inline-block;
              font-size: torem(48);
              color: $fontColor;
              margin-top: torem(6);
            }
            input {
              position: absolute;
              font-size: torem(38);
              right: 0;
              top: 0;
              left: 0;
              bottom: 0;
              opacity: 0;
            }
          }
        }
        .image-wrapper {
          padding-top: 3px;
          .image {
            width: torem(60);
            height: torem(60);
            margin: torem(10) torem(10) torem(10) 0;
          }
        }
      }
    }
    .feedback-submit {
      .feedback-submit-btn {
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 50px;
        border: none;
        background-color: $btnColor;
        &:hover {
          background-color: darken($btnColor, 30%);
        }
      }
    }
  }
</style>
