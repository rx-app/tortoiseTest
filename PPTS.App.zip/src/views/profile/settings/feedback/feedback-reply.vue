﻿<template>
	<div class="xdapp-msg-wrapper">
		<scroll :data="feedbackList" :listen-scroll="listenScroll" :probe-type="probeType" :pulldown="pulldown" @scrollToStart="refreshMore" class="scroll-container" ref="listview" style="background: #fff;">
			<div class="msg-list">
				<ul class="list-group">
					<loading v-show="hasMore" title=""></loading>
					<li class="list-group-item" v-for="(item,index) in feedbackList" :key="index" ref="groupItem">
						<span class="msg-time mui-badge">{{item.createTime | normalize}}</span>
						<div :class="{'msg-item':item.topicType * 1 == 2,'msg-item-right':item.topicType * 1 == 1, 'msg-item-nobefore': item.screenShotID !== ''}">
							<div v-if="item.topicType * 1 == 2">
								<img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png">
							</div>
							<dd v-if="item.screenShotID === ''" class="reply" v-html="item.content"></dd>
							<dd v-else class="feedback-img">
								<img :src="item.feedbackImg" @click="previewerShow(item.feedbackImg)">
							</dd>
							<div v-if="item.topicType * 1 == 1">
								<img class="mui-media-object mui-pull-left headImg" v-if="currentHeadImg" :src="currentHeadImg">
								<img class="mui-media-object mui-pull-left" v-else-if='currentUserGender==2' src="~@/public/asset/img/user/teacher-woman.png" alt="" />
								<img class="mui-media-object mui-pull-left" v-else src="~@/public/asset/img/user/teacher-man.png" alt="" />
								<!--<img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png">-->
							</div>
						</div>
					</li>
				</ul>
			</div>
		</scroll>
		<div v-show="previewer" class="previewer-modal" style="background: #fff;padding-top: 0!important;">
			<img :src="previewerUrl" alt="" @click="closePreviewer">
		</div>
	</div>
</template>

<script>
	import { ReplyType, PreOrLast, Poster, ACTION_TYPES , CACHE_KEYS } from '@/constants';
	import { $getCustomerReplyByType, $sendCustomerReply } from '@/api/customer-reply/customer-reply-api'
	import { loadUserInfo } from '@/api/common/common-api';
	import Scroll from '@/components/scroll/index';
	import Loading from '@/components/loading/index';
	import Tip from '@/components/tip';

	import { pager, orderBy, defaultPageSize } from '@/public/constant';
	import { $getUserFeedbackTopic } from '@/api/settings/setting-api';

	export default {
		data() {
			return {
				probeType: 3,
				listenScroll: true,
				pulldown: true,
				hasMore: false,
				params: {
					feedID: this.$route.query.feedID,
					...pager({
						pageSize: defaultPageSize
					}),
					...orderBy({
						dataField: 'createTime'
					})
				},
				feedbackList: [],
				messages: [],
				firstFetch: true,
				previewer: false,
				previewerUrl: ''
			}
		},
		created() {
			this.enableEvent();
			//this.getCustomerReply();
			this.getUserFeedbackTopic();
		},
		mounted() {
			xdapp.util.vue.commitActionStatus(true);
			window.xueda_replyType = window.xueda_replyType || this.replyType;
			this.$route.meta.title = this.getTitle(window.xueda_replyType)
		},
		activated() {
			if(typeof this.$route.query.keep === 'undefined') {
				this.feedbackList = []
				this.params = {
					feedID: this.$route.query.feedID,
					...pager({
						pageSize: defaultPageSize
					}),
					...orderBy({
						dataField: 'createTime'
					})
				}
				this.enableEvent();
				this.getUserFeedbackTopic();
			} else {
				this.enableEvent();
			}
		},
		methods: {
			getTitle(type) {
				type = parseInt(type)
				return ['功能异常', '意见建议', '其他问题'][type - 1]
			},
			closePreviewer() {
				document.querySelector('.xd-header').style.display = 'block'
				this.previewer = false;
				window.xdapp.previewer = false;
				this.previewerUrl = ''
			},
			previewerShow(imgUrl) {
				// this.$route.meta.showHeader = false
				document.querySelector('.xd-header').style.display = 'none'
				this.previewer = true;
				window.xdapp.previewer = true;
				this.previewerUrl = imgUrl
			},
			getUserFeedbackTopic() {
				$getUserFeedbackTopic(this.params, res => {
					this.feedbackList = res.queryResult.pagedData;
					if(this.firstFetch) {
						this._scrollToBottom();
						this.firstFetch = false;
					}
				});
			},
			getCustomerReply() {
				this.getData();
			},
			setPageTitle() {
				this.$route.meta.title = this.pageTitle;
			},
			async getData() {
				await loadUserInfo();
				if(this.replyType == ReplyType.Teacher) {
					this.params = {
						replierID: this.replierID,
						...this.params
					};
				}

				$getUserFeedbackTopic(this.params, res => {
					this.messages = res.pagedData.concat(this.messages);

					if(!res || !res.length || res.length < this.params.queryNumber) {
						this.hasMore = false;
					} else {
						this.hasMore = true;
						this.params.replyTime = res[0].createTime;
					}
					if(this.firstFetch) {
						this._scrollToBottom();
						this.firstFetch = false;
					}
				});
			},
			refreshMore() {
				if(!this.hasMore)
					return;
				this.getData();
			},
			enableEvent() {
				xdapp.util.vue.on(ACTION_TYPES.GOTO_FEEDBACK, this._gotoReply);
			},
			_gotoReply() {
				this.$router.push({
					name: "feedback-add-reply",
					query: {
						feedID: this.$route.query.feedID
					}
				});
			},
			_scrollToBottom() {
				this.$nextTick(() => {
					setTimeout(() => {
						let groupItems = this.$refs.groupItem;
						let el = groupItems[groupItems.length - 1];
						this.$refs.listview.scrollToElement(el, 200);
					}, 20);
				});
			}
		},
		computed: {
			replyType() {
				return this.$route.query.type;
			},
			pageTitle() {
				return this.$route.query.title;
			},
			replierID() {
				return this.$route.query.staffId;
			},
			currentHeadImg() {
				if(this.$store.state.currentHeadImg && m2.cache.get(CACHE_KEYS.CURRENT_ICONARR)) {
					return this.$store.state.currentHeadImg.imgData || m2.cache.get(CACHE_KEYS.CURRENT_ICONARR).imgData
				}
			}
		},
		components: {
			Scroll,
			Loading,
			Tip
		}
	}
</script>

<style lang="scss" scoped>
	div.previewer-modal {
		position: fixed;
		background: red;
		right: 0;
		top: 0;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 888;
		img {
			width: 100%;
			height: 100%;
		}
	}
	
	.xdapp-msg-wrapper {
		position: fixed;
		width: 100%;
		height: 100%;
		.scroll-container {
			height: 100%;
			overflow: hidden;
			.msg-list {
				background: #fff;
				ul.list-group {
					li {
						padding-top: torem(15);
						padding-bottom: torem(15);
						&:last-child {
							padding-bottom: torem(30);
						}
					}
					.msg-time {
						text-align: center;
						display: block;
						// margin-top: 14px;
						font-size:torem(12);
						margin-left: 40%;
						width: 70px;
						color: #fff;
					}
					.msg-item {
						z-index: 1;
						position: relative;
						padding: 10px 18px 0;
						display: flex;
						img {
							width: 40px;
							height: 40px;
							margin-right: 11px;
						}
						.reply {
							margin-left: 0;
							padding: 8px 15px;
							max-width: torem(222);
							font-size: torem(16);
							color: #333;
							// border: 1px solid #eee;
							border-radius: 5px;
							background-color: #eee;
							.tit {
								font-size: torem(20);
								color: #000;
								line-height: 28px;
							}
						}
						.feedback-img {
							img {
								width: torem(80);
								height: torem(80);
								border-radius: 3px;
							}
						}
						&:after {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-right: 7px solid #eee;
							position: absolute;
							left: 56px;
							top: 27px;
							z-index: 10;
						}
						&:before {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-right: 7px solid #eee;
							position: absolute;
							left: 58px;
							top: 27px;
							z-index: 20;
						}
					}
					.msg-item-nobefore {
						&:before,
						&:after {
							display: none;
						}
					}
					.msg-item-right {
						z-index: 1;
						position: relative;
						padding: 14px 18px 0;
						display: flex;
						align-items: center;
						justify-content: flex-end;
						img {
							width: 40px;
							height: 40px;							
							margin-left: 11px;
						}
						.headImg{
							border-radius: 50%;
						}
						.reply {
							font-size:torem(15);
							color: #333;
							padding: 8px 15px;
							margin-left: torem(57);
							background: #ffe3b6;
							border-radius: 5px;
							.tit {
								font-size: torem(20);
								color: #000;
								line-height: 28px;
							}
						}
						&:after {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-left: 7px solid #ffe3b6;
							position: absolute;
							right: 56px;
							top: 27px;
							z-index: 10;
						}
						&:before {
							content: '';
							width: 0;
							height: 0;
							border: 7px solid transparent;
							border-left: 7px solid #ffe3b6;
							position: absolute;
							right: 58px;
							top: 27px;
							z-index: 20;
						}
					}
				}
			}
		}
	}
</style>