﻿import * as types from './mutation-types';
import { CACHE_KEYS } from '@/constants';

export default {
  [types.GET_USER_INFO](state, data) {
    state.userId = data.userId;
    state.displayName = data.displayName;
    state.logOnName = data.logOnName;
    state.roles = data.roles;
    state.userInfo = data.userInfo;
    state.jobs = data.jobs;
    state.currentJob = (() => {
      return m2.cache.get(CACHE_KEYS.CURRENT_JOB) || data.jobs.find(item => item.isPrimary)
    })();
  },
  [types.ICON_ID](state,iconID){
    state.iconID = iconID;
  },
  [types.SWITCH_JOB](state,currentJob){
    state.currentJob = currentJob;
  },
  [types.ENABLE_STATUS](state, enableStatus){
    state.enabledStatus = enableStatus;
  },
  [types.FINGERPSDSTATUS](state,fingerPsdStatus){
    state.fingerPsdStatus = fingerPsdStatus;
  },
  [types.NAVTABS](state,navTabs){
    state.navTabs = navTabs;
  },
  [types.HEADLIST_ARR](state,headList){
    state.headList = headList;
  },
  [types.FINGERPSDNUM](state,fingerPsdNum){
    state.fingerPsdNum = fingerPsdNum;
  },
  [types.CURRENT_USER_HEAD](state,currentHeadImg){
    state.currentHeadImg = currentHeadImg;
  },
  [types.CURRENT_USER_GDENDER](state,currentUserGender){
    state.currentUserGender = currentUserGender;
  }
};
