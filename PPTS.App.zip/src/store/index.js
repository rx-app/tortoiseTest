import Vue from 'vue'
import Vuex from 'vuex'
import mutations from './mutations'

Vue.use(Vuex);

//配置vueX参数
let state = {
  userId: "",
  displayName: "",
  logOnName: "",
  roles: null,
  userInfo:{},
  currentJob: {},
  jobs:[],
  navTabs:[],
  iconID:'',
  currentHeadImg:{},
  headList:[],
  currentUserGender:1,
  enabledStatus: false // 右上角按钮的操作状态
};

let getters = {
  getJob: (state) => (id) => {
    return state.jobs.find(item => {
      return item.id == id
    })
  }
};

var store = new Vuex.Store({
  state,
  mutations,
  getters,
  strict: true
})

export default store;
