﻿// 获取当前用户信息
export const GET_USER_INFO = 'GET_USER_INFO'
// 获取当前孩子
export const GET_CURRENT_CHILDREN = 'GET_CURRENT_CHILDREN'
// 切换工作岗位
export const SWITCH_JOB = 'SWITCH_JOB'
// 修改操作按钮的状态
export const ENABLE_STATUS = 'ENABLE_STATUS'
// 获取手势密码是否开通
export const FINGERPSDSTATUS = 'FINGERPSDSTATUS'
// 获取手势密码
export const FINGERPSDNUM = 'FINGERPSDNUM'
// 教师体系，学管体系导航
export const NAVTABS = 'NAVTABS'
// 当前用户头像信息
export const CURRENT_USER_HEAD = 'CURRENT_USER_HEAD'
// 当前用户性别
export const CURRENT_USER_GDENDER = 'CURRENT_USER_GDENDER'
// 当前用户头像ID
export const ICON_ID = 'ICON_ID'
// 除了当前登陆者 其他用户的头像集合
export const HEADLIST_ARR = 'HEADLIST_ARR'
