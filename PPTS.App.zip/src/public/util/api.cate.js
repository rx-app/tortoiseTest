﻿import Vue from 'vue';
// import axios from 'axios';
// import { HEADER_KEYS, CACHE_KEYS } from '@/public/constant';
// import res from '@/api'

// axios.defaults.baseURL = process.env.APP_API_ROOT;

export default ()=>{  
    xdapp.config.categoriesConfig.categories.forEach(item => {
        const filterName = item.filterName;
        const categoryID = item.categoryID.toLowerCase();
        Vue.filter(filterName, (value) => {
            if (!value || !xdapp.dict) return;
              return m2.util.getValue(xdapp.dict[categoryID], value);
            });
        }
    );
}