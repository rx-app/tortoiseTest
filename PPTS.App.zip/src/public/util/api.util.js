﻿import Vue from 'vue';
import axios from 'axios';
import { HEADER_KEYS, CACHE_KEYS } from '@/public/constant';

//axios.defaults.baseURL = process.env.APP_API_ROOT;

export default {
	getFullConfig: async() => {
		if(xdapp.config) return;

		let config = await axios.get(xdapp.api.config.getFullConfig);

		xdapp.config = config;

		console.log('getFullConfig=', xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl);

		xdapp.config.categoriesConfig.categories.forEach(item => {
			const filterName = item.filterName;
			const categoryID = item.categoryID.toLowerCase();

			Vue.filter(filterName, (value) => {
				if(!value || !xdapp.dict) return;
				return m2.util.getValue(xdapp.dict[categoryID], value);
			});
		});
	},
	getApplicationInsightsConfig:async() =>{
		let aiConfig = await axios.get(xdapp.api.config.getApplicationInsightsConfig);
		xdapp.aiConfig = aiConfig;		
	}
};