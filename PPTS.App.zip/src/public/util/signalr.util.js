/*
 * @Descripttion: 
 * @version: app-1.1.3
 * @Author: 郭甜丹
 * @Date: 2019-11-08 17:53:50
 * @LastEditors  : 郭甜丹
 * @LastEditTime : 2020-01-07 14:03:33
 */
import { HubConnectionBuilder, LogLevel } from '@aspnet/signalr'
import { CACHE_KEYS } from '@/constants';

export default {
    install(Vue, options) {

        const staffHub = new Vue()
        Vue.prototype.$staffHub = staffHub

        //let connected = false
        staffHub.connected = false
        staffHub.connecting = false

        staffHub.ensureConnection = function () {

            var token = m2.cache.get(CACHE_KEYS.SESSION_TOKEN);

            if (xdapp.config.webApiConfig.webAPIs.pptsSignalrUrl && token && !staffHub.connected) {

                staffHub.connected = true

                const connection = new HubConnectionBuilder()
                    .withUrl(xdapp.config.webApiConfig.webAPIs.pptsSignalrUrl, { accessTokenFactory: () => token })
                    .configureLogging(LogLevel.Information)
                    .build()

                connection.on('MessageReceived', msg => {

                    if (msg) {
                        msg.forEach(m => {
                            m.data = m.bodyData ? JSON.parse(m.bodyData) : undefined;
                            staffHub.$emit(m.topicName, m)
                        });
                    }
                })
                let startedPromise = null, Timeout = 5000;
                function start() {
                    if (staffHub.connecting) return;
                    staffHub.connecting = true
                    startedPromise = connection.start().then(_ => {
                        staffHub.connecting = false
                        staffHub.$emit('signalr-connected', true)
                    }).catch(err => {
                        staffHub.connecting = false
                        console.error('Failed to connect with hub', err)
                        staffHub.connected = false
                        Timeout += 1000;
                        return new Promise((resolve, reject) =>
                            setTimeout(() => start().then(resolve).catch(reject), 5000))
                    })
                    return startedPromise
                }
                connection.onclose(() => {

                    staffHub.connected = false
                    staffHub.$emit('signalr-closed', false)
                    //start()
                    Timeout += 1000;
                    new Promise((resolve, reject) =>
                        setTimeout(() => start().then(resolve).catch(reject), Timeout))
                })

                start()
            }
        }
    }
}