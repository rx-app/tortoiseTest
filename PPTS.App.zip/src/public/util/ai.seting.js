export default {
    seting: (logOnName) => {
        if ($vue && $vue.$ai && $vue.$ai.aisdk) {
            var logOnName = m2.cache.get("ppts-current-user") && m2.cache.get("ppts-current-user").logOnName || logOnName;
            if (!logOnName) return;
            var validatedId = logOnName.replace(/[,;=| ]+/g, "_");
            if(logOnName=="loginOut"){
                $vue.$ai.aisdk.setAuthenticatedUserContext(null);
            }else{
                $vue.$ai.aisdk.setAuthenticatedUserContext(validatedId);
            }
            
            var ele = document.getElementById("aiSrcEle");
            if (!ele) {
                let scriptTag = document.createElement("script");
                scriptTag.id = "aiSrcEle";
                scriptTag.src = "https://az416426.vo.msecnd.net/scripts/b/ai.2.min.js";
                document.body.appendChild(scriptTag);
            }
        }
    }
};