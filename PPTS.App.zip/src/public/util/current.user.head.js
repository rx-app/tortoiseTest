import store from '@/store';
import * as types from '@/store/mutation-types';
import { HEAD_EXPIRY_TIME } from '@/public/constant';
import { CACHE_KEYS } from '@/constants';
import { loadUserInfo } from '@/api/common/common-api';
import { getHeadIDsByUserIDs, getHead } from '@/api/user/user-api';

function getHeadAgin() {
	getHead({
		iconID: m2.cache.get(CACHE_KEYS.CURRENT_ICONID) || $vue.$store.state.iconID
	}, result => {
		let currentHeadObj = {
			userID: m2.util.getCurrentUserID(),
			imgData: result,
			/*dates: new Date()*/
		};
		store.commit(types.CURRENT_USER_HEAD, currentHeadObj);
		// 保存当前用户头像信息
		m2.cache.set(CACHE_KEYS.CURRENT_ICONARR, currentHeadObj);
		window.xdapp.currentUserChangeIcon = false;
	})
}

export default {
	getCurrentHead: (type) => {
		let currentHeadMes = m2.cache.get(CACHE_KEYS.CURRENT_ICONARR) || $vue.$store.state.currentHeadImg;
		let currentIcon = m2.cache.get(CACHE_KEYS.CURRENT_ICONID) || $vue.$store.state.iconID;
		//点击更新按钮
		if (type == 'upload') {
			getHeadIDsByUserIDs(m2.util.getCurrentUserHead(), iconMess => {
				if (iconMess[0].iconID) {
					getHead({ iconID: iconMess[0].iconID }, result => {
						let currentHeadObj = {
							userID: m2.util.getCurrentUserID(),
							imgData: result,
							/*dates: new Date()*/
						};
						store.commit(types.CURRENT_USER_HEAD, currentHeadObj);
						// 保存当前用户头像信息
						m2.cache.set(CACHE_KEYS.CURRENT_ICONARR, currentHeadObj);
					})
				} else {
					store.commit(types.CURRENT_USER_GDENDER, iconMess[0].gender);
				}
			})
			return;
		}
		// if (type == 'upd') {
		// 	if (!currentIcon) {
		// 		getHeadIDsByUserIDs(m2.util.getCurrentUserHead(), iconMess => {
		// 			if (iconMess) {
		// 				store.commit(types.CURRENT_USER_GDENDER, iconMess[0].gender);
		// 			}
		// 		});
		// 		store.commit(types.CURRENT_USER_HEAD, {});
		// 		// 保存当前用户头像信息
		// 		m2.cache.set(CACHE_KEYS.CURRENT_ICONARR, {});
		// 		return;
		// 	}
		// 	if (currentHeadMes.userID !== m2.cache.get(CACHE_KEYS.CURRENT_USER).userId) {
		// 		getHeadAgin();
		// 		return;
		// 	}

		// }
		//当前用户没有iconID 请求用户信息 获取性别
		if (!currentIcon) {
			getHeadIDsByUserIDs(m2.util.getCurrentUserHead(), iconMess => {
				if (iconMess) {
					store.commit(types.CURRENT_USER_GDENDER, iconMess[0].gender);
				}
			})
		};
		//当前用户有iconID 但是没有头像串 请求
		if (currentIcon && !currentHeadMes.imgData) {
			getHeadAgin();
			return;
		};
		//当前用户有头像串 但存储过期 请求
		/*if(currentHeadMes.imgData && ((Date.parse(new Date()) - Date.parse(currentHeadMes.dates)) > HEAD_EXPIRY_TIME)) {
			getHeadAgin();
			return;
		};*/
		//刚换完头像
		if (window.xdapp.currentUserChangeIcon) {
			getHeadAgin();
			return;
		};
	}
}