document.addEventListener( "plusready",  function(){
    var    JIM_PAYMENT = 'jimpayment',
    B = window.plus.bridge;
    var jimpayment = {
        PluginTestFunction : function (Argus1, Argus2, successCallback, errorCallback ){
            var success = typeof successCallback !== 'function' ? null : function(args){
                successCallback(args);
            },
            fail = typeof errorCallback !== 'function' ? null : function(code){
                errorCallback(code);
            };
            callbackID = B.callbackId(success, fail);

            return B.exec(JIM_PAYMENT, "PluginTestFunction", [callbackID, Argus1, Argus2]);
        },
        PluginTestFunctionArrayArgu : function (Argus, successCallback, errorCallback ){
            var success = typeof successCallback !== 'function' ? null : function(args)
            {
                successCallback(args);
            },
            fail = typeof errorCallback !== 'function' ? null : function(code)
            {
                errorCallback(code);
            };
            callbackID = B.callbackId(success, fail);
            return B.exec(JIM_PAYMENT, "PluginTestFunctionArrayArgu", [callbackID, Argus]);
        },
        PluginTestFunctionSync : function (Argus1, Argus2){
            return B.execSync(JIM_PAYMENT, "PluginTestFunctionSync", [Argus1, Argus2]);
        },
        PluginTestFunctionSyncArrayArgu : function (Argus){
            return B.execSync(JIM_PAYMENT, "PluginTestFunctionSyncArrayArgu", [Argus]);
        }
    };
    window.myplus.jimpayment = jimpayment;
}, true );
