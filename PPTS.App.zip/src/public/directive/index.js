import Vue from 'vue';
import { CACHE_KEYS } from '@/constants';
Vue.directive('focus', {
	inserted: function(el) {
		el.focus();
	}
});
Vue.directive("power", {
	inserted: function(el, binding) {
		let currentFunctions = m2.cache.get(CACHE_KEYS.CURRENT_JOB)?m2.cache.get(CACHE_KEYS.CURRENT_JOB).functions:[];
		let isShow = currentFunctions.some(currentFunction => currentFunction == binding.value);
		if(!isShow) {
			el.style.display = "none";
		}
	}
})