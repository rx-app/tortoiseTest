﻿// 所有的缓存KEY
export const CACHE_KEYS = {
	CURRENT_JOB: 'ppts-current-job',
	CURRENT_USER: 'ppts-current-user',
	CURRENT_ICONID: 'ppts-current-iconID',
	CURRENT_ICONARR: 'ppts-current-iconArr',
	SESSION_TOKEN: 'ppts-session-token',
	ACTION_TYPE: 'ppts.event.actionType',
	PAYLOAD: 'ppts.event.payload',
	FINGERPSDSTATUS: "ppts.finger.psd",
	FINGERPSDNUM: "ppts.finger.num",
	ROOTADDRESS: "rootAddress",
	NAVTABS: 'navTabs'
};

// 浏览器头
export const HEADER_KEYS = {
	JOB_HEADER_KEY: 'pptsCurrentJobID'
};

export const ACTION_TYPES = {
	SELECT_TEACHER: '选择教师',
	SUBMIT_COMMET: '提交评价',
	SWITCH_JOB: '切换岗位',
	GOTO_FEEDBACK: '留言',
	CHANGE_INP: '编辑',
	NEXT_TYPE: '下一步'
};

// 底部tab菜单 适用于学管师
export const FOOTER_NAV_TABS_FIRST = [{
	name: '首页',
	imgOn: 'home-on.png',
	imgOff: 'home-off.png',
	showImgOn: true,
	link: 'home',
	functions: ''
}, {
	name: '学员',
	imgOn: 'customer-on.png',
	imgOff: 'customer-off.png',
	showImgOn: false,
	link: 'customer',
	functions: '睿学-导航-学员'
}, {
	name: '消息',
	imgOn: 'message-on.png',
	imgOff: 'message-off.png',
	showImgOn: false,
	link: 'message',
	functions: ''
}, {
	name: '课表',
	imgOn: 'course-on.png',
	imgOff: 'course-off.png',
	showImgOn: false,
	link: 'course',
	functions: '睿学-导航-课表'
}, {
	name: '我的',
	imgOn: 'profile-on.png',
	imgOff: 'profile-off.png',
	showImgOn: false,
	link: 'profile',
	functions: ''
}];

// 底部tab菜单 适用于教师
export const FOOTER_NAV_TABS_LAST = [{
	name: '首页',
	imgOn: 'home-on.png',
	imgOff: 'home-off.png',
	showImgOn: true,
	link: 'home',
	functions: ''
}, {
	name: '课表',
	imgOn: 'course-on.png',
	imgOff: 'course-off.png',
	showImgOn: false,
	link: 'course',
	functions: '睿学-导航-课表'
}, {
	name: '消息',
	imgOn: 'message-on.png',
	imgOff: 'message-off.png',
	showImgOn: false,
	link: 'message',
	functions: ''
}, {
	name: '学员',
	imgOn: 'customer-on.png',
	imgOff: 'customer-off.png',
	showImgOn: false,
	link: 'customer',
	functions: '睿学-导航-学员'
}, {
	name: '我的',
	imgOn: 'profile-on.png',
	imgOff: 'profile-off.png',
	showImgOn: false,
	link: 'profile',
	functions: ''
}];
// 底部tab菜单 适用于兼职
export const FOOTER_NAV_TABS_NOFULL = [{
	name: '首页',
	imgOn: 'home-on.png',
	imgOff: 'home-off.png',
	showImgOn: true,
	link: 'home',
	functions: ''
}, {
	name: '课表',
	imgOn: 'course-on.png',
	imgOff: 'course-off.png',
	showImgOn: false,
	link: 'course',
	functions: '睿学-导航-课表'
}, {
	name: '消息',
	imgOn: 'message-on.png',
	imgOff: 'message-off.png',
	showImgOn: false,
	link: 'message',
	functions: ''
}, {
	name: '我的',
	imgOn: 'profile-on.png',
	imgOff: 'profile-off.png',
	showImgOn: false,
	link: 'profile',
	functions: ''
}];
// 学员
export const CUSTOMER_INDEX = [{
	title: '学员',
	pathname: 'customer',
	icon_active: require('@/public/asset/img/course/customer-on.png'),
	icon: require('@/public/asset/img/course/customer-off.png'),
	active: true,
	functions: '睿学-学员列表'
}, {
	title: '成绩',
	pathname: 'score',
	icon_active: require('@/public/asset/img/course/ppts-score-on.png'),
	icon: require('@/public/asset/img/course/ppts-score.png'),
	active: false,
	functions: '睿学-成绩列表'
}, {
	title: '回访',
	pathname: 'returnVisit',
	icon_active: require('@/public/asset/img/course/return-on.png'),
	icon: require('@/public/asset/img/course/return-off.png'),
	active: false,
	functions: '睿学-回访列表'
}, {
	title: '家长会',
	pathname: 'parentMeet',
	icon_active: require('@/public/asset/img/course/parent-on.png'),
	icon: require('@/public/asset/img/course/parent-off.png'),
	active: false,
	functions: '睿学-家长会列表'
}, {
	title: '跟进',
	pathname: 'followUp',
	icon_active: require('@/public/asset/img/course/follow-on.png'),
	icon: require('@/public/asset/img/course/follow-off.png'),
	active: false,
	functions: '跟进管理（学员视图-跟进记录跟进记录详情）'
}];

//课表
export const COURSE_INDEX_ALL = [{
	title: '教师课表',
	pathname: 'course',
	icon_active: require('@/public/asset/img/course/teachCourse-on.png'),
	icon: require('@/public/asset/img/course/teachCourse-off.png'),
	active: true,
	functions: '睿学-教师课表'
}, {
	title: '学员课表',
	pathname: 'studentCourse',
	icon_active: require('@/public/asset/img/course/studentCourse-on.png'),
	icon: require('@/public/asset/img/course/studentCourse-off.png'),
	active: true,
	functions: '睿学-学员课表'
}];
// 我的
export const PROFILE_INDEX = [{
	title: '课间小憩',
	pathname: 'classBreak'
}, {
	title: '设置',
	pathname: 'settings'
}];
// 我的-设置
export const PROFILE_SETTING = [
	/*{
		title: '密码管理',
		pathname: 'profile-settings-password-manage'
	},
	{
	 title: '绑定管理',
	 pathname: 'profile-settings-bind-manage'
	 },
	 {
	 title: '授权管理',
	 pathname: 'profile-settings-author-manage'
	 },
	{
		title: '手势密码',
		pathname: 'profile-settings-finger'
	},
	{
		title: '消息通知',
		pathname: 'profile-settings-notify'
	},*/
	{
		title: '关于掌上学大',
		pathname: 'profile-settings-about'
	},
	{
		title: '建议反馈',
		pathname: 'feedback-list'
	},
	{
		title: '版本信息',
		pathname: 'profile-settings-version'
	}
];
// 我的-设置
export const PROFILE_PPTS = [{
	title: '关于睿学',
	pathname: 'profile-settings-about'
},
{
	title: '建议反馈',
	pathname: 'profile-settings-feedback'
},
{
	title: '版本信息',
	pathname: 'profile-settings-version'
}
];
// 我的-设置-密码管理-密码管理
export const PROFILE_PASSWORD_MANAGE = [{
	title: '登录密码',
	pathname: 'profile-settings-password-login'
}];
// 我的-设置-关于睿学
export const PROFILE_PPTS_ABOUT = [{
	title: '去评分',
	pathname: 'profile-settings-eval'
},
{
	title: '功能介绍',
	pathname: 'profile-settings-edition'
}
];
export const SIGNUP_TIP = '已通知归属学管师，如果该老师未能与您及时联系，可主动与其电话沟通！';
// 课时状态
export const ASSIGN_STATUS = {
	// 排定
	Assigned: 1,
	// 已上
	Confirmed: 3
};
// 课时评价
export const COURSE_EVALUATE_SCORE_CONFIG = [{
	value: 1,
	desc: '很差'
},
{
	value: 2,
	desc: '差'
},
{
	value: 3,
	desc: '一般'
},
{
	value: 4,
	desc: '好'
},
{
	value: 5,
	desc: '很好'
}
];
export const selectWay = [{
	key: "1",
	value: '发邮件'
},
{
	key: "2",
	value: '发短信'
}, {
	key: "3",
	value: 'app内消息'
}
];
// 年级
export const CUSTOMER_GRADE = [
	{
		gardeType: "幼儿园",
		garde: [
			{
				gardeName: "幼儿园小班",
				gardeValue: 4
			},
			{
				gardeName: "幼儿园中班",
				gardeValue: 5
			},
			{
				gardeName: "幼儿园大班",
				gardeValue: 6
			},
			{
				gardeName: "学前班",
				gardeValue: 10
			},
		]
	},
	{
		gardeType: "小学",
		garde: [
			{
				gardeName: "小学一年级",
				gardeValue: 11
			},
			{
				gardeName: "小学二年级",
				gardeValue: 12
			},
			{
				gardeName: "小学三年级",
				gardeValue: 13
			},
			{
				gardeName: "小学四年级",
				gardeValue: 14
			},
			{
				gardeName: "小学五年级",
				gardeValue: 15
			},
			{
				gardeName: "小学六年级",
				gardeValue: 16
			},
		]
	},
	{
		gardeType: "初中",
		garde: [
			{
				gardeName: "初中一年级",
				gardeValue: 21
			},
			{
				gardeName: "初中二年级",
				gardeValue: 22
			},
			{
				gardeName: "初中三年级",
				gardeValue: 23
			},
			{
				gardeName: "初中四年级",
				gardeValue: 24
			},
		]
	},
	{
		gardeType: "高中",
		garde: [
			{
				gardeName: "高中一年级",
				gardeValue: 31
			},
			{
				gardeName: "高中二年级",
				gardeValue: 32
			},
			{
				gardeName: "高中三年级",
				gardeValue: 33
			},
			{
				gardeName: "高三毕业",
				gardeValue: 34
			},
		]
	},
];
// 学员状态  没有所有的状态
export const CUSTOMER_STATUS_SHORT = [
	{
		value: 1,
		desc: '活跃'
	},
	{
		value: 2,
		desc: '上课'
	},
	{
		value: 3,
		desc: '停课'
	},
	{
		value: 4,
		desc: '休学'
	},
	{
		value: 5,
		desc: '有效'
	},
	{
		value: 6,
		desc: '结课'
	},
	{
		value: 7,
		desc: '无订单'
	}
];
// 学员状态
export const CUSTOMER_STATUS = [{
	value: 0,
	desc: '所有'
},
{
	value: 1,
	desc: '活跃'
},
{
	value: 2,
	desc: '上课'
},
{
	value: 3,
	desc: '停课'
},
{
	value: 4,
	desc: '休学'
},
{
	value: 5,
	desc: '有效'
},
{
	value: 6,
	desc: '结课'
},
{
	value: 7,
	desc: '无订单'
}
];/*.doc|.docx|.xls|.xlsx| |.bmp|.ppt|.mp4*/
export const loadFormat = "(.jpg|.jpeg|.png|.bmp)$";
// 通知消息科目
export const NotifyCatalog = {
	// 课业通知
	LessonNotify: 1,
	// 家长申请
	ParentApply: 2,
	// 系统消息
	SystemNotify: 99
};
//通知消息科目类型
export const NotifyCategoryDefine = {

}
// 消息通知查询方向
export const PreOrLast = {
	// 向后查询
	Next: 0,
	// 向前查询
	Pre: 1
};
// 家校互动类型
export const ReplyLinkType = {
	// 日常维护
	Educator: "日常维护",
	// 日常维护
	Conection: "家校互动",
	// 周反馈
	EducatorWeek: "周反馈"
};
// 家校互动类型
export const ReplyType = {
	//咨询师
	Inquiry: '1',
	//学管师
	MngTeacher: '2',
	// 教师
	Educator: '3',
	//校区反馈
	School: '4',
	// 周反馈
	EducatorWeek: "6"
};

// 家校互动发言人
export const Poster = {
	Xueda: 1,
	Customer: 2
};
//当前岗位
export const CurrentJob = "学习管理师"

//岗位类型
export const JobType = {
	// 学习管理师
	MngTeacherJob: 2,
	//教师
	//Educator:3,
}

// 我的-设置-关于睿学
export const PROFILE_RX_ABOUT = [/*{
		title: '去评分',
		pathname: 'profile-settings-eval',
		isGoUrl: true
	},*/
	{
		title: '功能介绍',
		pathname: 'profile-settings-about-list'
	}
];
//创建讨论组时 人员类型
export const GroupMembersUserType = {
	Consultant: 1,/*咨询师 */
	Educator: 2,/*学管师 */
	Teacher: 3,/*教师 */
	Customer: 4,/*学员家长 */
	Systerm: 5/*系统 */
}
// 机构类型
export const DepartmentType = {
	//总公司
	HQ: '1',
	//分公司
	Branch: '2',
	// 校区
	Campus: '3',
	//部门
	Department: '4',
};

export const spr = [
	{ key: "1", value: "儿子", ss: "1", r: [{ key: "1", value: "父亲", ps: "1" }, { key: "2", value: "母亲", ps: "2" }] },
	{ key: "2", value: "女儿", ss: "2", r: [{ key: "1", value: "父亲", ps: "1" }, { key: "2", value: "母亲", ps: "2" }] },
	{ key: "3", value: "孙子", ss: "1", r: [{ key: "3", value: "祖父", ps: "1" }, { key: "4", value: "祖母", ps: "2" }] },
	{ key: "4", value: "孙女", ss: "2", r: [{ key: "3", value: "祖父", ps: "1" }, { key: "4", value: "祖母", ps: "2" }] },
	{ key: "5", value: "外孙子", ss: "1", r: [{ key: "5", value: "外祖父", ps: "1" }, { key: "6", value: "外祖母", ps: "2" }] },
	{ key: "6", value: "外孙女", ss: "2", r: [{ key: "5", value: "外祖父", ps: "1" }, { key: "6", value: "外祖母", ps: "2" }] },
	{ key: "7", value: "曾孙", ss: "1", r: [{ key: "7", value: "曾祖父", ps: "1" }, { key: "8", value: "曾祖母", ps: "2" }] },
	{ key: "8", value: "曾孙女", ss: "2", r: [{ key: "7", value: "曾祖父", ps: "1" }, { key: "8", value: "曾祖母", ps: "2" }] },
	{ key: "9", value: "侄女", ss: "2", r: [{ key: "9", value: "姑姑", ps: "2" }, { key: "10", value: "姑父", ps: "1" }, { key: "11", value: "叔叔", ps: "1" }, { key: "12", value: "婶婶", ps: "2" }, { key: "25", value: "伯父", ps: "1" }, { key: "26", value: "伯母", ps: "2" }] },
	{ key: "10", value: "侄子", ss: "1", r: [{ key: "9", value: "姑姑", ps: "2" }, { key: "10", value: "姑父", ps: "1" }, { key: "11", value: "叔叔", ps: "1" }, { key: "12", value: "婶婶", ps: "2" }, { key: "25", value: "伯父", ps: "1" }, { key: "26", value: "伯母", ps: "2" }] },
	{ key: "11", value: "外甥", ss: "1", r: [{ key: "13", value: "舅舅", ps: "1" }, { key: "14", value: "舅母", ps: "2" }, { key: "15", value: "姨", ps: "2" }, { key: "16", value: "姨夫", ps: "1" }] },
	{ key: "12", value: "外甥女", ss: "2", r: [{ key: "13", value: "舅舅", ps: "1" }, { key: "14", value: "舅母", ps: "2" }, { key: "15", value: "姨", ps: "2" }, { key: "16", value: "姨夫", ps: "1" }] },
	{ key: "13", value: "养子", ss: "1", r: [{ key: "17", value: "养父", ps: "1" }, { key: "18", value: "养母", ps: "2" }] },
	{ key: "14", value: "养女", ss: "2", r: [{ key: "17", value: "养父", ps: "1" }, { key: "18", value: "养母", ps: "2" }] },
	{ key: "15", value: "继子", ss: "1", r: [{ key: "19", value: "继父", ps: "1" }, { key: "20", value: "继母", ps: "2" }] },
	{ key: "16", value: "继女", ss: "2", r: [{ key: "19", value: "继父", ps: "1" }, { key: "20", value: "继母", ps: "2" }] },
	{ key: "17", value: "弟弟", ss: "1", r: [{ key: "21", value: "哥哥", ps: "1" }, { key: "22", value: "嫂子", ps: "2" }, { key: "23", value: "姐姐", ps: "2" }, { key: "24", value: "姐夫", ps: "1" }] },
	{ key: "18", value: "妹妹", ss: "2", r: [{ key: "21", value: "哥哥", ps: "1" }, { key: "22", value: "嫂子", ps: "2" }, { key: "23", value: "姐姐", ps: "2" }, { key: "24", value: "姐夫", ps: "1" }] }
];
export const psr = [
	{ key: "1", value: "父亲", ps: "1", r: [{ key: "1", value: "儿子", ss: "1" }, { key: "2", value: "女儿", ss: "2" }] },
	{ key: "2", value: "母亲", ps: "2", r: [{ key: "1", value: "儿子", ss: "1" }, { key: "2", value: "女儿", ss: "2" }] },
	{ key: "3", value: "祖父", ps: "1", r: [{ key: "3", value: "孙子", ss: "1" }, { key: "4", value: "孙女", ss: "2" }] },
	{ key: "4", value: "祖母", ps: "2", r: [{ key: "3", value: "孙子", ss: "1" }, { key: "4", value: "孙女", ss: "2" }] },
	{ key: "5", value: "外祖父", ps: "1", r: [{ key: "5", value: "外孙子", ss: "1" }, { key: "6", value: "外孙女", ss: "2" }] },
	{ key: "6", value: "外祖母", ps: "2", r: [{ key: "5", value: "外孙子", ss: "1" }, { key: "6", value: "外孙女", ss: "2" }] },
	{ key: "7", value: "曾祖父", ps: "1", r: [{ key: "7", value: "曾孙", ss: "1" }, { key: "8", value: "曾孙女", ss: "2" }] },
	{ key: "8", value: "曾祖母", ps: "2", r: [{ key: "7", value: "曾孙", ss: "1" }, { key: "8", value: "曾孙女", ss: "2" }] },
	{ key: "9", value: "姑姑", ps: "2", r: [{ key: "9", value: "侄女", ss: "2" }, { key: "10", value: "侄子", ss: "1" }] },
	{ key: "10", value: "姑父", ps: "1", r: [{ key: "9", value: "侄女", ss: "2" }, { key: "10", value: "侄子", ss: "1" }] },
	{ key: "11", value: "叔叔", ps: "1", r: [{ key: "9", value: "侄女", ss: "2" }, { key: "10", value: "侄子", ss: "1" }] },
	{ key: "12", value: "婶婶", ps: "2", r: [{ key: "9", value: "侄女", ss: "2" }, { key: "10", value: "侄子", ss: "1" }] },
	{ key: "13", value: "舅舅", ps: "1", r: [{ key: "11", value: "外甥", ss: "1" }, { key: "12", value: "外甥女", ss: "2" }] },
	{ key: "14", value: "舅母", ps: "2", r: [{ key: "11", value: "外甥", ss: "1" }, { key: "12", value: "外甥女", ss: "2" }] },
	{ key: "15", value: "姨", ps: "2", r: [{ key: "11", value: "外甥", ss: "1" }, { key: "12", value: "外甥女", ss: "2" }] },
	{ key: "16", value: "姨夫", ps: "1", r: [{ key: "11", value: "外甥", ss: "1" }, { key: "12", value: "外甥女", ss: "2" }] },
	{ key: "17", value: "养父", ps: "1", r: [{ key: "13", value: "养子", ss: "1" }, { key: "14", value: "养女", ss: "2" }] },
	{ key: "18", value: "养母", ps: "2", r: [{ key: "13", value: "养子", ss: "1" }, { key: "14", value: "养女", ss: "2" }] },
	{ key: "19", value: "继父", ps: "1", r: [{ key: "15", value: "继子", ss: "1" }, { key: "16", value: "继女", ss: "2" }] },
	{ key: "20", value: "继母", ps: "2", r: [{ key: "15", value: "继子", ss: "1" }, { key: "16", value: "继女", ss: "2" }] },
	{ key: "21", value: "哥哥", ps: "1", r: [{ key: "17", value: "弟弟", ss: "1" }, { key: "18", value: "妹妹", ss: "2" }] },
	{ key: "22", value: "嫂子", ps: "2", r: [{ key: "17", value: "弟弟", ss: "1" }, { key: "18", value: "妹妹", ss: "2" }] },
	{ key: "23", value: "姐姐", ps: "2", r: [{ key: "17", value: "弟弟", ss: "1" }, { key: "18", value: "妹妹", ss: "2" }] },
	{ key: "24", value: "姐夫", ps: "1", r: [{ key: "17", value: "弟弟", ss: "1" }, { key: "18", value: "妹妹", ss: "2" }] },
	{ key: "25", value: "伯父", ps: "1", r: [{ key: "9", value: "侄女", ss: "2" }, { key: "10", value: "侄子", ss: "1" }] },
	{ key: "26", value: "伯母", ps: "2", r: [{ key: "9", value: "侄女", ss: "2" }, { key: "10", value: "侄子", ss: "1" }] }
];
//跟进记录-沟通结果
export const talkData = [{ key: 'A1', value: '有意向上门时间的客户，一周内上门' },
{ key: 'A2', value: '有意向上门时间的客户，两周内上门' },
{ key: 'A3', value: '有意向上门时间的客户，一个月内上门' },
{ key: 'A4', value: '有意向上门时间的客户，一个月以上上门' },
{ key: 'B1', value: '小一到高三年级以内的有效客户，需要一对一' },
{ key: 'B2', value: '小一到高三年级以内的有效客户，需要班组/上门及其他' },
{ key: 'B3', value: '小一到高三年级以内的有效客户，需要适中可以联系' },
{ key: 'B4', value: '小一到高三年级以内的有效客户，需要弱（再联系）' },
{ key: 'C1', value: '小一到高三年级以外的潜在客户，非目标年级（小一以下，高三以上年级）' },
{ key: 'C2', value: '小一到高三年级以外的潜在客户，非目标地域（客户城市无校区）' },
{ key: 'D', value: '无效客户' }];

export const isStudyThereArr = [{
	key: true, value: '是'
}, {
	key: false, value: '否'
}]