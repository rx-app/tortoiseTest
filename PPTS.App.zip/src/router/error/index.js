import router from '@/public/router';

export default [{
	...router('/error-offline', {
		name: 'error-offline',
        title: '',
        showHeader: false,
		showFooter: false,
		disableBack: true,
	}),
	component: resolve => require(['@/views/error/index'], resolve)
}]