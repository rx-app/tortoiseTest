﻿import router from '@/public/router';

export default [{/*首页*/
	...router('/', {
		redirect: '/home'
	}),
	component: resolve => require(['@/views/home'], resolve)
},{
	...router('/login', {/*登录页*/
		name: 'login',
		disableBack: true,
		keepAlive: false,
		hideChildren: true,
		showHeader: false
	}),
	component: resolve => require(['@/views/login/login'], resolve)
},{
	...router('/privacy', {/*登录页*/
		name: 'privacy',
		keepAlive: true,
		hideChildren: true,
		title: '服务条款'
	}),
	component: resolve => require(['@/views/login/server'], resolve)
},{
	...router('/login/unlock', {/*后期可能会用到的图势解锁页*/
		name: 'unlock',
		title: '解锁密码'
	}),
	component: resolve => require(['@/views/login/unlock'], resolve)
}]