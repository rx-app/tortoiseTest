import router from '@/public/router';

export default [{
	...router('/message', {
		name: 'message',
		title: '消息',
		showFooter: true,
		disableBack: true,
		group: 'message',
		showQRScan: true,
	}),
	component: resolve => require(['@/views/message/index'], resolve)
}, {
	...router('/message/lesson-notify', {
		name: 'message-lesson-notify',
		title: '家长申请'
	}),
	component: resolve => require(['@/views/message/lesson-notify/index'], resolve)
}, {
	...router('/message/customer-interact', {
		name: 'message-customer-interact',
		title: '家校互动'
	}),
	component: resolve => require(['@/views/message/customer-interact/index'], resolve)
}, {
	...router('/message/teacher-chats', {
		name: 'message-teacher-chats',
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-chats/index'], resolve)
}, {
	...router('/message/teacher-list', {
		name: 'message-teacher-list',
		title: '选择学员',
		hideChildren: true,
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-list/index'], resolve)
}, {
	...router('/message/group-list', {
		name: 'message-group-list',
		title: '选择学员',
		hideChildren: true,
		actionText: "下一步"
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-list/groupList'], resolve)
},{
	...router('/message/customer-list', {
		name: 'message-customer-list',
		title: '确认已选学员',
		hideChildren: true,
		keepAlive:true,
		actionText: "下一步"
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-list/customerList'], resolve)
},{
	...router('/message/send-message', {
		name: 'message-send-message',
		title: '输入内容',
		hideChildren: true,
		actionText: "完成"
	}),
	component: resolve => require(['@/views/message/customer-interact/send-message/send-message'], resolve)
},{
	...router('/message/group-detail', {
		name: 'message-group-detail',
		title: '群发消息记录',
		hideChildren: true,
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-list/group-detail'], resolve)
},{
	...router('/message/disscuion-group', {
		name: 'message-disscuion-group',
		title: '学员讨论组',
		hideChildren: true,
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-list/disscuionGroup'], resolve)
},{
	...router('/message/create-group', {
		name: 'message-create-group',
		title: '创建讨论组',
		hideChildren: true,
		actionText: "完成"
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-chats/createGroup'], resolve)
},{
	...router('/message/group-mess', {
		name: 'message-group-mess',
		title: '',
		hideChildren: true,
		settings: true,
	}),
	component: resolve => require(['@/views/message/customer-interact/send-message/group-message'], resolve)
},{
	...router('/message/group-settings', {
		name: 'message-group-settings',
		title: '管理讨论组',
		hideChildren: true,
		//actionText: "完成"
	}),
	component: resolve => require(['@/views/message/customer-interact/teacher-list/groupSetting'], resolve)
},{
	...router('/message/upload-name', {
		name: 'message-upload-name',
		title: '修改讨论组名称',
		hideChildren: true,
		actionText: "完成"
	}),
	component: resolve => require(['@/views/message/customer-interact/upload-group/uploadName'], resolve)
},{
	...router('/message/upload-add', {
		name: 'message-upload-add',
		title: '添加老师',
		hideChildren: true,
		actionText: "完成"
	}),
	component: resolve => require(['@/views/message/customer-interact/upload-group/uploadPersonAdd'], resolve)
},{
	...router('/message/upload-delect', {
		name: 'message-upload-delect',
		title: '移除老师',
		hideChildren: true,
		actionText: "完成"
	}),
	component: resolve => require(['@/views/message/customer-interact/upload-group/uploadPersonDelect'], resolve)
},{
	...router('/message/xd-news', {
		name: 'message-xd-news',
		title: '学大资讯',
		keepAlive:true,
	}),
	component: resolve => require(['@/views/message/xd-news/index'], resolve)
}, {
	...router('/message/news-detail', {
		name: 'message-news-detail',
		title: '学大资讯',
		hideChildren: true
	}),
	component: resolve => require(['@/views/message/xd-news/news-detail/index'], resolve)
}, {
	...router('/message/system-notify', {
		name: 'message-system-notify',
		title: '系统消息',
		right: 1
	}),
	component: resolve => require(['@/views/message/system-notify/index'], resolve)
}, {
	...router('/message/customer-reply', {
		name: 'message-customer-reply',
		title: '',
		hideChildren: true,
	}),
	component: resolve => require(['@/views/message/customer-interact/customer-reply/index-new'], resolve)
}, {
	...router('/message/customer-reply/leave-msg', {
		name: 'leaveMsg',
		title: '留言',
		hideChildren: true,
		actionText: "留言"
	}),
	component: resolve => require(['@/views/message/customer-interact/customer-reply/leave-msg'], resolve),
}]