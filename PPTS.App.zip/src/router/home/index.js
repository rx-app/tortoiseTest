﻿import router from '@/public/router';

export default [{
	...router('/home', {/*首页*/
		name: 'home',
		showFooter: true,
		disableBack: true,
		showQRScan: true,
		showHeader: true,
		showChildName: true,
		group: 'home'
	}),
	component: resolve => require(['@/views/home/index'], resolve)
}, {
	...router('/home/scan', {
		name: 'scan',
		hideChildren: true,
		title: '扫一扫'
	}),
	component: resolve => require(['@/views/home/scan'], resolve)
}, {
	...router('/home/psdSureCourse', {
		name: 'psdSureCourse',
		hideChildren: true,
		title: '密码确认课时'
	}),
	component: resolve => require(['@/views/home/partials/psd-sure-course'], resolve)
},
{
	...router('/home/namSureCourse', {
		name: 'namSureCourse',
		hideChildren: true,
		title: '点名确认课时'
	}),
	component: resolve => require(['@/views/home/partials/nam-sure-course'], resolve)
}, {
	...router('/home/addGuest', {
		name: 'addGuest',
		hideChildren: true,
		actionText: '完成',
		title: '新增潜客'
	}),
	component: resolve => require(['@/views/home/add-guest/add-guest'], resolve)
}, {
	...router('/home/selParent', {
		name: 'selParent',
		hideChildren: true,
		actionText: '完成',
		title: '选择已有家长'
	}),
	component: resolve => require(['@/views/home/add-guest/selAlready-parent'], resolve)
}]