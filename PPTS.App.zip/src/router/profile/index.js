﻿import router from '@/public/router';

export default [{
	...router('/profile', {
		name: 'profile',
		title: '我的',
		showFooter: true,
		disableBack: true,
		/*keepAlive: true,*/
		hideChildren: true,
		showHeader: false,
		group: 'profile'
	}),
	component: resolve => require(['@/views/profile/index'], resolve)
}, {
	...router('/profile/settings', {
		name: 'settings',
		title: '设置',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/index'], resolve)
}, {
	...router('/profile/user', {
		name: 'profile-user-userInfo',
		title: '个人信息',
		/*keepAlive: true,*/
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/user/index'], resolve)
}, {
	...router('/profile/settings/notify', {
		name: 'profile-settings-notify',
		title: '消息通知',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/notify'], resolve)
}, {
	...router('/profile/edit-avatar', {
		name: 'profile-edit-avatar',
		title: '个人头像',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/edit-avatar'], resolve)
}, {
	...router('/profile/cropper', {
		name: 'profile-cropper',
		title: '个人头像',
		hideChildren: true,
		showHeader: false,
	}),
	component: resolve => require(['@/views/profile/cropper'], resolve)
}, {
	...router('/profile/settings/about', {
		name: 'profile-settings-about',
		title: '关于掌上学大',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/about'], resolve)
}, {
	...router('/profile/settings/about/list', {
		name: 'profile-settings-about-list',
		title: '功能介绍',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/about-list'], resolve)
}, {
	...router('/profile/settings/feedback/edit', {
		name: 'feedbackEdit',
		title: '添加建议',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/feedback/edit'], resolve)
}, {
	...router('/profile/settings/feedback/content', {
		name: 'feedbackContent',
		title: '',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/feedback/content'], resolve)
}, {
	...router('/profile/settings/feedback/list', {
		name: 'feedback-list',
		title: '建议反馈',
		hideChildren: true,
		actionText: "留言"
	}),
	component: resolve => require(['@/views/profile/settings/feedback/feedback-list'], resolve)
}, {
	...router('/profile/settings/feedback/add', {
		name: 'feedback-add',
		title: '我要反馈',
		hideChildren: true,
		actionText: "提交",
		/*keepAlive: true,*/
	}),
	component: resolve => require(['@/views/profile/settings/feedback/feedback-add'], resolve)
}, {
	...router('/profile/settings/feedback/add/reply', {
		name: 'feedback-add-reply',
		title: '我要回复',
		hideChildren: true,
		actionText: "提交",
		/*keepAlive: true,*/
	}),
	component: resolve => require(['@/views/profile/settings/feedback/feedback-add'], resolve)
}, {
	...router('/profile/settings/feedback/feedback-reply', {
		name: 'feedback-reply',
		title: '建议反馈',
		hideChildren: true,
		actionText: "回复"
	}),
	component: resolve => require(['@/views/profile/settings/feedback/feedback-reply'], resolve)
}, {
	...router('/profile/settings/Feedback/edit', {
		name: 'feedbackList',
		title: '建议反馈',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/feedback/edit'], resolve)
}, {
	...router('/profile/settings/version', {
		name: 'profile-settings-version',
		title: '版本信息',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/version'], resolve)
}, {
	...router('/profile/settings/finger', {
		name: 'profile-settings-finger',
		title: '手势密码',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/finger'], resolve)
}, {
	...router('/profile/settings/lock', { //后期可能会用到的图势解锁页
		name: 'profile-settings-lock',
		title: '设置手势',
		hideChildren: true
	}),
	component: resolve => require(['@/views/login/unlock'], resolve)
}, {
	...router('/profile/settings/eval', {
		name: 'profile-settings-eval',
		title: '去评价',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/eval'], resolve)
}, {
	...router('/profile/settings/edition', {
		name: 'profile-settings-edition',
		title: '功能介绍',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/settings/edition'], resolve)
}, {
	...router('/profile/classBreak', {
		name: 'classBreak',
		title: '课间小憩',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/classBreak'], resolve)
}, {
	...router('/profile/classBreak-detail', {
		name: 'classBreak-detail',
		title: '课间小憩',
		hideChildren: true
	}),
	component: resolve => require(['@/views/profile/classBreak/classBreak-detail'], resolve)
}, {
	...router('/profile/classBreak-share', {
		name: 'classBreak-share',
		title: '我要分享',
		hideChildren: true,
		actionText: '完成'
	}),
	component: resolve => require(['@/views/profile/classBreak/classBreak-share'], resolve)
}, {
	...router('/profile/adminParent', {
		name: 'adminParent',
		title: '管理家长分享',
		hideChildren: true,
		/*actionText:'完成'*/
	}),
	component: resolve => require(['@/views/profile/classBreak/adminParent'], resolve)
}, {
	...router('/downLoad', {
		name: 'downLoad',
		title: '下载App',
		hideChildren: true,
		disableBack: true,
		showHeader: false,
		/*actionText:'完成'*/
	}),
	component: resolve => require(['@/views/profile/download-app'], resolve)
}]