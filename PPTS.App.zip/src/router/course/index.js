﻿import router from '@/public/router';

export default [{
	...router('/course', {
		name: 'course',
		title: '教师课表',
		showFooter: true,
		disableBack: true,
		group: 'course',
		/*keepAlive: true,*/
		showQRScan: true
	}),
	component: resolve => require(['@/views/course/teach-course/index'], resolve)
},{
	...router('/studentCourse', {
		name: 'studentCourse',
		title: '学员课表',
		showFooter: true,
		disableBack: true,
		group: 'course',
		/*keepAlive: true,*/
		showQRScan: true
	}),
	component: resolve => require(['@/views/course/student-course/index'], resolve)
}, {
	...router('/course/detail', {
		name: 'course-detail',
		title: '课表详情',
		hideChildren: true,
		actionText: ""
	}),
	component: resolve => require(['@/views/course/course/course-detail'], resolve)
},{
	...router('/course/otherEvaluate', {
		name: 'course-other-evaluate',
		title: '课表详情',
		hideChildren: true,
		actionText: ""
	}),
	component: resolve => require(['@/views/course/course/course-detail'], resolve)
},{
	...router('/course/evenEvaluate', {
		name: 'course-even-evaluate',
		title: '课表详情',
		hideChildren: true,
		actionText: ""
	}),
	component: resolve => require(['@/views/course/course/course-detail'], resolve)
}, {
	...router('/course/evaluate', {
		name: 'course-evaluate',
		title: '课表详情',
		hideChildren: true,
		actionText: "提交"
	}),
	component: resolve => require(['@/views/course/course/course-detail'], resolve)
}]