import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

import login from './login/'
import home from './home/'
import customer from './customer/'
import message from './message/'
import course from './course/'
import profile from './profile/'
import error from './error/'
import setCate from '@/public/util/api.cate';


import axios from '@/public/api/axios';

let routes = [
	...login,
	...home,
	...customer,
	...message,
	...course,
	...profile,
	...error
];

const router = new Router({
	routes
});

router.beforeEach(async (to, from, next) => {
    if(!window.$myData.completeBaseUrlLoad){
		mui.showLoading()
		window.xdapp.config = await axios.get(xdapp.api.config.getFullConfig)
		
		setCate();
		window.$myData.getRest();
		//window.xdapp.api={...window.xdapp.api,...window.$myData.apiData}  // 封装到函数里面
		mui.hideLoading();
	}
    next();
})


router.beforeEach( (to, from, next) => {
	

	xdapp.util.vue.commitActionStatus(false);
	/*检测版本更新*/
	axios.get(xdapp.api.config.getVersionConfig).then(
		r => {
			var version = r.version
			if(window.version && window.version != version) {
				mui.alert('有新版本，需要重新加载');
				plus.runtime.restart()
			}
			window.version = version;
		}
	)
	/*检测是否有网*/
	mui.plusReady(function() {
		isNetWork();
	});
	next();
});

// router.beforeEach((to, from, next) => {
// 	xdapp.util.vue.commitActionStatus(false);
// 	return next();
// });


export default router;