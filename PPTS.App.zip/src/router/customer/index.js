﻿import router from '@/public/router';
export default [{
  ...router('/customer', {
    name: 'customer',
    title: '学员列表',
    showFooter: true,
    disableBack: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive:true*/
  }),
  component: resolve => require(['@/views/customer/index'], resolve)
}, {
  ...router('/score', {
    name: 'score',
    title: '成绩',
    showFooter: true,
    disableBack: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/score/index'], resolve)
}, {
  ...router('/studentInfo', {
    name: 'studentInfo',
    title: '潜客信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/student-info'], resolve)
}, {
  ...router('/studentSignedInfo', {
    name: 'studentSignedInfo',
    title: '学员信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/student-signed-info'], resolve)
}, {
  ...router('/addedParent', {
    name: 'addedParent',
    title: '选择已有家长',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: false,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/addedParent'], resolve)
}, {
  ...router('/addedStuParent', {
    name: 'addedStuParent',
    title: '选择已有家长',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: false,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/addedStuParent'], resolve)
}, {
  ...router('/parentInfo', {
    name: 'parentInfo',
    title: '潜客信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/parent-info'], resolve)
}, {
  ...router('/parentSignedInfo', {
    name: 'parentSignedInfo',
    title: '学员信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/parent-signed-info'], resolve)
}, {
  ...router('/records', {
    name: 'records',
    title: '潜客信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/records'], resolve)
}, {
  ...router('/recordsSigned', {
    name: 'recordsSigned',
    title: '学员信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/records-signed'], resolve)
}, {
  ...router('/studentInfoEdit', {
    name: 'studentInfoEdit',
    title: '学员信息',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: true,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/student-info-edit'], resolve)
}, {
  ...router('/teacherHistory', {
    name: 'teacherHistory',
    title: '归属历史',
    showFooter: false,
    disableBack: false,
    hideChildren: true,
    group: 'customer',
    showQRScan: false,
    /*keepAlive: true*/
  }),
  component: resolve => require(['@/views/customer/teacherHistory'], resolve)
}, {
  ...router('/customerMess', {
    name: 'customerMess',
    title: '学员',
    hideChildren: true,
    group: 'customer',
  }),
  component: resolve => require(['@/views/customer/customer-mess/index'], resolve),
}, {
  ...router('/scoreList', {
    name: 'scoreList',
    title: '成绩',
    showFooter: true,
    disableBack: false,
    group: 'customer',
    showQRScan: false,
  }),
  component: resolve => require(['@/views/customer/score/score-list'], resolve)
}, {
  ...router('/accountStatement', {
    name: 'accountStatement',
    title: '对账单',
    hideChildren: true,
    group: 'customer',
  }),
  component: resolve => require(['@/views/customer/customer-mess/partials/statement'], resolve)
}, {
  ...router('/returnVisit', {
    name: 'returnVisit',
    title: '回访',
    showFooter: true,
    disableBack: true,
    group: 'customer',
    showQRScan: true
  }),
  component: resolve => require(['@/views/customer/return-visit/index'], resolve)
}, {
  ...router('/returnVisitDList', {
    name: 'return-visit-detail-list',
    title: '回访记录',
    hideChildren: true
  }),
  component: resolve => require(['@/views/customer/return-visit/return-visit-list.vue'], resolve)
}, {
  ...router('/parentMessDList', {
    name: 'parent-meet-detail-list',
    title: '家长会记录',
    hideChildren: true
  }),
  component: resolve => require(['@/views/customer/parent-meet/parent-meet-list.vue'], resolve)
}, {
  ...router('/visit/info', {
    name: 'visit-info',
    title: '回访详情',
    hideChildren: true,
    actionText: '完成',
  }),
  component: resolve => require(['@/views/customer/return-visit/visit-info/index.vue'], resolve)
}, {
  ...router('/visit/add', {
    name: 'visit-add',
    title: '录入回访',
    hideChildren: true,
    actionText: "完成",
  }),
  component: resolve => require(['@/views/customer/return-visit/visit-info/index.vue'], resolve)
}, {
  ...router('/meet/info', {
    name: 'meet-info',
    title: '家长会详情',
    hideChildren: true,
    actionText: '完成',
  }),
  component: resolve => require(['@/views/customer/parent-meet/meet-info/index.vue'], resolve)
}, {
  ...router('/meet/add', {
    name: 'meet-add',
    title: '新增会议',
    hideChildren: true,
    actionText: "完成",
  }),
  component: resolve => require(['@/views/customer/parent-meet/meet-info/index.vue'], resolve)
}, {
  ...router('/parentMeet', {
    name: 'parentMeet',
    title: '家长会',
    showFooter: true,
    disableBack: true,
    group: 'customer',
    showQRScan: true,
  }),
  component: resolve => require(['@/views/customer/parent-meet/index'], resolve)
}, {
  ...router('/followUp', {
    name: 'followUp',
    title: '跟进管理',
    showFooter: true,
    disableBack: true,
    group: 'customer',
    showQRScan: true
  }),
  component: resolve => require(['@/views/customer/follow-up/index'], resolve)
}, {
  ...router('/followUpList', {
    name: 'follow-up-list',
    title: '跟进记录',
    hideChildren: true
  }),
  component: resolve => require(['@/views/customer/follow-up/follow-up-list.vue'], resolve)
}, {
  ...router('/follow/info', {
    name: 'follow-info',
    title: '查看跟进记录',
    hideChildren: true,
  }),
  component: resolve => require(['@/views/customer/follow-up/follow-info/index.vue'], resolve)
}, {
  ...router('/follow/add', {
    name: 'follow-add',
    title: '新增跟进记录',
    hideChildren: true,
    actionText: "完成",
  }),
  component: resolve => require(['@/views/customer/follow-up/follow-info/index.vue'], resolve)
}];
