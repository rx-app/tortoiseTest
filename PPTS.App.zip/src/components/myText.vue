<template>
	<router-link :to="{name:aurl}" class=" mya" href="javascript:void(0)">
		<span class="txt">{{txt}}</span>
	</router-link>
	
</template>

<script>
	export default{
		props:['txt','aurl'],
		data(){
			return{
				
			}
			
		}
	}
</script>

<style scoped>
.mya{display: flex!important;
    justify-content: center;
    align-items: center;
    padding: 15px 10px;
    border-bottom: 1px solid #ddd;}
.name{color:#777;}
.value{display: block;text-align: right;flex: 1;color: #aaa}

</style>