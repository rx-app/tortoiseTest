<template>
  <div id="content-layer" class="full-container" :class="{'disappear':isComplete}" v-show="isShow">
    <div class="xd-header title-container">
      <div class="back">
        <a class="mui-icon mui-icon-left-nav" @click="back"></a>
      </div>
      <div class="title">{{title}}</div>
      <div class="complete">
        <span class="active" @click="complete">完成</span>
      </div>
    </div>
    <div class="input-container">
      <!-- @focus="fnFocus()" @blur="fnBlur" -->
      <textarea :placeholder="title" v-model="inputContent"></textarea>
    </div>
  </div>
</template>
<script>
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({
      bottom: "-1px"
    });
  }
}
export default {
  data() {
    return {
      isComplete: false,
      inputContent: "",
      active: false
    };
  },
  props: {
    isShow: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: "请输入"
    },
    content: {
      type: String,
      default: ""
    },
    category: {
      type: String,
      default: ""
    }
  },
  methods: {
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    focus() {
      console.log("focus");
    },
    back() {
      this.isComplete = true;
      document.querySelector(".xd-header").style.display = "block";
      setTimeout(() => {
        this.$emit("completeAction");
      }, 1000);
    },
    complete() {
      this.isComplete = true;
      setTimeout(() => {
        this.$emit("completeAction", {
          category: this.category,
          content: this.inputContent
        });
      }, 1000);
    }
  },
  watch: {
    isShow(value) {
      this.isComplete = !value;
      this.inputContent = this.content;
    },
    inputContent(value) {
      if (value != this.content) {
        this.active = true;
      } else {
        this.active = false;
      }
    }
  },
};
</script>
<style lang="scss" scoped>
$fontColor: #999;

.full-container {
  position: absolute;
  width: 100%;
  height: 100%;
  top: -2px;
  z-index: 10000;
  //overflow: hidden;
  background-color: #fff;
  animation: appear 1s linear;

  .title-container {
    position: absolute;
    z-index: 1001;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: torem(65);
    padding-top: torem(20);
    color: #fff;
    .back {
      padding-right: torem(10);
      a {
        color: #fff;
      }
    }
    .title {
      font-size: torem(16);
    }
    .complete {
      padding-right: torem(10);
      color: #e0e0e0;
      font-size: torem(14);
      letter-spacing: torem(2);
      .active {
        display: inline-block;
        color: #fff;
      }
      .disable {
        display: none;
      }
    }
  }
  .input-container {
    width: 100%;
    height: 100%;
    padding-top: 2rem;
    overflow: hidden;
    textarea {
      width: 100%;
      height: 100%;
      border: none;
      &::-webkit-input-placeholder {
        color: $fontColor;
      }
      &::-moz-placeholder {
        color: $fontColor;
      }
      &:-ms-input-placeholder {
        color: $fontColor;
      }
      &:-moz-placeholder {
        color: $fontColor;
      }
    }
  }
}

.disappear {
  animation: disappear 1s linear forwards;
}

@keyframes appear {
  from,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  0% {
    opacity: 0;
    transform: translate3d(1000px, 0, 0);
  }
  100% {
    opacity: 1;
    transform: none;
  }
}

@keyframes disappear {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: translate3d(1000px, 0, 0);
  }
}
</style>
