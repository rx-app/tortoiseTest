<template>
  <div class="text-diffent-type">
    <!-- * XXX  文本框   形式 -->
    <div v-if="isShowLine==1" class="default-line">
      <p class="text" :class="!lineName?'eleVis':''" v-if="lineName || keyMess=='parentSecPhone'">
        <span class="request" :class="!isRequest?'eleVis':''">*</span>
        <span>{{lineName}}</span>
      </p>
      <p class="schoolName" v-if="keyMess=='schoolName' && sureSchoolName">
        <span>{{sureSchoolName}}</span>
        <i class="iconfont icon-error" @click="delSchoolName()"></i>
      </p>
      <p :class="keyMess=='schoolName' && sureSchoolName?'shortWidth':''" class="inpDiv">
        <input
          :maxlength="maxlength"
          type="text"
          :placeholder="tipText"
          v-model="inpValue"
          @blur.stop="returnValue()"
          @input="handleInput($event)"
        >
      </p>
    </div>
    <!-- 单选   形式 -->
    <div v-if="isShowLine==2" class="default-line">
      <p class="text">
        <span class="request" :class="!isRequest?'eleVis':''">*</span>
        <span>{{lineName}}</span>
      </p>
      <ul>
        <li v-for="(item,index) in radioArr" :key="index" @click="setRadio(item.key)">
          <div class="mui-input-row mui-radio">
            <label>{{item.name}}</label>
            <input :id="item.key" :name="item.group" type="radio" :checked="parentOther==item.key">
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      inpValue: ""
    };
  },
  created() {
    if (this.keyMess && this.parentOther) {
      this.inpValue = this.parentOther;
    }
    if (this.keyMess == "schoolName" && window.xdapp.guestTemp) {
      this.inpValue = "";
    }
    //主要用于ios手机  获取文本框焦点同时滑动页面  光标不随页面走动
    document.addEventListener("touchmove", () => {
      document.activeElement.blur();
    });
  },
  methods: {
    handleInput(e) {
      switch (this.keyMess) {
        case "parentName":
          this.inpValue = e.target.value.replace(/[^\u4e00-\u9fa5a-zA-Z]/g, "");
          break;
        case "parentPriPhone":
          this.inpValue = e.target.value.replace(/[^\d]/g, "");
          break;
        case "parentSecPhone":
          this.inpValue = e.target.value.replace(/[^\d-]/g, "");
          break;
        case "customerName":
          this.inpValue = e.target.value.replace(/[^\u4e00-\u9fa5a-zA-Z]/g, "");
          break;
        case "ReferralStaffOACode":
          this.inpValue = e.target.value.replace(/[^\d_.a-zA-Z]/g, "");
          break;
        case "customerCode":
          this.inpValue = e.target.value.replace(/[^\da-zA-Z]/g, "");
          break;
        case "parentIDNumber":
          this.inpValue = e.target.value.replace(/[^\da-zA-Z]/g, "");
          break;
        // case "parentIDNumber":
        //   this.inpValue = e.target.value.replace(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/g, "");
        //   break;
        // case "parentEmail":
        //   break;
        case "customerPhone":
          this.inpValue = e.target.value.replace(/[^\d]/g, "");
          break;
        case "customerIDNumber":
          this.inpValue = e.target.value.replace(/[^\da-zA-Z]/g, "");
          break;
        case "schoolName":
          this.inpValue = e.target.value.replace(/\s|\xA0/g, "");
          break;
      }
    },
    delSchoolName() {
      this.$emit("textTypeBack", this.keyMess, "del");
    },
    returnValue() {
      if (!this.inpValue && this.keyMess !== "ReferralStaffOACode") return;
      switch (this.keyMess) {
        case "ReferralStaffOACode":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
        case "customerCode":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
        case "parentEmail":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
        case "parentIDNumber":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
        case "customerIDNumber":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
        case "parentPriPhone":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
        case "parentSecPhone":
          this.$emit("textTypeBack", this.keyMess, this.inpValue);
          break;
      }
    },
    setRadio(key) {
      switch (this.keyMess) {
        case "parentGender":
          this.$emit("textTypeBack", this.keyMess, key);
          break;
        case "customerGender":
          this.$emit("textTypeBack", this.keyMess, key);
          break;
        case "isStudyAgain":
          this.$emit("textTypeBack", this.keyMess, key);
          break;
      }
    }
  },
  props: {
    isShowLine: {
      type: Number,
      default: 1
    },
    lineName: {
      type: String,
      default: ""
    },
    tipText: {
      type: String,
      default: "请输入"
    },
    isRequest: {
      type: Boolean,
      default: false
    },
    keyMess: {
      type: String,
      default: ""
    },
    radioArr: {
      type: Array,
      default: function() {
        return [];
      }
    },
    sureSchoolName: {
      type: String,
      default: ""
    },
    parentOther: {},
    maxlength: {
      type: Number,
      default: 128
    }
  },
  watch: {
    sureSchoolName(obj) {
      if (obj) {
        this.inpValue = "";
      }
    },
    inpValue(obj) {
      switch (this.keyMess) {
        case "parentName":
          this.$emit("textTypeBack", this.keyMess, obj);
          break;
        case "customerName":
          this.$emit("textTypeBack", this.keyMess, obj);
          break;
        case "AddressDetail":
          this.$emit("textTypeBack", this.keyMess, obj);
          break;
        case "customerPhone":
          this.$emit("textTypeBack", this.keyMess, obj);
          break;
        case "schoolName":
          this.$emit("textTypeBack", this.keyMess, obj);
          break;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.text-diffent-type {
  position: relative;
}
.default-line {
  display: flex;
  align-content: center;
  justify-content: space-around;
  height: torem(45);
  .request {
    color: red;
    margin-top: torem(3);
    margin-right: torem(3);
  }
  .text {
    display: flex;
    align-items: center;
    width: torem(112);
    font-size: torem(14);
    color: #333;
  }
  p {
    input {
      border: none;
      width: 100%;
      height: 100%;
    }
    input::-webkit-input-placeholder {
      color: #ccc;
      font-size: torem(14);
    }
  }
  .inpDiv {
    flex: 1;
  }
  ul {
    display: flex;
    align-items: center;
    width: 72%;
    padding-left: torem(18);
    li {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-right: torem(50);
    }
  }
  .shortWidth {
    width: torem(100);
  }
  .schoolName {
    display: flex;
    align-items: center;
    justify-content: space-around;
    border-radius: 6px;
    text-align: center;
    background: linear-gradient(
      to bottom,
      #f0f9ff 0,
      #cbebff 47%,
      #a1dbff 100%
    );
    border: 1px solid #acacac;
    flex: 1;
    padding: torem(2) torem(3);
    line-height: torem(28);
    height: torem(30);
    margin-top: torem(7.5);
    span {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: torem(120);
    }
    i {
      margin-left: 5px;
      color: #333;
    }
  }
}
.default-line:after {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 15px;
  height: 1px;
  content: "";
  -webkit-transform: scaleY(0.5);
  transform: scaleY(0.5);
  background-color: #c8c7cc;
}
.eleVis {
  visibility: hidden;
}
</style>
