<template>
  <div class="pptsapp-bottom-list" :class="{'pop':!isComplete,'down':isComplete}">
    <div class="cover" @click="clear()"></div>
    <div class="group-items" ref="groupItems">
      <div :class="{tcenter:center}" class="title">{{title}}</div>
      <div v-if="!isRadio" class="operation">
        <span @click="selAll()" :class="selAllFlag?'sel':''">全选</span>
        <span @click="complete()">完成</span>
      </div>
      <ul class="list-group" v-if="isRadio">
        <li
          v-for="(item,index) in items"
          :key="index"
          :class="{center}"
          class="item"
          @click.prevent.stop="select(item,index)"
        >
          <div class="value">{{item.value}}</div>
          <div class="select" :ref="`item${index}`" :class="{'current':model==item.key}"></div>
        </li>
      </ul>
      <ul class="list-group" v-if="!isRadio">
        <li
          v-for="(item,index) in items"
          :key="index"
          :class="{center}"
          class="item"
          @click.prevent.stop="selectMore(item,index)"
        >
          <div class="value">{{item.value}}</div>
          <div
            class="select"
            :ref="`item${index}`"
            :class="{'current':JSON.stringify(arr).indexOf(JSON.stringify(item)) !== -1}"
          ></div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      isComplete: true,
      selAllFlag: false,
      arr: []
    };
  },
  props: {
    category: {
      type: String,
      default: ""
    },
    center: {
      type: Boolean,
      default: false
    },
    items: {
      type: Array,
      default: null
    },
    title: {
      type: String,
      defult: ""
    },
    isShow: {
      type: Boolean,
      default: false
    },
    model: {
      // type: String,
      // default: ''
    },
    isRadio: {
      type: Boolean,
      default: true
    }
  },
  methods: {
    clear() {
      this.$emit("selectItem");
    },
    select(item, index) {
      this.isComplete = true;
      setTimeout(() => {
        this.$emit("selectItem", { category: this.category, item: item });
      }, 300);
    },
    selectMore(item, index) {
      var selIndex = JSON.stringify(this.arr).indexOf(JSON.stringify(item));
      if (selIndex == -1) {
        this.arr.push(item);
      } else {
        this.arr = this.arr.filter(items => {
          return items.key !== item.key;
        });
      }
      this.arr.length == this.items.length? this.selAllFlag = true:this.selAllFlag = false;
    },
    selAll() {
      if (!this.selAllFlag) {
        this.selAllFlag = true;
        this.arr = [];
        this.items.forEach(item => {
          this.arr.push(item);
        });
      }else{
        this.selAllFlag = false;
        this.arr = [];
      }
    },
    complete() {
      this.$emit("selectItem", { category: this.category, itemArr: this.arr });
    }
  },
  watch: {
    isShow(value) {
      if (value) {
        this.isComplete = !value;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.pptsapp-bottom-list {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: 1000;
  .cover {
    height: 100%;
    background-color: rgba(0, 0, 0, 0.3);
  }
  .operation {
    height: torem(30);
    line-height: torem(30);
    padding: 0 torem(27);
    display: flex;
    justify-content: space-between;
    margin: 10px 0;
    span {
      display: inline-block;
      width: torem(60);
      text-align: center;
      border-radius: 5px;
      background: #ddd;
    }
    span:nth-child(2) {
      background: skyblue;
      color: #fff;
    }
    .sel {
      background: orange;
      color: #fff;
    }
    .sel:after{
      content:"\2714";
      margin-left: torem(5);
    }
  }
  .group-items {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    z-index: 1001;
    .title {
      height: torem(40);
      text-align: center;
      line-height: torem(40);
      border-bottom: torem(1) solid #eee;
      font-size: torem(16);
      &.tcenter {
        background: #8bbdef;
        color: #fff;
      }
    }

    .list-group {
      max-height: torem(260);
      overflow-y: auto;
      .center {
        div {
          text-align: center;
          width: 100%;
        }
        div.select {
          display: none;
        }
      }
      .item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: torem(40);
        margin: 0 torem(15);
        border-bottom: torem(1) solid #eee;
        font-size: torem(14);

        .select.current {
          &::before {
            content: "\2714";
            font-family: "iconfont" !important;
            font-size: torem(16);
            color: #007aff;
          }
        }
      }
    }
  }
}

.pop {
  div.group-items {
    animation: listItems 0.3s linear;
    transform: translateY(0);
  }
}

.down {
  div.group-items {
    animation: listItemsDown 0.3s linear forwards;
  }
}

.hide {
  opacity: 0;
}

@keyframes listItems {
  from {
    opacity: 1;
    transform: translateY(260px);
  }
  to {
    opacity: 1;
    transform: translateY(0px);
  }
}

@keyframes listItemsDown {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translateY(260px);
  }
}
</style>
