﻿<template>
  <footer class="mui-bar mui-bar-tab xd-footer" v-show="this.$route.meta.showFooter" ref="footer">
    <li
      @click="goPage(item)"
      v-for="(item, index) in this.$store.state.navTabs"
      class="mui-tab-item"
      :key="index"
      tag="a"
      v-if="isShowNav(item.functions)"
    >
      <span class="mui-img mui-icon">
        <img
          :src="($route.meta.group==item.link)?require(`@/public/asset/img/icons/${item.imgOn}`):require(`@/public/asset/img/icons/${item.imgOff}`)"
          alt
        >
      </span>
      <span
        class="mui-tab-label"
        :class="{'router-link-active':$route.meta.group==item.link}"
      >{{item.name}}</span>
    </li>
  </footer>
</template>

<script>
import { CACHE_KEYS } from "@/constants";
import store from "@/store";
import * as types from "@/store/mutation-types";
export default {
  methods: {
    goPage(item) {
      window.bbObj = undefined;
      this.$router.push({
        name: item.link
      });
      // return {}
    },
    isShowNav(functions) {
      return m2.util.getPermionLoad(functions);
    }
  },
  mounted() {
    if (!this.$store.state.navTabs.length) {
      store.commit(types.NAVTABS, m2.cache.get(CACHE_KEYS.NAVTABS));
    }
    xdapp.footer = this.$refs.footer;
  }
};
</script>
<style lang="scss">
.mui-bar-tab .mui-tab-item .mui-icon~.mui-tab-label{
  font-size: torem(13)
}
</style>