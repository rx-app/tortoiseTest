﻿<template>
	<div class="mui-popup-backdrop mui-active xd-sign-children-popup" @click="close">
		<div id="triangle"></div>
		<div class="mui-scroll dialog">
			<ul class="mui-table-view mui-table-view-radio">
				<!--class="mui-table-view-cell" class="mui-navigate-right"  :class="getSelectedCss(job.id)"-->
				<li v-for="job in this.$store.state.jobs" class="ppts-view-cell" @click="switchJob(job)">
					<p>
						<!--<i class="icon-job iconfont"></i>--></p>
					<a>{{job.name}}</a>
					<i v-if="getSelectedCss(job.id)" class="iconfont icon-check-mark"></i>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
	import { SWITCH_JOB } from '@/store/mutation-types';
	import { CACHE_KEYS } from '@/constants';
	import '@/public/asset/js/jquery/jquery-1.8.0';

	export default {
		methods: {
			getSelectedCss(id) {
				//return this.$store.state.currentJob.id === id ? true : false;
				return m2.cache.get('ppts-current-job').id === id ? true : false;
			},
			switchJob(data) {

				this.$store.commit(SWITCH_JOB, data);
				// 保存当前岗位信息信息
				m2.cache.set(CACHE_KEYS.CURRENT_JOB, data);

				if(this.$route.name == 'home') {
					this.$router.push({
						name: 'setting'
					})
					$vue.$nextTick(function() {
						this.$router.push({
							name: 'home'
						});
					})
				} else {
					this.$router.push({
						name: 'home'
					});
				}
				//重新刷新页面

				//location.reload();
				//this.$router.go(0);
				// 提交切换岗位事件
				xdapp.util.vue.emit();
			},
			close(e) {
				this.$emit("showNames", e.target.innerText);
				this.$emit("showModal", false);
			}
		}
	}
</script>
<style lang="scss" scoped>
	.xd-sign-children-popup {
		background: rgba(0, 0, 0, 0.2);
		z-index: 1000000;
	}
	
	.dialog {
		background: #FFFFFF;
		border-radius: 12px;
		top: torem(56);
		right: torem(13);
		overflow: hidden;
		width: torem(180);
	}
	
	#triangle {
		width: 0px;
		height: 0px;
		border-width: 15px;
		border-style: solid;
		border-color: transparent transparent rgba(255, 255, 255, 0.9) transparent;
		position: absolute;
		top: torem(36);
		right: torem(20);
	}
	
	/*.mui-table-view-cell {
		display: flex;
		align-items: center;
		padding: 6px 15px;
		p {
			height: torem(28);
			overflow: hidden;
			margin: 0 torem(4) 0 0;
			line-height: torem(28);
			.childPort {
				font-size: torem(24);
				color: #00b3ed69
			}
		}
	}
	
	.mui-table-view-radio .mui-table-view-cell {
		padding-right: 54px;
	}
	
	.mui-table-view-radio .mui-table-view-cell>a:not(.mui-btn) {
		font-size: torem(12);
		color: #333333;
		letter-spacing: -0.39px;
	}
	
	.icon-job {
		color: skyblue;
		font-size: torem(20)
	}*/
	
	.ppts-view-cell {
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		padding: 11px 12px;
		position: relative;
		overflow: hidden;
		a {
			color: #333333;
			font-size: torem(14);
			// white-space: nowrap;
			// text-overflow: ellipsis;
			// overflow: hidden;
			padding-left: 5px;
		}
		i {
			color: #007aff;
			padding-left: 5px;
			font-size: torem(18);
			font-weight: bolder;
		}
	}
	
	.ppts-view-cell::after {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 15px;
		height: 1px;
		content: '';
		-webkit-transform: scaleY(.5);
		transform: scaleY(.5);
		background-color: #c8c7cc;
	}
	.mui-table-view{
		max-height: torem(400);
		overflow-y: scroll;
	}
	.mui-table-view:after{
		height: 0;
	}
</style>