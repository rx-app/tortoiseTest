<template>
  <div class="xdapp-tip">
    <slot></slot>
  </div>
</template>
<script>

</script>
<style lang="scss" scoped>
  .xdapp-tip {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100px;
    color: #999;
    font-size: torem(14)
  }
</style>
