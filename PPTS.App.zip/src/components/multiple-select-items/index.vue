<template>
  <div class="pptsapp-bottom-list" :class="{'pop':!isComplete,'down':isComplete}">
    <div class="cover" @click="clear()"></div>
    <div class="group-items" ref="groupItems">
      <div class="title">
        <span>{{title}}</span>
        <span class="done" @click.prevent.stop="complete()">完成</span>
      </div>
      <ul class="list-group">
        <li v-for="(item,index) in targetItems" class="item">
          <div class="select" @click.prevent.stop="select(item,index)">
            <span :class="{'current':keys.indexOf(item.key) > -1}">{{item.value}}</span>
          </div>
          <div class="input" v-show="writable && item.key!='-1' && keys.indexOf(item.key) > -1">
            <input
              v-if="!inpSize"
              type="text"
              :placeholder="item.value"
              v-model="item.remark"
              @focus="setFocus()"
            />
            <div v-else class="textDiv">
              <!--contenteditable="true"-->
              <!--@input="setNumParentPerson"-->
              <textarea
                placeholder="请输入内容,最多可输入3000字"
                maxlength="3000"
                autofocus="autofocus"
                v-model="item.remark"
                class="conStyle"
                name
                id
                cols="5"
                rows="6"
                @focus="setFocus()"
              ></textarea>
              <!--<textarea @input="setNumParentPerson" class="conStyle" v-model="item.remark"  rows="6" cols="5"></textarea>-->
              <!--<span class="count"><span class="num">{{numParentContent}}</span>/3000</span>-->
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      isComplete: true,
      numParentContent: 0,
      keys: []
    };
  },
  props: {
    category: {
      type: String,
      default: ""
    },
    items: {
      type: Array,
      default: null
    },
    title: {
      type: String,
      default: ""
    },
    isShow: {
      type: Boolean,
      default: false
    },
    model: {
      type: Array,
      default: []
    },
    multiple: {
      type: Boolean,
      default: false
    },
    writable: {
      type: Boolean,
      default: false
    },
    inpSize: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    setNumParentPerson(e) {
      this.numParentContent = this.calcLength(e.target.value);
      if (this.numParentContent > 3000) {
        this.numParentContent = 3000;
      } else {
        this.parentContent = e.target.value;
      }
    },
    calcLength(str) {
      return str.length;
    },
    clear() {
      this.$emit("multipSelectItem");
    },
    setFocus() {
      this._removeElementsByClass("mui-dtpicker");
    },
    complete() {
      let obj = {};
      this.keys.forEach(item => {
        let target = this.targetItems.find(t => t.key == item);
        if (!target.value || !target.remark) {
          mui.toast("类型和内容都必填哦!");
          return;
        } else {
          obj = {
            key: item,
            value: target.value,
            remark: target.remark
          };
          (obj.category = this.category), (this.isComplete = true);
          setTimeout(() => {
            this.$emit(
              "multipSelectItem",
              obj /*{category: this.category, keys: this.keys, obj}*/
            );
          }, 300);
        }
      });
    },
    select(item, index) {
      console.log(item);
      this.keys = [];
      this.keys.push(item.key);
      /*if (item.key == -1) {
				  if (this.keys.indexOf(item.key) > -1) {
				    this.keys = [];
				  } else {
				    this.keys = [];
				    this.targetItems.forEach(i => {
				      if (this.keys.indexOf(i.key) == -1)
				        this.keys.push(i.key);
				    });
				  }
				}
				else {
				  let _index = this.keys.indexOf(item.key);
				  if (_index == -1) {
				    this.keys.push(item.key);
				    if (this.checkAll()) {
				      this.keys.unshift('-1');
				    }
				  }
				  else {
				    this.keys.splice(_index, 1);
				    let _i = this.keys.indexOf('-1');
				    if (_i > -1)
				      this.keys.splice(_i, 1);
				  }
				}*/
    },
    checkAll() {
      return this.keys.length == this.targetItems.length - 1;
    },
    _removeElementsByClass(className) {
      var elements = document.getElementsByClassName(className);
      while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
      }
    }
  },
  computed: {
    targetItems() {
      /* let item = this.items.find(item => item.key == '-1');
				 if (!item) {
				   this.items.unshift({key: "-1", value: '全部'});
				 }*/
      return this.items;
    }
  },
  watch: {
    isShow(value) {
      if (value) {
        this.isComplete = !value;
        this.keys = [];
      }
    },
    model() {
      if (this.model && this.model.length) {
        this.model.forEach(m => {
          this.keys.push(m);
        });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
$contentColor: #999;
.pptsapp-bottom-list {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: 99;
  .cover {
    height: 100%;
    background-color: rgba(0, 0, 0, 0.3);
  }
  .group-items {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    z-index: 1001;
    .title {
      height: torem(40);
      text-align: center;
      line-height: torem(40);
      border-bottom: torem(1) solid #eee;
      font-size: torem(16);
      .done {
        position: absolute;
        right: torem(15);
        color: #007aff;
      }
    }
    .list-group {
      max-height: torem(260);
      overflow-y: auto;
      .item {
        border-bottom: torem(1) solid #eee;
        font-size: torem(14);
        .select {
          margin: 0 torem(15);
          height: torem(40);
          line-height: torem(40);
        }
        .input {
          margin: 0;
          padding: 0 torem(15) torem(6) torem(15);
          input[type="text"] {
            margin: 0;
            padding: 0 torem(5);
            height: torem(24);
            text-align: left;
            color: $contentColor;
            font-size: torem(14);
            border-radius: 0 !important;
            background-clip: padding-box !important;
            background-color: $backgroundColor;
            border: 1px solid $backgroundColor;
            &::-webkit-input-placeholder {
              color: $contentColor;
            }
            &::-moz-placeholder {
              color: $contentColor;
            }
            &:-ms-input-placeholder {
              color: $contentColor;
            }
            &:-moz-placeholder {
              color: $contentColor;
            }
          }
        }
        .current {
          &::after {
            float: right;
            right: torem(15);
            content: "\2714";
            font-family: "iconfont" !important;
            font-size: torem(16);
            color: #007aff;
          }
        }
      }
      .conStyle {
        /*height: torem(200);*/
        border-radius: 10px;
        padding: 10px;
        border: 1px solid #eee;
      }
    }
  }
}

.pop {
  div.group-items {
    animation: listItems 0.3s linear;
    transform: translateY(0);
  }
}

.down {
  div.group-items {
    animation: listItemsDown 0.3s linear forwards;
  }
}

.hide {
  opacity: 0;
}

.textDiv {
  .count {
    display: block;
    width: 100%;
    height: torem(30);
    text-align: right;
  }
}

@keyframes listItems {
  from {
    opacity: 1;
    transform: translateY(260px);
  }
  to {
    opacity: 1;
    transform: translateY(0px);
  }
}

@keyframes listItemsDown {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translateY(260px);
  }
}
</style>
