<template>
  <ul class="mui-table-view rx-list-items">
    <router-link
      v-for="(item, index) in routerItems"
      @click.native="changeImg(item.img)"
      :class="{'link-item':item.routerLink}"
      :to="item.pathname"
      :key="index"
      tag="li"
      class="item"
    >
      <span v-if="item.icon" class="mui-icon iconfont" :class="item.icon"></span>
      <span class="name">{{item.title}}</span>
      <span class="value" :class="{'no-arrow':!item.pathname.name}" @click="changeKind(item.sel)">
        {{item.value}}
        <p v-if="item.img">
          <img v-if="currentHeadImg && item.img" :src="currentHeadImg" class="img-header" alt />
          <img
            v-else-if="currentUserGender==2 && item.img"
            src="~@/public/asset/img/user/teacher-woman.png"
            class="img-header"
            alt
          />
          <img
            v-else-if="item.img"
            src="~@/public/asset/img/user/teacher-man.png"
            class="img-header"
            alt
          />
        </p>
      </span>
      <!-- <div id="triangle" v-if="item.sel" :class="{'up':kind}" @click="changeKind(item.sel)"></div> -->
      <!-- <ul v-if="kind && item.sel" class="list">
        <span id="cicle"></span>
        <li v-for="job in jobs" :class="{'select':job.id==isSelect}">{{job.name}}</li>
      </ul> -->
    </router-link>
  </ul>
</template>
<script>
import { mapState } from "vuex";
import { getHead } from "@/api/user/user-api";
import { CACHE_KEYS } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
export default {
  data() {
    return {
      kind: false,
      jobs: m2.cache.get("ppts-current-user")
        ? m2.cache.get("ppts-current-user").jobs
        : []
    };
  },
  props: {
    items: {
      type: Array,
      required: true
    }
  },
  methods: {
    changeKind(switchs) {
      if (!switchs) return;
      this.kind = !this.kind;
    },
    changeImg(isChange) {
      if (!isChange) return;
      plus.nativeUI.actionSheet(
        {
          cancel: "取消",
          buttons: [
            {
              title: "拍照"
            },
            {
              title: "从相册中选择"
            },
            {
              title: "更新头像"
            }
          ]
        },
        e => {
          //1 是拍照  2 从相册中选择
          switch (e.index) {
            case 1:
              this.appendByCamera();
              break;
            case 2:
              this.appendByGallery();
              break;
            case 3:
              this.uploadHeadImg();
              break;
          }
        }
      );
    },
    appendByCamera() {
      var that = this;
      plus.camera.getCamera().captureImage(
        src => {
          that._compressImage(src);
        },
        e => {
          console.log("点击了取消拍照!");
        },
        {
          optimize: false
        }
      );
    },
    appendByGallery() {
      var that = this;
      plus.gallery.pick(src => {
        that._compressImage(src);
      });
    },
    uploadHeadImg() {
      xdapp.util.user.getCurrentHead("upload");
    },
    goCropper(urlData) {
      this.$router.push({
        name: "profile-cropper",
        query: {
          urlData: urlData
        }
      });
    },
    _compressImage(src) {
      var that = this;
      plus.nativeUI.showWaiting("加载中...");
      plus.zip.compressImage(
        {
          src: src,
          format: "jpg",
          dst: "_doc/" + new Date().getTime() + ".jpg",
          quality: 30
        },
        event => {
          plus.nativeUI.closeWaiting();
          plus.io.resolveLocalFileSystemURL(
            event.target,
            entry => {
              entry.file(function(file) {
                that.goCropper(file);
              });
            },
            e => {
              mui.toast("读取拍照文件错误");
            }
          );
        }
      );
    }
  },
  created() {
    this.kind = false;
  },
  computed: {
    routerItems() {
      let _items = [];
      this.items.forEach(item => {
        if (!item.pathname || m2.type.isString(item.pathname)) {
          item.pathname = {
            name: item.pathname
          };
        }
        _items.push(item);
      });
      return _items;
    },
    // isSelect() {
    //   return m2.cache.get("ppts-current-job").id;
    // },
    ...mapState({
      //currentHeadImg: state => state.currentHeadImg.imgData,
      currentUserGender: state => state.currentUserGender
    }),
    currentHeadImg() {
      if (
        this.$store.state.currentHeadImg &&
        m2.cache.get(CACHE_KEYS.CURRENT_ICONARR)
      ) {
        return (
          this.$store.state.currentHeadImg.imgData ||
          m2.cache.get(CACHE_KEYS.CURRENT_ICONARR).imgData
        );
      }
    }
  },
  watch: {
    currentHeadImg() {
      if (
        this.$store.state.currentHeadImg &&
        m2.cache.get(CACHE_KEYS.CURRENT_ICONARR)
      ) {
        return (
          this.$store.state.currentHeadImg.imgData ||
          m2.cache.get(CACHE_KEYS.CURRENT_ICONARR).imgData
        );
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.rx-list-items {
  position: absolute;
  width: 100%;
  /*height: 100%;*/
  .item {
    display: flex !important;
    justify-content: center;
    align-items: center;
    padding: torem(10);
    border-bottom: 1px solid #eee;
    margin: 0 torem(5);
    position: relative;
  }
  .link-item:after {
    content: "\E583";
    font-family: Muiicons;
    color: #bbb;
    -webkit-font-smoothing: antialiased;
    margin-left: 5px;
  }
  .name {
    color: #777;
    font-size: torem(14);
  }
  .value {
    display: block;
    text-align: right;
    flex: 1;
    font-size: torem(14);
    color: #aaa;
    .img-header {
      width: 1.70667rem;
      height: 1.70667rem;
      border-radius: 50%;
    }
  }
  .no-arrow {
    margin-right: 3px;
  }
}

.mui-content > .mui-table-view:first-child {
  margin-top: 0;
}

.job-list {
  position: relative;
  top: torem(67);
  right: torem(10);
  li {
    height: torem(30);
  }
}

// #triangle {
//   width: 0px;
//   height: 0px;
//   border-width: 6px;
//   border-style: solid;
//   border-color: transparent transparent #e0e0e0 transparent;
//   position: absolute;
//   top: torem(11);
//   right: torem(1);
// }

// #cicle {
//   display: inline-block;
//   width: 0px;
//   height: 0px;
//   border-width: 12px;
//   border-style: solid;
//   border-color: transparent transparent #e0e0e0 transparent;
//   position: absolute;
//   top: torem(-20);
//   right: torem(1);
// }

// .up {
//   border-color: #e0e0e0 transparent transparent transparent !important;
//   top: torem(20) !important;
// }

// .list {
//   position: absolute;
//   top: torem(45);
//   right: torem(10);
//   padding: torem(10) torem(15);
//   background: #e0e0e0;
//   border-radius: torem(6);
//   max-height: torem(300);
//   overflow-y: scroll;
//   li {
//     //height: torem(30);
//     line-height: torem(30);
//     padding: 0 torem(10);
//     border-bottom: 1px solid #eee;
//   }
//   .select {
//     background: #fff;
//   }
// }
</style>