<template>
	<div class="xd-select-student">
		<tip v-if="!students.length">
			<span>暂无可选择学员</span>
		</tip>
		<div class="students-head" v-if="students.length">
			<p class="inp"><input type="text" placeholder="输入学员姓名/编号进行查询" v-model="inpVal" />
				<!--<i class="iconfont icon-found"></i>--></p>
			<div id="slider" class="mui-slider" data-slider="4">
				<div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
					<a class="mui-control-item" :class="isValidStudent?'mui-active':''" href="#item1mobile">
						有效学员
					</a>
					<a class="mui-control-item " :class="!isValidStudent?'mui-active':''" href="#item2mobile">
						所有学员
					</a>
				</div>
				<div id="item1mobile" class="mui-control-content" :class="isValidStudent?'mui-active':''">
					<div id="scroll1" class="mui-scroll-wrapper" data-scroll="1">
						<div class="mui-scroll" style="transform: translate3d(0px, 0px, 0px) translateZ(0px);">
							<div class="students-list">
								<ul>
									<li v-for="(item,index) in validStudents" :class="item.current?'selectStudent':''"><span>{{item.customerName}}</span><span>{{item.customerCode}}</span><span @click="addFeedBack(item)">添加周反馈</span></li>
								</ul>
							</div>
						</div>
						<div class="mui-scrollbar mui-scrollbar-vertical">
							<div class="mui-scrollbar-indicator" style="transition-duration: 0ms; display: block; height: 52px; transform: translate3d(0px, 0px, 0px) translateZ(0px);"></div>
						</div>
					</div>
				</div>
				<div id="item2mobile" class="mui-slider-item mui-control-content" :class="!isValidStudent?'mui-active':''" ref="item2" style="height:450px">
					<div id="scroll2" class="mui-scroll-wrapper" data-scroll="2">
						<div class="mui-scroll" style="transform: translate3d(0px, 0px, 0px) translateZ(0px); transition-duration: 0ms;">
							<div class="students-list">
								<ul>
									<li v-for="(item,index) in students" :class="item.current?'selectStudent':''"><span>{{item.customerName}}</span><span>{{item.customerCode}}</span><span @click="addFeedBack(item)">添加周反馈</span></li>
								</ul>
							</div>
						</div>
						<div class="mui-scrollbar mui-scrollbar-vertical">
							<div class="mui-scrollbar-indicator" style="transition-duration: 0ms; display: block; height: 207px; transform: translate3d(0px, 0px, 0px) translateZ(0px);"></div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</template>

<script>
	import Tip from '@/components/tip';
	export default {
		data() {
			return {
				inpVal: '',
				isShow: true,
				isValidStudent: false,
			}
		},
		props: ['students'],
		methods: {
			searchStudent() {
				const regTest = new RegExp(this.inpVal, 'i');
				if(!this.inpVal) {
					this.isValidStudent = false;
					this.validStudents.forEach((item) => {
						item.current = false;
					})
					this.students.forEach((item) => {
						item.current = false;
					})
					return;
				}
				this.validStudents.forEach((item) => {
					if(regTest.test(item.customerName) || regTest.test(item.customerCode)) {
						item.current = true;
						this.isValidStudent = true;
					} else {
						item.current = false;
						if(!this.isValidStudent) {
							this.students.forEach((item) => {
								if(regTest.test(item.customerName) || regTest.test(item.customerCode)) {
									item.current = true;
								} else {
									item.current = false;
								}

							})
						}
					}

				})

			},

		},
		watch: {
			inpVal() {
				this.searchStudent();
			}
		},
		components: {
			Tip
		}
	}
	/*import { ACTION_TYPES, ReplyType } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api';
	import { $getStudentList } from '@/api/customer-reply/customer-reply-api';
	import Tip from '@/components/tip';
	export default {
		data() {
			return {
				students: [],
				inpVal: '',
				isShow: true,
				isValidStudent: false,
				refreshContainer: '#item2mobile',
				allStudentSideH: 450
			}
		},
		created() {
			this.getStudentList();
		},
		methods: {
			searchStudent() {
				const regTest = new RegExp(this.inpVal, 'i');
				if(!this.inpVal) {
					this.isValidStudent = false;
					this.validStudents.forEach((item) => {
						item.current = false;
					})
					this.students.forEach((item) => {
						item.current = false;
					})
					return;
				}
				this.validStudents.forEach((item) => {
					if(regTest.test(item.customerName) || regTest.test(item.customerCode)) {
						item.current = true;
						this.isValidStudent = true;
					} else {
						item.current = false;
						if(!this.isValidStudent) {
							this.students.forEach((item) => {
								if(regTest.test(item.customerName) || regTest.test(item.customerCode)) {
									item.current = true;
								} else {
									item.current = false;
								}

							})
						}
					}

				})

			},
			async getStudentList() {
				await loadUserInfo();

				$getStudentList(res => {
					this.students = res;
				});
			},
			addFeedBack(item) {
				this.$router.push({
					name: 'message-customer-reply',
					query: {
						staffId: item.customerID,
						replyType: this.replyType,
						title: this.replyType + '-' + item.customerName + "家长"
					}
				})
			},
			addHeight() {
				this.allStudentSideH = this.allStudentSideH + 50;
				this.$refs.item2.style.height = this.allStudentSideH + 'px';
			}
		},
		computed: {
			validStudents() {
				const validStudents = [];
				this.students.forEach((item) => {
					if(item.isValid) {
						validStudents.push(item);
					}
				})
				return validStudents;
			},
			replyType() {
				if(this.$route.query.num == 0) return "日常维护";
				if(this.$route.query.num == 1) return "周反馈";
			}
		},
		watch: {
			inpVal() {
				this.searchStudent();
			}
		},
		components: {
			Tip
		}
	}*/
</script>

<style lang="scss">
	.xd-select-student {
		text-align: center;
		.students-head {
			width: 100%;
		}
		.inp {
			width: 90%;
			margin-left: 5%;
			margin-top: torem(15);
			height: 45px;
			border: 1px solid #eee;
			input {
				width: 100%;
				height: 100%;
				border: none;
			}
			i {
				position: absolute;
				right: torem(26);
				top: torem(92);
				color: #eee;
				font-size: torem(24)
			}
		}
		#item1mobile,
		#item2mobile {
			overflow-y: scroll;
			height: torem(450);
			margin-top: 15px;
		}
		.mui-slider {
			padding: 0 torem(18);
		}
		#sliderSegmentedControl {
			.mui-active {
				background-image: linear-gradient(90deg, #FFB82A 0%, #FF9900 100%);
				color: #fff;
			}
		}
		.students-list {
			ul>li {
				width: 100%;
				height: 40px;
				display: flex;
				align-items: center;
				justify-content: space-around;
				span {
					font-size: torem(14)
				}
				span:nth-child(3) {
					color: skyblue;
				}
			}
		}
		.selectStudent {
			background-color: #eee;
		}
	}
</style>