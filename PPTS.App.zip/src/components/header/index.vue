﻿<template>
  <div>
    <header
      id="xd-header"
      class="mui-bar mui-bar-nav xd-header"
      v-show="this.$route.meta.showHeader"
    >
      <a class="qrcode" v-show="this.$route.meta.showQRScan && isShowScan()" @click="getScan()">
        <span class="mui-icon iconfont icon-qr"></span>
      </a>
      <div
        class="mui-icon mui-icon-left-nav mui-pull-left ios-back"
        v-show="!this.$route.meta.disableBack"
        @click="back()"
      ></div>
      <span
        class="mui-pull-left header-left-btn"
        v-show="this.$route.meta.leftBtn"
        @click="routerActions()"
      >{{this.$route.meta.leftBtn}}</span>
      <span
        class="mui-icon mui-pull-right"
        v-show="this.$route.meta.settings"
        @click="emitAction()"
      >
        <i class="iconfont icon-setting" style="font-size: 24px;"></i>
      </span>
      <p class="mui-pull-right user-menu" v-show="!this.$route.meta.hideChildren">
        <span class="child" v-show="this.$route.meta.showChildName">
          <span class="name">{{this.$store.state.currentJob.name}}</span>
        </span>
        <i id="add-user-menu" class="mui-icon iconfont icon-groups" @click="toggle()"></i>
      </p>
      <span v-if="this.$route.meta.actionText">
        <span
          class="action"
          @click="emitAction()"
          v-show="this.$store.state.enabledStatus"
        >{{this.$route.meta.actionText}}</span>
        <span
          class="action disabled"
          v-show="!this.$store.state.enabledStatus"
        >{{this.$route.meta.actionText}}</span>
      </span>
      <h1 class="mui-title">{{this.$route.meta.title}}</h1>
    </header>
    <job-list v-show="showModal" v-on:showNames="getNamesValue" v-on:showModal="getShowModalValue"></job-list>
  </div>
</template>
<script>
import JobList from "../job-list/";
export default {
  data() {
    return {
      showModal: false
    };
  },
  methods: {
    emitAction() {
      xdapp.util.vue.emit();
    },
    back() {
      if (window.xdapp.scan) {
        window.xdapp.scan.close();
      } else if (this.$route.name === "feedback-list") {
        this.$router.push({
          name: "settings"
        });
        return;
      } else if (this.$route.name === "settings") {
        this.$router.push({
          name: "profile"
        });
        return;
      } else if (this.$route.name === "feedback-reply") {
        this.$router.push({
          name: "feedback-list"
        });
        return;
      } else if (this.$route.name === "profile-user-userInfo") {
        this.$router.push({
          name: "profile"
        });
        return;
      } else if (this.$route.name === "message-group-mess") {
        this.$router.push({
          name: "message-disscuion-group"
        });
        return;
      } else if (this.$route.name === "message-disscuion-group") {
        this.$router.push({
          name: "message-customer-interact"
        });
        return;
      } else if (this.$route.name === "message-customer-interact") {
        this.$router.push({
          name: "message"
        });
        return;
      } else if (this.$route.name === "message-send-message") {
        this.$router.push({
          name: "message-customer-list",
          query: {
            reviewAgin: false
          }
        });
        return;
      } else if (this.$route.name === "message-customer-list") {
        this.$router.push({
          name: "message-group-list"
        });
        return;
      } else if (this.$route.name === "message-group-list") {
        this.$router.push({
          name: "message-teacher-chats",
          query: { num: 0 }
        });
        return;
      } else if (this.$route.name === "message-teacher-chats") {
        this.$router.push({
          name: "message-customer-interact"
        });
        return;
      } else if (this.$route.name === "message-teacher-list") {
        if (this.$route.query.num == 1) {
          this.$router.push({
            name: "message-teacher-chats",
            query: { num: 1 }
          });
        } else {
          this.$router.push({
            name: "message-teacher-chats",
            query: { num: 0 }
          });
        }

        return;
      } else if (this.$route.name === "addGuest") {
        // this.$router.push({
        //   name: "home"
        // });

        if ($vue.$route.query.refer == 1) {
          $vue.$router.push({
            name: "customer"
          });
        } else {
          $vue.$router.push({
            name: "home"
          });
        }
        return;
      } else if (
        $vue.$route.name == "studentInfo" ||
        $vue.$route.name == "parentInfo" ||
        $vue.$route.name == "records" ||
        $vue.$route.name == "studentInfoEdit"
      ) {
        if ($vue.$route.query.refer == 1) {
          $vue.$router.push({
            name: "customer"
          });
        } else {
          $vue.$router.push({
            name: "home"
          });
        }
        return;
      } else if (
        $vue.$route.name == "studentSignedInfo" ||
        $vue.$route.name == "recordsSigned" ||
        $vue.$route.name == "parentSignedInfo"
      ) {
        if ($vue.$route.query.refer == 1) {
          $vue.$router.push({
            name: "customer",
            query: { tab: 2 }
          });
        } else if ($vue.$route.query.refer == 2) {
          $vue.$router.push({
            name: "message-teacher-list",
            query: { num: 0 }
          });
        }

        return;
      }
      this.$router.go(-1);
    },
    routerActions() {
      this.$router.push({ name: "addGuest", query: { refer: 1 } });
    },
    toggle() {
      this.showModal = !this.showModal;
    },
    getNamesValue(data) {
      this.showNames = data;
    },
    getShowModalValue(data) {
      this.showModal = data;
    },
    getScan() {
      this.$router.push({
        name: "scan"
      });
    },
    isShowScan() {
      return m2.util.getPermionLoad("睿学-确认课时");
    }
  },
  components: {
    JobList
  }
};
</script>
<style lang="scss" scoped="">
.ios-back{
  user-select: none;
  // color: transparent!important;
  &::before{
    color: #fff;
  }
}
.xd-header {
  padding-top: torem(-100);
  .mui-icon {
    color: #fff;
    img {
      width: 24px;
      height: 24px;
      margin-left: torem(-150);
    }
  }
  .header-left-btn {
    color: #fff;
    font-size: torem(14);
  }
}

.user-menu {
  display: flex;
  align-items: center;
  color: #fff;
  margin-right: 10px;
  .child {
    span {
      @include letterStyle(14, #fff, -0.62, 20.8);
    }
    span.name {
      @include letterStyle(18, #fff, -0.62, 20.8);
      margin-right: torem(12.4);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: torem(240);
      display: inline-block;
    }
  }
  img {
    width: torem(36);
    height: torem(36);
    z-index: 20;
    border-radius: 100%;
    margin-right: torem(5);
  }
}

.mui-title {
  @include letterStyle(17, #fff, -0.62, 36);
  position: absolute;
  left: 50%;
  margin-left: torem(-80) !important;
  width: torem(160) !important;
  text-align: center !important;
}

.mui-bar {
  height: 63px;
  padding-top: 20px;
}

.qrcode {
  float: left;
  margin-left: torem(10);
}

.search {
  float: left;
  margin-left: torem(10);
}
</style>