<template>
  <div class="loading">
    <img width="24" height="24" src="~@/public/asset/img/icons/loading.gif">
    <p class="desc">{{title}}</p>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    props: {
      title: {
        type: String,
        default: '正在载入...'
      }
    }
  }
</script>
<style scoped lang="scss">
  .loading {
    width: 100%;
    height: 34px;
    margin-top: 16px;
    text-align: center;
    .desc {
      line-height: 20px;
      font-size: torem(12);
      color: #ccc;
    }
  }
</style>
