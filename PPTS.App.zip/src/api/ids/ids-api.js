﻿import axios from '@/public/api/axios'

export const login = (criteria, success,err) =>{
    let failure=(error) => {
        let message = error.errMsg.substring(error.errMsg.indexOf("，") + 1);
        mui.alert(message,'提示','','','div');
    }
    if(err && typeof err == 'function'){
        failure = (error) => {
            let message = error.errMsg.substring(error.errMsg.indexOf("，") + 1);
            mui.alert(message,'提示','','','div');
            err(error);
        }
    }
    axios.$post(xdapp.api.ids.logon, criteria, {
        success,
        failure,
    });
}
export const logOff = (success) =>
    axios.$get(xdapp.api.ids.logoff, {}, {
        success,
        failure: (error) => {
            mui.alert(error.errMsg,'提示','','','div');
        }
    });
