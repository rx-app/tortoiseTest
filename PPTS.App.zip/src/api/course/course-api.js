﻿import axios from '@/public/api/axios'

export const getTeacherCourses = (criteria, success) =>
	axios.$post(xdapp.api.course.getTeacherCourses, criteria, success);

export const getPagedStudentCourses = (criteria, success) =>
	axios.$post(xdapp.api.course.getPagedStudentCourses, criteria, success);

export const courseDetail = (criteria, success) =>
	axios.$get(xdapp.api.course.getStudentCourseInfo, criteria, success);

export const getLessonInfo = (criteria, success) =>
	axios.$post(xdapp.api.course.getLessonInfo, criteria, success);

export const postLessonEvaluation = (criteria, success) =>
	axios.$post(xdapp.api.course.postLessonEvaluation, criteria, success);

export const confirmStudentCourse = (criteria, success) =>
	axios.$post(xdapp.api.course.confirmStudentCourse, criteria, {
		success,
		error: () => {
			window.xdapp.scan.close();
			$vue.$router.push({
				name: "home"
			});
		}
	});

export const getCustomerListByLessonID = (lessonID, success) =>
	axios.get(xdapp.api.course.getCustomerListByLessonID + "?lessonID=" + lessonID).then(success);

export const getCustomerListByGroupID = (groupID, success) =>
	axios.get(xdapp.api.course.getCustomerListByGroupID + "?groupID=" + groupID).then(success);

export const confirmForClassGroup = (criteria, success) =>
	axios.$post(xdapp.api.course.confirmForClassGroup, criteria, success);

export const confirmForOneToMore = (criteria, success) =>
	axios.$post(xdapp.api.course.confirmForOneToMore, criteria, success);

export const passwordConfirm = (criteria, success) =>
	axios.$post(xdapp.api.course.passwordConfirm, criteria, success);

export const monitorConfirmAsset = (criteria, success) =>
	axios.$post(xdapp.api.course.monitorConfirmAsset, criteria, success);

export const getScopeTeacherCourse = (criteria, success) =>
	axios.$post(xdapp.api.course.getScopeTeacherCourse, criteria, success);

export const getAppInfo = (criteria, success) =>
	axios.$post(xdapp.api.config.getAppInfo, criteria, success);

export const getAppInfoByQuery = (criteria, success) =>
	axios.$get(xdapp.api.config.getAppInfoByQuery, criteria, success);
