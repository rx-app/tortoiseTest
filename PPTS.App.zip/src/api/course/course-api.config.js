export default {
  course: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
    },
    url: '/api/Course/{0}',
    actions: {
      getTeacherCourses: "GetTeacherCourse", /*获取老师课表  post*/
      confirmForClassGroup: "ConfirmForClassGroup",/*班组点名确认课时*/
      confirmForOneToMore:"ConfirmForOneToMore",/*一对多班组点名*/
      confirmStudentCourse: "ConfirmStudentCourse", /*PPTS扫描RX签到  post*/
      getLessonInfo: "GetLessonInfo",/*获取课程信息（含评价）*/
      postLessonEvaluation: "PostLessonEvaluation",/*对学生进行课程评价*/
      getCustomerListByLessonID:"GetCustomerListByLessonID",/*获取学员班次列表*/
      getCustomerListByGroupID:"GetCustomerListByGroupID",/*获取一对多课次学生列表*/
      passwordConfirm:"PasswordConfirm",/*点名确认课时*/
      monitorConfirmAsset:"MonitorConfirmAsset",/*被扫码后展示最新课程状况*/
      getScopeTeacherCourse:"GetScopeTeacherCourse",/*获取岗位下教师课表*/
    }
  }
}
