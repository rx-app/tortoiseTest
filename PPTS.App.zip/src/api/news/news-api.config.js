export default {
  news: {
    getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
    url: '/api/news/{0}',
    actions: {
      getNewsList: "getNewsList",
      getTop3NewsList: "GetTop3NewsList",
      getNews: "getNews",
      getHasNews:"getHasNews",
      getNewsByDay: "getNewsByDay",
      getNewestNews: 'getNewestNews',
    }
  }
}
