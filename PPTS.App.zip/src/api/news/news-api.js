import axios from '@/public/api/axios';

// 获取资讯列表
export let $getNewsList = (criteria, success) => {
  axios.$post(xdapp.api.news.getNewsList, criteria, success);
};

// 获取资讯列表
export let $getTop3NewsList = (criteria, success) => {
  axios.$post(xdapp.api.news.getTop3NewsList + criteria, {}, success);
};

// 获取资讯内容
export let $getNews = (criteria, success) => {
  axios.$get(xdapp.api.news.getNews, criteria, success);
};

// 是否存在最新资讯
export let $getHasNews = (criteria, success) => {
  axios.$get(xdapp.api.news.getHasNews, criteria, success);
};
// 按天获取资讯列表
export let $getNewsByDay = (criteria, success) => {
  axios.$post(xdapp.api.news.getNewsByDay, criteria, success);
};

export let $getNewestNews = (success) => {
  axios.$get(xdapp.api.news.getNewestNews, {}, success);
};
