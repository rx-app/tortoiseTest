export default {
	customerReply: {
		getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
		url: 'api/customerReply/{0}',
		actions: {
			upLoadFile:'upLoadFile',
			downLoadFile:'downLoadFile',
			loadLast: "LoadLast",/*加载最新家校互动*/
			loadCustomerReplyPage: 'LoadCustomerReplyPage',
			loadEducatorCustomerReplyPage: "LoadEducatorCustomerReplyPage",/*加载学管师家校互动页面*/
			loadDailyCustomerReplyPage: "LoadDailyCustomerReplyPage",/*加载日常维护页面*/
			loadCustomerReply: "LoadCustomerReply",/*加载家校互动*/
			loadEducatorWeekCustomerReplyPage: "LoadEducatorWeekCustomerReplyPage",/*加载周反馈页面*/
			loadCustomer: "LoadCustomer",/*加载学生信息*/
			userSendCustomerReply: "UserSendCustomerReply",/*员工发送  家校互动信息*/
			loadDiscussionLast:"LoadDiscussionLast",/*家长讨论组最新消息*/
			loadDiscussionPage: "LoadDiscussionPage",/*家长讨论组页面*/
			queryDiscussionGroupIDByCustomer:"QueryDiscussionGroupIDByCustomer",/*通过学员姓名或编号查询*/
			queryCustomer:"QueryCustomer",/*通过学生名或者学生编号查询学员*/
			queryDiscussionGroupStaff: "QueryDiscussionGroupStaff",/*通过学生ID查询符合创建讨论组的员工*/
			createDiscussionGroup:"CreateDiscussionGroup",/*创建讨论组*/
			loadDiscussion:"LoadDiscussion",/*加载讨论组*/
			speakInDiscussion: "SpeakInDiscussion",/*在讨论组中说话*/
			editDiscussionGroupName:"EditDiscussionGroupName",/*修改讨论组名称*/
			loadDiscussionGroupInfo: "LoadDiscussionGroupInfo",/*加载讨论组信息*/
			deleteMemberFromDiscussionGroup:"DeleteMemberFromDiscussionGroup",/*从讨论组中移出成员*/
			addMemberToDiscussionGroup: "AddMemberToDiscussionGroup",/*添加成员到讨论组*/
			queryAddDiscussionGroupStaff:"QueryAddDiscussionGroupStaff",/*查询添加讨论组所需要的员工*/
			loadLastMultipleCustomerReply:"LoadLastMultipleCustomerReply",/*获取最新群发消息*/
			loadMultipleCustomerReply: "LoadMultipleCustomerReply",/*获取群发消息*/
			userSendMultipleCustomerReply:"UserSendMultipleCustomerReply",/*群发日常维护消息*/
			loadCustomerByStatus: "LoadCustomerByStatus",/*通过状态加载学生信息*/
			loadCustomerByGrade:"LoadCustomerByGrade",/*通过年级加载学生信息*/
			partTimeTeacherEnable:"PartTimeTeacherEnable",/*兼职教师是否可用*/
			deleteDiscussion:"DeleteDiscussion",/*删除讨论组*/
			loadDiscussionPageByCustomer:"LoadDiscussionPageByCustomer",/*通过学生查询家长讨论组页面*/
		}
	}
}