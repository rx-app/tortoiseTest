﻿import axios from '@/public/api/axios';

// 获取教师/学管师最新家校互动
export let $getLastReply = (success) => {
  axios.$get(xdapp.api.customerReply.loadLast, {}, success);
};
// 获取家校互动页面
export let $getCustomerReply = (success) => {
  axios.$get(xdapp.api.customerReply.loadCustomerReplyPage, {}, success);
};
// 获取学管师家校互动页面
export let $getEducatorCustomerReply = (success) => {
  axios.$get(xdapp.api.customerReply.loadEducatorCustomerReplyPage, {}, success);
};
// 删除家校互动聊天记录
/*export let $deleteCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.deleteReplyByReplyObject, criteria, success);
};*/
// 获取学生信息
export let $getStudentList = (success) => {
  axios.$get(xdapp.api.customerReply.loadCustomer, {}, success);
};
// 加载家校互动
export let $getCustomerReplyByType = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.loadCustomerReply, criteria, success);
};
// 获取学管师周反馈页面
export let $loadEducatorWeekCustomerReplyPage = (success) => {
  axios.$get(xdapp.api.customerReply.loadEducatorWeekCustomerReplyPage, {}, success);
};
// 获取学管师日常维护页面
export let $loadDailyCustomerReplyPage = (success) => {
  axios.$get(xdapp.api.customerReply.loadDailyCustomerReplyPage, {}, success);
};
// 删除指定教师家校互动
/*export let $deleteTeacherCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.deleteTeacherReplyByTeacherID, criteria, success);
};*/
// 发送家校互动信息
export let $sendCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.userSendCustomerReply, criteria, success);
};
// 家长讨论组最新消息
export let $loadDiscussionLast = (success) => {
  axios.$get(xdapp.api.customerReply.loadDiscussionLast, {}, success);
};
// 家长讨论组页面
export let $loadDiscussionPage = (success) => {
  axios.$get(xdapp.api.customerReply.loadDiscussionPage, {}, success);
};
// 通过学员姓名或编号查询
export let $queryDiscussionGroupIDByCustomer = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.queryDiscussionGroupIDByCustomer+'?customer='+criteria,{}, success);
};
//通过学生名或者学生编号查询学员
export let $queryCustomer = (criteria,success) => {
  axios.$post(xdapp.api.customerReply.queryCustomer+'?customer='+criteria,{}, success);
};
//通过学生ID查询符合创建讨论组的员工
export let $queryDiscussionGroupStaff = (criteria,success) => {
  axios.$post(xdapp.api.customerReply.queryDiscussionGroupStaff+'?customerID='+criteria,{}, success);
};
//创建讨论组
export let $createDiscussionGroup = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.createDiscussionGroup,criteria, success);
};
// 加载讨论组
export let $loadDiscussion = (criteria,success) => {
  axios.$post(xdapp.api.customerReply.loadDiscussion, criteria, success);
};
// 在讨论组中说话
export let $speakInDiscussion = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.speakInDiscussion,criteria, success);
};
//修改讨论组名称
export let $editDiscussionGroupName = (criteria,success) => {
  axios.$post(xdapp.api.customerReply.editDiscussionGroupName, criteria, success);
};
//加载讨论组信息
export let $loadDiscussionGroupInfo = (criteria,success) => {
  axios.$post(xdapp.api.customerReply.loadDiscussionGroupInfo+'?DiscussionGroupID='+criteria,{}, success);
};
//从讨论组中移出成员
export let $deleteMemberFromDiscussionGroup = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.deleteMemberFromDiscussionGroup,criteria, success);
};
//添加成员到讨论组
export let $addMemberToDiscussionGroup = (criteria,success) => {
  axios.$post(xdapp.api.customerReply.addMemberToDiscussionGroup,criteria, success);
};
//查询添加讨论组所需要的员工
export let $queryAddDiscussionGroupStaff = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.queryAddDiscussionGroupStaff+'?DiscussionGroupID='+criteria,{}, success);
};
// 获取最新群发消息
export let $loadLastMultipleCustomerReply = (success) => {
  axios.$post(xdapp.api.customerReply.loadLastMultipleCustomerReply,{}, success);
};
//获取群发消息
export let $loadMultipleCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.loadMultipleCustomerReply,criteria, success);
};
//群发日常维护消息
export let $userSendMultipleCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.userSendMultipleCustomerReply,criteria, success);
};
//通过状态加载学生信息
export let $loadCustomerByStatus = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.loadCustomerByStatus,criteria, success);
};
//通过年级加载学生信息
export let $loadCustomerByGrade = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.loadCustomerByGrade,criteria, success);
};
//兼职教师是否可用
export let $partTimeTeacherEnable = (success) => {
  axios.$post(xdapp.api.customerReply.partTimeTeacherEnable,{}, success);
};
//删除讨论组
export let $deleteDiscussion = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.deleteDiscussion+'?DiscussionGroupID='+criteria,{}, success);
};
//通过学生查询家长讨论组页面
export let $loadDiscussionPageByCustomer = (criteria, success) => {
  axios.$get(xdapp.api.customerReply.loadDiscussionPageByCustomer+'?Customer='+criteria,{}, success);
};

export let upLoadFile = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.upLoadFile, criteria, success);
};

export let downLoadFile = xdapp.api.customerReply.downLoadFile
