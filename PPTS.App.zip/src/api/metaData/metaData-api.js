﻿import axios from '@/public/api/axios'

/*获取信息来源 */
export const getCustomerSource = (criteria, success) =>
axios.$post(xdapp.api.metadata.getCustomerSource, criteria, success);

/*获取地址 */
export const getLocationData = (criteria, success) =>
axios.$post(xdapp.api.metadata.getLocationData, criteria, success);


/*获取学校 */
export const getSchools = (criteria, success) =>
axios.$post(xdapp.api.metadata.getSchools, criteria, success);

