export default {
  metadata: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
    },
    url: '/api/metadata/{0}',
    actions: {
      getCustomerSource: "getCustomerSource", /*获取信息来源*/
      getLocationData:'getLocationData',/*获取地址*/
      getSchools:'getSchools',/*获取学校*/

      
    }
  }
}
