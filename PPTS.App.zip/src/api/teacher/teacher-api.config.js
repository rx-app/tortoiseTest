export default {
  teacher: {
    getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
    url: '/api/Teacher/{0}',
    actions: {
      getTodayHasCourseTeachers: "GetTodayHasCourseTeachers", /*获取今日有课教师  post*/
    }
  }
}
