﻿import axios from '@/public/api/axios'

export const getTodayHasCourseTeachers = (criteria, success) =>
	axios.$post(xdapp.api.teacher.getTodayHasCourseTeachers, criteria, success);

