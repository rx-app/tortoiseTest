﻿import Vue from 'vue';
import axios from 'axios';
import store from '@/store';
import * as types from '@/store/mutation-types';
import { HEADER_KEYS, CACHE_KEYS, FOOTER_NAV_TABS_FIRST, FOOTER_NAV_TABS_LAST, FOOTER_NAV_TABS_NOFULL } from '@/constants';

//axios.defaults.baseURL = process.env.APP_API_ROOT;

export const fingerPsdStatus = () => {
	return m2.cache.get(CACHE_KEYS.FINGERPSDSTATUS) || $vue.$store.state.fingerPsdStatus;
};

export const fingerPsdNum = () => {
	return m2.cache.get(CACHE_KEYS.FINGERPSDNUM) || $vue.$store.state.fingerPsdNum;
};

export const getCurrentJob = () => {
	return m2.cache.get(CACHE_KEYS.CURRENT_JOB) || $vue.$store.state.currentJob;
};

export const getUserId = () => {
	return m2.cache.get(CACHE_KEYS.USERID) || $vue.$store.state.userId;
};

export const getUserLoginName = () => {
	return m2.cache.get(CACHE_KEYS.CURRENT_USER) && m2.cache.get(CACHE_KEYS.CURRENT_USER).logOnName;
};
export const loadUserInfo = (type) => {
	/*return new Promise((resolve) => {*/
	const currentJob = m2.cache.get(CACHE_KEYS.CURRENT_JOB);

	if (!currentJob || !currentJob.id || type == 'upd') {
		const token = m2.cache.get(CACHE_KEYS.SESSION_TOKEN);
		if (!token) {
			$vue.$router.push({
				name: 'login'
			});
		} else {
			return axios({
				method: 'post',
				url: xdapp.api.user.loadUserInfo,
				...xdapp.util.ajax.getRequestHeaders(token)
			}).then(res => {
				const state = $vue.$store.state;
				let ifid = res.jobs.find(item => item.id == state.currentJob.id)
				// 对于同一账号再次登录，仍然保存退出前选择的岗位
				if (state.userId === res.userId && state.currentJob && ifid) {
					res.currentJob = state.currentJob;
				} else {
					res.currentJob = res.jobs.find(item => item.isPrimary);
				} 
				// 将当前用户信息放入state
				store.commit(types.GET_USER_INFO, res);
				// 将当前用户头像ID放入state
				store.commit(types.ICON_ID, res.iconID);
				// 保存当前用户头像ID
				m2.cache.set(CACHE_KEYS.CURRENT_ICONID, res.iconID);
				//保存当前用户ID
				m2.cache.set(CACHE_KEYS.CURRENT_USER, res);
				// 保存当前教师信息
				m2.cache.set(CACHE_KEYS.CURRENT_JOB, res.currentJob);

				//xdapp.util.user.getCurrentHead();

				const footNavKind = m2.util.getPermionLoad('睿学-教师导航');
				if (footNavKind) {
					if (m2.cache.get('ppts-current-job').isFullTime) {
						store.commit(types.NAVTABS, FOOTER_NAV_TABS_LAST);
						m2.cache.set(CACHE_KEYS.NAVTABS, FOOTER_NAV_TABS_LAST);
					} else {
						store.commit(types.NAVTABS, FOOTER_NAV_TABS_NOFULL);
						m2.cache.set(CACHE_KEYS.NAVTABS, FOOTER_NAV_TABS_NOFULL);
					}

				} else {
					store.commit(types.NAVTABS, FOOTER_NAV_TABS_FIRST);
					m2.cache.set(CACHE_KEYS.NAVTABS, FOOTER_NAV_TABS_FIRST);
				}
			});
		}
	} else {
		// 关闭应用时，从缓存中直接获取
		store.commit(types.GET_USER_INFO, m2.cache.get(CACHE_KEYS.CURRENT_USER));
	}
	/*	resolve(result);
	});*/
};

export const getUserFeedback = (success, error) =>
	axios.post(xdapp.api.settings.getUserFeedback).then(success).catch(error);

export const saveFeedback = (criteria, success, error) =>
	axios.post(xdapp.api.settings.saveFeedback, criteria).then(success).catch(error);

export const getAppInfo = (criteria, success, error) =>
	axios.post(xdapp.api.config.getAppInfo, criteria).then(success).catch(error);


export const getAppInfoByQuery = (criteria, success, error) =>
	axios.get(xdapp.api.config.getAppInfoByQuery, criteria).then(success).catch(error);