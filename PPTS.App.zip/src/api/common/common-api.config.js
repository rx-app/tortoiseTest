export default {
  config: [{
    preLoad:true,
    getBaseUrl:()=>{
      return process.env.APP_API_ROOT
    },
    url: '/api/Config/{0}',
    actions: {
    	getAppInfo:'GetAppInfo',
    	getAppInfoByQuery:"GetAppInfoByQuery",
      getFullConfig: "GetFullConfig", /*获得配置信息 get post*/
      getWebApiConfig: "GetWebApiConfig", /*获得webapi配置信息 get post*/
      getCategoriesConfig: "GetCategoriesConfig", /*获得Categories配置信息 get post*/
      getVersionConfig: "GetVersionConfig",/*获得配置版本号信息 get post*/
      getApplicationInsightsConfig:"GetApplicationInsightsConfig"/*获得AI监测配置信息*/
    }
  },{
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
    },
    url: '/api/Settings/{0}',
    actions: {
      getUserFeedback: "GetUserFeedback" ,/*建议反馈试图 get post*/
      saveFeedback: "SaveFeedback"
    }
  }]
}
