﻿import axios from '@/public/api/axios'

/*跟进记录查询*/
export const getAllFollows = (criteria, success) =>
	axios.$post(xdapp.api.CustomerFollows.getAllFollows, criteria, success);
/*跟进记录分页查询*/
export const getPagedFollows = (criteria, success) =>
	axios.$post(xdapp.api.CustomerFollows.getPagedFollows, criteria, success);
/*新建跟进记录*/
export const createFollow = (criteria, success) =>
	axios.$get(xdapp.api.CustomerFollows.createFollow, criteria, success);
/*提交新建的跟进记录*/
export const $createFollow = (criteria, success) =>
	axios.$post(xdapp.api.CustomerFollows.createFollow, criteria, success);
/*查看指定跟进*/
export const viewFollow = (criteria, success) =>
	axios.$get(xdapp.api.CustomerFollows.viewFollow, criteria, success);
	