export default {
	CustomerFollows: [{
		getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
		url: '/api/CustomerFollows/{0}',
		actions: {
			getAllFollows: "GetAllFollows",/*跟进记录查询*/
			getPagedFollows: "GetPagedFollows",/*跟进记录分页查询*/
			createFollow: "CreateFollow",/*新建跟进记录*/
			viewFollow: "ViewFollow",/*查看指定跟进*/
		}
	}]
}