export default {
  user: {
    getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.userApiUrl
		},
    url:'/api/User/{0}',
    actions: {
    	modifyHead:'ModifyHead',/*教师上传头像*/
      loadUserInfo: "LoadUserInfo", /*获得用户信息 post*/
      loadCurrentJob:"LoadCurrentJob",/*获得用户当前岗位信息*/
      getHead:"GetHead",/*获取用户头像*/
      getHeadIDsByUserIDs:"GetHeadIDsByUserIDs",/*获取用户头像ID*/
      updateUserInfo:'updateUserInfo', /*修改个人信息*/
    }
  }
}
