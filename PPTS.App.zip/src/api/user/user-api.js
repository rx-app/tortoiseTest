﻿import axios from '@/public/api/axios';

export const sendUserRegisterCode = (cellNumber, success, error) =>
    axios.post(xdapp.api.user.sendUserRegisterCode + "?CellNumber=" + cellNumber).then(success).catch(error);

export const registerUser = (criteria, success, error) =>
    axios.post(xdapp.api.user.registerUser, criteria).then(success).catch(error);

export const sendLogOnCode = (cellNumber, success, error) =>
    axios.post(xdapp.api.user.sendVerificationLogOnCode + "?CellNumber=" + cellNumber).then(success).catch(error);

export const registerUserPhoneNumValidate = (validateCode, success, error) =>
    axios.post(xdapp.api.user.registerUserPhoneNumValidate, validateCode).then(success).catch(error);

export const validateUserResetPwdCode = (criteria, success, error) =>
    axios.post(xdapp.api.user.validateUserResetPwdCode + "?CellNumber=" + criteria.cellNumber + "&Code=" + criteria.code).then(success).catch(error);

export const sendUserResetPwdCode = (cellNumber, success, error) =>
  axios.post(xdapp.api.user.sendUserResetPwdCode + "?CellNumber=" + cellNumber).then(success).catch(error);

export const loadUserInfo = (cellNumber, success, error) =>
  axios.post(xdapp.api.user.loadUserInfo + "?CellNumber=" + cellNumber).then(success).catch(error);

export const updateUserInfo = (cellNumber, success, error) =>
  axios.post(xdapp.api.user.updateUserInfo + "?CellNumber=" + cellNumber).then(success).catch(error);

export const resetUserPwd = (criteria, success, error) =>
    axios.post(xdapp.api.user.resetUserPwd, criteria).then(success).catch(error);

export const validateUserRegisterCode = (criteria, success, error) =>
    axios.post(xdapp.api.user.validateUserRegisterCode + "?CellNumber=" + criteria.cellNumber + "&Code=" + criteria.code).then(success).catch(error);

/*获取学员详细信息 get*/
export const getHead = (criteria, success) =>
	axios.$get(xdapp.api.user.getHead,criteria,success);
	
/*上传头像*/

// xdapp.api.user.modifyHead;
export const modifyHead = ()=> {
    return xdapp.api.user.modifyHead;
} 
export const getHeadIDsByUserIDs = (criteria, success) => {
    axios.$post(xdapp.api.user.getHeadIDsByUserIDs, criteria, success);
}