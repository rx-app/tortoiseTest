﻿import axios from '@/public/api/axios'

/*获取今日上课学员 post*/
export const getTodayHasCourseCustomers = (criteria, success) =>
  axios.$post(xdapp.api.customer.getTodayHasCourseCustomers, criteria, success);

/*获取学员详细信息 get*/
export const getCustomer = (criteria, success) =>
  axios.$get(xdapp.api.customer.getCustomer + '?customerID=' + criteria, {}, success);

/*获取家长信息 get*/
export const getParentList = (criteria, success) =>
  axios.$get(xdapp.api.customer.getParentList + '?customerID=' + criteria, {}, success);

/*获取账户列表 get*/
export const getAccountList = (criteria, success) =>
  axios.$get(xdapp.api.customer.getAccountList + '?customerID=' + criteria, {}, success);

/*获取对账单 post*/
export const queryAccountFlowList = (criteria, success) =>
  axios.$post(xdapp.api.customer.queryAccountFlowList, criteria, success);

/*获取课表 post*/
export const getAssignList = (criteria, success) =>
  axios.$post(xdapp.api.customer.getAssignList, criteria, success);

/*获取岗位下每天是否有课 post*/
export const getScopeEveryDayTopOneAssign = (criteria, success) =>
  axios.$post(xdapp.api.customer.getScopeEveryDayTopOneAssign, criteria, success);

/*获取当前岗位所有学员 post*/
export const getCurrentJobCustomers = (criteria, success) =>
  axios.$post(xdapp.api.customer.getCurrentJobCustomers, criteria, success);

/*获取当前岗位学员回访post*/
export const getCurrentJobCustomerVisits = (criteria, success) =>
  axios.$post(xdapp.api.customer.getCurrentJobCustomerVisits, criteria, success);

/*获取当前岗位学员家长会 get*/
export const getCurrentJobCustomerMeetings = (criteria, success) =>
  axios.$post(xdapp.api.customer.getCurrentJobCustomerMeetings, criteria, success);

/*获取学员回访 get*/
export const getScore = (criteria, success) =>
  axios.$get(xdapp.api.customer.getScore + '?scoreID=' + criteria, {}, success);

/*获取当前岗位的成绩 post*/
export const GetCurrentJobCustomerScores = (criteria, success) =>
  axios.$post(xdapp.api.customer.GetCurrentJobCustomerScores, criteria, success);

/*获取学员回访 get*/
export const getVisit = (criteria, success) =>
  axios.$get(xdapp.api.customer.getVisit, criteria, success);

/*获取学员家长会 get*/
export const getMeeting = (criteria, success) =>
  axios.$get(xdapp.api.customer.getMeeting,criteria, success);

/*录入学员回访 post*/
export const postCustomerVisit = (criteria, success) =>
  axios.$post(xdapp.api.customer.postCustomerVisit, criteria, success);

/*录入家长会 post*/
export const postCustomerMeeting = (criteria, success) =>
  axios.$post(xdapp.api.customer.postCustomerMeeting, criteria, success);

/*获取学员回访对象 get*/
export const getCreateVisitModel = (criteria, success) =>
  axios.$get(xdapp.api.customer.getCreateVisitModel, criteria, success);

/*获取学员家长会对象 get*/
export const getCreateMeetingModel = (criteria, success) =>
  axios.$get(xdapp.api.customer.getCreateMeetingModel, criteria, success);

/*获取当前岗位学员课表 post*/
export const getScopeAssignList = (criteria, success) =>
  axios.$post(xdapp.api.customer.getScopeAssignList, criteria, success);

/*上传文件 post*/
export const uploadMaterial = (criteria, success) =>
  axios.$post(xdapp.api.customer.uploadMaterial, criteria, success);

/*下载文件 post*/
export const downloadMaterial = (criteria, success) =>
  axios.$post(xdapp.api.customer.downloadMaterial, criteria, success);

/*分页查询潜客 post*/
export const getPagedCustomers = (criteria, success) =>
axios.$post(xdapp.api.customer.getPagedCustomers, criteria, success);

/*获取潜客信息 post*/
export const getCustomerInfo = (criteria, success) =>
axios.$get(xdapp.api.customer.getCustomerInfo, criteria, success);

export const getStudentInfo = (criteria, success) =>
axios.$get(xdapp.api.customer.getStudentInfo, criteria, success);

/*获取潜客 post*/
export const getAllCustomers = (criteria, success) =>
axios.$post(xdapp.api.customer.getAllCustomers, criteria, success);

/*获取潜客 post*/
export const getPagedStudents = (criteria, success) =>
axios.$post(xdapp.api.customer.getPagedStudents, criteria, success);


/*获取潜客家长信息 post*/
export const getCustomerParents = (criteria, success) =>
axios.$get(xdapp.api.customer.getCustomerParents, criteria, success);

/*修改学员信息 post*/
export const updateStudent = (criteria, success) =>
axios.$post(xdapp.api.customer.updateStudent, criteria, success);

/*更新潜客家长 post*/
export const updateCustomerParent = (criteria, success) =>
axios.$post(xdapp.api.customer.updateCustomerParent, criteria, success);

/*更新潜客 post*/
export const updateCustomer = (criteria, success) =>
axios.$post(xdapp.api.customer.updateCustomer, criteria, success);

/*新增潜客家长 post*/
export const createCustomerParent = (criteria, success) =>
axios.$post(xdapp.api.customer.createCustomerParent, criteria, success);

/*下载创建潜客家长是所需要的信息 get*/
export const createCustomerParentGet = (criteria, success) =>
axios.$get(xdapp.api.customer.createCustomerParent, criteria, success);


/*下载创建学员家长所需要的信息 get*/
export const createStudentParent = (criteria, success) =>
axios.$get(xdapp.api.customer.createStudentParent, criteria, success);

/*新增学员家长 post*/
export const createStudentParentPost = (criteria, success) =>
axios.$post(xdapp.api.customer.createStudentParent, criteria, success);

/*获取学员家长信息 post*/
export const getStudentParents = (criteria, success) =>
axios.$get(xdapp.api.customer.getStudentParents, criteria, success);


/*获取指定学员的指定家长 */
export const getStudentParentPost = (criteria, success) =>
axios.$post(xdapp.api.customer.getStudentParent, criteria, success);


/*修改学员家长信息 */
export const updateStudentParent = (criteria, success) =>
axios.$post(xdapp.api.customer.updateStudentParent, criteria, success);

/*查询归属历史:坐席、咨询、学管、市场专员 post*/
export const getStaffRelations = (criteria, success) =>
axios.$post(xdapp.api.customer.getStaffRelations, criteria, success);

/*查询归属历史分页 */
export const getPagedStaffRelations = (criteria, success) =>
axios.$post(xdapp.api.customer.getPagedStaffRelations, criteria, success);

/*查询教师历史归属 */
export const getTeacherRelations = (criteria, success) =>
axios.$post(xdapp.api.customer.getTeacherRelations, criteria, success);


/*查看教师历史归属 */
export const getPagedTeacherRelations = (criteria, success) =>
axios.$post(xdapp.api.customer.getPagedTeacherRelations, criteria, success);


/*最近30天潜客随机获取 post*/
export const randomPotentialCustomer = (criteria, success) =>
axios.$post(xdapp.api.customer.randomPotentialCustomer, criteria, success);

/*获取签约学员 post*/
export const getAllStudents = (criteria, success) =>
axios.$post(xdapp.api.customer.getAllStudents, criteria, success);

/*新增潜客 get*/
export const $createCustomer = (criteria, success) =>
axios.$get(xdapp.api.customer.createCustomer, criteria, success);

/*新增潜客 post*/
export const createCustomer = (criteria, success) =>
axios.$post(xdapp.api.customer.createCustomer, criteria, success);

/*通过OA获取员工 get*/
export const getStaffByOA = (criteria, success) =>
axios.$get(xdapp.api.customer.getStaffByOA, criteria, success);

/*通过学员编号获取学员 get*/
export const getCustomerByCode = (criteria, success) =>
axios.$get(xdapp.api.customer.getCustomerByCode, criteria, success);

/*查询所有家长 post*/
export const getAllParents = (criteria, success) =>
axios.$post(xdapp.api.customer.getAllParents, criteria, success);

/*添加潜客孩子家长 post*/
export const addCustomerParent = (criteria, success) =>
axios.$post(xdapp.api.customer.addCustomerParent, criteria, success);

/*添加学员孩子家长 post*/
export const addStudentParent = (criteria, success) =>
axios.$post(xdapp.api.customer.addStudentParent, criteria, success);

/*跟进记录查询 post*/
export const getAllFollows = (criteria, success) =>
axios.$post(xdapp.api.customer.getAllFollows, criteria, success);