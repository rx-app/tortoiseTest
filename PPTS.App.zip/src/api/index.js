﻿import injectApp from '@/public/app';
import { HEADER_KEYS, CACHE_KEYS } from '@/constants';

import common from './common/common-api.config';
import ids from './ids/ids-api.config';
import user from './user/user-api.config';
import customerReply from './customer-reply/customer-reply-api.config'
import notify from './notify/notify-api.config'
import course from './course/course-api.config'
import news from './news/news-api.config'
import customer from './customer/customer-api.config'
// import metadata from './metadata/metadata-api.config'
import settings from './settings/setting-api.config'
import classBreak from './classBreak/classBreak-api.config'
import teacher from './teacher/teacher-api.config'
import organization from './organization/organization-api.config'
import metadata from './metadata/metadata-api.config'
import customerFollows from './customerFollows/customerFollows-api.config'

const API_CONFIG = {
  ...common,
  ...ids,
  ...user,
  ...customerReply,
  ...notify,
  ...course,
  ...news,
  ...customer,
  ...metadata,
  ...settings,
  ...classBreak,
  ...teacher,
  ...organization,
  ...metadata,
  ...customerFollows,
};

export default API_CONFIG;
window.$myData = {};
window.xdapp =window.xdapp || {}
window.xdapp.api = {'cacheKey':'ppts-current-job', 'headerKey':HEADER_KEYS.JOB_HEADER_KEY}
injectApp(API_CONFIG);
