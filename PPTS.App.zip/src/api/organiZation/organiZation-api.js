import axios from '@/public/api/axios'

/*获取机构信息*/
export const getOrgInfo = (criteria, success) =>
	axios.$get(xdapp.api.Organization.getOrgInfo, criteria, success);
/*获取子机构*/
export const getChildrenByType = (criteria, success) =>
	axios.$post(xdapp.api.Organization.getChildrenByType, criteria, success);