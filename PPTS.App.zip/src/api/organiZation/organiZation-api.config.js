export default {
	Organization: [{
		getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
		url: '/api/Organization/{0}',
		actions: {
			getOrgInfo: "GetOrgInfo",/*获取机构信息*/
			getChildrenByType: "GetChildrenByType",/*获取子机构*/
		}
	}]
}