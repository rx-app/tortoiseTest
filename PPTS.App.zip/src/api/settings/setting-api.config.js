export default {
  settings: {
    getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
    url: '/api/Settings/{0}',
    actions: {
      getUserFeedback: "GetUserFeedback",
      getUserFeedbackTopic: "GetUserFeedbackTopic",
      savePostFeedback: "SavePostFeedback",
      getUserTypeFeedback: "GetUserTypeFeedback",
      saveReplyFeedback: "SaveReplyFeedback",
      feedbackUpload: "FeedbackUpload",
      uploadMaterial: 'uploadMaterial'
    }
  }
}
