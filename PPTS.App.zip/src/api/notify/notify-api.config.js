export default {
  notify : {
    getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.messageApiUrl
		},
    url: '/api/notify/{0}',
    actions: {
      deletedNotifyMessage: "deletedNotifyMessage",/*清除消息 家长申请*/
      queryNotifyMessagesList: "queryNotifyMessagesList",/*查询消息 家长申请集合*/
      queryLastNotifyMessages: "queryLastNotifyMessages",/*查询最新消息 家长申请*/
    }
  }
}
