import axios from '@/public/api/axios';

/*export const delMsg = (criteria, success) =>
  axios.$post(xdapp.api.notify.deletedNotifyMessage, criteria, success);

export const delList = (criteria, success) =>
  axios.$post(xdapp.api.notify.deletedNotifyMessagesList, criteria, success);

export const getList = (criteria, success) =>
  axios.$post(xdapp.api.notify.queryNotifyMessagesList, criteria, success);

export const getMsg = (criteria, success) =>
  axios.$post(xdapp.api.notify.queryLastNotifyMessages, criteria, success);
*/ 
/*查询消息、家长申请集合*/
export const $getNotifyList = (criteria, success) =>{
  axios.$post(xdapp.api.notify.queryNotifyMessagesList, criteria, success);
}
/*查询最新消息、家长申请*/
export let $getLastNotify = (criteria, success) => {
   axios.$post(xdapp.api.notify.queryLastNotifyMessages, criteria, success);
};
/*清除消息、家长申请*/
export let $deletedNotifyMessage = (criteria, success) => {
   axios.$post(xdapp.api.notify.deletedNotifyMessage, criteria, success);
};



