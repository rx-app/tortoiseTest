export default {
	PeriodOfRelaxing: [{
		getBaseUrl: () => {
			if (!xdapp.config || !xdapp.config.webApiConfig) {
				m2.loadApiError();
				return ''
			}
			return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
		},
		url: '/api/PeriodOfRelaxing/{0}',
		actions: {
			send: "Send",/*用户分享课间小憩*/
			load: "Load",/*加载课间小憩*/
			loadParentPeriodOfRelaxing: "LoadParentPeriodOfRelaxing",/*加载家长分享*/
			approve: "Approve",/*审核*/
			loadRandom: "LoadRandom",/*随机获取课间小憩*/
			loadByID: "LoadByID",/*通过ID获取课间小憩*/
		}
	}]
}