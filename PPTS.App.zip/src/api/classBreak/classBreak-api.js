﻿import axios from '@/public/api/axios'

/*用户分享课间小憩*/
export const send = (criteria, success) =>
	axios.$post(xdapp.api.PeriodOfRelaxing.send, criteria, success);
/*加载课间小憩*/
export const load = (criteria, success) =>
	axios.$post(xdapp.api.PeriodOfRelaxing.load, criteria, success);
/*加载家长分享*/
export const loadParentPeriodOfRelaxing = (criteria, success) =>
	axios.$post(xdapp.api.PeriodOfRelaxing.loadParentPeriodOfRelaxing, criteria, success);
/*审核*/
export const approve = (criteria, success) =>
	axios.$post(xdapp.api.PeriodOfRelaxing.approve, criteria, success);
/*随机获取课间小憩*/
export const loadRandom = (criteria, success) =>
	axios.$get(xdapp.api.PeriodOfRelaxing.loadRandom, criteria, success);
/*通过ID获取课间小憩*/
export const loadByID = (criteria, success) =>
	axios.$get(xdapp.api.PeriodOfRelaxing.loadByID+'?ID='+criteria,{},success);
	