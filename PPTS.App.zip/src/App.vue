﻿<template>
  <div>
    <Header></Header>
    <keep-alive>
      <router-view class="container" v-if="this.$route.meta.keepAlive"></router-view>
    </keep-alive>
    <router-view class="container" v-if="!this.$route.meta.keepAlive"></router-view>
    <Footer></Footer>
  </div>
</template>
<script>
  import Header from './components/header';
  import Footer from './components/footer';

  import 'lib-flexible';
  import './public/lib/m2';
  import './api';
  import './public/util';
  import './public/filter';
  import './public/directive';
  export default {
    components: {
      Header,
      Footer
    },
    mounted () {
      mui.disableHoriztontal();
    }
  }
</script>
<style>
  @import './public/asset/css/mui/mui.plus.css';
  @import './public/asset/css/common.css';
</style>
