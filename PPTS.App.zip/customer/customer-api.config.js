export default {
  customer: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.pptsAppBaseUrl
    },
    url: '/api/Customer/{0}',
    actions: {
      getTodayHasCourseCustomers: "GetTodayHasCourseCustomers", /*获取今日上课学员 post*/
      getCustomer: "GetCustomer",/*获取学员详细信息 get*/
      getParentList: "GetParentList", /*获取家长信息 get*/
      getAccountList: "GetAccountList",/*获取账户列表 get*/
      queryAccountFlowList: "QueryAccountFlowList",/*获取账户列表 get*/
      getAssignList: "GetAssignList", /*获取课表 post*/
      getCurrentJobCustomerVisits: 'GetCurrentJobCustomerVisits', /*获取当前岗位学员回访*/
      getCurrentJobCustomers:"GetCurrentJobCustomers",/*获取当前岗位所有学员 post*/
      getVisit: 'GetVisit',
      postCustomerVisit: 'PostCustomerVisit',
      postCustomerMeeting:'PostCustomerMeeting',
      getScore:'GetScore',
      getMeeting:'GetMeeting',
      GetCurrentJobCustomerScores:'GetCurrentJobCustomerScores',
      getCreateVisitModel: 'GetCreateVisitModel',
      getCreateMeetingModel:'GetCreateMeetingModel',
      getCurrentJobCustomerMeetings:'GetCurrentJobCustomerMeetings',
      uploadMaterial:'UploadMaterial',/*上传文件*/
      downloadMaterial:'DownloadMaterial',/*下载文件*/
      getScopeAssignList:'GetScopeAssignList',/*学管师/主任  获取岗位下所有学员课表*/
      getScopeEveryDayTopOneAssign:'GetScopeEveryDayTopOneAssign',/*获取岗位下每天是否有课*/
      getPagedCustomers:'getPagedCustomers',/*分页查询潜客*/
      getCustomerInfo:'getCustomerInfo',/*分页查询潜客*/
      getAllCustomers:'getAllCustomers',/*获取潜客*/
      getCustomerParents:'getCustomerParents',/*获取潜客家长信息*/
      updateStudent:'updateStudent',/*修改学员信息*/
      createStudentParent:'createStudentParent',/*下载创建学员家长所需要的信息*/
      updateCustomer:'updateCustomer',/*更新潜客*/
      updateCustomerParent:'updateCustomerParent',/*更新潜客家长*/
      // createStudentParent:'createStudentParent',/*新增学员家长*/
      getStudentParents:'getStudentParents',/*获取学员家长信息*/
      getStudentParent:'getStudentParent',/*获取指定学员的指定家长*/
      updateStudentParent:'updateStudentParent',/*修改学员家长信息*/
      getStaffRelations:'getStaffRelations',/*查询归属历史:坐席、咨询、学管、市场专员*/
      getPagedStaffRelations:'getPagedStaffRelations',/*查询归属历史分页*/
      getTeacherRelations:'getTeacherRelations',/*查询教师历史归属*/
      getPagedTeacherRelations:'getPagedTeacherRelations',/*查看教师历史归属*/

      
    }
  }
}
