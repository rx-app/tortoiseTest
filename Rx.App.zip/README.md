# rx-app

> Ruixue App project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```/*var ua = navigator.userAgent.toLowerCase();
								if(/iphone|ipad|ipod/.test(ua)) {
									window.onscroll = function() {
										var header = document.getElementsByTagName('header')[0];
										header.setAttribute('style', 'position:absolute;top:' + window.pageYOffset + 'px;left:0');
										console.log(window.pageYOffset)
									}
								}*/

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
