module.exports = {
    NODE_ENV: '"production"',
    APP_API_ROOT: '"//rxwebapi-fw.ppts.xueda.com/RxApp/Rx.Api"',
    SHOW_ACCOUNT: true,
    SHOW_UACAppOrder: true,
    VERSION: {
        android: {
            latest: '"1.1.3"',
            min: '"1.0.3"'
        },
        ios: {
            latest: '"1.1.3"',
            min: '"1.0.3"'
        },
    },
}