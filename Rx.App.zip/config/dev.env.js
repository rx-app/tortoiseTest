var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  IMPERSONATE_USER: {
    LOGIN_ACCOUNT: '"13550149352"',
    LOGIN_PASSWORD: '"password"'
  }, //是否为模拟账户登录
  // APP_API_ROOT: '"http://10.1.55.88/RxApp/Rx.Api/"',//本地
  APP_API_ROOT: '"http://rxwebapi-uat.ppts.xueda.com/RxApp/Rx.Api"',//uat
  SHOW_ACCOUNT: true,
  SHOW_UACAppOrder: true,
  VERSION: {
    android: {
      latest: '"1.1.3"',
      min: '"1.0.3"'
    },
    ios: {
      latest: '"1.1.3"',
      min: '"1.0.3"'
    },
  },
})
