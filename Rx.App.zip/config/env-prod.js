module.exports = {
    NODE_ENV: '"production"',
    APP_API_ROOT: '"https://rxwebapi.ppts.xueda.com/RxApp/Rx.Api/"',
    SHOW_ACCOUNT: false,
    SHOW_UACAppOrder: false,
    VERSION: {
        android: {
            latest: '"1.1.3"',
            min: '"1.0.3"'
        },
        ios: {
            latest: '"1.1.3"',
            min: '"1.0.3"'
        },
    },
}