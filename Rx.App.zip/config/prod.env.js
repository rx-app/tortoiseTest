﻿module.exports = {
  NODE_ENV: '"production"',
  APP_API_ROOT: '"https://rxwebapi.ppts.xueda.com/RxApp/Rx.Api/"'
}