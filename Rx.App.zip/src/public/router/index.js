﻿export default (url, config = {}) => {
    let showFooter = false;
    let disableBack = false;
    let hideChildren = false;
    let showQRScan = false;/* 是否在左侧显示二维码扫描图标(默认不显示)*/
    let showHeader = true; /*显示页头（默认不显示，在此只为兼容title为空的情况）*/
    let showChildName = false;/*是否在右侧显示孩子名称（如，学生：张三，默认不显示）*/
    let keepAlive = false;
    let supIOSVersionNum = "1.0.0";//导航所支持的苹果版本号
    let supAndroidVersionNum = "1.0.0";//导航所支持的苹果版本号
    let actionText = '';/* 是否在右侧显示操作按钮(默认不显示)*/

    let group = undefined;
    if (config.showFooter != undefined) {
        showFooter = config.showFooter;
    }

    if (config.disableBack != undefined) {
        disableBack = config.disableBack;
    }

    if (config.hideChildren != undefined) {
        hideChildren = config.hideChildren;
    }

    if (config.showQRScan != undefined) {
        showQRScan = config.showQRScan;
    }

    if (config.showHeader != undefined) {
        showHeader = config.showHeader;
    }

    if (config.showChildName != undefined) {
        showChildName = config.showChildName;
    }

    if (config.keepAlive != undefined) {
        keepAlive = config.keepAlive;
    }

    if (config.supIOSVersionNum != undefined) {
        supIOSVersionNum = config.supIOSVersionNum;
    }
    if (config.supAndroidVersionNum != undefined) {
        supAndroidVersionNum = config.supAndroidVersionNum;
    }

    if (config.group != undefined) {
        group = config.group;
    }

    if (config.actionText != undefined) {
        actionText = config.actionText;
    }

    let routeConfig = {
        path: url,
        name: config.name || url,
        meta: {
            title: config.title,
            showFooter,
            disableBack,
            hideChildren,
            showQRScan,
            showHeader,
            showChildName,
            keepAlive,
            group,
            supIOSVersionNum,
            supAndroidVersionNum,
            actionText
        }
    };

    if (config.redirect != undefined) {
        routeConfig = { ...routeConfig, redirect: config.redirect };
    }

    if (config.right != undefined) {
        routeConfig = { ...routeConfig, right: config.right };
    }

    return routeConfig;
}