﻿import Vue from 'vue';

import { DATE_FORMAT } from '@/public/constant';

const getDateConfig = (config = {}) => {
    let cfg = { isShort: true, locale: 'en-US', ...config };
    return {
        isShort: cfg.isShort,
        format: DATE_FORMAT[cfg.locale]
    }
};

Vue.filter('dateTimeFormat', (value, config) => {
    if (!value) return;
    let cfg = getDateConfig(config);
    return value.format(cfg.isShort ? cfg.format.dateTimeShort : cfg.format.dateTime);
});

Vue.filter('dateFormat', (value, config) => {
    if (!value) return;
    let cfg = getDateConfig(config);
    return value.format(cfg.format.dateShort);
});

Vue.filter('timeFormat', (value, config) => {
    if (!value) return;
    let cfg = getDateConfig(config);
    return value.format(cfg.format.timeShort);
});

Vue.filter('feedbackType', (type) => {
    return ['功能异常', '意见建议', '其它问题'][type];
});

Vue.filter('msgType', (type) => {
    return ['微信', '支付宝','全民付','银联云闪付'][type - 1];
});

Vue.filter('businessTypeSup', (type) => {
    return ['一对一', '班组', '一对多', '非课收'][type - 1];
});

Vue.filter('businessTypeCat', (type) => {
    return ['一对一 集', '班组 集', '一对多 集', '非课收 集'][type - 1];
});

Vue.filter('dateRange', (startTime, endTime, config) => {
    if (!startTime) return;
    let cfg = getDateConfig(config);
    const start = startTime.format(cfg.isShort ? cfg.format.dateShort : cfg.format.dateTime);
    const end = endTime.format(cfg.isShort ? cfg.format.dateShort : cfg.format.dateTime);

    return start + ' ' + cfg.format.separator + ' ' + end;
});

Vue.filter('timeRange', (startTime, endTime, config) => {
    if (!startTime) return;
    let cfg = getDateConfig(config);
    const start = startTime.format(cfg.isShort ? cfg.format.timeShort : cfg.format.dateTime);
    const end = endTime.format(cfg.isShort ? cfg.format.timeShort : cfg.format.dateTime);

    return start + ' ' + cfg.format.separator + ' ' + end;
});

Vue.filter('dateTimeRange', (startTime, endTime, config) => {
    if (!startTime) return;
    let cfg = getDateConfig(config);
    const start = startTime.format(cfg.isShort ? cfg.format.dateTimeShort : cfg.format.dateTime);
    const end = endTime.format(cfg.isShort ? cfg.format.dateTimeShort : cfg.format.dateTime);

    return start + ' ' + cfg.format.separator + ' ' + end;
});

Vue.filter('substr', (str, length = 5) => {
    if (!str || !m2.type.isString(str)) return str;
    if (str.length <= length) return str;
    return str.substring(0, length - 1) + '...';
});

Vue.filter('normalize', (value) => {
    if (!value) return

    let result = ''

    const now = new Date().getTime()
    const oldTime = new Date(value).getTime()
    const difference = now - oldTime
    const minute = 1000 * 60
    const hour = minute * 60
    const day = hour * 24
    const month = day * 30
    const year = month * 12
    const _year = difference / year
    const _month = difference / month
    const _week = difference / (7 * day)
    const _day = difference / day
    const _hour = difference / hour
    const _minute = difference / minute

    if (_year >= 1) {
        result = ~~(_year) + '年前'
    } else if (_month >= 1) {
        result = ~~(_month) + '个月前'
    } else if (_week >= 1) {
        result = ~~(_week) + '周前'
    } else if (_day >= 1) {
        result = ~~(_day) + '天前'
    } else if (_hour >= 1) {
        result = ~~(_hour) + '小时前'
    } else if (_minute >= 1) {
        result = ~~(_minute) + '分钟前'
    } else {
        result = '刚刚'
    }

    return result
});

Vue.filter('cast', value => {
    if (new Date(value) && new Date(value).getFullYear() < 1900)
        return;
    return value;
});

Vue.filter('numberToMoney', money => {
    var fmtAmt = "";
    if (money && money != null) {
        money = money.replace(/,/g, "").replace(/,/g, "");
        if (money.indexOf(".") == -1) {
            money = money + ".00";
        }

        var index = money.indexOf(".");
        var floatValue = money.substring(index + 1);

        var count = 0;
        for (var i = (index); i >= 0; i--) {
            fmtAmt = money[i] + fmtAmt;
            if (count == 3 && i != 0) {
                fmtAmt = "," + fmtAmt;
                count = 0;
            }
            count++;
        }
    }
    fmtAmt += floatValue;
    return fmtAmt;
})
//xdapp.util.api.getFullConfig((filterName, categoryID) => {
//    Vue.filter(filterName, (value) => {
//        if (!value || !xdapp.dict) return;
//        return m2.util.getValue(xdapp.dict[categoryID], value);
//    });
//});
