import axios from 'axios';
import { AXIOS_TEXT } from '@/public/constant';

axios.defaults.baseURL = process.env.APP_API_ROOT;

// 请求之前
axios.interceptors.request.use(function(config) {
	!config.url.includes('GetVersionConfig') && mui.showLoading(AXIOS_TEXT.LOADING, 'div');
	return xdapp.util.ajax.getRequestConfig(config);
}, function(error) {
	return Promise.reject(error);
});

// 请求回来数据之后
axios.interceptors.response.use(function(response) {
	xdapp.util.ajax.parseResponseData(response);
	!response.config.url.includes('GetVersionConfig') && mui.hideLoading();
	return response.data;
}, function(error) {	
	mui.hideLoading();
	
	// if(error.request.responseURL.includes('User/GetHead?iconID')){
	// 	return Promise.reject(error)
	// }
	if(error.response.status == 401) {
		if(error.response.data) {
			$vue.$router.push({
				name: "home-limit"
			});
		} else {
			window.illegalUser = true;
			if(!window.userInfoErrorAlert){
				window.userInfoErrorAlert=true;
			    mui.alert('用户身份信息有误，请重新登录(同一时间只能在一台手机上登录，或距您上次登录时间过长。)')
			}
			$vue.$router.push({
				name: "login"
			});
			mui.hideLoading();
		}
		

	} else {
		const response = error.response.data;
		const errorMessage = response.description; // xdapp.config.isDebugMode ? response.stackTrace : response.description;

		mui.hideLoading(() => mui.alert(errorMessage, AXIOS_TEXT.ERROR_MESSAGE_TITLE,'','','div'));
	}
	return Promise.reject(error);
});

const handleCallback = (promise, callbacks) => {
	let handler = {};
	if(m2.type.isFunction(callbacks)) {
		handler.success = callbacks;
	}
	if(m2.type.isObject(callbacks)) {
		handler = callbacks;
	}
	promise.then((res) => {
		if(!res || res.errCode == undefined || (res.errCode != undefined && !res.errCode)) {
			m2.type.isFunction(handler.success) && handler.success(res);
		} else {
			m2.type.isFunction(handler.failure) && handler.failure(res);
		}
	}, (error) => {
		m2.type.isFunction(handler.error) && handler.error(error);
	});
};
window.ajaxList = []
axios.$post = async(url, criteria, callbacks) => {
	const promise = axios.post(url, criteria, {
		cancelToken: new axios.CancelToken(function executor(c) {
			window.ajaxList.push(c);
		})
	});
	handleCallback(promise, callbacks);
};

axios.$get = async(url, criteria, callbacks) => {
	const promise = axios.get(url, {
		params: criteria,
		cancelToken: new axios.CancelToken(function executor(c) {
			window.ajaxList.push(c);
		})
	});
	handleCallback(promise, callbacks);
};
export default axios;
