import Vue from 'vue';
import { CACHE_KEYS } from '@/constants';
Vue.directive('focus', {
	inserted: function(el) {
		el.focus();
	}
});
Vue.directive("power", {
	inserted: function(el, binding) {
		let currentFunctions = m2.cache.get(CACHE_KEYS.CURRENT_JOB)?m2.cache.get(CACHE_KEYS.CURRENT_JOB).functions:[];
		let isShow = currentFunctions.some(currentFunction => currentFunction == binding.value);
		if(!isShow) {
			el.style.display = "none";
		}
	}
})

Vue.directive("role", {
	inserted: function(el, binding) {
      let role = $vue.$store.state.currentChild.relation;
		if(role!=1) {
			el.style.display = "none";
		}
	}
})
