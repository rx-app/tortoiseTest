﻿//import axios from 'axios'
import { CACHE_KEYS, HEADER_KEYS } from '@/constants';


export default function(apiConfig) {
    
    let preData ={};
    let restData = {};
    let getProp = (url, length, defaultValue) => {
        if (length > 1) {
            const matches = url.match(/\/api\/(.*)\//);
            if (matches.length > 1) {
                let match = matches[1];
                return match.charAt(0).toLowerCase() + match.substring(1);
            }
        }

        return defaultValue;
    };
    
    function _devide(){
        let preLength=0;
        for (let prop in apiConfig) {
            let config = apiConfig[prop];
            let items = [];
            if (m2.type.isArray(config)) {
                items = config;
            }
            if (m2.type.isObject(config)) {
                items = [...items, config];
            }
            let length = items.length;
            items.forEach((item) => {
                let propValue = getProp(item.url, length, prop);
                if (item.preLoad) {
                    preData[propValue]=item;
                    preLength += Object.keys(preData[propValue].actions).length;
                } else {
                    restData[propValue] = item;
                }
            });
        }
        window.preDataLength=preLength;
    }
    
    function genarator(data){
        let res={}
        for(var i in data){
            res[i]=_translate( data[i] )
        }
        return res;
    }
    function _translate(ctr){
        let res ={}
        let prop=getProp(ctr)
        for(const i in ctr.actions){
            let baseUrl= ctr.getBaseUrl()
            if(!baseUrl){
                baseUrl = ''
            }
            res[i] =baseUrl+ctr.url.replace('{0}','')+ctr.actions[i]
        }
        return res;
    }

    function init(){
        _devide();
        
        window.xdapp.api ={...window.xdapp.api, ...genarator(preData)}
        
        window.restData=restData

        window.$myData.getRest=(()=>{
    
            let rest = genarator(window.restData)
            window.xdapp.api={...window.xdapp.api,...rest}
            delete window.apiData
            delete window.restData
            window.$myData.completeBaseUrlLoad=true;
        })

    }
    return init()

}
