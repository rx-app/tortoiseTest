export default {
    async install(Vue, options) {
        await xdapp.util.api.getApplicationInsightsConfig();
        if (xdapp.aiConfig.isEnabled) {
            var ai = new Vue()
            Vue.prototype.$ai = ai;

            var sdkInstance = "appInsightsSDK";
            window[sdkInstance] = "appInsights";
            var aiName = window[sdkInstance];
            ai.aisdk = window[aiName] || function (e) { function n(e) {t[e] = function () { var n = arguments; t.queue.push(function () { t[e].apply(t, n) }) } } var t = { config: e }; t.initialize = !0; var i = document, a = window; try { t.cookie = i.cookie } catch (e) { } t.queue = [], t.version = 2; for (var r = ["Event", "PageView", "Exception", "Trace", "DependencyData", "Metric", "PageViewPerformance"]; r.length;) n("track" + r.pop()); n("startTrackPage"), n("stopTrackPage"); var s = "Track" + r[0]; if (n("start" + s), n("stop" + s), n("setAuthenticatedUserContext"), n("clearAuthenticatedUserContext"), n("flush"), !(!0 === e.disableExceptionTracking || e.extensionConfig && e.extensionConfig.ApplicationInsightsAnalytics && !0 === e.extensionConfig.ApplicationInsightsAnalytics.disableExceptionTracking)) { n("_" + (r = "onerror")); var o = a[r]; a[r] = function (e, n, i, a, s) { var c = o && o(e, n, i, a, s); return !0 !== c && t["_" + r]({ message: e, url: n, lineNumber: i, columnNumber: a, error: s }), c }, e.autoExceptionInstrumented = !0 } return t }(
                {
                    instrumentationKey: xdapp.aiConfig.aiInstrumentationKey,
                    endpointUrl: xdapp.aiConfig.aiInstrumentationUrl,
                    enableAutoRouteTracking: xdapp.aiConfig.isEnabled
                }
            ); 
            window[aiName] = ai.aisdk, ai.aisdk.queue && 0 === ai.aisdk.queue.length && ai.aisdk.trackPageView({});
            
            ai.aisdk.queue.push(function () {
                ai.aisdk.addTelemetryInitializer(function (envelope) {
                    envelope.tags["ai.cloud.role"] = process.env.NODE_ENV;
                    console.log(process.env.NODE_ENV)
                });
            });

        }

    }
}

