import { CACHE_KEYS } from '@/constants';
import { HEADER_KEYS } from '@/public/constant';

const saveToken = (response) => {
  if (response.headers[HEADER_KEYS.X_SESSION_TOKEN]) {
    var token = response.headers[HEADER_KEYS.X_SESSION_TOKEN];
    m2.cache.set(CACHE_KEYS.SESSION_TOKEN, token);
  }
};

const handleDate = (response) => {
  if (typeof response.data == 'string') {
    var JSON_PROTECTION_PREFIX = /^\)\]\}',?\n/;
    var APPLICATION_JSON = 'application/json';
    var JSON_START = /^\[|^\{(?!\{)/;
    var JSON_ENDS = {
      '[': /]$/,
      '{': /}$/
    };

    var tempData = response.data.replace(JSON_PROTECTION_PREFIX, '').trim();
    if (tempData) {
      var contentType = response.headers['content-type'];
      var jsonStart = tempData.match(JSON_START);
      if ((contentType && (contentType.indexOf(APPLICATION_JSON) === 0)) || jsonStart && JSON_ENDS[jsonStart[0]].test(tempData)) {
        response.data = (new Function("", "return " + tempData))();
      }
    }
  }
};

const handleDictionary = (response) => {
  if (response.data && response.data.dictionaries) {
    xdapp.dict = xdapp.dict || {};
    // 过滤掉失效的字典值
    var result = {};
    var dict = response.data.dictionaries;
    for (var p in dict) {
      let prop = p.toLowerCase();
      result[prop] = result[prop] || [];
      for (var index in dict[p]) {
        var item = dict[p][index];
        // 兼容自定义字典
        if (item.isValidate == undefined || item.isValidate) {
          result[prop].push(item);
        }
      }
    }
    xdapp.dict = { ...xdapp.dict, ...result };
  }
};

export default {
  getRequestHeaders: (token, props) => {
    return {
      'Content-Type': HEADER_KEYS.CONTENT_JSON_TYPE,
      [HEADER_KEYS.X_SESSION_TOKEN]: token,
      ...props
    }
  },
  getRequestConfig: (config) => {
    var token = m2.cache.get(CACHE_KEYS.SESSION_TOKEN);
    if (xdapp.api.cacheKey && xdapp.api.headerKey) {
      var current = m2.cache.get(xdapp.api.cacheKey) ? m2.cache.get(xdapp.api.cacheKey).id : undefined;
      config.headers = xdapp.util.ajax.getRequestHeaders(token, {
        [xdapp.api.headerKey]: current
      });
    } else {
      config.headers = xdapp.util.ajax.getRequestHeaders(token);
    }

    return config;
  },
  parseResponseData: (response) => {
    saveToken(response);
    handleDate(response);
    handleDictionary(response);
  }
};
