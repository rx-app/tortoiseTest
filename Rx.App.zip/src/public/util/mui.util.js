﻿(function ($, window, document) {
    //显示加载框
    $.showLoading = function (message, type) {
        if ($.loading === false) return;

        if ($.os.plus && type !== 'div') {
            $.plusReady(function () {
                plus.nativeUI.showWaiting(message);
            });
        } else {
            var html = '';
            html += '<i class="mui-spinner mui-spinner-white"></i>';
            html += '<p class="text">' + (message || "数据加载中") + '</p>';

            //遮罩层
            var mask = document.getElementsByClassName("mui-show-loading-mask");
            if (mask.length == 0) {
                mask = document.createElement('div');
                mask.classList.add("mui-show-loading-mask");
                document.body.appendChild(mask);
                mask.addEventListener("touchmove", function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                });
            } else {
                mask[0].classList.remove("mui-show-loading-mask-hidden");
            }
            //加载框
            var toast = document.getElementsByClassName("mui-show-loading");
            if (toast.length == 0) {
                toast = document.createElement('div');
                toast.classList.add("mui-show-loading");
                toast.classList.add('loading-visible');
                document.body.appendChild(toast);
                toast.innerHTML = html;
                toast.addEventListener("touchmove", function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                });
            } else {
                toast[0].innerHTML = html;
                toast[0].classList.add("loading-visible");
            }
        }
    };

    //隐藏加载框
    $.hideLoading = function (callback) {
        if ($.os.plus) {
            $.plusReady(function () {
                plus.nativeUI.closeWaiting();
            });
        }
        var mask = document.getElementsByClassName("mui-show-loading-mask");
        var toast = document.getElementsByClassName("mui-show-loading");
        if (mask.length > 0) {
            mask[0].classList.add("mui-show-loading-mask-hidden");
        }
        if (toast.length > 0) {
            toast[0].classList.remove("loading-visible");
            callback && callback();
        }
    };

    // 初始化下拉刷新
    $.initPullRefresh = function (muiParams) {
        mui.init({
            pullRefresh: {
                container: muiParams.container,
                down: {
                    callback: muiParams.pulldownRefresh
                },
                up: {
                    height: 50,//可选.默认50.触发上拉加载拖动距离
                    // auto:true,//可选,默认false.自动上拉加载一次
                    contentnomore: '没有更多数据了',//可选，请求完毕若没有更多数据时显示的提醒内容；
                    contentrefresh: muiParams.contentrefresh || "正在加载...",//可选，正在加载状态时，上拉加载控件上显示的标题内容
                    callback: muiParams.pullupRefresh
                }
            }
        });
    };

    // 禁止横屏
    $.disableHoriztontal = function () {
        mui.plusReady(function () {
            plus.screen.lockOrientation("portrait-primary");
        });
    };
})(mui, window, document);
