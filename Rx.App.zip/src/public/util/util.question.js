import { CACHE_KEYS } from "@/constants";
export function storageQuestionFun(editType) {
    var cellNumber = m2.cache.get(CACHE_KEYS.CURRENT_USER) && m2.cache.get(CACHE_KEYS.CURRENT_USER).cellNumber;
    var questionMess = m2.cache.get(CACHE_KEYS.QUESTIONMESS);
    if (questionMess && questionMess.length) {
        questionMess.forEach((item, index) => {
            if (item.user == cellNumber) {
                questionMess.splice(index, 1);
                if (editType == 'isFirstQuestion') {
                    item.isFirstQuestion = false;
                } else if (editType == 'isComplete') {
                    item.isComplete = true;
                }
                questionMess.push(item);
                m2.cache.set(CACHE_KEYS.QUESTIONMESS, questionMess);
            }
        });
    }
};
export function currentLoginUser() {
    var questionMess = m2.cache.get(CACHE_KEYS.QUESTIONMESS),
        cellNumber = m2.cache.get(CACHE_KEYS.CURRENT_USER) && m2.cache.get(CACHE_KEYS.CURRENT_USER).cellNumber,
        curLoginMessObj = {
            isFirstQuestion: true, //是否是第一次加载
            isComplete: false, //是否填写完成调查问卷
            user: cellNumber
        };
    if (questionMess && questionMess.length) {
        var arr = [];
        questionMess.forEach(item => {
            arr.push(item.user);
        });
        if (arr.indexOf(cellNumber) == -1) {
            questionMess.push(curLoginMessObj);
            m2.cache.set(CACHE_KEYS.QUESTIONMESS, questionMess);
        }
    } else {
        m2.cache.set(CACHE_KEYS.QUESTIONMESS, [curLoginMessObj]);
    }
};



