﻿import ajaxUtil from './ajax.util';
import apiUtil from './api.util';
import vueUtil from './vue.util';
import aiUtil from './ai.seting';
import './mui.util';

xdapp.util = {};
xdapp.util.ajax = ajaxUtil || {};
xdapp.util.api = apiUtil || {};
xdapp.util.vue = vueUtil || {};
xdapp.util.aiUtil = aiUtil || {};

export default xdapp.util;