export default () => { /*之前切换的路由在断网之后  还是能切换成功的 */
    mui.plusReady(function () {
        if (plus.networkinfo.getCurrentType() == plus.networkinfo.CONNECTION_NONE) {
            document.querySelector('.network-box').style.display = 'block'
        } else {
            var i = new Image();
            i.src = 'https://ss0.bdstatic.com/5aV1bjqh_Q23odCf/static/superman/img/logo_top_ca79a146.png?t=' + Date.parse(new Date());
            i.onload = function () {
                document.querySelector('.network-box').style.display = 'none';
            };
            i.onerror = function () {
                document.querySelector('.network-box').style.display = 'block';
            };
        }
    });
};