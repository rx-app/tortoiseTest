/*
 * @Descripttion: 
 * @version: app-1.1.3
 * @Author: 郭甜丹
 * @Date: 2019-11-08 17:55:29
 * @LastEditors  : 郭甜丹
 * @LastEditTime : 2020-01-08 09:50:27
 */
import { HubConnectionBuilder, LogLevel } from '@aspnet/signalr'
import { CACHE_KEYS } from '@/constants';

export default {
    install(Vue, options) {
        const staffHub = new Vue()
        Vue.prototype.$staffHub = staffHub

        //let connected = false
        staffHub.connected = false
        staffHub.connecting = false

        staffHub.ensureConnection = function () {

            var token = m2.cache.get(CACHE_KEYS.SESSION_TOKEN);
            if (xdapp.config.webApiConfig.webAPIs.rxSignalrUrl && token && !staffHub.connected) {

                //connected = true
                staffHub.connected = true

                const connection = new HubConnectionBuilder()
                    .withUrl(xdapp.config.webApiConfig.webAPIs.rxSignalrUrl, { accessTokenFactory: () => token })
                    .configureLogging(LogLevel.Information)
                    .build()

                console.log("*********connection***********");
                console.log(connection);

                connection.on('MessageReceived', msg => {

                    if (msg) {

                        msg.forEach(m => {
                            m.data = m.bodyData ? JSON.parse(m.bodyData) : undefined;
                            console.log(m.topicName);
                            staffHub.$emit(m.topicName, m)
                        });
                    }
                })

                let startedPromise = null,Timeout = 5000;
                
                function start() {
                    if (staffHub.connecting) return;
                    staffHub.connecting = true
                    startedPromise = connection.start().then(_ => {
                        staffHub.connecting = false
                        staffHub.$emit('signalr-connected', true)
                    }).catch(err => {
                        staffHub.connecting = false
                        console.error('Failed to connect with hub', err)
                        staffHub.connected = false
                        Timeout += 1000;
                        return new Promise((resolve, reject) =>
                            setTimeout(() => start().then(resolve).catch(reject), Timeout))
                    })
                    return startedPromise
                }
                connection.onclose(() => {

                    staffHub.connected = false
                    staffHub.$emit('signalr-closed', false)
                    console.log("*********onclose***********");
                    console.log(staffHub.connected);

                    //start()
                    Timeout += 1000;
                    new Promise((resolve, reject) =>
                        setTimeout(() => start().then(resolve).catch(reject), Timeout))
                })

                start()
            }
        }
    }
}