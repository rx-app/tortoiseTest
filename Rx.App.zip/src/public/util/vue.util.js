﻿import store from '@/store';
import * as types from '@/store/mutation-types';
import { CACHE_KEYS } from '@/constants';

export default {
    commitActionStatus: (status) => {
        store.commit(types.ENABLE_STATUS, status);
    },
    on: (actionType, callback) => {
        const cacheKey = CACHE_KEYS.ACTION_TYPE;
        m2.cache.set(cacheKey, actionType);

        const cacheAction = m2.cache.get(cacheKey);
        $vue.$off(cacheAction).$on(cacheAction, callback);
    },
    emit: () => {
        const cacheKey = CACHE_KEYS.ACTION_TYPE;
        const cacheAction = m2.cache.get(cacheKey);
        if (cacheAction) {
            $vue.$emit(cacheAction, m2.cache.get(CACHE_KEYS.PAYLOAD));
        }
    }
};