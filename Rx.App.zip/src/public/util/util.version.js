export default (toRouter)=> {
    mui.plusReady(() => {
        var HUAWEIDownLoadUrl = 'https://appgallery.cloud.huawei.com/uowap/index.html#/detailApp/C100464383?source=appshare&subsource=C100464383&shareTo=weixin&locale=zh_CN';
        //检测到跳转的路由兼容的最低版本
        var userVersion = plus.runtime.version || "1.0.0";
        var userVendor = plus.device.vendor;

        if (mui.os.ios) {
            var routerSupVersion = toRouter.meta.supIOSVersionNum;
        } else {
            var routerSupVersion = toRouter.meta.supAndroidVersionNum;
        }
        if (userVersion < routerSupVersion) {
            mui.confirm("该导航功能需升级应用!", "提示", e => {
                if (e.index) {
                    if (mui.os.ios) {
                        let obj = xdapp.config.appInfos.find(e => { return e.sysType == 'IOS' })
                        if (obj) {
                            let url = obj.downloadUrl;//"https://itunes.apple.com/cn/app/id1431618339?mt=8";
                            plus.runtime.openURL(url);
                            plus.runtime.restart();
                        }
                    } else {
                        if(userVendor == 'HUAWEI'){
                            plus.runtime.openURL(HUAWEIDownLoadUrl);
                            plus.runtime.restart();
                            return;
                        }
                        let obj = xdapp.config.appInfos.find(e => { return e.sysType != 'IOS' })
                        if (obj) {
                            let url = obj.downloadUrl;//"http://openbox.mobilem.360.cn/index/d/sid/4007159";
                            plus.runtime.openURL(url);
                            plus.runtime.restart();
                        }
                    }
                } else {
                    if (toRouter.name == "login" || toRouter.name == "profile") {
                        return;
                    }
                    $vue.$router.push({
                        name: "profile"
                    })
                }
            }, "div");
        }
    })
}