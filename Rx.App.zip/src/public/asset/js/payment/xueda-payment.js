document.addEventListener("plusready", function () {
    var XUEDA_PAYMENT = 'XuedaPayment',
        B = window.plus.bridge;
    var xuedaPayment =
    {
        PAY_RESULT_OK: '0000',
        PAY_RESULT_COMM: "9999",
        PAY_RESULT_USER_CANCEL: "1000",
        PAY_RESULT_PARARM: "1001",
        PAY_RESULT_SENT_FAILED: "1002",
        PAY_RESULT_CLIENT_UNINSTALL: "1003",
        PAY_RESULT_RDER_PROCESS: "2001",
        PAY_RESULT_ORDER_DUPLICATE: "2002",
        PAY_RESULT_PAY_FAIL: "2003",
        PAY_RESULT_AUTH_DENIED: "005",
        PAY_RESULT_UNSUPPORT: "006",
        PAY_RESULT_BAN: "007",

        pay: function (payChannel, payData, successCallback, errorCallback) {
            var success = typeof successCallback !== 'function' ? null : function (args) {
                successCallback(JSON.parse(args));
            },
                fail = typeof errorCallback !== 'function' ? null : function (code) {
                    errorCallback(code);
                };
            callbackID = B.callbackId(success, fail);

            return B.exec(XUEDA_PAYMENT, "pay", [callbackID, payChannel, payData]);
        }
    };
    window.plus.XuedaPayment = xuedaPayment;
}, true);