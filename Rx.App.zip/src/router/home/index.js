import router from '@/public/router';

export default [{
	...router('/home', {/*首页*/
		name: 'home',
		showFooter: true,
		disableBack: true,
		showQRScan: true,
		showHeader: true,
		showChildName: true,
		supIOSVersionNum:"1.1.3",
		supAndroidVersionNum:"1.1.3",
		group: 'home'
	}),
	component: resolve => require(['@/views/home/index'], resolve)
},{
	...router('/home/scan', {
		name: 'scan',
		title: '扫一扫',
		hideChildren: true,
	}),
	component: resolve => require(['@/views/home/scan'], resolve)
},{
	...router('/downLoad', {
		name: 'downLoad',
		title: '下载',
		hideChildren: true,
		showHeader: false
	}),
	component: resolve => require(['@/views/home/download-app'], resolve)
},{
	...router('/home-limit', {
		name: 'home-limit',
		title: '首页',
		showHeader:true,
		showFooter: true,
		group:'home-limit',
		hideChildren: true,
		disableBack: true,
		group: 'home',
	}),
	component: resolve => require(['@/views/home/limit'], resolve)
},{
	...router('/course-limit', {
		name: 'course-limit',
		title: '课业',
		showHeader:true,
		showFooter: true,
		group:'course-limit',
		hideChildren: true,
		disableBack: true,
	}),
	component: resolve => require(['@/views/course/limit'], resolve)
},{
	...router('/account-limit', {
		name: 'account-limit',
		title: '账户',
		showHeader:true,
		showFooter: true,
		group:'account-limit',
		hideChildren: true,
		disableBack: true,
	}),
	component: resolve => require(['@/views/home/limit'], resolve)
},]
