import router from '@/public/router';

export default [{
  ...router('/message', {
    name: 'message',
    title: '消息',
    showFooter: true,
    disableBack: true,
    supIOSVersionNum:"1.0.0",
		supAndroidVersionNum:"1.0.0",
    group: 'message',
    showQRScan: true,
  }),
  component: resolve => require(['@/views/message/index'], resolve)
}, {
  ...router('/message-limit', {
    name: 'message-limit',
    title: '消息',
    showFooter: true,
    disableBack: true,
    group: 'message-limit',
    hideChildren: true,
  }),
  component: resolve => require(['@/views/message/limit'], resolve)
}, {
  ...router('/message/lesson-notify', {
    name: 'message-lesson-notify',
    title: '课业通知'
  }),
  component: resolve => require(['@/views/message/lesson-notify/index'], resolve)
}, {
  ...router('/message/customer-interact', {
    name: 'message-customer-interact',
    title: '家校互动'
  }),
  component: resolve => require(['@/views/message/customer-interact/index'], resolve)
}, {
  ...router('/message/teacher-chats', {
    name: 'message-teacher-chats',
    title: '教师'
  }),
  component: resolve => require(['@/views/message/customer-interact/teacher-chats/index'], resolve)
}, {
  ...router('/message/teacher-list', {
    name: 'message-teacher-list',
    title: '选择教师',
    actionText: '完成',
    hideChildren: true,
  }),
  component: resolve => require(['@/views/message/customer-interact/teacher-list/index'], resolve)
}, {
  ...router('/message/xd-news', {
    name: 'message-xd-news',
    title: '学大资讯',
    hideChildren: true,
    keepAlive: false,
  }),
  component: resolve => require(['@/views/message/xd-news/index'], resolve)
}, {
  ...router('/message/news-detail', {
    name: 'message-news-detail',
    title: '学大资讯',
    hideChildren: true,
    // keepAlive: true
  }),
  component: resolve => require(['@/views/message/xd-news/news-detail/index'], resolve)
}, {
  ...router('/message/system-notify', {
    name: 'message-system-notify',
    title: '系统消息',
    right: 1
  }),
  component: resolve => require(['@/views/message/system-notify/index'], resolve)
}, {
  ...router('/message/customer-reply', {
    name: 'message-customer-reply',
    title: '',
    keepAlive:false,
    hideChildren: true,
    actionText: '留言'
  }),
  component: resolve => require(['@/views/message/customer-interact/customer-reply/index'], resolve),
}, {
  ...router('/message/customer-reply/leave-msg', {
    name: 'leaveMsg',
    title: '留言',
    hideChildren: true,
    actionText: "留言"
  }),
  component: resolve => require(['@/views/message/customer-interact/customer-reply/leave-msg'], resolve),
},{
  ...router('/message/dis', {
    name: 'msgDis',
    title: '系统消息',
    right: 1,
    hideChildren: true,
  }),
  component: resolve => require(['@/views/message/customer-interact/dis-reply/index'], resolve)
}
]
