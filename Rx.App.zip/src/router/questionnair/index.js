import router from '@/public/router';

export default [{
	...router('/questionnair', {/*调查问卷页*/
        name: 'questionnair',
        title: '调查问卷',
		disableBack: false,
		keepAlive: false,
		hideChildren: true,
        showHeader: true,
        group: 'questionnair'
	}),
	component: resolve => require(['@/views/questionnair/index'], resolve)
}]
