import router from '@/public/router';

export default [{/*首页*/
	...router('/', {
		redirect: '/home'
	}),
	component: resolve => require(['@/views/home'], resolve)
},{
	...router('/login', {/*登录页*/
		name: 'login',
		disableBack: true,
		keepAlive: false,
		hideChildren: true,
		showHeader: false
	}),
	component: resolve => require(['@/views/login/login'], resolve)
}, {
	...router('/login/reset-mess', {/*忘记密码页*/
		name: 'reset-mess',
		showHeader: false,
		hideChildren: true
	}),
	component: resolve => require(['@/views/login/reset-mess'], resolve)
},{
	...router('/privacy', {/*忘记密码页*/
		title: '服务条款',
		name: 'protocol',
		showHeader: true,
		hideChildren: true
	}),
	component: resolve => require(['@/views/login/server'], resolve)
},{
	...router('/login/reset-psd', {/*重置密码页*/
		name: 'reset-psd',
		title: '重置密码',
		hideChildren: true,
		showHeader: false
	}),
	component: resolve => require(['@/views/login/reset-psd'], resolve)
},{
	...router('/register', {/*注册页*/
		name: 'register',
		disableBack: true,
		keepAlive: false,
		hideChildren: true,
		showHeader: false
	}),
	component: resolve => require(['@/views/login/register'], resolve)
}]
