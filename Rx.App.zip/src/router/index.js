import Vue from 'vue';
import Router from 'vue-router';
import { CACHE_KEYS } from "@/constants"

Vue.use(Router);

import login from './login/'
import home from './home/'
import course from './course/'
import message from './message/'
import account from './account/'
import payment from './payment/'
import profile from './profile/'
import questionnair from './questionnair/'
import setCate from '@/public/util/api.cate';
import checkUpVersion from '@/public/util/util.version';
import isNetWork from '@/public/util/util.network';
import {storageQuestionFun} from '@/public/util/util.question'
import axios from '@/public/api/axios';

import { $getLastLessonNotify, $getLastSystemNotify } from '@/api/notify/notify-api';

let routes = [
	...login,
	...home,
	...course,
	...message,
	...account,
	...payment,
	...profile,
	...questionnair
];

const router = new Router({
	routes
});
router.beforeEach(async (to, from, next) => {
	if (!window.$myData.completeBaseUrlLoad) {
		//mui.showLoading('配置信息加载中','div')
		// setTimeout(() => {
		// 	mui.hideLoading();
		// }, 3000);
		let t1 = Date.now()

		window.xdapp.config = await axios.get(xdapp.api.config.getFullConfig)

		setCate();
		window.$myData.getRest();
		let t2 = Date.now();
		next()
		// mui.toast(( (t2-t1)/1000 ) )
		// mui.alert(plus.nativeUI.closeWaiting)
		// try{
		// 	plus.nativeUI.closeWaiting();
		// }catch(err){

		// }

		// mui.alert( (t2-t1)/1000 )
		// window.xdapp.api={...window.xdapp.api,...window.$myData.apiData}  // 封装到函数里面


	} else {
		if (to.path.startsWith('/privacy') || to.path.startsWith('/register') || to.path.startsWith('/profile') || to.path.startsWith('/home-limit') || to.path.startsWith('/login')) {
			next()
			// }else if(xdapp.api && xdapp.api.customerReply && xdapp.api.customerReply.loadLast) {
			// 	if (!window.$myData.judgeUserStatus) {
			// 		window.$myData.judgeUserStatus = true
			// 		let res = await axios.get(xdapp.api.customerReply.loadLast)
			// 		console.log(res)

			// 	}
			// next();
		} else {
			
			let res = await axios.post(xdapp.api.user.logonUserStatus)
			// next();
		}
		next()

	}

})

router.beforeEach((to, from, next) => {
	if (m2.cache.get("isExistPaymentObj")) {
		m2.cache.set("isExistPaymentObj", null);//清除支付存的数据
	}
	if (from.name == "home") {
		//存储调查问卷信息
		storageQuestionFun('isFirstQuestion');
	}
	xdapp.util.vue.commitActionStatus(false);
	axios.get(xdapp.api.config.getVersionConfig).then(
		r => {

			var version = r.version
			if (window.version && window.version != version) {
				mui.alert('有新版本，需要重新加载');
				plus.runtime.restart()

			}
			window.version = version;
		}
	)
	//检测到跳转的路由兼容的最低版本
	checkUpVersion(to);
	/*检测是否有网*/
	isNetWork();
	next();
});

/*
router.beforeEach((to, from, next) => {
	xdapp.util.vue.commitActionStatus(false);
	return next();
});*/
export default router;
