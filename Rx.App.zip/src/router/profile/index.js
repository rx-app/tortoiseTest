﻿import router from '@/public/router';

export default [{
  ...router('/profile', {
    name: 'profile',
    title: '我的',
    showFooter: true,
    disableBack: true,
    keepAlive: false,
    hideChildren: true,
    showHeader: false,
    supIOSVersionNum:"1.0.0",
		supAndroidVersionNum:"1.0.0",
    group: 'profile'
  }),
  component: resolve => require(['@/views/profile/index'], resolve)
}, {
  ...router('/profile/user', {
    name: 'profile-user-userInfo',
    title: '个人信息',
    keepAlive: false,
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/user/index'], resolve)
}, {
  ...router('/profile/edit-avatar', {
    name: 'profile-edit-avatar',
    title: '个人头像',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/edit-avatar'], resolve)
}, {
  ...router('/profile/child-avatar', {
    name: 'childAvatar',
    title: '修改头像',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/child-avatar'], resolve)
}, {
  ...router('/profile/cropper', {
    name: 'profile-cropper',
    title: '个人头像',
    hideChildren: true,
    showHeader: false,
  }),
  component: resolve => require(['@/views/profile/cropper'], resolve)
}, {
  ...router('/profile/cropper-child', {
    name: 'profile-cropper-child',
    title: '个人头像',
    hideChildren: true,
    showHeader: false,
  }),
  component: resolve => require(['@/views/profile/cropper-child'], resolve)
}, {
  // 	...router('/profile/cropper/child', {
  // 		name: 'profile-cropper-child',
  // 		title: '个人头像',
  // 		hideChildren: true
  // 	}),
  // 	component: resolve => require(['@/views/profile/cropper-child'], resolve)
  // }, {
  ...router('/profile/user/edit-name', {
    name: 'profile-user-edit-name',
    title: '设置名字',
    hideChildren: true,
    actionText: '提交'
  }),
  component: resolve => require(['@/views/profile/user/edit'], resolve)
}, {
  ...router('/profile/user/edit-sex', {
    name: 'profile-user-edit-sex',
    title: '设置性别',
    actionText: '提交',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/user/edit'], resolve)
}, {
  ...router('/profile/user/edit-area', {
    name: 'profile-user-edit-area',
    title: '设置地区',
    actionText: '提交',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/user/edit'], resolve)
}, {
  ...router('/profile/children', {
    name: 'profile-children-list',
    title: '孩子信息',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/children/children-list'], resolve)
}, {
  ...router('/profile/children/info/:id', {
    name: 'profile-children-child-info',
    title: '孩子信息',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/children/child-info'], resolve)
}, {
  ...router('/profile/children/editConPwd', {
    name: 'editConPwd',
    title: '修改确认密码',
    hideChildren: true,
    actionText: '提交'
  }),
  component: resolve => require(['@/views/profile/children/editConPwd'], resolve)
}, {
  ...router('/profile/children/edit-name/:id', {
    name: 'profile-children-edit-name',
    title: '修改姓名',
    actionText: '提交',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/children/edit'], resolve)
}, {
  ...router('/profile/children/parent-phone', {
    name: 'profile-children-parent-phone',
    title: '家长联系方式',
    actionText: '提交',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/children/edit'], resolve)
}, {
  ...router('/profile/children/sign-password', {
    name: 'profile-children-sign-password',
    title: '签到密码',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/children/sign-password'], resolve)
}, {
  ...router('/profile/children/more', {
    name: 'profile-children-more',
    title: '更多',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/children/more'], resolve)
}, {
  ...router('/profile/classbreak', {
    name: 'profile-classbreak',
    title: '课间小憩',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/classbreak/index'], resolve)
}, {
  ...router('/profile/classbreak/content', {
    name: 'break-content',
    title: '课间小憩',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/classbreak/content'], resolve)
}, {
  ...router('/profile/classbreak/add', {
    name: 'break-add',
    title: '课间小憩',
    hideChildren: true,
    actionText: '提交',
  }),
  component: resolve => require(['@/views/profile/classbreak/add'], resolve)
}, {
  ...router('/profile/settings', {
    name: 'profile-settings',
    title: '设置',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/index'], resolve)
}, {
  ...router('/profile/settings/password', {
    name: 'profile-settings-password-manage',
    title: '密码管理',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/password-manage'], resolve)
}, {
  ...router('/profile/settings/bind', {
    name: 'profile-settings-bind-manage',
    title: '绑定管理',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/bind-manage'], resolve)
}, {
  ...router('/profile/settings/feedback/edit', {
    name: 'feedbackEdit',
    title: '添加建议',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/feedback/edit'], resolve)
}, {
  ...router('/profile/settings/feedback/content', {
    name: 'feedbackContent',
    title: '',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/feedback/content'], resolve)
}, {
  ...router('/profile/settings/feedback/list', {
    name: 'feedback-list',
    title: '意见反馈',
    hideChildren: true,
    actionText: "留言"
  }),
  component: resolve => require(['@/views/profile/settings/feedback/feedback-list'], resolve)
}, {
  ...router('/profile/settings/feedback/add', {
    name: 'feedback-add',
    title: '我要反馈',
    hideChildren: true,
    actionText: "提交",
    keepAlive: true,
  }),
  component: resolve => require(['@/views/profile/settings/feedback/feedback-add'], resolve)
}, {
  ...router('/profile/settings/feedback/add/reply', {
    name: 'feedback-add-reply',
    title: '我要回复',
    hideChildren: true,
    actionText: "提交",
    keepAlive: true,
  }),
  component: resolve => require(['@/views/profile/settings/feedback/feedback-add'], resolve)
}, {
  ...router('/profile/settings/feedback/feedback-reply', {
    name: 'feedback-reply',
    title: '意见反馈',
    hideChildren: true,
    actionText: "回复"
  }),
  component: resolve => require(['@/views/profile/settings/feedback/feedback-reply'], resolve)
}, {
  ...router('/profile/settings/Feedback/edit', {
    name: 'feedbackList',
    title: '意见反馈',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/feedback/edit'], resolve)
}, {
  ...router('/profile/settings/author', {
    name: 'profile-settings-author-manage',
    title: '授权管理',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/author-manage'], resolve)
}, {
  ...router('/profile/settings/author-invite', {
    name: 'profile-settings-author-invite',
    title: '授权邀请',
    actionText: '完成',
    hideChildren: true,
  }),
  component: resolve => require(['@/views/profile/settings/author-invite'], resolve)
}, {
  ...router('/profile/settings/notify', {
    name: 'profile-settings-notify',
    title: '消息通知',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/notify'], resolve)
}, {
  ...router('/profile/settings/about', {
    name: 'profile-settings-about',
    title: '关于掌上学大',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/about'], resolve)
}, {
  ...router('/profile/settings/about/list', {
    name: 'profile-settings-about-list',
    title: '功能介绍',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/about-list'], resolve)
}, {
  ...router('/profile/settings/feedback', {
    name: 'profile-settings-feedback',
    title: '建议反馈',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/feedback/list'], resolve)
}, {
  ...router('/profile/settings/version', {
    name: 'profile-settings-version',
    title: '版本信息',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/version'], resolve)
}, {
  ...router('/profile/settings/password-login', {
    name: 'profile-settings-password-login',
    title: '登录密码',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/password-login'], resolve)
}, {
  ...router('/profile/settings/eval', {
    name: 'profile-settings-eval',
    title: '去评价',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/eval'], resolve)
}, {
  ...router('/profile/settings/edition', {
    name: 'profile-settings-edition',
    title: '功能介绍',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/edition'], resolve)
}, {
  ...router('/profile/settings/msg-setting', {
    name: 'msg-setting',
    title: '短信设置',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/msg-setting'], resolve)
}, {
  ...router('/profile/settings/finger', {
    name: 'profile-settings-finger',
    title: '手势密码',
    hideChildren: true
  }),
  component: resolve => require(['@/views/profile/settings/finger'], resolve)
}, {
  ...router('/profile/settings/lock', {
    /*后期可能会用到的图势解锁页*/
    name: 'profile-settings-lock',
    title: '设置手势',
    hideChildren: true
  }),
  component: resolve => require(['@/views/login/unlock'], resolve)
}, {
  ...router('/unlock', {
    /*后期可能会用到的图势解锁页*/
    name: 'unlock',
    title: '请先解锁密码',
    hideChildren: true,
    disableBack: true,
  }),
  component: resolve => require(['@/views/login/unlock'], resolve)
},]
