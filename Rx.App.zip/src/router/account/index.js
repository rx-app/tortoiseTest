import router from '@/public/router';

export default [{
	...router('/account', {
		name: 'account',
		title: '账户',
		showFooter: true,
		disableBack: true,
		supIOSVersionNum:"1.0.0",
		supAndroidVersionNum:"1.0.0",
		group: 'account',
		showQRScan: true
	}),
	component: resolve => require(['@/views/account/info'], resolve)
}, {
	...router('/account/info', {
		name: 'accountInfo',
		title: '账户信息'
	}),
	component: resolve => require(['@/views/account/info'], resolve)
}, {
	...router('/account/chooseAccount', {
		name: 'chooseAccount',
		title: '选择账户'
	}),
	component: resolve => require(['@/views/account/chooseAccount'], resolve)
}, {
	...router('/account/statement', {
		name: 'accountStatement',
		title: '对账单',
		//hideChildren: true
	}),
	component: resolve => require(['@/views/account/statement'], resolve)
}, {
	...router('/account/orederList', {
		name: 'orderList',
		title: '订购单',
		//hideChildren: true
	}),
	component: resolve => require(['@/views/account/order-list'], resolve)
}]
