import router from '@/public/router';

export default [{
  ...router('/course', { name: 'course', title: '上课记录', showFooter: true, disableBack: true, supIOSVersionNum:"1.0.0",
  supAndroidVersionNum:"1.0.0", group: 'course', showQRScan: true }),
  component: resolve => require(['@/views/course/course/course-record-list'], resolve)
}, {
  ...router('/score', { name: 'score', title: '成绩管理', showFooter: true, disableBack: true, group: 'course', showQRScan: true, }),
  component: resolve => require(['@/views/course/score/score-list'], resolve)
}, {
  ...router('/signup', { name: 'signup', title: '课程推荐', showFooter: true, disableBack: true, group: 'course', showQRScan: true, }),
  component: resolve => require(['@/views/course/report/course-signup'], resolve)
}, {
  ...router('/course/evaluate', { name: 'course-evaluate', title: '课表详情', hideChildren: true, actionText: "提交" }),
  component: resolve => require(['@/views/course/course/course-detail'], resolve)
}, {
  ...router('/course/detail', { name: 'course-detail', title: '课表详情', hideChildren: true }),
  component: resolve => require(['@/views/course/course/course-detail-limit'], resolve)
}, {
  ...router('/course/edit-score', { name: 'edit-score', title: '课程评分', hideChildren: true, actionText: "提交" }),
  component: resolve => require(['@/views/course/score/edit-score'], resolve)
}]
