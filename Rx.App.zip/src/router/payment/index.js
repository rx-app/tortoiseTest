import router from '@/public/router';

export default [{
	...router('/payment', {/*缴费*/
		name: 'payment',
		title: '缴费',
		showFooter: true,
		disableBack: true,
		showQRScan: true,
		showHeader: true,
		supIOSVersionNum:"1.1.3",
		supAndroidVersionNum:"1.1.3",
		group: 'payment'
	}),
	component: resolve => require(['@/views/payment/index'], resolve)
}]
