﻿<template>
  <div>
    <Header></Header>
    <keep-alive>
      <router-view class="container" v-if="this.$route.meta.keepAlive && isReloadAlive"></router-view>
    </keep-alive>
    <router-view class="container" v-if="!this.$route.meta.keepAlive && isReloadAlive"></router-view>
    <home-tip v-show="isAva" />
    <Footer></Footer>
  </div>
</template>
<script>
  import Header from './components/header';
  import Footer from './components/footer';
  import HomeTip from "@/views/home/partials/home-tip";

  import 'lib-flexible';
  import './public/lib/m2';
  import './api';
  import './public/util';
  import './public/filter';
  import './public/directive';
  // import { GET_ACCOUNT_LIST } from "@/api/customer/customer-api";
  import {mapState,mapMutations} from 'vuex';

  export default {
    provide(){
      return {
        reload:this.reload
      }
    },
    data(){
      return {
        isReloadAlive:true
      }
    },
    methods:{
      reload(){
        this.isReloadAlive = false,
        this.$nextTick(()=>{
          this.isReloadAlive = true
        })
      }
    },
    components:{
        Header,
        Footer,
        HomeTip,
    },
    computed:{
      ...mapState(['isAva'])
    },
    mounted () {
        mui.disableHoriztontal();
    }
  }
</script>
<style>
  @import './public/asset/css/mui/mui.plus.css';
  @import './public/asset/css/common.css';
</style>

