﻿import axios from 'axios';
import myaxios from '@/public/api/axios';
import store from '@/store';
import * as types from '@/store/mutation-types';
import { getHead } from "@/api/user/user-api";
import { HEADER_KEYS } from '@/public/constant';
import { CACHE_KEYS } from '@/constants';
// axios.defaults.baseURL = process.env.APP_API_ROOT;

export const fingerPsdStatus = () => {
	return !!window.localStorage.getItem('passwordxx');
	// return m2.cache.get(CACHE_KEYS.FINGERPSDSTATUS) || $vue.$store.state.fingerPsdStatus;
};

export const fingerPsdNum = () => {
	return m2.cache.get(CACHE_KEYS.FINGERPSDNUM) || $vue.$store.state.fingerPsdNum;
};
export const getCurrentChild = () => {
	return m2.cache.get(CACHE_KEYS.CURRENT_CHILD) || $vue.$store.state.currentChild;
};

export const loadUserInfo = (type) => {
	//   return new Promise((resolve) => {
	const token = m2.cache.get(CACHE_KEYS.SESSION_TOKEN);
	if (!token) {
		$vue.$router.push({
			name: 'login'
		});
	} else {
		const currentChild = m2.cache.get(CACHE_KEYS.CURRENT_CHILD);
		if ((!currentChild || !currentChild.id) || type === 'upd') {
			return axios({
				method: 'post',
				url: xdapp.api.user.loadUserInfo,
				...xdapp.util.ajax.getRequestHeaders(token)
			}).then(res => {
				if (res) {
					console.log('获取用户信息')
					console.log(res)
					var relation = ''
					var relationList= []
					if( res.children && res.children.length ){
						// Object.keys( res.children )
						res.children.forEach( (v,i)=>{
							relationList.push( v.relation )
						} )
					}
					
					if( relationList.find( v => v==1 ) ){
						relation = '(主监护人)'
					}else if( relationList.find( v => v==2 ) ){
						relation = '(学生本人)'
					}else if( relationList.find( v => v==3 ) ){
						relation = '(次要监护人)'
					}else{
						relation = ''
					}
					store.commit('relation', relation);
					const state = $vue.$store.state;
					let ifid = res.children.find(item => item.id == state.currentChild.id)
					// 对于同一账号再次登录，仍然保存退出前选择的孩子
					if (state.userId === res.userId && state.currentChild && ifid) {
						res.currentChild = state.currentChild;
					} else {
						res.currentChild = res.children.find(item => item.isDefault);
					}
					try {
						let current = (res.children.filter( item =>{
							return  item.id == state.currentChild.id
						} ))[0]
						res.currentChild.name =current.name;
						// debugger
						let relation =''
						if( current.relation==1  ){
							relation = '(主监护人)'
						}else if( current.relation==2  ){
							relation = '(学生本人)'
						}else if( current.relation==3  ){
							relation = '(次要监护人)'
						}else{
							relation = ''
						}
						store.commit('relation', relation);
					   
					} catch (error) {
						
					}
					
					var userIcons = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD) || [];
					var userLogon = {
						userID: res.userId,
						iconID: res.iconID,
						gender: res.gender,
						imgData: '',
						type: 1
					};
					var userIconsCurrent = userIcons.find(item => item.userID === res.userId);
					var currentUserIndex = userIcons.indexOf(userIconsCurrent);
					// if (currentUserIndex !== -1) {
					// 	userIcons.splice(currentUserIndex, 1, userLogon)
					// } else {
					// 	userIcons.push(userLogon);
					// }
					if (currentUserIndex == -1) {
						userIcons.push(userLogon);
					}
					res.children.forEach(item => {
						var userIconsCurrentChild = userIcons.find(items => items.userID === item.id);
						if (userIconsCurrentChild && userIconsCurrentChild.iconID && userIconsCurrentChild.imgData) {
							return;
						} else if (item.iconID) {
							getHead({
								iconID: item.iconID
							}, res => {
								var userChild = {
									userID: item.id,
									iconID: item.iconID,
									gender: item.gender,
									imgData: res,
									type: 2
								};
								if (JSON.stringify(userIcons).indexOf(JSON.stringify(userChild)) == -1) {
									userIcons.push(userChild);
								}
								// 保存当前用户涉及查看的头像
								m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, userIcons);
								//保存当前用户涉及查看的头像

								var objs = userIcons.slice();
								store.commit(types.CURRENT_MODI_HEAD, objs);
							})
						} else {
							var userChild = {
								userID: item.id,
								iconID: item.iconID,
								gender: item.gender,
								imgData: '',
								type: 2
							};
							if (JSON.stringify(userIcons).indexOf(JSON.stringify(userChild)) == -1) {
								userIcons.push(userChild);
							}
							m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, userIcons);
							//保存当前用户涉及查看的头像
							var objs = userIcons.slice();
							store.commit(types.CURRENT_MODI_HEAD, objs);
						}

					})
					m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, userIcons);
					//保存当前用户涉及查看的头像
					var objs = userIcons.slice();
					store.commit(types.CURRENT_MODI_HEAD, objs);
					// 保存当前孩子信息
					m2.cache.set(CACHE_KEYS.CURRENT_CHILD, res.currentChild);
					// 保存当前人信息
					m2.cache.set(CACHE_KEYS.CURRENT_USER, res);
					// 将当前用户信息放入state
					store.commit(types.GET_USER_INFO, res);
				}
			});
		} else {
			// 关闭应用时，从缓存中直接获取
			store.commit(types.GET_USER_INFO, m2.cache.get(CACHE_KEYS.CURRENT_USER));
			console.log('关闭应用时，从缓存中直接获取')
		}
	}
};
export const getUserFeedback = (success) =>
	myaxios.$post(xdapp.api.settings.getUserFeedback, success);

export const saveFeedback = (criteria, success) =>
	myaxios.$post(xdapp.api.settings.saveFeedback, criteria, success);

export const getAppInfo = (criteria, success, error) =>
	axios.post(xdapp.api.config.getAppInfo, criteria).then(success).catch(error);