import axios from '@/public/api/axios';

export const getUserFeedback = (criteria, success) => axios.$post(xdapp.api.settings.getUserFeedback, criteria, success);
export const getUserFeedbackTopic = (criteria, success) => axios.$post(xdapp.api.settings.getUserFeedbackTopic, criteria, success);
export const savePostFeedback = (criteria, success) => axios.$post(xdapp.api.settings.savePostFeedback, criteria, success);
export const getUserTypeFeedback = (criteria, success) => axios.$post(xdapp.api.settings.getUserTypeFeedback, criteria, success);
export const saveFeedback = (criteria, success) => axios.$post(xdapp.api.settings.saveFeedback, criteria, success);
export const feedbackUpload = (criteria, success) => axios.$post(xdapp.api.settings.feedbackUpload, criteria, success);


export const $getFeedbackList = (criteria, success) => {
  
  axios.$post(xdapp.api.settings.getUserFeedback, criteria, success);
};
export let $uploadMaterial = (criteria, success) => {
  
  axios.$post(xdapp.api.settings.uploadMaterial, criteria, success);
};
export let $initSavePostFeedback = (success) => {
  
  axios.$post(xdapp.api.settings.getUserTypeFeedback, {}, success);
};
export let $submitFeedback = (criteria, success) => {
  
  axios.$post(xdapp.api.settings.savePostFeedback, criteria, success);
};
export let $saveReplyFeedback = (criteria, success) => {
  
  axios.$post(xdapp.api.settings.saveReplyFeedback, criteria, success);
};
export const $getUserFeedbackTopic = (criteria, success) => {
  
  axios.$post(xdapp.api.settings.getUserFeedbackTopic, criteria, success);
}
