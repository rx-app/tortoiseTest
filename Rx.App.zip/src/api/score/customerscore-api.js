import axios from '@/public/api/axios';

export const getAllScores = (criteria, success) =>
  axios.$post(xdapp.api.customerscore.getAllScores, criteria,success);

export const getPagedScores = (criteria, success) =>
  axios.$post(xdapp.api.customerscore.getPagedScores, criteria,success);

export const getScoresInfo = (id, success ) =>
  axios.$get(xdapp.api.customerscore.getScoresInfo ,{id:id},success);

export const modifyParentalSatisfaction = (criteria, success) =>
  axios.$post(xdapp.api.customerscore.modifyParentalSatisfaction, criteria,success);

export const subjectReport= (criteria, success) =>
  axios.$post(xdapp.api.customerscore.subjectReport, criteria,success);

