export default {
  customerscore: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/CustomerScores/{0}',
    actions: {
      getAllScores: "GetAllScores", /*post*/
      getPagedScores: "GetPagedScores", /*post*/
      getScoresInfo: "GetScoresInfo", /*get*/
      modifyParentalSatisfaction: "ModifyParentalSatisfaction", /*post*/
      subjectReport:"SubjectReport",/*post*/
    }
  }
}
