export default {
  user: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.userApiUrl
    },
    url: '/api/User/{0}',
    actions: {
      loadUserInfo:'loadUserInfo',
      modifyHead:'ModifyHead',
      getHead:'GetHead',
      setSendMsgSwitch:'SetSendMsgSwitch',
      setSendGenNotifySwitch:'SetSendGenNotifySwitch',
      secondGuardianAuthority: "SecondGuardianAuthority", /*获得用户信息 post*/
      updateUserInfo: "UpdateUserInfo", /*获得用户信息 post*/
      getSeconedGuardianInfo: "GetSeconedGuardianInfo", /*获得用户信息 post*/
      getSecondGuardianAuthorityByCellNumber: "GetSecondGuardianAuthorityByCellNumber", /*获得用户信息 post*/
      removeSecondGuardianAuthority: "RemoveSecondGuardianAuthority", /*获得用户信息 post*/
      getChild: "GetChild", /*获得用户信息 post*/
      getSecondGuardianAuthorityBySID: "GetSecondGuardianAuthorityBySID", /*获得用户信息 post*/
      registerUserPhoneNumValidate: "RegisterUserPhoneNumValidate", /*注册用户手机号码验证  post*/
      sendUserRegisterCode: "SendUserRegisterCode", /*发送用户注册验证码 post*/
      registerUser: "RegisterUser", /*注册 post*/
      sendUserResetPwdCode: "SendUserResetPwdCode", /*发送重置密码验证码  post*/
      resetUserPwd: "ResetUserPwd", /*重置密码 post*/
      updateUserPwd: "UpdateUserPwd", /*修改密码 post*/
      seconedGuardianAuthority: "SeconedGuardianAuthority", /*次要监护人授权  post*/
      updateUserInfo: "UpdateUserInfo", /*修改用户信息 post*/
      getSeconedGuardianInfo: "GetSeconedGuardianInfo", /*获取次要监护人列表 get*/
      getSeconedGuardianAuthorityByCellNumber: "GetSeconedGuardianAuthorityByCellNumber", /*获取指定次要监护人信息列表  get*/
      removeSeconedGuardianAuthority: "RemoveSeconedGuardianAuthority", /*解除指定次要监护人和学生的授权 post*/
      getChild: "GetChild", /*获取所有被授权的学员信息 get*/
      getSeconedGuardianAuthorityBySID: "GetSeconedGuardianAuthorityBySID", /*获取指定学员的授权信息列表 get*/
      sendVerificationLogOnCode: "SendVerificationLogOnCode",
      validateUserResetPwdCode : "ValidateUserResetPwdCode",/*验证验证码是否正确*/
      validateUserRegisterCode:"ValidateUserRegisterCode",/*注册验证验证码是否正确*/
      getCustomerSecondGuardianRelationByCellNumber:'getCustomerSecondGuardianRelationByCellNumber',
      changeNameApply: 'ChangeNameApply',
      changeParentPhoneApply: 'ChangeParentPhoneApply',
      getHeadIDsByUserIDs: 'GetHeadIDsByUserIDs',
      logonUserStatus: 'LogonUserStatus',
    }
  }
}
