import axios from '@/public/api/axios';

export const setSendMsgSwitch = (criteria, success) => {
  axios.$post(xdapp.api.user.setSendMsgSwitch, criteria, success);
}

export const setSendGenNotifySwitch = (criteria, success) => {
  axios.$post(xdapp.api.user.setSendGenNotifySwitch, criteria, success);
}

export const modifyHead = xdapp.api.user.modifyHead
// export const modifyHead = 'http://10.1.55.88/RxApp/Rx.Api' + xdapp.api.user.modifyHead

export const getHead = (criteria, success) => {
  axios.$get(xdapp.api.user.getHead, criteria, success);
}
export const getHeadIDsByUserIDs = (criteria, success) => {
  axios.$post(xdapp.api.user.getHeadIDsByUserIDs, criteria, success);
}
export const secondGuardianAuthority = (criteria, success) => {
  axios.$post(xdapp.api.user.secondGuardianAuthority, criteria, success);
}

export const updateUserInfo = (criteria, success) => {
  axios.$post(xdapp.api.user.updateUserInfo, criteria, success);
}

export const getSeconedGuardianInfo = (success) => {
  axios.$post(xdapp.api.user.getSeconedGuardianInfo, {}, success);
}

export const getSecondGuardianAuthorityByCellNumber = (criteria, success) => {
  axios.$get(xdapp.api.user.getSecondGuardianAuthorityByCellNumber, criteria, success);
}

export const removeSecondGuardianAuthority = (criteria, success) => {
  axios.$post(xdapp.api.user.removeSecondGuardianAuthority, criteria, success);
}

export const getChild = (success) => {
  axios.$post(xdapp.api.user.getChild, {}, success);
}

export const getSecondGuardianAuthorityBySID = (criteria, success) => {
  axios.$post(xdapp.api.user.getSecondGuardianAuthorityBySID, criteria, success);
}

export const sendUserRegisterCode = (cellNumber, success, error) =>
  axios.post(xdapp.api.user.sendUserRegisterCode + "?CellNumber=" + cellNumber).then(success).catch(error);

export const registerUser = (criteria, success, error) =>
  axios.post(xdapp.api.user.registerUser, criteria).then(success).catch(error);

export const sendLogOnCode = (cellNumber, success, error) =>
  axios.post(xdapp.api.user.sendVerificationLogOnCode + "?CellNumber=" + cellNumber).then(success).catch(error);

export const registerUserPhoneNumValidate = (validateCode, success, error) =>
  axios.post(xdapp.api.user.registerUserPhoneNumValidate, validateCode).then(success).catch(error);

export const validateUserResetPwdCode = (criteria, success, error) =>
  axios.post(xdapp.api.user.validateUserResetPwdCode + "?CellNumber=" + criteria.cellNumber + "&Code=" + criteria.code).then(success);

export const sendUserResetPwdCode = (cellNumber, success, error) =>
  axios.get(xdapp.api.user.sendUserResetPwdCode + "?CellNumber=" + cellNumber).then(success);

export const resetUserPwd = (criteria, success, error) =>
  axios.$post(xdapp.api.user.resetUserPwd, criteria,success);
  
export const updateUserPwd = (criteria, success, error) =>
  axios.post(xdapp.api.user.updateUserPwd, criteria).then(success);

export const validateUserRegisterCode = (criteria, success, error) =>
  axios.post(xdapp.api.user.validateUserRegisterCode + "?CellNumber=" + criteria.cellNumber + "&Code=" + criteria.code).then(success).catch(error);

export const getCustomerSecondGuardianRelationByCellNumber = (criteria, success) => {
  axios.$get(xdapp.api.user.getCustomerSecondGuardianRelationByCellNumber, criteria, success);
}

export const changeNameApply = (criteria, success) => {
  axios.$post(xdapp.api.user.changeNameApply, criteria, success);
}

export const changeParentPhoneApply = (criteria, success) => {
  axios.$post(xdapp.api.user.changeParentPhoneApply, criteria, success);
}

export const logonUserStatus = (criteria, success) => {
  axios.$post(xdapp.api.user.logonUserStatus, criteria, success);
}