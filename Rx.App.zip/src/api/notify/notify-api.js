import axios from '@/public/api/axios';

export const delMsg = (criteria, success) =>
  axios.$post(xdapp.api.notify.deletedNotifyMessage, criteria, success);

export const delList = (criteria, success) =>
  axios.$post(xdapp.api.notify.deletedNotifyMessagesList, criteria, success);

export const getList = (criteria, success) =>
  axios.$post(xdapp.api.notify.queryNotifyMessagesList, criteria, success);

export const getMsg = (criteria, success) =>
  axios.$post(xdapp.api.notify.queryLastNotifyMessagesByCatalog, criteria, success);

/** new api **/
export let $getLastLessonNotify = (criteria, success) => {
   axios.$get(xdapp.api.notify.queryLastLessonNotify, criteria, success);
};

export let $getLastSystemNotify = (criteria, success) => {
  axios.$get(xdapp.api.notify.queryLastSystemNotify, criteria,success);
};

export const $getLessonNotifyList = (criteria, success) =>{
  axios.$post(xdapp.api.notify.queryLessonNotifyList, criteria, success);
}

export const $getSystemNotifyList = (criteria, success) =>{
  axios.$post(xdapp.api.notify.querySystemNotifyList, criteria, success);
}

