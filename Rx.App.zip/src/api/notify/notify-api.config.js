export default {
  notify : {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/notify/{0}',
    actions: {
      deletedNotifyMessage: "deletedNotifyMessage",
      deletedNotifyMessagesList: "deletedNotifyMessagesList",
      queryLastLessonNotify: "queryLastLessonNotify",
      queryLastSystemNotify: "queryLastSystemNotify",
      queryLessonNotifyList: "queryLessonNotifyList",
      querySystemNotifyList: "querySystemNotifyList",
    }
  }
}
