import axios from '@/public/api/axios';

export const scan = (criteria, success) =>
  axios.$post(xdapp.api.course.confirmStudentCourse, criteria, success);



