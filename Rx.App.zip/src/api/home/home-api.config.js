export default {
  course: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/StudentCourse/{0}',
    actions: {
      confirmStudentCourse: "ConfirmStudentCourse", /*获取学员课表  post*/
    }
  }
}
