import axios from '@/public/api/axios';

export const getSalePagedProducts = (criteria,success, error) =>
  axios.post(xdapp.api.order.getSalePagedProducts,criteria).then(success).catch(error);

  
export const addClassReport = (criteria,success, error) =>
  axios.post(xdapp.api.order.addClassReport,criteria).then(success).catch(error);
