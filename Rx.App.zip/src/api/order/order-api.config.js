export default {
  order: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/Order/{0}',
    actions: {
      getSalePagedProducts: "GetSalePagedProducts", /*获取学员符合的班组产品  post*/
      addClassReport: "AddClassReport" /*我要报名 post*/
    }
  }
}
