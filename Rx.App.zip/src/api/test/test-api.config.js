export default {
  test: {
    url: '/api/Test/{0}',
    actions: {
      upload: "Upload", /*post*/
      apiFilterTest: "APIFilterTest", /*post*/
      apiFilterTest2: "APIFilterTest2", /*post*/
      apiFilterTest3: "APIFilterTest3", /*post*/
      address: "address", /*get*/
    }
  }
}
