export default {
  news: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/news/{0}',
    actions: {
      getTop3NewsList: "GetTop3NewsList",
      getNewsList: "getNewsList",
      getNews: "getNews",
      getNewsByDay: "getNewsByDay",
      getNewestNews:'getNewestNews',
    }
  }
}
