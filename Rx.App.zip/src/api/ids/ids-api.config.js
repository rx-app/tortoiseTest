export default {
  ids: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/IDS/{0}',
    actions: {
      logon: "Logon", /*post*/
      logoff: "Logoff", /*注销应用功能  get post*/
      getLogonInfo: "GetLogonInfo"/*post*/
    }
  }
}
