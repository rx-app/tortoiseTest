import axios from '@/public/api/axios';

export const login = (criteria, success,err) =>
  {
    let failure=(error) => {
      var message = error.errMsg
      mui.alert(message);
    }
    if(err && typeof err == 'function'){
      failure = (error) => {
        var message = error.errMsg
        mui.alert(message);
        err(error);
      }
    }
    axios.$post(xdapp.api.ids.logon, criteria, {
      success,
      failure
    })
  };
export const logOff = (success) =>
  axios.$get(xdapp.api.ids.logoff, {}, {
    success,
    failure: (error) => {
      mui.alert(error.errMsg);
    }
  });
