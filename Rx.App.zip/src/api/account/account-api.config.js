export default {
  account: {
    getBaseUrl: () => {
      if (!xdapp.config || !xdapp.config.webApiConfig) {
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/Account/{0}',
    actions: {
      queryChargeApplyList: "QueryChargeApplyList", /*查询 缴费单列表 post*/
      getUnionPay: "GetUnionPay", /*获取缴费银联订单 post*/
      getUnionPayOrderMessage: "GetUnionPayOrderMessage", /*获取银联订单 post*/
    }
  }
}
