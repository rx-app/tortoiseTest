import axios from '@/public/api/axios';

/*查询 缴费单列表 post*/
export const queryChargeApplyList = (criteria, success) =>
	axios.$post(xdapp.api.account.queryChargeApplyList, criteria, success);

/*获取缴费银联订单 post*/
export const getUnionPay = (criteria, success) =>
	axios.$post(xdapp.api.account.getUnionPay, criteria, success);

/*获取缴费单 get*/
export const getUnionPayOrderMessage = (criteria, success) =>
	axios.$post(xdapp.api.account.getUnionPayOrderMessage, criteria, success);