﻿import axios from '@/public/api/axios';

export const monitorConfirmAsset = (criteria,success) =>
  axios.$post(xdapp.api.course.monitorConfirmAsset, criteria, success);

export const getStudentCourses = (criteria, success) =>
  axios.$post(xdapp.api.course.getStudentCourses, criteria, success);

export const getPagedStudentCourses = (criteria, success) =>
  axios.$post(xdapp.api.course.getPagedStudentCourses, criteria, success);

export const courseDetail = (criteria, success) =>
  axios.$get(xdapp.api.course.getStudentCourseInfo, criteria, success);

export const confirmStudentCourse = (criteria, success) =>
  axios.$post(xdapp.api.course.confirmStudentCourse, criteria, {
    success,
    error: (ex) => {
      window.xdapp.scan.close();
      $vue.$router.push({
        name: "home"
      });
    }
  });

export const getLessonInfo = (criteria, success) =>
  axios.$post(xdapp.api.course.getLessonInfo, criteria, success);

export const postLessonEvaluation = (criteria, success) =>
  axios.$post(xdapp.api.course.postLessonEvaluation, criteria, success);

export const getAppInfoByQuery = (criteria,success) =>
	axios.$get(xdapp.api.config.getAppInfoByQuery,criteria, success);