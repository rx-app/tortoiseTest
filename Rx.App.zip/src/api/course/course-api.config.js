export default {
  course: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/StudentCourse/{0}',
    actions: {
      getStudentCourses: "GetStudentCourses", /*获取学员课表  post*/
      getPagedStudentCourses: "GetPagedStudentCourses", /*获取分页学员课表 post*/
      getStudentCourseInfo: "GetStudentCourseInfo", /*根据课时ID获取学员课表 get*/
      confirmStudentCourse: "ConfirmStudentCourse", /*RX扫描掌上学大APP签到  post*/
      getLessonInfo: "GetLessonInfo",
      postLessonEvaluation: "PostLessonEvaluation",
      monitorConfirmAsset:'MonitorConfirmAsset',
    }
  }
}
