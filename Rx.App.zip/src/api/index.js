import injectApp from '@/public/app';
import axios from 'axios'
import { CACHE_KEYS, HEADER_KEYS } from '@/constants';

import common from './common/common-api.config'
import ids from './ids/ids-api.config'
import user from './user/user-api.config'
import customer from './customer/customer-api.config'
import customerReply from './customer-reply/customer-reply-api.config'
import notify from './notify/notify-api.config'
import dashboard from './dashboard/dashboard-api.config'
import course from './course/course-api.config'
import test from './test/test-api.config'
import relax from './relax/relax-api.config'
import order from './order/order-api.config'
import news from './news/news-api.config'
import score from './score/customerscore-api.config'
import settings from './settings/setting-api.config'
import account from './account/account-api.config'
import questionnaire from './questionnaire/questionnaire-api.config'

const API_CONFIG = {

    ...common,
    ...ids,
    ...user,
    ...customer,
    ...dashboard,
    ...course,
    // ...test,
    ...order,
    ...score,
    ...notify,
    ...customerReply,
    ...news,
    ...settings,
    ...relax,
    ...account,
    ...questionnaire
};
export default API_CONFIG;

window.$myData = {};
window.xdapp =window.xdapp || {}
window.xdapp.api = {'cacheKey':CACHE_KEYS.CURRENT_CHILD, 'headerKey':HEADER_KEYS.CHILD_HEADER_KEY}
injectApp(API_CONFIG);


