import axios from '@/public/api/axios';

export const getLatestNews = (criteria, success) =>
  axios.$get(xdapp.api.dashboard.getLatestNews, criteria, success);
