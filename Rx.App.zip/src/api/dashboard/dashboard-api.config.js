export default {
  dashboard: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/Dashboard/{0}',
    actions: {
      getLatestCourses: "GetLatestCourses", /*get*/
      getUncommentedCourses: "GetUncommentedCourses", /*get*/
      getLatestNews: "GetLatestNews", /*获取学大资讯 get*/
      test2: "Test2", /*测试方法2 post*/
      test3: "Test3", /*post*/
    }
  }
}
