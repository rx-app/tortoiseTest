export default {
  customerReply: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/customerReply/{0}',
    actions: {
      loadLast: "loadLast",
      loadReply: "loadReply",
      loadReplyPage: "loadReplyPage",
      upLoadFile:'upLoadFile',
      downLoadFile:'downLoadFile',
      loadTeacherReplyPage:'loadTeacherReplyPage',
      loadTeacherCollection: "loadTeacherCollection",
      userSendCustomerReply: "userSendCustomerReply",
      deleteReplyByReplyObject: 'deleteReplyByReplyObject',
      deleteTeacherReplyByTeacherID:'deleteTeacherReplyByTeacherID',
      loadDiscussionLastCollection: "loadDiscussionLastCollection", // 加载讨论组最新集合     
      loadDiscussion: "loadDiscussion", // 加载讨论组     
      deleteDiscussion: "deleteDiscussion", // 删除讨论组     
      speakInDiscussion: "speakInDiscussion", // 在讨论组中说话
    }
  }
}
