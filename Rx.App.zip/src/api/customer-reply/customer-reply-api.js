﻿import axios from '@/public/api/axios';

// 获取学员最新家校互动
export let $getLastReply = (success) => {
  axios.$get(xdapp.api.customerReply.loadLast, {}, success);
};
// 获取学员家校互动
export let $getCustomerReply = (success) => {
  axios.$get(xdapp.api.customerReply.loadReplyPage, {}, success);
};
// 删除家校互动聊天记录
export let $deleteCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.deleteReplyByReplyObject, criteria, success);
};
// 获取学员教师列表
export let $getTeacherList = (success) => {
  axios.$get(xdapp.api.customerReply.loadTeacherCollection, {}, success);
};
// 加载家校互动
export let $getCustomerReplyByType = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.loadReply, criteria, success);
};
// 获取家校互动教师页面
export let $getTeacherReplyList = (success) => {
  axios.$get(xdapp.api.customerReply.loadTeacherReplyPage, {}, success);
};
// 删除指定教师家校互动
export let $deleteTeacherCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.deleteTeacherReplyByTeacherID, criteria, success);
};
// 发送家校互动信息
export let $sendCustomerReply = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.userSendCustomerReply, criteria, success);
};
// 发送家校互动信息
export let loadDiscussionLastCollection = ( success) => {
  axios.$post(xdapp.api.customerReply.loadDiscussionLastCollection, {}, success);
};
// 发送家校互动信息
export let loadDiscussion = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.loadDiscussion, criteria, success);
};
export let deleteDiscussion = ( success) => {
  axios.$post(xdapp.api.customerReply.deleteDiscussion, {}, success);
};
// 发送家校互动信息
export let speakInDiscussion = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.speakInDiscussion, criteria, success);
};

export let upLoadFile = (criteria, success) => {
  axios.$post(xdapp.api.customerReply.upLoadFile, criteria, success);
};

export let downLoadFile = xdapp.api.customerReply.downLoadFile

