export default {
  customer: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/Customer/{0}',
    actions: {
      getConfirmPassword: "GetConfirmPassword", /*get*/
      modifyConfirmPassword: "ModifyConfirmPassword", /*get*/
      modifyHead: "ModifyHead", /*get*/
      getCustomerList: "GetCustomerList", /*get*/
      getCustomer: "GetCustomer", /*get*/
      getParentList: "GetParentList", /*get*/
      getAccountList: "GetAccountList", /*get*/
      getOrderList: "GetOrderList", /*get*/
      getAssignList: "GetAssignList",/*get*/
      queryAccountFLowList: "queryAccountFLowList",/*post*/
    }
  }
}
