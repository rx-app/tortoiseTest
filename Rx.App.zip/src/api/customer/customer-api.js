import axios from '@/public/api/axios';
export const getConfirmPassword = (criteria, success) =>axios.$get(xdapp.api.customer.getConfirmPassword, criteria, success);
export const getCustomer = (criteria, success) =>axios.$get(xdapp.api.customer.getCustomer, criteria, success);
export const modifyConfirmPassword = (criteria, success) =>axios.$post(xdapp.api.customer.modifyConfirmPassword, criteria, success);

export const GET_ACCOUNT_LIST = (criteria, success) =>axios.$get(xdapp.api.customer.getAccountList, criteria, success);
export const GET_ORDER_LIST = (criteria, success) =>axios.$post(xdapp.api.customer.getOrderList, criteria, success);
export const QUERY_ACCOUNT_FLOW_LIST = (criteria, success) =>axios.$post(xdapp.api.customer.queryAccountFLowList, criteria, success);
export const modifyHeadCus = /*process.env.APP_API_ROOT + */xdapp.api.customer.modifyHead;
