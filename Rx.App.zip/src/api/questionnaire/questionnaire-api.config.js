export default {
  questionnaire: {
    getBaseUrl: () => {
      if (!xdapp.config || !xdapp.config.webApiConfig) {
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/Questionnaire/{0}',
    actions: {
      loadQuestionnaire: "LoadQuestionnaire", /*加载调查问卷 get*/
      submitQuestionnaire: "SubmitQuestionnaire", /*提交调查问卷 post*/
    }
  }
}
