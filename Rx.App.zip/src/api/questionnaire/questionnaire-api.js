import axios from '@/public/api/axios';

/*提交调查问卷 post*/
export const submitQuestionnaire = (criteria, success) =>
	axios.$post(xdapp.api.questionnaire.submitQuestionnaire, criteria, success);

/*加载调查问卷 get*/
export const loadQuestionnaire = (criteria, success) =>
	axios.$get(xdapp.api.questionnaire.loadQuestionnaire, criteria, success);