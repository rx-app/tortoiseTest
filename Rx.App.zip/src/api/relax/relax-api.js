﻿import axios from '@/public/api/axios';

export let loadRandom = (criteria,success) => {
  axios.$get(xdapp.api.periodOfRelaxing.loadRandom, criteria, success);
};

export let loadByID = (criteria,success) => {
  axios.$get(xdapp.api.periodOfRelaxing.loadByID, criteria, success);
};

export let send = (criteria, success) => {
  axios.$post(xdapp.api.periodOfRelaxing.send, criteria, success);
};

export let load = (criteria, success) => {
  axios.$post(xdapp.api.periodOfRelaxing.load, criteria, success);
};

