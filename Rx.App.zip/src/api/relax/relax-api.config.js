export default {
  periodOfRelaxing: {
    getBaseUrl:()=>{
      if(!xdapp.config || !xdapp.config.webApiConfig){
        m2.loadApiError();
        return ''
      }
      return xdapp.config.webApiConfig.webAPIs.rxApiBaseUrl
    },
    url: '/api/periodOfRelaxing/{0}',
    actions: {
      send: "send",
      load: "load",
      loadByID: "loadByID",
      loadRandom:'loadRandom',
    }
  }
}
