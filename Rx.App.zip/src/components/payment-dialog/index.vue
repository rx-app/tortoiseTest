<template>
  <div class="mask" v-if="maskShow" @touchmove.prevent>
    <div class="mask-box">
      <i class="iconfont icon-error" @click="maskDis()"></i>
      <div class="msg-box">
        <h5>付款</h5>
        <div class="main-mess">
          <p>支付金额</p>
          <h3>￥{{paymentAmount.toString() | numberToMoney}}</h3>
        </div>
        <div
          class="mui-input-row mui-radio"
          v-for="(item,index) in payMethods"
          :key="index"
          @click="selectPayMethod($event)"
        >
          <label v-if="item.isShow">
            <p class="paymentMethod">
              <span class="paymentImg">
                <img src="~@/public/asset/img/payment/wechat.jpg" v-if="item.id == 1" />
                <img src="~@/public/asset/img/payment/alipay.jpg" v-if="item.id == 2" />
                <img src="~@/public/asset/img/payment/unionPay.jpg" v-if="item.id == 4" />
              </span>
              <span class="paymentName">{{item.payName}}</span>
            </p>
            <input name="radio1" type="radio" :dataid="item.id" />
          </label>
        </div>
        <div class="paymentBtn">
          <button @click="goPayment()" :disabled="selPayMethod == 0">确认付款</button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import "@/public/asset/js/payment/xueda-payment.js";
import { APPUnionPayMsgTypeDefine } from "@/constants";
import { getUnionPay } from "@/api/account/account-api";
export default {
  data() {
    return {
      payMethods: [
        {
          id: APPUnionPayMsgTypeDefine.WXUnifiedOrder,
          payName: "微信",
          isShow: true
        },
        {
          id: APPUnionPayMsgTypeDefine.TradePrecreate,
          payName: "支付宝",
          isShow: true
        },
        {
          id: APPUnionPayMsgTypeDefine.UACAppOrder,
          payName: "云闪付",
          isShow: false //process.env.SHOW_UACAppOrder
        }
      ],
      selPayMethod: 0
    };
  },
  props: {
    maskShow: {
      type: Boolean,
      required: false
    },
    paymentAmount: {
      type: Number,
      required: 0
    },
    remindPaymentId: {
      type: String,
      required: ""
    }
  },
  methods: {
    selectPayMethod(e) {
      this.selPayMethod = Number(e.srcElement.attributes.dataid.value);
    },
    maskDis() {
      mui.confirm(
        "尚未完成付款，是否确认关闭？",
        "提示",
        e => {
          if (e.index) {
            this.$emit("changeDialogShow", false);
            this.selPayMethod = 0;
          }
        },
        "div"
      );
    },
    getUnionPayFun() {
      m2.cache.set("isExistPaymentObj", null);
      var _this = this;
      this.params = {
        applyID: this.remindPaymentId,
        unionPayType: this.selPayMethod
      };
      getUnionPay(this.params, {
        success: () => {
          alert("下单返回errCode为0");
        },
        failure: res => {
          //在failure里面进行回调操作是由于返回数据存在errCode属性  在axios那块被拦截无法走success回调
          if (res.errCode !== 1) {
            mui.alert("下单失败请稍后重试!", "提示", "", "", "div");
            return;
          }
          switch (_this.selPayMethod) {
            case 1:
              console.log(res.appPayRequest);
              var result = JSON.parse(res.appPayRequest);
              window.plus.XuedaPayment.pay(
                "wxPay",
                JSON.stringify(result),
                function(result) {
                  if (
                    result.resultCode ==
                    window.plus.XuedaPayment.PAY_RESULT_CLIENT_UNINSTALL
                  ) {
                    mui.alert(
                      result.resultInfo.resultMsg,
                      "提示",
                      "",
                      "",
                      "div"
                    );
                    _this.$emit("changeBtnText", false);
                    _this.$emit("isSurePayBtn", true);
                    window.xdapp.aliPayError = true;
                  } else {
                    _this.selPayMethod = 0;
                    _this.$emit("changeBtnText", true);
                    _this.$emit("isSurePayBtn", false);
                    m2.cache.set("isExistPaymentObj", res);
                    window.xdapp.aliPayError = false;
                  }
                },
                function(error) {
                  mui.alert(error.resultInfo.resultMsg, "提示", "", "", "div");
                }
              );
              _this.selPayMethod = 0;
              _this.$emit("changeBtnText", true);
              _this.$emit("isSurePayBtn", false);
              m2.cache.set("isExistPaymentObj", res);
              window.xdapp.aliPayError = false;
              break;
            case 2: //支付宝
              window.plus.XuedaPayment.pay(
                "alipay",
                res.appPayRequest,
                function(result) {
                  mui.alert(result.resultInfo.resultMsg, "提示", "", "", "div");
                  window.xdapp.aliPayError = true;
                  return;
                },
                function(error) {
                  console.log(error);
                }
              );
              _this.selPayMethod = 0;
              _this.$emit("changeBtnText", true);
              _this.$emit("isSurePayBtn", false);
              m2.cache.set("isExistPaymentObj", res);
              window.xdapp.aliPayError = false;
              break;
            case 4: //云闪付
              window.plus.XuedaPayment.pay(
                "cloudpay",
                res.appPayRequest,
                function(result) {
                  if (
                    result.resultCode == window.plus.XuedaPayment.PAY_RESULT_OK
                  ) {
                    _this.selPayMethod = 0;
                    _this.$emit("changeBtnText", true);
                    _this.$emit("isSurePayBtn", false);
                    m2.cache.set("isExistPaymentObj", res);
                    window.xdapp.aliPayError = false;
                  } else {
                    mui.alert(
                      result.resultInfo.resultMsg,
                      "提示",
                      "",
                      "",
                      "div"
                    );
                    window.xdapp.aliPayError = true;
                  }
                },
                function(error) {
                  console.log(error);
                }
              );
          }
        },
        error: err => {
          this.$emit("isUnionPayError", true);
        }
      });
    },
    goPayment() {
      this.$emit("changeDialogShow", false);
      this.getUnionPayFun();
    }
  }
};
</script>

<style lang="scss">
.mask {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.3);
  z-index: 998;
  .mask-box {
    position: fixed;
    width: torem(300);
    height: torem(280);
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    margin: auto;
    text-align: center;
    .msg-box {
      width: 100%;
      padding: torem(15);
      background-color: #fff;
      border-radius: torem(8);
    }
    .iconfont {
      display: inline-block;
      color: #fff;
      font-size: torem(26);
      position: absolute;
      right: torem(-20);
      top: torem(-26);
    }
    h5 {
      font-size: torem(18);
      font-weight: bolder;
      height: torem(30);
      line-height: torem(30);
      border-bottom: 1px solid #ccc;
    }
    .main-mess {
      margin-top: torem(10);
      padding-bottom: torem(10);
      border-bottom: 1px solid #ccc;
      p {
        margin-bottom: torem(20);
      }
    }
    .paymentBtn {
      text-align: center;
      margin-top: torem(15);
      button {
        border: none;
        width: torem(200);
        height: torem(30);
        background-color: skyblue;
        color: #fff;
        border-radius: 8px;
      }
    }
    .mui-input-row {
      label {
        display: flex;
      }
      .paymentMethod {
        display: flex;
        align-items: center;
        margin-bottom: 0;
        .paymentImg {
          width: torem(30);
          height: torem(30);
          img {
            width: 100%;
            height: 100%;
          }
        }
        .paymentName {
          margin-left: torem(15);
        }
      }
      input[type="radio"] {
        top: torem(11) !important;
      }
    }
  }
}
</style>
