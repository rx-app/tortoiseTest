<template>
  <footer class="mui-bar mui-bar-tab xd-footer" v-show="this.$route.meta.showFooter" @touchmove.prevent>
    <div >
      <router-link
        :to="{name:item.link}"
        v-for="(item, index) in navTabs"
        v-if="(relation == 1 && item.link =='payment') || item.link !=='payment'"
        class="mui-tab-item"
        :key="index"
        tag="a"
      >
        <span class="mui-img mui-icon">
          <img
            :src="($route.meta.group==item.link)?require(`@/public/asset/img/icons/${item.imgOn}`):require(`@/public/asset/img/icons/${item.imgOff}`)"
            alt
          />
        </span>
        <span
          class="mui-tab-label"
          :class="{'router-link-active':$route.meta.group==item.link}"
        >{{item.name}}</span>
      </router-link>
    </div>
  </footer>
</template>

<script>
//import {FOOTER_NAV_TABS} from '@/constants';

export default {
  data() {
    return {
      navTabs: null
    };
  },
  props:[''],
  computed: {
    relation() {
      return this.$store.state.currentChild.relation;
    }
  },
  created() {
    this.navTabs = this.$store.state.footerTab;
  }
};
</script>
