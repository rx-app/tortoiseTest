<template  >
  <div>
    <header
      id="xd-header"
      class="mui-bar mui-bar-nav xd-header"
      style="position:absolute;z-index:99"
      v-show="this.$route.meta.showHeader"
    >
      <a class="qrcode" v-show="this.$route.meta.showQRScan" @click="getScan()">
        <span class="mui-icon iconfont icon-qr"></span>
      </a>
      <a
        class="mui-icon mui-icon-left-nav mui-pull-left"
        v-if="this.$route.name=='accountStatement' || this.$route.name=='orderList'"
        v-show="!this.$route.meta.disableBack"
        @click="backTo()"
      ></a>
      <a
        class="mui-icon mui-icon-left-nav mui-pull-left"
        v-else-if="this.$route.name=='profile-edit-avatar' || this.$route.name=='orderList'"
        v-show="!this.$route.meta.disableBack"
        @click="backToUser()"
      ></a>
      <a
        class="mui-icon mui-icon-left-nav mui-pull-left"
        v-else-if="this.$route.name=='profile-user-userInfo' || this.$route.name=='orderList'"
        v-show="!this.$route.meta.disableBack"
        @click="backToNav()"
      ></a>
      <a
        class="mui-icon mui-icon-left-nav mui-pull-left"
        v-else
        v-show="!this.$route.meta.disableBack"
        @click="back()"
      ></a>

      <p class="mui-pull-right user-menu" v-show="!this.$route.meta.hideChildren">
        <span class="child" v-show="this.$route.meta.showChildName">
          学员：
          <span class="name">{{this.$store.getters.currentChild.name | substr(4)}}</span>
        </span>
        <i id="add-user-menu" class="mui-icon iconfont icon-groups" @click="toggle()"></i>
      </p>
      <span v-if="this.$route.meta.actionText">
        <span
          class="action"
          @click="emitAction()"
          v-show="this.$store.state.enabledStatus"
        >{{this.$route.meta.actionText}}</span>
        <span
          class="action disabled"
          v-show="!this.$store.state.enabledStatus"
        >{{this.$route.meta.actionText}}</span>
      </span>
      <h1 class="mui-title">{{this.$route.meta.title}}</h1>
    </header>
    <child-list
      v-show="showModal"
      v-on:showNames="getNamesValue"
      v-on:showModal="getShowModalValue"
    ></child-list>
  </div>
</template>

<script>
import ChildList from "../child-list/";
export default {
  data() {
    return {
      showModal: false
    };
  },
  methods: {
    emitAction() {
      xdapp.util.vue.emit();
    },
    back() {
      console.log("路由名称" + this.$route.name);
      if (this.$route.name === "profile-settings-finger") {
        this.$router.replace({
          name: "profile-settings"
        });
      } else if (this.$route.name === "profile-settings") {
        this.$router.replace({
          name: "profile"
        });
      } else if (this.$route.name === "feedback-list") {
        this.$router.replace({
          name: "profile-settings"
        });
      } else if (this.$route.name === "feedback-reply") {
        this.$router.replace({
          name: "feedback-list"
        });
      } else if (this.$route.name === "profile-children-child-info") {
        this.$router.replace({
          name: "profile-children-list"
        });
      } else if (this.$route.name === "profile-children-list") {
        this.$router.replace({
          name: "profile"
        });
      } else if (this.$route.name === "message-customer-interact") {
        this.$router.replace({
          name: "message"
        });
      } else {
        this.$router.go(-1);
      }
    },
    toggle() {
      this.showModal = !this.showModal;
    },
    getNamesValue(data) {
      this.showNames = data;
    },
    getShowModalValue(data) {
      this.showModal = data;
    },
    getScan() {
      this.$router.push({
        name: "scan"
      });
    },
    backTo() {
      this.$router.push({
        name: "account"
      });
    },
    backToUser() {
      this.$router.push({
        name: "profile-user-userInfo"
      });
    },
    backToNav() {
      this.$router.push({
        name: "profile"
      });
    }
  },
  components: {
    ChildList
  }
};
</script>

<style lang="scss" scoped>
.xd-header {
  padding-top: torem(-100);
  z-index: 99;
  .mui-icon {
    color: #fff;
    img {
      width: 24px;
      height: 24px;
      margin-left: torem(-150);
    }
  }
  .user-menu {
    display: flex;
    align-items: center;
    color: #fff;
    margin-right: 10px;
    .child {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: torem(240);
      display: inline-block;
      span {
        @include letterStyle(14, #fff, -0.62, 20.8);
      }
      span.name {
        @include letterStyle(22, #fff, -0.62, 20.8);
        margin-right: torem(12.4);
      }
    }
    img {
      width: torem(36);
      height: torem(36);
      z-index: 20;
      border-radius: 100%;
      margin-right: torem(5);
    }
  }
}

.mui-title {
  @include letterStyle(17, #fff, -0.62, 43.8);
  position: absolute;
  left: 20vw;
  right: 20vw;
  margin: auto;
  // width: torem(100) !important;
  text-align: center !important;
  white-space: normal;
  text-overflow: initial !important;
}

.mui-bar {
  height: 65px;
  padding-top: 20px;
}

.qrcode {
  float: left;
  margin-left: torem(10);
}
</style>