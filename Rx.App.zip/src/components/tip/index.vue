<template>
  <div class="xdapp-tip">
    <slot></slot>
  </div>
</template>
<script>

</script>
<style scoped>
  .xdapp-tip {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100px;
    color: #999;
    font-size: 14px;
    position: absolute;
    z-index: 99;
    margin: auto;
    left: 0;
    right: 0;
  }
</style>
