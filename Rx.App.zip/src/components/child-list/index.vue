﻿<template>
	<div class="mui-popup-backdrop mui-active rx-sign-children-popup" @click="close"  >
		<div id="triangle"></div>
		<div class="mui-scroll dialog">
			<ul class="mui-table-view mui-table-view-radio">
				<!--class="mui-table-view-cell" :class="{'mui-selected':child.id==currentId}"-->
				<li v-for="child in this.$store.state.children" class="ppts-view-cell" @click="switchChild(child)">
					<p><img :src="getIconImg(child.id)" /></p>
					<a>{{child.name | substr(4)}}</a>
					<i v-if="getSelectedCss(child.id)" class="iconfont icon-check-mark"></i>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
	import { SWITCH_CHILD } from '@/store/mutation-types';
	import { CACHE_KEYS } from '@/constants';

	export default {
		data() {
			return {
				icons: [],
			}
		},
		computed: {
			currentId() {
				return this.$store.getters.currentChild.id
			},
			currentUser() {
				return this.$store.getters.currentModiHead || m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
			}
		},
		watch: {
			currentUser: {
				handler: function() {
					this.icons = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
				},
				deep: true
			}
		},
		methods: {
			getSelectedCss(id) {
				return this.$store.getters.currentChild.id === id ? true : false;
			},
			getIconImg(userID) {
				if(window.xdapp.icons){
					this.icons = window.xdapp.icons;
				}
				let icon = this.icons.find(item => item.userID === userID);
				if(icon && icon.imgData) {
					this.childImgData = icon.imgData;
				} else if(icon && icon.gender) {
					let img = icon.gender == 1 ? 'boy.png' : 'girl.png';
					this.childImgData = require(`@/public/asset/img/user/${img}`);
				}else{
					this.childImgData = '';
				}
				return this.childImgData;

			},
			switchChild(data) {
				// 同一位学员不需要切换
				if(this.$store.getters.currentChild.id === data.id) {
					return;
				}
				// 将未切换的孩子保存到全局
				window.swithChildOldID = this.$store.getters.currentChild.id
				
				this.$store.commit(SWITCH_CHILD, data);
				// 保存当前孩子信息
				m2.cache.set(CACHE_KEYS.CURRENT_CHILD, data);
				// debugger
				let relation =''
				if( data.relation==1  ){
							relation = '(主监护人)'
						}else if( data.relation==2  ){
							relation = '(学生本人)'
						}else if( data.relation==3  ){
							relation = '(次要监护人)'
						}else{
							relation = ''
						}
				this.$store.commit('relation', data.relation);
				// 提交切换孩子事件
				xdapp.util.vue.emit();
			},
			close(e) {
				this.$emit("showNames", e.target.innerText);
				this.$emit("showModal", false);
			}
		}
	}
</script>
<style lang="scss" scoped>
	.rx-sign-children-popup {
		background: rgba(0, 0, 0, 0.2);
		z-index: 1000000;
	}
	
	.dialog {
		background: #FFFFFF;
		border-radius: 12px;
		top: torem(56);
		right: torem(13);
		overflow: hidden;
		width: torem(150);
	}
	
	#triangle {
		width: 0px;
		height: 0px;
		border-width: 15px;
		border-style: solid;
		border-color: transparent transparent rgba(255, 255, 255, 0.9) transparent;
		position: absolute;
		top: torem(36);
		right: torem(20);
	}
	
	.ppts-view-cell {
		padding-right: 54px;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		padding: 6px 15px;
		position: relative;
		overflow: hidden;
		border-bottom: 1px solid #eee;
		padding-left: 0;
		margin-left: 6px;
		p {
			width: torem(28);
			height: torem(28);
			border-radius: 100%;
			overflow: hidden;
			margin: 0 torem(10) 0 torem(5);
			img {
				width: 100%;
				height: 100%;
			}
		}
		a {
			color: #333333;
			font-size: 14px;
			white-space: nowrap;
			text-overflow: ellipsis;
			overflow: hidden;
			width: torem(55)
		}
		i {
			color: #007aff;
			padding-left: 5px;
			font-size: torem(18);
			font-weight: bolder;
		}
	}
	
	// .ppts-view-cell::after {
	// 	position: absolute;
	// 	right: 0;
	// 	bottom: 0;
	// 	left: 15px;
	// 	height: 1px;
	// 	content: '';
	// 	// -webkit-transform: scaleY(.5);
	// 	transform: scaleY(.5);
	// 	background-color: #c8c7cc;
	// }
	// @media (min-device-pixel-ratio: 2),(-webkit-min-device-pixel-ratio: 2) {
	// 	.ppts-view-cell::after {
	// 		position: absolute;
	// 		right: 0;
	// 		bottom: 0;
	// 		left: 15px;
	// 		height: 1px;
	// 		content: '';
	// 		// -webkit-transform: scaleY(.5);
	// 		// transform: scaleY(.5);
	// 		background-color: #c8c7cc;
	// 	}
	// }
	.mui-table-view{
		max-height: torem(400);
		overflow-y: scroll;
	}
	.mui-table-view:after{
		height: 0;
	}
</style>