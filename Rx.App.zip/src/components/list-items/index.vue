<template>
  <ul class="mui-table-view rx-list-items">
    <router-link v-for="(item, index) in routerItems"
                 :to="item.pathname"
                 :key="index"
                 tag="li"
                 class="item"
                 :class="{'link-item':item.pathname.name}">
      <span v-if="item.icon" class="mui-icon iconfont" :class="item.icon"></span>
      <span class="name" v-html="item.title"></span>
      <span class="value" :class="{'no-arrow':!item.pathname.name}">{{item.value}}
        <img v-if="item.img" :src="item.img" class="img-header"/></span>
    </router-link>
  </ul>
</template>
<script>
  export default {
    props: {
      'items': {
        type: Array,
        required: true
      }
    },
    methods: {},
    computed: {
      routerItems(){
        let _items = [];
        console.log(this.items)
        this.items.forEach(item => {
          if (!item.pathname || m2.type.isString(item.pathname)) {
            item.pathname = {name: item.pathname};
          }
          if(item.query){
            item.pathname.query=item.query;
          }
          _items.push(item);
        });
        return _items;
      }
    }
  }
</script>
<style lang="scss" scoped>
  .rx-list-items {
    .item {
      display: flex !important;
      justify-content: center;
      align-items: center;
      padding: torem(10);
      border-bottom: 1px solid #eee;
      margin: 0 torem(5);
    }
    .link-item:after {
      content: '\E583';
      font-family: Muiicons;
      color: #bbb;
      -webkit-font-smoothing: antialiased;
      margin-left: 5px;
    }
    .name {
      color: #777;
      font-size:14px;
    }
    .value {
      display: block;
      text-align: right;
      flex: 1;
      color: #aaa;

      .img-header {
        width: 1.70667rem;
        height: 1.70667rem;
      }
    }
    .no-arrow {
      margin-right: 17px;
    }
  }
</style>
