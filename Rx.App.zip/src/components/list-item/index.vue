<template>
  <ul class="mui-table-view rx-list-items">
    <router-link
      v-for="(item, index) in routerItems"
      @click.native="changeImg(item.routerLink,item.img)"
      :class="{'link-item':item.routerLink}"
      :to="item.pathname"
      :key="index"
      tag="li"
      class="item"
    >
      <span v-if="item.icon" class="mui-icon iconfont" :class="item.icon"></span>
      <span class="name" v-html="item.title">{{item.title}}</span>
      <span class="value" :class="{'no-arrow':!item.pathname.name}" @click="changeKind(item.sel)">
        {{item.value}}
        <p v-if="item.img">
          <img v-if="icons" :src="icons" class="img-header" alt>
          <img
            v-else-if="curGender==2 && type==1"
            src="~@/public/asset/img/user/mother.png"
            class="img-header"
            alt
          >
          <img
            v-else-if="(curGender==1 || curGender==0 || curGender==null)&& type==1"
            src="~@/public/asset/img/user/father.png"
            class="img-header"
            alt
          >
          <img
            v-else-if="curGender==2 && type==2"
            src="~@/public/asset/img/user/girl.png"
            class="img-header"
            alt
          >
          <img
            v-else-if="curGender==1 && type==2"
            src="~@/public/asset/img/user/boy.png"
            class="img-header"
            alt
          >
        </p>
      </span>
      <div id="triangle" v-if="item.sel" :class="{'up':kind}" @click="changeKind(item.sel)"></div>
      <ul v-if="kind && item.sel" class="list">
        <span id="cicle"></span>
        <li v-for="job in jobs" :class="{'select':job.id==isSelect}">{{job.name}}</li>
      </ul>
    </router-link>
  </ul>
</template>
<script>
import { mapState } from "vuex";
import store from "@/store";
import * as types from "@/store/mutation-types";
import { getHead , getHeadIDsByUserIDs} from "@/api/user/user-api";
import { CACHE_KEYS } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
export default {
  data() {
    return {
      icons: "",
      curGender: -1,
      kind: false
    };
  },
  props: {
    items: {
      type: Array,
      required: true
    },
    userID: {
      type: String,
      required: true
    },
    type: {
      type: Number,
      required: true
    }
  },
  methods: {
    changeKind(switchs) {
      if (!switchs) return;
      this.kind = !this.kind;
    },
    changeImg(isChange, isImg) {
      if (!isChange || !isImg) return;
      plus.nativeUI.actionSheet(
        {
          cancel: "取消",
          buttons: [
            {
              title: "拍照"
            },
            {
              title: "从相册中选择"
            },
            {
              title: "更新头像"
            }
          ]
        },
        e => {
          //1 是拍照  2 从相册中选择
          switch (e.index) {
            case 1:
              this.appendByCamera();
              break;
            case 2:
              this.appendByGallery();
              break;
            case 3:
              this.uploadHeadImg();
              break;
          }
        }
      );
    },
    appendByCamera() {
      var that = this;
      plus.camera.getCamera().captureImage(
        src => {
          that._compressImage(src);
        },
        e => {
          console.log("点击了取消拍照!");
        },
        {
          optimize: false
        }
      );
    },
    appendByGallery() {
      var that = this;
      plus.gallery.pick(src => {
        that._compressImage(src);
      });
    },
    uploadHeadImg() {
      var headObj = [{
        type: this.type == 1 ? 3 : 2,
        userID: this.userID
      }];
      getHeadIDsByUserIDs(headObj, iconMess => {
        if (iconMess[0].iconID) {
          var currentIcon = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
          var _this = this;
          if (currentIcon && this.userID) {
            currentIcon.forEach(item => {
              if (item.userID == this.userID) {
                getHead(
                  {
                    iconID: iconMess[0].iconID
                  },
                  res => {
                    _this.icons = res;
                    item.imgData = res;
                    m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, currentIcon);
                    window.xdapp.icons = currentIcon;
                    var objs = currentIcon.slice();
                    store.commit(types.CURRENT_MODI_HEAD, objs);
                  }
                );
              }
            });
          }
        }
      });
    },
    goCropper(urlData) {
      this.$router.push({
        name: "profile-cropper",
        query: {
          urlData: urlData,
          userID: this.userID,
          type: this.type
        }
      });
    },
    _compressImage(src) {
      var that = this;
      plus.nativeUI.showWaiting("加载中...");
      plus.zip.compressImage(
        {
          src: src,
          format: "jpg",
          dst: "_doc/" + new Date().getTime() + ".jpg",
          quality: 30
        },
        event => {
          plus.nativeUI.closeWaiting();
          plus.io.resolveLocalFileSystemURL(
            event.target,
            entry => {
              entry.file(function(file) {
                that.goCropper(file);
              });
            },
            e => {
              mui.toast("读取拍照文件错误");
            }
          );
        }
      );
    },
    currentHeadImg() {
      var currentIcon = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
      var _this = this;
      if (currentIcon && this.userID) {
        currentIcon.forEach(item => {
          if (item.userID == this.userID) {
            if (item.iconID && !window.xdapp[this.userID] && item.imgData) {
              this.icons = item.imgData;
            } else if (item.iconID) {
              getHead(
                {
                  iconID: item.iconID
                },
                res => {
                  _this.icons = res;
                  item.imgData = res;
                  m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, currentIcon);
                  window.xdapp.icons = currentIcon;
                  var objs = currentIcon.slice();
                  store.commit(types.CURRENT_MODI_HEAD, objs);
                }
              );
              window.xdapp[this.userID] = false;
            } else {
              this.curGender = item.gender;
            }
          }
        });
      }
    }
  },
  created() {
    this.kind = false;
    this.currentHeadImg();
  },
  watch: {
    userID(obj) {
      if (obj) {
        this.currentHeadImg();
      }
    }
  },
  computed: {
    routerItems() {
      let _items = [];
      this.items.forEach(item => {
        if (!item.pathname || m2.type.isString(item.pathname)) {
          item.pathname = {
            name: item.pathname
          };
        }
        _items.push(item);
      });
      return _items;
    },
    isSelect() {
      return m2.cache.get("ppts-current-job").id;
    },
    ...mapState({
      //currentHeadImg: state => state.currentHeadImg.imgData,
      currentUserGender: state => state.currentUserGender
    })
  }
};
</script>
<style lang="scss" scoped>
.rx-list-items {
  position: absolute;
  width: 100%;
  /*height: 100%;*/
  .item {
    display: flex !important;
    justify-content: center;
    align-items: center;
    padding: torem(10);
    border-bottom: 1px solid #eee;
    margin: 0 torem(5);
    position: relative;
  }
  .link-item:after {
    content: "\E583";
    font-family: Muiicons;
    color: #bbb;
    -webkit-font-smoothing: antialiased;
    margin-left: 5px;
  }
  .name {
    color: #777;
    font-size: torem(14);
  }
  .value {
    display: block;
    text-align: right;
    flex: 1;
    font-size: torem(14);
    color: #aaa;
    .img-header {
      width: 1.70667rem;
      height: 1.70667rem;
      border-radius: 50%;
    }
  }
  .no-arrow {
    margin-right: 3px;
  }
}

.mui-content > .mui-table-view:first-child {
  margin-top: 0;
}

.job-list {
  position: relative;
  top: torem(67);
  right: torem(10);
  li {
    height: torem(30);
  }
}

#triangle {
  width: 0px;
  height: 0px;
  border-width: 6px;
  border-style: solid;
  border-color: transparent transparent #e0e0e0 transparent;
  position: absolute;
  top: torem(11);
  right: torem(1);
}

#cicle {
  display: inline-block;
  width: 0px;
  height: 0px;
  border-width: 12px;
  border-style: solid;
  border-color: transparent transparent #e0e0e0 transparent;
  position: absolute;
  top: torem(-20);
  right: torem(1);
}

.up {
  border-color: #e0e0e0 transparent transparent transparent !important;
  top: torem(20) !important;
}

.list {
  position: absolute;
  top: torem(45);
  right: torem(10);
  padding: torem(10) torem(15);
  background: #e0e0e0;
  border-radius: torem(6);
  li {
    height: torem(30);
    line-height: torem(30);
    padding: 0 torem(10);
  }
  .select {
    background: #fff;
  }
}
</style>