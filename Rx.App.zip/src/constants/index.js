﻿export const ACTION_TYPES = {
  SELECT_TEACHER: '选择教师',
  SUBMIT_COMMET: '提交评价',
  SWITCH_CHILD: '切换孩子',
  Author_Invite: '授权邀请',
  SUBMIT_SCORE_COMMIT: '课程评分',
  GOTO_FEEDBACK: '留言',
  leave_message: 'leaveMessage',
  SUBMIT_FEEDBACK: '我要反馈'
};
// 所有的缓存KEY
export const CACHE_KEYS = {
  CURRENT_CHILD: 'rx-current-child',
  CURRENT_USER: 'rx-current-user',
  SESSION_TOKEN: 'rx-session-token',
  ACTION_TYPE: 'rx.event.actionType',

  FINGERPSDSTATUS: "rx.finger.psd",
  FINGERPSDNUM: "rx.finger.num",
  QUESTIONMESS:"rx.current.question",
  CURRENT_MODI_HEAD:'rx.current.modiHead',
  QUESOPENTIME:"rx.quesOpen.time"
};
// 浏览器头
export const HEADER_KEYS = {
  CHILD_HEADER_KEY: 'CurrentChildID'
};
export const RX_TEXT = {
  SIGNUP_TIP: '已通知归属学管师，如果该老师未能与您及时联系，可主动与其电话沟通！'
};

// 课时状态
export const ASSIGN_STATUS = {
  // 排定
  Assigned: 1,
  // 已上
  Confirmed: 3
};

export const SLIDE_STATUS = {
  DEFAULT: 0,
  ASSIGNED: 1, // 排定
  UNCOMMENT: 2, // 已上未评价
  COMMENTED: 3 // 已上已评价
};

// 课时状态
export const ASSIGN_STATUS_VALUE = {
  // 排定
  Assigned: '排定',
  // 已上
  Confirmed: '已上'
};

// 课时评价
export const COURSE_EVALUATE_SCORE_CONFIG = [
  {value: 1, desc: '很差'},
  {value: 2, desc: '差'},
  {value: 3, desc: '一般'},
  {value: 4, desc: '好'},
  {value: 5, desc: '很好'}
];

// 性别
export const GENDER = {
  // 男
  MALE: 1,
  // 女
  FEMALE: 2
};

// 通知消息科目
export const NotifyCatalog = {
  // 课业通知
  LessonNotify: 1,
  // 掌上学大信息变更申请
  APPChangeInfoApply: 2,
  // 系统消息
  SystemNotify: 99
};

// 消息通知查询方向
export const PreOrLast = {
  // 向后查询
  Next: 0,
  // 向前查询
  Pre: 1
};

// 家校互动类型
export const ReplyType = {
  // 咨询师反馈
  Consultant: 1,
  // 学管师反馈
  Educator: 2,
  // 教师反馈
  Teacher: 3,
  // 校区反馈
  School: 4,
  // 周反馈
  EducatorWeek: 6
};

// 家校互动发言人
export const Poster = {
  Xueda: 1,
  Customer: 2
};

// 底部tab菜单
export const FOOTER_NAV_TABS = [{
  name: '首页',
  imgOn: 'home-on.png',
  imgOff: 'home-off.png',
  active: true,
  link: 'home'
}, {
  name: '课业',
  imgOn: 'course-on.png',
  imgOff: 'course-off.png',
  link: 'course'
}, {
  name: '消息',
  imgOn: 'message-on.png',
  imgOff: 'message-off.png',
  link: 'message'
}, {
  name: '账户',
  imgOn: 'account-on.png',
  imgOff: 'account-off.png',
  link: 'account'
},
// {
//   name: '缴费',
//   imgOn: 'account-on.png',
//   imgOff: 'account-off.png',
//   link: 'payment'
// },
 {
  name: '我的',
  imgOn: 'profile-on.png',
  imgOff: 'profile-off.png',
  link: 'profile'
}];
// 课表
export const COURSE_INDEX = [{
  title: '上课记录',
  pathname: 'course',
  icon_active: require('@/public/asset/img/course/course.png'),
  icon: require('@/public/asset/img/course/courseoff.png'),
  active: true
},
  {
    title: '成绩管理',
    pathname: 'score',
    icon_active: require('@/public/asset/img/course/score.png'),
    icon: require('@/public/asset/img/course/scoreoff.png'),
    active: false
  },
  // {
  //   title: '课程推荐',
  //   pathname: 'signup',
  //   icon_active: require('@/public/asset/img/course/book.png'),
  //   icon: require('@/public/asset/img/course/bookoff.png'),
  //   active: false
  // }
];
// 我的
export const PROFILE_INDEX = [
  {
    title: '孩子信息',
    pathname: 'profile-children-list'
  },
  {
    title: '课间小憩',
    pathname: 'profile-classbreak'
  },
  {
    title: '设置',
    pathname: 'profile-settings'
  },
];
// 我的-设置
export const PROFILE_SETTING = [
  {
    title: '密码管理',
    pathname: 'profile-settings-password-manage'
  },
  //   {
  //     title: '绑定管理',
  //     pathname: 'profile-settings-bind-manage'
  //   },
  {
    title: '短信设置',
    pathname: 'msg-setting'
  },
  {
    title: '授权管理',
    pathname: 'profile-settings-author-manage'
  },
  // {
  //   title: '手势密码',
  //   pathname: 'profile-settings-finger'
  // },
  {
    title: '建议反馈',
    pathname: 'feedback-list'
  },
  // {
  //   title: '消息通知',
  //   pathname: 'profile-settings-notify'
  // }
  {
    title: '版本信息',
    pathname: 'profile-settings-version'
  },
  {
    title: '关于掌上学大',
    pathname: 'profile-settings-about'
  },
];
// 我的-设置
export const PROFILE_RX = [
 
];
// 我的-设置-密码管理-密码管理
export const PROFILE_PASSWORD_MANAGE = [{
  title: '登录密码',
  pathname: 'profile-settings-password-login'
}];
// 我的-设置-关于睿学
export const PROFILE_RX_ABOUT = [/*{
  title: '去评分',
  pathname: 'profile-settings-eval',
  isGoUrl: true
},*/
  {
    title: '功能介绍',
    pathname: 'profile-settings-about-list'
  }
];
// 授权关系
export const UserCustomerRelation = [{
  // 主要监护人
  MainGuardian: 1,
  // 学员
  Customer: 2,
  // 次要关系人
  SeconedGuardian: 3
}];
//订单支付方式
export const APPUnionPayMsgTypeDefine = {
  WXUnifiedOrder:1,
  TradePrecreate:2,
  QMFOrder:3,
  UACAppOrder:4,
  Query:5,
  Close:6,
  Refund:7
};
//订单支付状态
export const APPPayOrderStatus = {
  Invalid:0,
  NewOrder:1,
  WaitingForPaying:2,
  Paid:3,
  Closed:4,
  Refunded:5,
}


