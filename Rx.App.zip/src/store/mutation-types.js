// 获取当前用户信息
export const GET_USER_INFO = 'GET_USER_INFO'
// 获取当前孩子
export const GET_CURRENT_CHILDREN = 'GET_CURRENT_CHILDREN'
// 切换孩子
export const SWITCH_CHILD = 'SWITCHCHILD'
// 修改操作按钮的状态
export const ENABLE_STATUS = 'ENABLE_STATUS'
// 获取手势密码是否开通
export const FINGERPSDSTATUS = 'FINGERPSDSTATUS'
// 获取手势密码
export const FINGERPSDNUM = 'FINGERPSDNUM'
// 当前用户涉及查看的头像信息集合
export const CURRENT_MODI_HEAD = 'CURRENT_MODI_HEAD'
// 除了当前登陆者 其他用户的头像集合
export const HEADLIST_ARR = 'HEADLIST_ARR'