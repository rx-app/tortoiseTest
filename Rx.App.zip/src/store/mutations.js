﻿import * as types from './mutation-types';
import { CACHE_KEYS } from '@/constants';

export default {
	[types.GET_USER_INFO](state, data) {
		state.userId = data.userId;
		state.displayName = data.displayName;
		state.logOnName = data.logOnName;
		state.isValid = data.isValid;
		state.provinceName = data.provinceName;
		state.cityName = data.cityName;
		state.countyName = data.countyName;
		state.uuid = data.uuid;
		state.cellNumber = data.cellNumber;
		state.loginAccount = data.loginAccount;
		state.createTime = data.createTime;
		state.alias = data.alias;
		state.locationCode = data.locationCode;
		state.iconID = data.iconID;
		state.gender = data.gender;
		state.birth = data.birth;
		state.accountStatus = data.accountStatus;
		state.provinceCode = data.provinceCode;
		state.cityCode = data.cityCode;
		state.countyCode = data.countyCode;
		state.children = data.children;
		state.currentChild = (() => {
			return m2.cache.get(CACHE_KEYS.CURRENT_CHILD)
		})();
	},
	[types.SWITCH_CHILD](state, currentChild) {
		state.currentChild = currentChild;
	},
	[types.ENABLE_STATUS](state, enableStatus) {
		state.enabledStatus = enableStatus;
	},
	[types.FINGERPSDSTATUS](state, fingerPsdStatus) {
		state.fingerPsdStatus = fingerPsdStatus;
	},
	[types.FINGERPSDNUM](state, fingerPsdNum) {
		state.fingerPsdNum = fingerPsdNum;
	},
	[types.CURRENT_MODI_HEAD](state, currentModiHead) {
		state.currentModiHead = currentModiHead;
	},
	[types.HEADLIST_ARR](state, headList) {
		state.headList = headList;
	},
	relation(state,res){
		state.relation = res;
	},
	setIsAva(state,res){
		state.isAva = res;
	},
	changeFooterTab(state, payload) {
		if(payload == 'limited') {
			state.footerTab = [{
				name: '首页',
				imgOn: 'home-on.png',
				imgOff: 'home-off.png',
				active: true,
				link: 'home-limit'
			}, {
				name: '课业',
				imgOn: 'course-on.png',
				imgOff: 'course-off.png',
				link: 'course-limit'
			}, {
				name: '消息',
				imgOn: 'message-on.png',
				imgOff: 'message-off.png',
				link: 'message-limit'
			}, {
				//   name: '账户',
				//   imgOn: 'account-on.png',
				//   imgOff: 'account-off.png',
				//   link: 'account-limit'
				// }, {
				name: '我的',
				imgOn: 'profile-on.png',
				imgOff: 'profile-off.png',
				link: 'profile'
			}]
		} else {
			state.footerTab = process.env.SHOW_ACCOUNT ? [{
				name: '首页',
				imgOn: 'home-on.png',
				imgOff: 'home-off.png',
				active: true,
				link: 'home'
			}, {
				name: '课业',
				imgOn: 'course-on.png',
				imgOff: 'course-off.png',
				link: 'course'
			}, {
				name: '消息',
				imgOn: 'message-on.png',
				imgOff: 'message-off.png',
				link: 'message'
			}, {
				name: '账户',
				imgOn: 'account-on.png',
				imgOff: 'account-off.png',
				link: 'account'
			}, {
				name: '我的',
				imgOn: 'profile-on.png',
				imgOff: 'profile-off.png',
				link: 'profile'
			}] : [{
				name: '首页',
				imgOn: 'home-on.png',
				imgOff: 'home-off.png',
				active: true,
				link: 'home'
			}, {
				name: '课业',
				imgOn: 'course-on.png',
				imgOff: 'course-off.png',
				link: 'course'
			}, {
				name: '消息',
				imgOn: 'message-on.png',
				imgOff: 'message-off.png',
				link: 'message'
			}, {
				//   name: '账户',
				//   imgOn: 'account-on.png',
				//   imgOff: 'account-off.png',
				//   link: 'account'
				// }, {
				name: '我的',
				imgOn: 'profile-on.png',
				imgOff: 'profile-off.png',
				link: 'profile'
			}];
		}
	}
};