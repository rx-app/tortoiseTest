import Vue from 'vue'
import Vuex from 'vuex'
import mutations from './mutations'

Vue.use(Vuex);
//配置vueX参数
let state = {
  userId: "",
  relation:'',
  displayName: "",
  logOnName: "",
  isAva:false,
  isValid: true,
  provinceName: "",
  cityName: "",
  countyName: "",
  uuid: "",
  cellNumber: "",
  loginAccount: "",
  createTime: null,
  alias: "",
  locationCode: "",
  iconID: "",
  gender: null,
  birth: null,
  accountStatus: 0,
  provinceCode: "",
  cityCode: "",
  countyCode: "",
  children: [],
  currentChild: {},
  currentModiHead:[],
  headList:[],
  enabledStatus: false, // 右上角按钮的操作状态
  footerTab:process.env.SHOW_ACCOUNT? [{
    name: '首页',
    imgOn: 'home-on.png',
    imgOff: 'home-off.png',
    active: true,
    link: 'home'
  }, {
    name: '课业',
    imgOn: 'course-on.png',
    imgOff: 'course-off.png',
    link: 'course'
  }, {
    name: '消息',
    imgOn: 'message-on.png',
    imgOff: 'message-off.png',
    link: 'message'
  },{
    name: '账户',
    imgOn: 'account-on.png',
    imgOff: 'account-off.png',
    link: 'account'
  },
  {
    name: '缴费',
    imgOn: 'pay-on.png',
    imgOff: 'pay-off.png',
    link: 'payment'
  },
   {
    name: '我的',
    imgOn: 'profile-on.png',
    imgOff: 'profile-off.png',
    link: 'profile'
  }]:[{
    name: '首页',
    imgOn: 'home-on.png',
    imgOff: 'home-off.png',
    active: true,
    link: 'home'
  }, {
    name: '课业',
    imgOn: 'course-on.png',
    imgOff: 'course-off.png',
    link: 'course'
  }, {
    name: '消息',
    imgOn: 'message-on.png',
    imgOff: 'message-off.png',
    link: 'message'
  },
  {
    name: '缴费',
    imgOn: 'account-on.png',
    imgOff: 'account-off.png',
    link: 'payment'
  },
   {
  //   name: '账户',
  //   imgOn: 'account-on.png',
  //   imgOff: 'account-off.png',
  //   link: 'account'
  // }, {
    name: '我的',
    imgOn: 'profile-on.png',
    imgOff: 'profile-off.png',
    link: 'profile'
  }]
};

let getters = {
  children: state => {
    return state.children;
  },
  currentChild: state => {
    return state.currentChild;
  },
  currentModiHead: state =>{
  	return state.currentModiHead;
  },
  getChild: (state) => (id) => {
    return state.children.find(item => {
      return item.id == id
    })
  }
};

var store = new Vuex.Store({
  state,
  mutations,
  getters,
  strict: true
})

export default store;
