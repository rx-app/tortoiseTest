<template>
  <div class="wrap">
    <div id="bcid">
      <!--盛放扫描控件的div-->
    </div>

    <div class="mui-bar mui-bar-footer" style="padding: 0px;">
      <div class="fbt" @click="scanPicture()">从相册选择二维码</div>
      <!-- <div class="fbt mui-action-back" @click="closeCam">取　 消</div> -->
      <div class="fbt mui-action-back" @click="closeCam">取 消</div>
    </div>
  </div>
</template>

<script>
import { confirmStudentCourse } from "@/api/course/course-api";
export default {
  mounted() {
    mui.plusReady(function() {
      mui.init();
      startRecognize();
    });

    function startRecognize() {
      try {
        window.xdapp.scan = null;
        var filter;
        //自定义的扫描控件样式
        var styles = {
          frameColor: "#29E52C",
          scanbarColor: "#29E52C",
          background: ""
        };

        //扫描控件构造
        window.xdapp.scan = new plus.barcode.Barcode("bcid", filter, styles);
        window.xdapp.scan.onmarked = onmarked;
        window.xdapp.scan.onerror = onerror;
        window.xdapp.scan.start();
        //打开关闭闪光灯处理
        var flag = false;
        /*document.getElementById("turnTheLight").addEventListener('tap', function() {
						if(flag == false) {
							this.scan.setFlash(true);
							flag = true;
						} else {
							this.scan.setFlash(false);
							flag = false;
						}
					});*/
      } catch (e) {
        alert("出现错误啦:\n" + e);
      }
    }

    function onerror(e) {
      alert(e);
    }

    function onmarked(type, result) {
      var text = "";
      switch (type) {
        case plus.barcode.QR:
          text = "QR: ";
          break;
        case plus.barcode.EAN13:
          text = "EAN13: ";
          break;
        case plus.barcode.EAN8:
          text = "EAN8: ";
          break;
      }
      const criteria = {
        userType: "1",
        resultString: result
      };
      confirmStudentCourse(criteria, () => {
        mui.alert("成功确认课时!");
        window.xdapp.scan.close();
        $vue.$router.push({
          name: "home"
        });
      });
    }
  },
  beforeRouteLeave(to, from, next) {
    window.xdapp.scan.close();
    document.body.style.background = "#efeff4";
    next();
  },
  beforeRouteEnter(to, from, next) {
    document.body.style.background = "#000";
    next();
  },

  methods: {
    closeCam() {
      window.xdapp.scan.close();
    },
    scanPicture: function() {
      plus.gallery.pick(
        function(path) {
          plus.nativeUI.showWaiting("确认课时中...");
          var pathTarget =
            "_doc/" + new Date().getTime() + Math.random() + ".jpg";
          plus.zip.compressImage(
            {
              src: path,
              dst: pathTarget,
              quality: 10
            },
            event => {
              //   var target = event.target; // 压缩转换后的图片url路径，以"file://"开头
              //   var size = event.size; // 压缩转换后图片的大小，单位为字节（Byte）
              plus.barcode.scan(
                pathTarget,
                function(type, result) {
                  var text = "";
                  switch (type) {
                    case plus.barcode.QR:
                      text = "QR: ";
                      break;
                    case plus.barcode.EAN13:
                      text = "EAN13: ";
                      break;
                    case plus.barcode.EAN8:
                      text = "EAN8: ";
                      break;
                  }
                  var ua = navigator.userAgent;
                  if (/(Android)/i.test(ua)) {
                    result = eval(result);
                  }
                  const criteria = {
                    userType: "0",
                    resultString: result //eval(result)
                  };
                  confirmStudentCourse(criteria, () => {
                    mui.alert("成功确认课时!");
                    plus.nativeUI.closeWaiting();
                    window.xdapp.scan.close();
                    $vue.$router.push({
                      name: "home"
                    });
                  });
                },
                function(error) {
                  plus.nativeUI.alert("请扫描学管师或教师提供的对应课程的二维码!");
                  plus.nativeUI.closeWaiting();
                  window.xdapp.scan.close();
                  $vue.$router.push({
                    name: "home"
                  });
                }
              );
            },
            error => {
              plus.nativeUI.alert("图片压缩失败!");
            }
          );
        },
        function(err) {
          //plus.nativeUI.alert("扫码失败！");
          // window.xdapp.scan.close();
        }
      );
    }
  }
};
</script>

<style lang="scss" scoped>
.wrap {
  padding-bottom: 0 !important;
}

#bcid {
  width: 100%;
  position: absolute;
  top: 65px;
  bottom: torem(42);
  left: 0;
  background: #000;
}

.fbt {
  z-index: 10;
  color: #fff;
  width: 50%;
  background-color: #000;
  float: left;
  line-height: torem(44);
  font-size: torem(14);
  text-align: center;
}
</style>