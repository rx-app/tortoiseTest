<template>
  <div>
    <div id="stu-main-content" class="xd-home" ref="testdom">
      <!-- <div class="xiaoying" @click="linkTo()">跳转到小英</div> -->
      <mt-loadmore
        class="loadMore"
        :bottom-status.sync="bottomStatus"
        :auto-fill="false"
        :bottom-distance="-70"
        :bottom-all-loaded="allLoaded"
        :top-method="loadTop"
        :bottom-method="loadBottom"
        ref="loadmore"
      >
        <div slot="bottom" class="mint-loadmore-bottom">
          <span
            v-show="bottomStatus !== 'loading'"
            :class="{ 'rotate': bottomStatus === 'drop' }"
          >让手指休息一下，看看其他~~</span>
          <span v-show="bottomStatus === 'loading'">让手指休息一下，看看其他~~</span>
        </div>
        <div class="pullUp" style="margin-bottom:10px">
          <!--今日课表-->
          <course-today :courseList="courseList" :filterDay="filterDay" />
          <!--课表日历-->
          <Course-calendar
            @switchDay="switchDay"
            @switchMonth="switchMonth"
            :markArray="markArray"
            :resetMonth="resetMonth"
          />
          <div class="xueda-news" v-if="relation == 1 && paymentData">
            <div class="xd-news">
              <p class="xueda-img">
                <img src="~@/public/asset/img/payment/payment.png" />
              </p>
              <span class="tit">待缴费提醒</span>
            </div>
            <div>
              <div class="content">
                <p>
                  <span>【{{paymentData.chargeMoney.toString() | numberToMoney}}元】</span>
                  <!-- <span>{{paymentData.submitterJobName}} ：</span> -->
                  <span>制单人 ：</span>
                  <span>{{paymentData.submitterName}}</span>
                </p>
                <p class="paymentBtn" @click="goPayment($event)">立即付款</p>
              </div>
            </div>
          </div>
          <!--提示-->
          <xueda-news></xueda-news>
          <class-break></class-break>
          <!--首页页脚-->
          <!--<home-footer/>-->
        </div>
      </mt-loadmore>
      <payment-dialog
        v-if="paymentData"
        :maskShow="isShowPaymentDialog"
        :paymentAmount="paymentData.chargeMoney"
        :remindPaymentId="paymentData.applyID"
        @isUnionPayError="isUnionPayErrorFun($event)"
        @changeDialogShow="changeDialogShowFun($event)"
      ></payment-dialog>
    </div>
    <home-tip v-show="isAva" />
    <div v-if="!isComplete && relation == 1">
      <router-link
        v-if="isFirstQuestion"
        class="question big"
        :to="{name:'questionnair'}"
        tag="div"
      >
        <img src="~@/public/asset/img/bg/big.png" alt />
      </router-link>
      <router-link v-else class="question small" :to="{name:'questionnair'}" tag="div">
        <img src="~@/public/asset/img/bg/small.png" alt />
      </router-link>
    </div>
  </div>
</template>
<script>
import { pager, orderBy } from "@/public/constant";
import {
  ASSIGN_STATUS,
  ACTION_TYPES,
  APPPayOrderStatus,
  CACHE_KEYS
} from "@/constants";
import { getStudentCourses } from "@/api/course/course-api";
import { loadUserInfo, getCurrentChild } from "@/api/common/common-api";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import { GET_ACCOUNT_LIST } from "@/api/customer/customer-api";
import { monitorConfirmAsset } from "@/api/course/course-api";
import {
  queryChargeApplyList,
  getUnionPayOrderMessage
} from "@/api/account/account-api";
import { loadQuestionnaire } from "@/api/questionnaire/questionnaire-api";
import CourseToday from "./partials/course-today";
import CourseCalendar from "./partials/course-calendar";
import HomeTip from "./partials/home-tip";
//import HomeFooter from './partials/home-footer'
import ClassBreak from "./partials/class-break";
import XuedaNews from "./partials/xueda-news";
import PaymentDialog from "@/components/payment-dialog";
import { currentLoginUser } from "@/public/util/util.question";

export default {
  data() {
    return {
      courseList: [],
      courseArray: [],
      markArray: [],
      filterDay: m2.date.today(),
      today: m2.date.today(),
      resetMonth: undefined, // 用于下拉刷新、跨月时重置日历选中日期
      refreshContainer: ".xd-home",
      interval: null,
      allLoaded: false,
      teacherIDs: [],
      paymentData: null,
      isGetTeacherIDs: true,
      //timeOutNum: 0,
      //timeOutMax: 2,
      //timeOutFun: null,
      //resumePhoneFLag: false,
      params: {
        customerID: m2.cache.get("rx-current-child")
          ? m2.cache.get("rx-current-child").id
          : null,
        payStatus: 0,
        pageParams: {
          pageIndex: 1,
          pageSize: 1
        }
      },
      isComplete: true,
      isShowPaymentDialog: false,
      isAva: false //true为可用余额不足
    };
  },
  async created() {
    xdapp.util.aiUtil.seting();
    currentLoginUser();
    console.log("home", 3);
    this.$staffHub.ensureConnection();
    this.$staffHub.$on("confirmStudentCourse", msg => {
      console.log("*********msg***********");
      console.log(msg);
      if (
        m2.cache.get("rx-current-user") &&
        m2.cache.get("rx-current-user").cellNumber == msg.target
      ) {
        this.pulldownRefresh();
      }
    });
    this.$staffHub.$on("signalr-closed", res => {
      //监测hub关闭重新开启轮询
      if (!res) {
        this.pollConfirmCourse();
      }
    });
    document.body.style.background = "#fff";
    await loadUserInfo("upd");
    if (m2.cache.get("rx-current-user") !== null) {
      if (!m2.cache.get("rx-current-user").children.length) {
        this.$store.commit("changeFooterTab", "limited");
        this.$router.push("home-limit");
        return;
      } else {
        this.$store.commit("changeFooterTab", "normal");
      }
      this.getCourse();
      // this.initMuiPullRefresh();
      // 订阅切换孩子事件
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getCourse2);
      this.getAvaVal();
      this.getParmentData();
      this.bindResumeCallback();
      this.initIsComplete();
    }
    document.querySelector(".xd-header").style.position = "fixed";
    mui.plusReady(function() {
      plus.webview.currentWebview().setStyle({ softinputMode: "adjustResize" });
    });
  },
  destroyed() {
    document.body.style.background = "#efeff4";
    document.querySelector(".xd-header").style.position = "absolute";
    document.removeEventListener("resume", this.resumeCallback, false);
  },
  mounted() {
    document.body.style.background = "#fff";

    this.pollConfirmCourse();
    window.scrollTo(0, 0);
    this.setHeight();
  },
  activated() {
    this.setHeight();
  },
  updated() {
    window.scrollTo(0, 0);
  },
  beforeRouteLeave(to, from, next) {
    if (to.name == "login" && window.legalUser) {
      // next();
    } else {
      next();
    }
  },
  beforeDestroy() {
    console.log("beforeDestroy");
    if (this.interval) {
      this.clearTimeoutFun();
      mui.loading = true;
    }
  },
  watch: {
    courseList() {
      this.pollConfirmCourse();
      this.relishAgin();
      this.isGetTeacherIDs = true;
    }
  },
  computed: {
    relation() {
      return $vue.$store.state.currentChild.relation;
    },
    isFirstQuestion() {
      return this.getQuestionMess("isFirstQuestion");
    }
  },
  methods: {
    // linkTo() {
    //   if (mui.os.android) {
    //     var mContext = plus.android.runtimeMainActivity();
    //     var Intent = plus.android.importClass("android.content.Intent");
    //     var intent = new Intent();
    //     intent.setClassName(
    //       "com.xueda.rxapp.anuat",
    //       "com.github.lzyzsd.jsbridge.example.MainActivity"
    //     );
    //     mContext.startActivity(intent);
    //   } else {
    //     //ios
    //   }
    // },
    setClearDateVal() {
      if (this.relation == 1) {
        var quesOpenTime = m2.cache.get(CACHE_KEYS.QUESOPENTIME),
          questionMess = m2.cache.get(CACHE_KEYS.QUESTIONMESS);
        var oneDay = 24 * 60 * 60 * 1000;
        if (quesOpenTime) {
          if (quesOpenTime + oneDay <= new Date().getTime()) {
            questionMess.forEach(item => {
              item.isFirstQuestion = true;
            });
            m2.cache.set(CACHE_KEYS.QUESOPENTIME, new Date().getTime());
            m2.cache.set(CACHE_KEYS.QUESTIONMESS, questionMess);
          }
        } else {
          m2.cache.set(CACHE_KEYS.QUESOPENTIME, new Date().getTime());
        }
        this.dialogShow(questionMess);
      }
    },
    //是否在起始时间段
    _isDuringDate(beginDateStr, endDateStr) {
      var curDate = new Date(),
        beginDate = new Date(beginDateStr),
        endDate = new Date(endDateStr);
      if (curDate >= beginDate && curDate <= endDate) {
        return true;
      }
      return false;
    },
    dialogShow(questionMess) {
      var cellNumber =
        m2.cache.get(CACHE_KEYS.CURRENT_USER) &&
        m2.cache.get(CACHE_KEYS.CURRENT_USER).cellNumber;
      if (
        this.getQuestionMess("isFirstQuestion") &&
        this.relation == 1 &&
        !this.isComplete
      ) {
        mui.confirm(
          "为提升我们的服务质量，请您抽5分钟填写满意度调查问卷，谢谢！",
          "提示",
          ["暂不参加", "立即参加"],
          function(e) {
            if (e.index == 1) {
              $vue.$router.push({ name: "questionnair" });
            }
            questionMess.forEach(item => {
              if (item.user == cellNumber) {
                item.isFirstQuestion = false;
              }
            });
            m2.cache.set(CACHE_KEYS.QUESTIONMESS, questionMess);
          },
          "div"
        );
      }
    },
    getQuestionMess(type) {
      var cellNumber =
        m2.cache.get(CACHE_KEYS.CURRENT_USER) &&
        m2.cache.get(CACHE_KEYS.CURRENT_USER).cellNumber;
      var questionMess = m2.cache.get(CACHE_KEYS.QUESTIONMESS);
      if (questionMess && questionMess.length) {
        questionMess.forEach(item => {
          if (item && item.user == cellNumber) {
            if (type == "isFirstQuestion") {
              this.val = item.isFirstQuestion;
            }
            if (type == "isComplete") {
              this.val = item.isComplete;
            }
          }
        });
      }
      return this.val;
    },
    initIsComplete() {
      loadQuestionnaire("", res => {
        if (res.questionnaire && res.questionList) {
          this.isComplete = false;
        } else {
          this.isComplete = true;
        }
        this.setClearDateVal();
      });
    },
    linkToPaymentList() {
      this.$router.push({ name: "payment", query: { type: "2" } });
    },
    goPayment(e) {
      this.isShowPaymentDialog = true;
      window.xdapp.goOut = "remind"; //点击付款的页面 进行标识
    },
    isUnionPayErrorFun(msg) {
      if (msg) {
        this.$nextTick(function() {
          this.getParmentData();
        });
      }
    },
    changeDialogShowFun(msg) {
      this.isShowPaymentDialog = msg;
    },
    bindResumeCallback() {
      mui.plusReady(() => {
        document.addEventListener("resume", this.resumeCallback, false);
      });
    },
    resumeCallback() {
      if (window.xdapp.goOut == "payment") {
        //由于页面切回来 肯定会走home 如果是payment页面就不执行
        return;
      }
      this.getParmentData();
      if (
        m2.cache.get("isExistPaymentObj") &&
        !window.xdapp.aliPayError 
        // && !this.resumePhoneFLag
      ) {
        //this.resumePhoneFLag = true; //ios会执行两次resume 所以通过开关控制
        mui.showLoading("付款中...", "div");
        //检测订单交易状态
        getUnionPayOrderMessage(m2.cache.get("isExistPaymentObj"), {
          success: res => {
            m2.cache.set("isExistPaymentObj", null);
          },
          failure: res => {
            switch (res.msgStatus) {
              case APPPayOrderStatus.Invalid:
                this.$nextTick(function() {
                  this.getParmentData();
                });
                mui.alert("订单已失效!", "提示", "", "", "div");
                break;
              case APPPayOrderStatus.WaitingForPaying:
                //mui.showLoading("付款中...", "div");
                // this.timeOutFun = setTimeout(this.incrementNumber, 5000);
                mui.alert(
                  "未支付成功，可点击立即付款再次进行支付!",
                  "提示",
                  "",
                  "",
                  "div"
                );
                 //mui.hideLoading();
                m2.cache.set("isExistPaymentObj", null);
               // this.resumePhoneFLag = false;
                break;
              case APPPayOrderStatus.Paid:
                mui.hideLoading();
                mui.alert(
                  "支付成功!\n 支付凭证请联系" +
                    this.paymentData.submitterName +
                    "老师",
                  "提示",
                  this.linkToPaymentList(),
                  "",
                  "div"
                );
                m2.cache.set("isExistPaymentObj", null);
                break;
              case APPPayOrderStatus.Closed:
                this.$nextTick(function() {
                  this.getParmentData();
                });
                mui.alert("订单关闭!", "提示", "", "", "div");
                break;
              case APPPayOrderStatus.Refunded:
                this.$nextTick(function() {
                  this.getParmentData();
                });
                mui.alert("已退款!", "提示", "", "", "div");
                break;
              default:
                this.$nextTick(function() {
                  this.getParmentData();
                });
                mui.alert("订单异常!", "提示", "", "", "div");
            }
          }
        });
      }
    },
    getParmentData() {
      queryChargeApplyList(this.params, res => {
        this.paymentData = res.queryResult.pagedData[0];
      });
    },
    setHeight() {
      setTimeout(() => {
        let content = document.querySelector("#stu-main-content");
        if (content !== null && typeof content !== "undefined") {
          let windowHeight = window.innerHeight;
          let jHight = windowHeight + 75;
          //这里从 65 改成了 75，之前在ios上底部导航栏和页面之间有一段白色的空隙
          //这个值太小的话，底部会出现白条，太大的话，底部会拉不下去
          content.style.height = "calc(" + jHight + "px - 0.4rem - 2.6rem)";
        }
      }, 100);
    },
    // incrementNumber() {
    //   if (this.timeOutNum < this.timeOutMax) {
    //     this.timeOutNum++;
    //     this.resumePhoneFLag = false;
    //     this.resumeCallback();
    //   } else {
    //     clearTimeout(this.timeOutFun);
    //     mui.hideLoading();
    //     m2.cache.set("isExistPaymentObj", null);
    //     this.resumePhoneFLag = false;
    //     mui.alert(
    //       "未支付成功，可点击立即付款再次进行支付!",
    //       "提示",
    //       "",
    //       "",
    //       "div"
    //     );
    //   }
    // },
    relishAgin() {
      /*传给子元素课表里学生ID 教师ID提取出来*/
      if (this.courseList.length) {
        this.courseList.forEach(item => {
          var curTeach = {
            type: "1",
            userID: item.teacherID
          };
          if (
            JSON.stringify(this.teacherIDs).indexOf(JSON.stringify(curTeach)) ==
            -1
          ) {
            this.teacherIDs.push(curTeach);
          }
        });
      }
      this.relishTeacherIDs();
    },
    relishTeacherIDs() {
      if (this.teacherIDs.length && this.isGetTeacherIDs) {
        this.isGetTeacherIDs = false;
        getHeadIDsByUserIDs(this.teacherIDs, res => {
          this.courseList.forEach(item => {
            res.forEach(sel => {
              if (item.teacherID == sel.userID) {
                this.$set(item, "teacherIcons", sel);
              }
            });
          });
        });
      }
    },
    loadTop(e) {
      event.preventdefault;
      event.stopPropagation();
      this.pulldownRefresh();
      this.getParmentData();
      this.isDrop = false;
      this.$refs.loadmore.onTopLoaded(); //刷新完重新定位
    },
    loadBottom() {
      this.$refs.loadmore.onBottomLoaded();
    },
    bottomStatus() {
      console.log("上拉状态");
    },
    pulldownRefresh() {
      this.getData(m2.date.firstDay("m"), m2.date.endDay("m"), () => {
        this.filterCourseList(this.courseArray, this.today);
        this.filterMarkArray(this.courseArray);
        // 下拉刷新重置日期通知日历更新
        this.resetMonth = new Date();
      });
    },
    getAvaVal() {
      GET_ACCOUNT_LIST(
        {
          customerID: m2.cache.get("rx-current-child").id
        },
        res => {
          console.log(res.accounts);
          let t = 0;
          res.accounts.forEach(v => (t += v.accountValue));
          if (t < 1000) {
            this.isAva = true;
          }
        }
      );
    },
    async getData(startTime, endTime, callback) {
      await loadUserInfo();

      const criteria = {
        studentID: getCurrentChild().id,
        startTime: m2.date.toUTC(startTime),
        endTime: m2.date.toUTC(endTime),
        assignStatus: [ASSIGN_STATUS.Assigned, ASSIGN_STATUS.Confirmed],
        ...pager({
          pageIndex: 0,
          pageSize: 0
        }),
        ...orderBy({
          dataField: "StartTime"
        })
      };

      getStudentCourses(criteria, res => {
        this.courseArray = res.queryResult.pagedData;

        if (callback) callback();
      });
    },
    getCourse2() {
      mui.loading = true;
      let a = m2.date.firstDay("m", window.rx_home_date);
      let b = m2.date.endDay("m", window.rx_home_date);
      this.getData(a, b, () => {
        this.filterCourseList(this.courseArray, this.today);
        this.filterMarkArray(this.courseArray);
        setTimeout(() => {
          $(".wh_isToday").removeClass("wh_isToday");
        });
      });
      this.isAva = false;
      this.getAvaVal();
      this.getParmentData();
      this.initIsComplete();
    },
    getCourse() {
      mui.loading = true;
      let a = m2.date.firstDay("m");
      let b = m2.date.endDay("m");
      this.getData(a, b, () => {
        this.filterCourseList(this.courseArray, this.today);
        this.filterMarkArray(this.courseArray);
      });
    },
    //轮循  检测是否有确认课时未更新
    pollConfirmCourse() {
      console.log("*********$staffHub.connected***********");
      console.log(this.$staffHub.connected);
      if (this.$staffHub.connected) return;
      if (this.courseList && this.courseList.length) {
        var currentDate = this.courseList[0].startTime;
      } else {
        return;
      }
      if (m2.date.isToday(currentDate)) {
        this.courseList.forEach(item => {
          if (
            item.assignStatus == 1 &&
            m2.date.isSureCourse(item.startTime, item.endTime)
          ) {
            var params = {
              AssignID: item.assignID,
              userType: 1,
              userID: "",
              resultString: item.resultString
            };
            if (this.interval) {
              return;
            }
            this.setTimeOut(params, item);
          } else {
            this.clearTimeoutFun();
          }
        });
      } else {
        this.clearTimeoutFun();
      }
    },
    setTimeOut(params, item) {
      this.interval = setTimeout(() => {
        mui.loading = false;
        monitorConfirmAsset(params, res => {
          if (
            res.isSuccess &&
            res.hasData &&
            item.courseID == res.data.assignID
          ) {
            this.pulldownRefresh();
            return;
          }
          this.setTimeOut(params);
        });
      }, 5000);
    },
    clearTimeoutFun() {
      if (this.interval) {
        clearTimeout(this.interval);
        this.interval = null;
        mui.loading = true;
      }
    },
    switchDay(targetDay) {
      // debugger
      // if (m2.date.isEqual(targetDay, this.filterDay)) return;  刷新后再切换当日不会重新渲染
      // 同月份直接筛选课表 不同月份重新请求
      if (m2.date.isOneMonth(targetDay, this.filterDay)) {
        console.log(this.courseArray);

        this.filterCourseList(this.courseArray, targetDay);
        this.filterDay = targetDay;
      } else {
        this.filterDay = targetDay;
        this.courseList = [];
        this.markArray = [];
        this.getData(
          m2.date.firstDay("m", targetDay),
          m2.date.endDay("m", targetDay),
          () => {
            this.filterCourseList(this.courseArray, this.filterDay);
            this.filterMarkArray(this.courseArray);
          }
        );
      }
    },
    switchMonth(target) {
      const { current: targetMonth, calendar } = target;
      this.getData(
        m2.date.firstDay("m", targetMonth),
        m2.date.endDay("m", targetMonth),
        () => {
          this.courseList = [];
          this.markArray = [];
          if (!this.courseArray.length) return;
          // 切换月份找距离现在最近的课表
          if (m2.date.isOneMonth(targetMonth, this.today))
            this.filterDay = this.today;
          else if (targetMonth < this.today) {
            this.filterDay = m2.date.normalize(this.courseArray[0].startTime);
          } else {
            this.filterDay = m2.date.normalize(
              this.courseArray[this.courseArray.length - 1].startTime
            );
          }

          this.filterCourseList(this.courseArray, this.filterDay);
          this.filterMarkArray(this.courseArray);

          if (this.courseList[0] && this.courseList[0].startTime) {
            this.resetMonth = this.courseList[0].startTime;
          }
          // this.resetCalendar(calendar);
        }
      );
    },
    filterCourseList(courseList, filterDate) {
      if (m2.date.isOneMonth(filterDate, this.today)) {
        this.courseList = this.filterCurrentMonthCourse(courseList, filterDate);
      } else {
        this.courseList = this.filter(courseList, filterDate);
      }
    },
    filterMarkArray(courseList) {
      // 计算需要被标记的月份
      if (!courseList.length) {
        this.markArray = [];
        return;
      }
      let dayNumberList = [];
      courseList.forEach(course => {
        let dayNumber = course.startTime.getDate();
        if (!dayNumberList.includes(dayNumber)) dayNumberList.push(dayNumber);
      });
      this.markArray = dayNumberList;
    },
    filterCurrentMonthCourse(courseList, filterDate) {
      let result = [];
      // if (m2.date.isEqual(filterDate, this.today)) {
      //   let list = [];
      //   list = courseList.filter(course => course.startTime >= filterDate).reverse();
      //   if (!list.length)
      //     list = courseList.filter(course => course.startTime < filterDate);

      //   if (list.length) {
      //     result = this.filter(courseList, m2.date.normalize(list[0].startTime));
      //   }
      // } else {
      result = this.filter(courseList, m2.date.normalize(filterDate));
      //}
      return result;
    },
    filter(courseList, filterDate) {
      return courseList.filter(course => {
        return (
          course.startTime >= filterDate &&
          course.startTime < m2.date.addDays(filterDate, 1)
        );
      });
    },
    resetCalendar(calendar) {
      if (this.courseList[0] && this.courseList[0].startTime) {
        calendar.ChoseMonth(this.courseList[0].startTime);
      }
    },
    // initMuiPullRefresh() {
    //   this.$nextTick(() => {
    //     for (var i = mui.hooks.inits.length - 1, item; i >= 0; i--) {
    //       item = mui.hooks.inits[i];
    //       if (item.name == "pullrefresh") {
    //         item.repeat = true;
    //       }
    //     }
    //     mui.initPullRefresh({
    //       container: this.refreshContainer,
    //       pulldownRefresh: this.pulldownRefresh
    //     });
    //   })
    // },
    // pulldownRefresh() {
    //   this.getData(m2.date.firstDay('m'), m2.date.endDay('m'), () => {
    //     this.filterCourseList(this.courseArray, this.today);
    //     this.filterMarkArray(this.courseArray);
    //     this.resetCalMonth();
    //     mui(this.refreshContainer).pullRefresh().endPulldownToRefresh();
    //   });
    // },
    resetCalMonth() {
      // 下拉刷新重置日期通知日历更新
      this.resetMonth = new Date();
    }
  },
  components: {
    CourseToday,
    CourseCalendar,
    HomeTip,
    XuedaNews,
    ClassBreak,
    PaymentDialog
    /*HomeTip,
			  XuedaNews,
			   ClassBreak,
			   HomeFooter,*/
  }
};
</script>
<style>
/* html,body{
	height: 100%;
	overflow: hidden;
} */
</style>

<style lang="scss" scoped>
.xiaoying {
  margin-top: 30px;
  padding: 5px 10px;
  border: 1px solid #999;
  border-radius: 6px;
  display: inline-block;
}
.mask {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.3);
  z-index: 998;
  .mask-box {
    position: fixed;
    width: torem(300);
    height: torem(350);
    border-radius: torem(8);
    background-color: #fff;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    margin: auto;
    padding: torem(15);
    text-align: center;
  }
}
.xd-home {
  width: 100%;
  overflow: auto;
  overflow-y: scroll;
}
.container {
  background: url(~@/public/asset/img/bg/home-bg.png) repeat-x;
  background-size: 100% 260px;
  background-color: #fff;
  height: 100vh;
  overflow: hidden;
}
.xueda-news {
  background: #fff;
  width: 100%;
  margin-top: torem(-1);
  padding: torem(10) 0;
}

.xd-news {
  padding-top: torem(20);
  display: flex;
  padding: 10px 0 0 10px;
  padding: 0 torem(23);
  align-items: center;
  height: torem(40);
  background-color: #fff;
  p {
    margin-bottom: 0;
  }
  div {
    display: flex;
    align-items: center;
  }
  .xueda-img {
    width: torem(22);
    height: torem(22);
    border-radius: 100%;
    margin-right: torem(6);
    border: 1px solid #fff;
    overflow: hidden;
    img {
      width: 100%;
      height: 100%;
    }
  }
  span {
    color: #8f8f94;
    font-size: torem(14);
  }
  span.tit {
    font-size: torem(15);
    font-weight: bold;
  }
}
.content {
  display: flex;
  height: 40px;
  line-height: 40px;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  p {
    margin-bottom: 0;
  }
  .paymentBtn {
    color: skyblue;
  }
}
.question {
  position: fixed;
  right: torem(10);
  top: torem(246);
  z-index: 1;
  img {
    width: 100%;
    height: 100%;
  }
}
.big {
  width: torem(50);
  height: torem(50);
}
.small {
  width: torem(30);
  height: torem(30);
}
</style>