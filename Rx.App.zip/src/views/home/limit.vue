﻿<template>
  <div class="limit">
    
    <xueda-news></xueda-news>
    <class-break></class-break>
    <div style="display:none">{{this.$route.name +Math.random()}}</div>
      
  </div>
</template>
<script>
import { loadUserInfo, getCurrentChild } from "@/api/common/common-api";
import ClassBreak from "./partials/class-break";
import XuedaNews from "./partials/xueda-news";

export default {
  async created() {
    await loadUserInfo('upd')
    if(!m2.cache.get('rx-current-user').children.length){
      this.$store.commit('changeFooterTab','limited')
    }else{
      this.$store.commit('changeFooterTab','normal')
    }
    
  },
  async updated() {
    await loadUserInfo('upd')
    if(!m2.cache.get('rx-current-user').children.length){
      this.$store.commit('changeFooterTab','limited')
    }else{
      this.$store.commit('changeFooterTab','normal')
    }
    
  },
  components: {
    XuedaNews,
    ClassBreak,
  }
}
</script>

<style lang="scss" scoped>
  .limit{
    .box{
      background: #fff;
      padding: 40px;
      text-align: center;
      p{
        font-size: 14px;
      }
    }
  }
</style>
