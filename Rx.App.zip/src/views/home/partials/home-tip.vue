﻿<template>
  <div class="rx-home-tip" v-if="this.$route.name=='home'&&this.isClose" >
    <dl>
      <dt><img src="~@/public/asset/img/home/tip.png" alt=""/></dt>
      <dd>
        <span>您的账户已不足1000元，为了不影响孩子上课，建议联系学管师进行充值。</span>
      </dd>
    </dl>
    <div class="rx-home-error"><img src="~@/public/asset/img/home/off.png" alt="" @click="close()"/></div>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        isClose: true
      }
    },
    methods: {
      close(){
        this.isClose = false;
      }
    }
  }
</script>
<style lang="scss" scoped>
  .rx-home-tip {
    width: 100%;
    height: torem(50);
    padding: 10px 15px;
    background-image: linear-gradient(-129deg, #FF9D00 0%, #FFD635 100%);
    position: fixed;
    bottom:53px;
    z-index: 10000;
    dl {
      width: 100%;
      height: 100%;
      display: flex;
      align-content: center;
      dt {
        width: torem(31);
        height: torem(31);
        background-color: #fff;
        border-radius: 100%;
        img {
          width: 100%;
          height: 100%;
          border-radius: 100%;
        }
      }
      dd {
        display: flex;
        flex-direction: column;
        justify-content: center;
        margin-left: 15px;
        span {
          @include letterStyle(14, #955800, 0, 20);
          font-size: torem(14);
        }
      }
    }
  }

  .rx-home-error {
    position: absolute;
    top: 0;
    bottom: 0;
    right: torem(20);
    margin: auto 0;
    border-radius: 100%;
    width: torem(16);
    height: torem(16);
    text-align: center;
    line-height: torem(16);
  }
</style>
