<template>
  <div class="xueda-news">
    <div class="xd-news">
      <p class="xueda-img">
        <img src="~@/public/asset/img/payment/payment.png" />
      </p>
      <span class="tit">代缴费提醒</span>
    </div>
    <div>
      <div class="content">
        <p>
          <span>【{{paymentData.chargeMoney | numberToMoney}}元】</span>
          <span>{{paymentData.submitterJobName}} ：</span>
          <span>{{paymentData.submitterName}}</span>
        </p>
        <p class="paymentBtn" @click="goPayment($event)">立即付款</p>
      </div>
      <payment-dialog
        :maskShow="isShowPaymentDialog"
        :paymentAmount="paymentData.chargeMoney"
        :remindPaymentId="paymentData.applyID"
        @changeDialogShow="changeDialogShowFun($event)"
      ></payment-dialog>
    </div>
  </div>
</template>
<script>
import PaymentDialog from "@/components/payment-dialog";
export default {
  data() {
    return {
      isShowPaymentDialog: false
    };
  },
  props: {
    paymentData: {
      type: Object,
      required: {}
    }
  },
  methods: {
    goPayment(e) {
      // console.log(e.path[7].scrollTop);
      // if (mui.os.android) {
      //   if (e.path[7].scrollTop < 120) {
      //     e.path[7].scrollTop = "120";
      //   }
      //   if (e.path[7].scrollTop > 590) {
      //     e.path[7].scrollTop = "590";
      //   }
      // }
      setTimeout(() => {
        this.isShowPaymentDialog = true;
      }, 0);
      window.xdapp.goOut = "remind"; //点击付款的页面 进行标识
    },
    changeDialogShowFun(msg) {
      this.isShowPaymentDialog = msg;
    }
  },
  components: {
    PaymentDialog
  }
};
</script>
<style lang="scss" scoped>
.xueda-news {
  background: #fff;
  width: 100%;
  margin-top: torem(-1);
  padding: torem(10) 0;
}

.xd-news {
  padding-top: torem(20);
  display: flex;
  padding: 10px 0 0 10px;
  padding: 0 torem(23);
  align-items: center;
  height: torem(40);
  background-color: #fff;
  p {
    margin-bottom: 0;
  }
  div {
    display: flex;
    align-items: center;
  }
  .xueda-img {
    width: torem(22);
    height: torem(22);
    border-radius: 100%;
    margin-right: torem(6);
    border: 1px solid #fff;
    overflow: hidden;
    img {
      width: 100%;
      height: 100%;
    }
  }
  span {
    color: #8f8f94;
    font-size: torem(14);
  }
  span.tit {
    font-size: torem(15);
    font-weight: bold;
  }
}
.content {
  display: flex;
  height: 40px;
  line-height: 40px;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  p {
    margin-bottom: 0;
  }
  .paymentBtn {
    color: skyblue;
  }
}
</style>
