<template>
  <div class="rx-course-list ribbon">
    <div class="t-c" v-if="!course">
      <p>今天没课喔~</p>
      <p>放心休息，关注近期课程。</p>
    </div>
    <div @tap="toLink">
      <div class="rx-course-overview" v-if="course">
        <dl>
          <dt>
            <span v-if="course.teacherIcons" class="mui-media-object mui-pull-left">
              <img v-if="course.teacherIcons.iconID" :src="getIconImg(course.teacherIcons.userID)" />
              <img
                v-else-if="course.teacherIcons.gender==2"
                src="~@/public/asset/img/user/teacher-woman.png"
                alt
              />
              <img
                v-else-if="course.teacherIcons.gender==1"
                src="~@/public/asset/img/user/teacher-man.png"
                alt
              />
            </span>
          </dt>
          <dd>
            <b>{{course.teacherName}}</b>
            <span>老师</span>
          </dd>
        </dl>
        <ul>
          <li>{{course.startTime | dateFormat({locale: 'zh-CN'})}}</li>
          <li>{{course.startTime | timeRange(course.endTime, {locale: 'zh-CN'})}}</li>
          <li>
            <div>
              <span class="mui-badge mui-badge-warning" v-if="course.gradeName">{{course.gradeName}}</span>
            </div>
            <span
              class="mui-badge mui-badge-purple"
              v-if="course.subjectName"
            >{{course.subjectName}}</span>
            <!-- <span
              class="mui-badge mui-badge-danger"
              v-if="course.businessType==2 && course.assignStatus==1 && course.isConfirmed"
            >已点名</span> -->
            <span  class="mui-badge mui-badge-success">{{course.assignStatus | assignStatus}}</span>
          </li>
        </ul>
      </div>
      <!--排定-->
      <div class="rx-course-code" v-if="slideType==1">
        <div
          v-if="course.businessType==1  && Date.parse(course.startTime) - 60*90*1000 < Date.parse(new Date()) && Date.parse(new Date()) < Date.parse(course.endTime)+ 60*90*1000"
        >
          <div
            :id="course.assignID"
            class="qr-canvas"
            @tap.stop="toChangeSize(course.resultString,course.startTime,course.endTime)"
          ></div>
          <p class="desc">扫一扫确认课时</p>
        </div>
        <div v-else-if="course.businessType==1">
          <img
            v-if="Date.parse(course.startTime)<Date.parse(new Date())"
            class="course-img"
            src="~@/public/asset/img/course/course-time-out.jpg"
            alt
          />
          <img
            v-if="Date.parse(course.startTime)>Date.parse(new Date())"
            class="course-img"
            src="~@/public/asset/img/course/course-no-start.jpg"
            alt
          />
          <p
            class="desc noneSure"
            v-if="Date.parse(course.startTime)<Date.parse(new Date())"
          >逾期，不可确认</p>
          <p class="desc noneSure" v-if="Date.parse(course.startTime)>Date.parse(new Date())">未到确认时间</p>
        </div>

        <div v-else>
          <img class="course-img" src="~@/public/asset/img/course/course-bg.jpg" alt />
          <p class="desc">好好学习，天天向上</p>
        </div>
      </div>
      <!--已上未评价-->
      <div class="rx-course-code" v-else-if="slideType==2">
        <div class="course-comment">
          <i class="star"></i>
          <span v-show="this.$store.state.currentChild.relation==1" class="link">我要评价</span>
          <span v-show="this.$store.state.currentChild.relation!=1" class="link">查看详情</span>
        </div>
        <p class="desc">谈谈对课程的感受吧</p>
      </div>
      <!--已上已评价-->
      <div class="rx-course-code" v-else-if="slideType==3">
        <div class="course-comment">
          <i class="star on"></i>
          <span class="link">课后评价</span>
        </div>
        <p class="desc">查看课程的评价记录</p>
      </div>
      <div class="wrapper" v-show="course && course.businessType">
        <span
          class="inner-ribbon"
          v-if="course.businessType && course.categoryType != 8"
        >{{course.businessType | businessTypeSup}}</span>
        <span class="inner-ribbon" v-else>{{course.businessType | businessTypeCat}}</span>
      </div>
    </div>
  </div>
</template>
<script>
import store from "@/store";
import * as types from "@/store/mutation-types";
import {
  CACHE_KEYS,
  ASSIGN_STATUS,
  SLIDE_STATUS,
  COURSE_EVALUATE_SCORE_CONFIG as scoreConfig
} from "@/constants";
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/qrcode/jquery.qrcodeReview";
export default {
  data() {
    return {
      scoreConfig: scoreConfig,
      icons: []
    };
  },
  props: ["course"],
  methods: {
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },
    getUserIcons() {
      if (this.course.teacherIcons && this.course.teacherIcons.iconID) {
        var userIcons =
          m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD) ||
          this.$store.state.headList.slice() ||
          [];

        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(
            i => i.userID === this.course.teacherIcons.userID
          );
        }
        if (
          curIcon /*&& ((Date.parse(new Date()) - Date.parse(curIcon.dates)) < HEAD_EXPIRY_TIME)*/
        ) {
          this.icons.push({
            userID: this.course.teacherIcons.userID,
            imgData: curIcon.imgData
          });
        } else {
          getHead(
            {
              iconID: this.course.teacherIcons.iconID
            },
            res => {
              let obj = {
                userID: this.course.teacherIcons.userID,
                imgData: res
              };
              this.icons.push(obj);
              userIcons.push(obj);
              store.commit(types.HEADLIST_ARR, userIcons);
            }
          );
        }
      }
    },
    toChangeSize(content, startTime, endTime) {
      mui.plusReady(() => {
        plus.nativeUI.showWaiting();
      });
      var $container = $("#showSizeCode");
      this.generateQRCode($container, content, startTime, endTime);
      var wrapBox = document.getElementsByClassName("rx-sign-code")[0];
      wrapBox.style.display = "block";
      if (wrapBox.style.display == "block") {
        mui.plusReady(() => {
          plus.nativeUI.closeWaiting();
        });
      }
    },
    generateQRCode(container, content, startTime, endTime) {
      $("#showSizeCode canvas").remove();
      container.qrcodeReview({
        render: "canvas", //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
        text: content, //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
        width: 220, //二维码的宽度
        height: 220, //二维码的高度
        background: "#fff", //二维码的后景色
        foreground: "#000", //二维码的前景色 //二维码中间的图片
        startTime: startTime,
        endTime: endTime,
        // pdding: 20,
        /*src: '@/public/asset/img/user/boy.png',*/ correctLevel: 1
      });
    },
    toLink() {
      if (this.slideType == 2) {
        if (m2.cache.get("rx-current-child").relation != 1) {
          this.$router.push({
            name: "course-detail",
            query: {
              assignID: this.course.assignID,
              customerID: this.course.customerID,
              teacherID: this.course.teacherID,
              type: 0
            }
          });
        } else {
          this.$router.push({
            name: "course-evaluate",
            query: {
              assignID: this.course.assignID,
              customerID: this.course.customerID,
              teacherID: this.course.teacherID
            }
          });
        }
      } else {
        this.$router.push({
          name: "course-detail",
          query: {
            assignID: this.course.assignID,
            customerID: this.course.customerID,
            teacherID: this.course.teacherID,
            type: 1
          }
        });
      }
      //this.$router.push({name:this.slideType==2?'course-evaluate':'course-detail', query:{assignID:this.course.assignID}})
    },
    getCourseItems(evaluate) {
      return [
        {
          key: "goal",
          title: "辅导目标",
          score: evaluate.goal || 0,
          desc: this.getScoreDesc(evaluate.goal)
        },
        {
          key: "attitude",
          title: "授课态度",
          score: evaluate.attitude || 0,
          desc: this.getScoreDesc(evaluate.attitude)
        },
        {
          key: "atmosphere",
          title: "课堂氛围",
          score: evaluate.atmosphere || 0,
          desc: this.getScoreDesc(evaluate.atmosphere)
        },
        {
          key: "logic",
          title: "逻辑严谨",
          score: evaluate.logic || 0,
          desc: this.getScoreDesc(evaluate.logic)
        },
        {
          key: "style",
          title: "形式新颖",
          score: evaluate.style || 0,
          desc: this.getScoreDesc(evaluate.style)
        }
      ];
    },
    getScoreDesc(val) {
      let config = scoreConfig.find(item => item.value == val);
      if (!config) return undefined;
      return config.desc;
    }
  },
  computed: {
    slideType() {
      if (!this.course) {
        return SLIDE_STATUS.DEFAULT;
      }
      if (this.course.assignStatus == ASSIGN_STATUS.Assigned) {
        return SLIDE_STATUS.ASSIGNED;
      }
      if (this.course.assignStatus == ASSIGN_STATUS.Confirmed) {
        return this.course.evaluate
          ? SLIDE_STATUS.COMMENTED
          : SLIDE_STATUS.UNCOMMENT;
      }
    }
  },
  watch: {
    course: {
      handler: function() {
        this.getUserIcons();
      },
      deep: true
    }
  }
};
</script>
<style lang="scss">
i.star {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/star.png) no-repeat;
  background-size: 100%;
  width: torem(12);
  height: torem(12);
  margin-right: torem(5);
}

i.star.on {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/staron.png) no-repeat;
  background-size: 100%;
  width: torem(12);
  height: torem(12);
  margin-right: torem(5);
}

.rx-course-list {
  width: torem(320);
  height: torem(190);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: torem(20) torem(15) torem(15);
  background: rgba(255, 255, 255, 0.95);
  box-shadow: 0 2px 34px 0 rgba(125, 93, 39, 0.25);
  border-radius: 8px;
  margin: 5px auto 0;
  &.ribbon {
    display: inline-flex;
    position: relative;
    float: left;
    background-size: cover;
    text-transform: uppercase;
    color: #fff;
    .wrapper {
      width: 22%;
      height: torem(73);
      position: absolute;
      top: -8px;
      left: torem(256);
      overflow: hidden;
    }
    .wrapper:before {
      content: "";
      display: block;
      border-radius: 8px 8px 0px 0px;
      width: 20px;
      height: 8px;
      position: absolute;
      right: 50px;
      background: #4d6530;
    }
    .inner-ribbon {
      display: inline-block;
      text-align: center;
      width: 128px;
      height: 20px;
      line-height: 18px;
      position: absolute;
      top: 16px;
      text-indent: -8px;
      right: -46px;
      z-index: 2;
      overflow: hidden;
      transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      -moz-transform: rotate(45deg);
      -webkit-transform: rotate(45deg);
      -o-transform: rotate(45deg);
      border: 1px dashed;
      -webkit-box-shadow: 0 0 0 3px #00b3ed,
        0px 21px 5px -18px rgba(0, 0, 0, 0.6);
      box-shadow: 0 0 0 3px #00b3ed, 0px 21px 5px -18px rgba(0, 0, 0, 0.6);
      background: #00b3ed;
    }
    .wrapper:after {
      content: "";
      display: block;
      border-radius: 0px 8px 8px 0px;
      width: 8px;
      height: 20px;
      position: absolute;
      right: 0px;
      top: 50px;
      background: #4d6530;
    }
  }
}

.rx-course-overview {
  margin-top: torem(-5);
  margin-right: torem(18);
  float: left;
  dl {
    display: flex;
    margin-bottom: torem(20);
    dt {
      width: torem(48);
      height: torem(48);
      margin-right: torem(12);
      overflow: hidden;
      img {
        width: 100%;
        height: 100%;
        border-radius: 100%;
      }
    }
    dd {
      display: flex;
      flex-direction: column;
      justify-content: center;
      flex: 1;
      b {
        @include letterStyle(20, #333, -0.33, 28);
        @include overHidden(1);
      }
      span {
        @include letterStyle(13, #666, -0.2, 18);
      }
    }
  }
  ul {
    li {
      @include letterStyle(13, #666, -0.27, 23);
      span {
        display: inline-block;
      }
    }
  }
}

.rx-course-code {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: transparent;
  .qr-canvas {
    width: torem(120);
    height: torem(120);
    text-align: center;
    padding-top: 3%;
  }
  .desc {
    @include letterStyle(10, #808080, 2, 21);
    margin-bottom: torem(5) !important;
    text-align: center;
    transform: translate(0, 7px);
  }
  .desc.noneSure {
    transform: translate(0, 2px);
  }
  .course-img {
    width: torem(130);
    height: torem(130);
    transform: translate(0, 4px);
    border-radius: 12px;
  }
  .course-comment {
    background: rgba(255, 255, 255, 0.89);
    -webkit-box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    border-radius: 12px;
    height: torem(130);
    padding-top: 25%;
    bottom: 0;
    width: torem(130);
    text-align: center;
    color: #999;
    .star {
      display: inline-block;
      text-align: center;
      width: torem(40);
      height: torem(40);
    }
    .link {
      display: block;
      margin-top: torem(5);
      color: #777;
    }
  }
}

.swiper-wrapper {
  display: flex;
  .swiper-slide {
    width: 86% !important;
    margin-left: 2.3333%;
    margin-top: 4px;
    margin-bottom: 25px;
  }
  .swiper-slide-next,
  .swiper-slide-prev {
    height: torem(171);
    .rx-course-list {
      height: torem(171);
      margin-top: torem(15);
    }
  }
}
</style>
