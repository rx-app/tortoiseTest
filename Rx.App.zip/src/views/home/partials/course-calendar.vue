﻿<template>
	<div class="rx-couse-calendar">
		<Calendar @choseDay="switchDay" @changeMonth="switchMonth" @isToday="clickToday" :markArray="markArray" ref="course-calendar" class="rx-calendar" />
	</div>
</template>
<script>
	import Vue from "vue"
	import Calendar from 'vue-calendar-component';
	Vue.use(Calendar);
	export default {
		data() {
			return {
				demoEvents: [],
				prev: m2.date.today(),
				current: m2.date.today()
			}
		},
		props: ['markArray', 'resetMonth'],
		watch: {
			resetMonth() {
				this.$refs['course-calendar'].ChoseMonth(this.resetMonth);
			}
		},
		updated () {
			// 获取当前月份
			let currMonth = new Date().getMonth() + 1
			let currDay = new Date().getDate()
			let currYear = new Date().getFullYear()
			let currDate = currYear + '/' + currMonth + '/' + currDay
			this.$refs['course-calendar'].list.map(one => {
				if (this.$store.getters.currentChild.id !== window.swithChildOldID && currMonth === new Date(one.date).getMonth() + 1) {
					one.isToday = false
				}
				if (currDate === one.date) {
					one.isToday = true
					one.isTodayNow = true
				}
			})
		},
		methods: {
			monthChange(month) {
				console.log('month', month)
			},
			dayChange(day) {
				console.log('day=' + day);
			},
			clickToday(data) {
				console.log('clickToday=', data);
			},
			switchDay(data) {
				console.log('switch day:', data);
				this.prev = m2.date.normalize(data);
				this.current = m2.date.normalize(data);
				this.$emit('switchDay', this.current);
			},
			switchMonth(data) {
				console.log('switch month:', data);

				this.current = m2.date.normalize(data);
				window.rx_home_date=this.current;
				if(!m2.date.isOneMonth(this.current, this.prev)) {
					this.$emit('switchMonth', {
						calendar: this.$refs['course-calendar'],
						current: this.current
					});
				}
				this.prev = this.current;
			}
		}
	}
</script>
<style lang="scss">
	.wh_jiantou1,
	.wh_jiantou2 {
    width:9px;
    height:9px;
		border-top: 1px solid #979797;
		border-left: 1px solid #979797;
	}

	.wh_jiantou2 {
		transform: rotate(135deg);
	}

	.wh_top_changge .wh_content_li {
		color: #808080;
	}

	.wh_content_item {
		font-size: torem(14)!important;
		color: #7B7978;
		width: 14.28%;
        padding-bottom:12%;
	}

  .wh_content_item div {
    padding-top: torem(10);
  }
  .wh_content_item div .wh_isToday {
		background: #FFA300;
		color: #fff;
	}

	.wh_content_item div .isTodayNow {
		background: #E03229;
		color: #fff;
	}

	.wh_content_item div .wh_isMark {
		border: 1px solid transparent !important;
	}

	.wh_content_all {
		background-color: #fff;
	}

	.wh_isMark:after {
		background: #c0392b;
		border-radius: 50%;
		bottom: 2px;
		display: block;
		content: '';
		height: 4px;
		left: 50%;
		margin: -4px 0 0 -1px;
		position: absolute;
		width: 4px;
	}

	.wh_content_item li {
		width: 36px;
		height: 36px;
		line-height: 36px;
	}

	.wh_content_item div .isTodayNow:after,
	.wh_content_item div .wh_isToday:after {
		background: #fff;
	}

  @media only screen and (max-width: 320px){
    .wh_content_item div {
      padding-top: torem(0) !important;
    }
    .wh_content_item {
      padding-bottom: 13% !important;
    }
  }

  @media only screen and (min-width: 321px) and (max-width: 384px){
    .wh_content_item div {
      padding-top: torem(5) !important;
    }
  }

  @media only screen and (min-width: 384px){
    .wh_content_item div {
      padding-top: torem(10) !important;
    }
  }

</style>
