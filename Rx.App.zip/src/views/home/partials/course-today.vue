﻿<template>
  <div class="rx-course-today">
    <course-slide :course="0" v-if="!courseList.length" />
    <course-slide :course="courseList[0]" v-else-if="courseList.length==1" />
    <!-- <swiper :options="m2.date.isOneDay(courses[0].startTime,new Date())?swiperOption:swiperOption2" v-else> -->
    <template v-else>
      <swiper v-if="flag" :options="swiperOption">
        <swiper-slide v-for="(course, index) in courseList" :key="index">
          <course-slide :course="course" />
        </swiper-slide>
        <div class="swiper-pagination" slot="pagination"></div>
      </swiper>
    </template>
  </div>
</template>
<script>
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/qrcode/jquery.qrcode";
import "swiper/dist/css/swiper.css";

import { swiper, swiperSlide } from "vue-awesome-swiper";
import courseSlide from "./course-slide";
import { setTimeout } from "timers";
export default {
  data() {
    return {
      i: 0,
      flag: true
      // n:2,
    };
  },
  props: ["courseList", "filterDay", "n"],
  mounted() {
    // console.log(this.courses)
  },
  computed: {
    cList() {
      return this.courseList;
    },
    courses() {
      return this.courseList /*.reverse()*/;
    },
    swiperOption() {
      return {
        pagination: {
          el: ".swiper-pagination"
        },
        initialSlide: this.getNearestCourse(this.courseList),
        slidesPerView: "auto",
        centeredSlides: true,
        on: {
          slideChangeTransitionEnd: function() {
            console.log(this.activeIndex)
            courseTodayThis.$emit("activeIndex", this.activeIndex); //切换结束时，告诉我现在是第几个slide
          }
        },
        zoom: {
          maxRatio: 5, //最大倍数
          minRatio: 2, //最小倍数
          toggle: true, //不允许双击缩放，只允许手机端触摸缩放。
          containerClass: "my-zoom-container" //zoom container 类名
        }
      };
    }
  },
  watch: {
    courseList() {
      window.courseTodayThis = this;
      this.flag = false;
      setTimeout(() => {
        this.flag = true;
        this.$nextTick(() => {
          this.renderCourseQRCode();
        });
      }, 10);
    }
  },
  methods: {
    getNearestCourse(list) {
      if (this.courses.length == 0) {
        return 0;
      }
      if (!m2.date.isOneDay(this.courses[0].startTime, new Date())) {
        console.log("ttt");
        return 0;
      }
      let times = [];
      list.forEach((v, i) => {
        times.push(v.startTime.getTime());
        times.push(v.endTime.getTime());
      });
      let now = Date.now();
      let newList = times.map(v => {
        return v - now;
      });
      // debugger
      let clone = [...newList];
      let res = newList.sort((a, b) => Math.abs(a) - Math.abs(b) || b - a)[0];
      let index = clone.indexOf(res);
      console.log(index);
      console.log(newList);
      // debugger
      return Math.ceil((index + 1) / 2) - 1;
    },
    generateQRCode(container, content) {
      var ele = document.getElementById(container);
      var $container = $("#" + container);
      $container.qrcode({
        render: "canvas", //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
        text: content, //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
        width: ele ? ele.offsetWidth : 0, //二维码的宽度
        height: ele ? ele.offsetHeight : 0, //二维码的高度
        background: "#ffffff", //二维码的后景色
        foreground: "#000000", //二维码的前景色
        //src: 'ppts.App/src/assets/photo.jpg', 二维码中间的图片
        correctLevel: 1
      });
    },
    renderCourseQRCode() {
      $("canvas").remove();
      this.courses.forEach(item => {
        this.generateQRCode(item.assignID, item.resultString);
      });
    }
  },
  components: {
    swiper,
    swiperSlide,
    courseSlide
  }
};
</script>
<style lang="scss">
.rx-course-today {
  margin-top: torem(5);
  background: transparent;
  height: 60vw;
  display: flex;
}

.swiper-pagination-bullets {
  bottom: 0px !important;
}

.swiper-slide-prev {
  margin-left: 1.555% !important;
}

@media only screen and (max-width: 320px) {
  .rx-course-today {
    margin-bottom: torem(20);
  }
}
</style>
