<template>
	<div class="down-top">

		<div class="down-box">
			<div v-if="!isWexin" v-for="(item, i) in list" :key="i">
				<a :href="item.downloadUrl" :style="item.sysType !== 'IOS' ? 'background:rgb(135,196,63)' : ''">
					<span class="img-box">
            <img v-if="item.sysType === 'IOS'" :src="require('@/public/asset/img/edu/icon_ios.png')" alt="">
            <img v-else :src="require('@/public/asset/img/edu/icon_android.png')" alt="">
          </span>
					<span class="loadName" v-if="item.sysType === 'IOS'">IPhone下载</span>
					<span class="loadName" v-else>Android下载</span>
				</a>
				<div class="db-txt" v-html='item.versionInfo'></div>
			</div>
			<div v-if="isWexin" style="font-size: .5rem;line-height: 2">
				点击右上角-在浏览器打开，<br>就能下载啦~~~
			</div>
		</div>
	</div>
</template>
<script>
	import { getAppInfo } from '@/api/common/common-api';
	export default {
		data() {
			return {
				isWexin: false,
				list: []
			}
		},
		created() {
			this.isWexin = this.is_weixn()
			this.eastToken()
		},
		methods: {
			is_weixn() {
				return navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1
			},
			getDonwAdress() {
				getAppInfo({}, (res) => {
					this.list = res;
				})
			},
			eastToken() {
				this.getDonwAdress()
			},
		}
	}
</script>
<style lang="scss" scoped>
	.down-top {
		padding-top: 0 !important;
		/* overflow: hidden; */
	}
	
	.weixin-box {
		position: absolute;
		width: 100%;
		height: 100%;
		overflow: hidden;
	}
	
	.weixin-box img {
		width: 100%;
		height: 100%;
	}
	
	.down-box {
		position: absolute;
		/*text-align: center;*/
		width: 100%;
		height: 100%;
		padding-left: torem(20);
		background: url(~@/public/asset/img/edu/bg.png) repeat;
		box-sizing: border-box;
	}
	
	.down-box a {
		display: flex;
		width: 55%;
		margin: 20px auto 0;
		background: rgba(255, 188, 0, 1);
		border-radius: 10px;
		align-content: center;
		justify-content: space-between;
		padding: 10px;
		color: #fff;
		font-size: .5rem;
		margin-bottom: torem(10);
	}
	
	.down-box .img-box {
		display: inline-block;
		flex-basis: 1.5rem;
		text-align: center;
	}
	
	.down-box img {
		width: 85%;
		height: 100%;
	}
	
	.loadName {
		line-height: torem(60);
	}
	.db-txt{
		padding-left: 35%;
	}
</style>