﻿<template>
  <div class="xd-regist">
    <h3 class="xd-regist-title">注册</h3>
    <p class="xd-regist-inp inp-margin">
      <img :src="phoneStyle?require('@/public/asset/img/user/phone-on.png'):require('@/public/asset/img/user/phone-off.png')"  alt="" class="xd-regist-icon"/>
      <input type="tel" placeholder="输入手机号" v-model="criteria.cellNumber" @click="toggleCrUser(1)" />
      <i class="line" :class="phoneStyle?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error" v-show="criteria.cellNumber" @click="delText(1)"></i>
    </p>

    <p class="xd-regist-inp">
      <img :src="cellNumStyle?require('@/public/asset/img/user/code-on.png'):require('@/public/asset/img/user/code-off.png')"  alt="" class="xd-regist-icon"/>
      <input type="text" placeholder="输入手机验证码" style="width:60vw" v-model="criteria.registerCode" @click="toggleCrUser(2)"/>
      <span :disabled="disabled" :class="[criteria.cellNumber.length==11?'xd-regist-codeOn':'xd-regist-codeOff',disabled?'fade':'']" style="border:none" class="mui-btn code" @click="getValidateCode()" >{{btnText}}</span>
      <i class="line" :class="cellNumStyle?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error" v-show="criteria.registerCode" style="right:50vw" @click="criteria.registerCode=''"></i>

    </p>
    <p class="xd-regist-inp">
      <img :src="pwdStyle?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"  alt="" class="xd-regist-icon"/>
      <input :type="inpType" placeholder="6-20位，建议数字和字母组合" v-model="criteria.pwd" @click="toggleCrUser(3)"/>
       <i class="iconfont eye" style="margin-top:-4px" :class="iconStatus" @click="toggleInpType()"></i>
      <i class="line" :class="pwdStyle?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error" v-show="criteria.pwd" @click="delText(3)"></i>
    </p>
    <div type="button" class="mui-btn mui-btn-primary mui-btn-block xd-regist-btn " @click="resgister()"
            :disabled="!(criteria.pwd && criteria.registerCode && criteria.cellNumber )"
             :class="(criteria.pwd && criteria.registerCode && criteria.cellNumber )? 'xd-regist-btnOn':'xd-regist-btnOff'">
      注册
    </div>
    <p class="xd-resgist-link">已有账号
      <router-link class="xd-resgist-link" to="login" tag="span">立即登录</router-link>
    </p>
    <p class="xd-regist-footer">注册则代表您阅读并使用学大教育的
      <router-link class="protocol" :to="{name:'protocol'}">
        《用户协议》
      </router-link>
    </p>
  </div>
</template>

<script>
  import {
    sendUserRegisterCode,
    registerUser,
    registerUserPhoneNumValidate,
    validateUserRegisterCode
  } from '@/api/user/user-api'
import { login } from '@/api/ids/ids-api';
import {loadUserInfo} from '@/api/common/common-api';
function resize2() {//*12*点击输入框时，小键盘挡住了输入框
  if (document.activeElement.tagName == 'INPUT' || document.activeElement.tagName == 'TEXTAREA') {
    window.setTimeout(function () {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}



  export default {
    data() {
      return {
        item: {
          flag: false,
          message: ""
        },
        criteria: {
          cellNumber: '',
          pwd: '',
          registerCode: ''
        },
        validateCode: {
          identity: '',
          phoneNum: ''
        },
        verifyCriteria: {
          cellNumber: '',
          code: ''
        },
        reg: 11 && /^(\d{11})$/,
        pwdReg: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z\+\^\!=:\:@！￥#$~%^&_'\?\(\)\-\*\～\.\(\)\[\]\【\】\（\）\/\|\\\&]{6,20}$/,
        phoneReg: /^[0-9]*$/,
        disabled: false,
        regDisabled: false,
        time: 0,
        btnText: '获取验证码',
        phoneStyle:false,/*手机号输入框触发*/
        cellNumStyle:false,/*验证码输入框触发*/
        pwdStyle:false,/*密码输入框触发*/
        inpType:'password',
        iconStatus:'icon-close-eyes',
      }
    },
    watch:{
      criteria:{
        handler(curVal,oldVal){
          if(curVal.cellNumber.length>=11){
            curVal.cellNumber=curVal.cellNumber.substr(0,11)
          }
        },
        deep:true
      },
      'criteria.cellNumber':function(val,oldval){
        this.criteria.cellNumber=val.replace(/\D+/, '');
      }
    },
    created () {
      if (/Android/gi.test(navigator.userAgent)) {
        window.addEventListener('resize', resize2)
      }
    },
    destroyed(){
      if (/Android/gi.test(navigator.userAgent)) {
          window.removeEventListener('resize', resize2)
      }
    },
    methods: {
      delText(num){
        switch(num){
          case 1:this.criteria.cellNumber='';break;
          case 2:this.criteria.registerCode='';break;
          case 3:this.criteria.pwd='';break;
        }
      },
      toggleInpType() {
				if(this.inpType == 'text') {
					this.inpType = 'password';
					this.iconStatus = 'icon-close-eyes'
				} else {
					this.inpType = 'text';
					this.iconStatus = 'icon-eyes'

				}

			},
      toggleCrUser(num){
          switch(num){
            case 1:
              this.phoneStyle=true;
              this.cellNumStyle=false;
              this.pwdStyle=false;
              break;
            case 2:
              this.phoneStyle=false;
              this.cellNumStyle=true;
              this.pwdStyle=false;
              break;
            case 3:
              this.phoneStyle=false;
              this.cellNumStyle=false;
              this.pwdStyle=true;
              break;
          }

//        this.crPsd=false;
      },
      toggleCrPsd(){
        this.cellNumStyle=false;
//        this.crPsd=true;
      },
      toggleVrUser(){
        this.pwdStyle=true;
//        this.vrPsd=false;
      },
      validatePhone(){
        var _this = this;
        if (!_this.criteria.cellNumber) {
          _this.regDisabled = true;
          _this.phoneStyle = "inp-lineOn line"

          mui.alert('请输入手机号!', function () {
            _this.regDisabled = false;
          });
          return 1;
        } else if (!_this.phoneReg.test(_this.criteria.cellNumber)) {
          _this.regDisabled = true;
          _this.phoneStyle = "inp-lineOn line"
          mui.alert("手机号码必须为数字!", function () {
            _this.regDisabled = false;
          })
          // _this.criteria.cellNumber = '';
          return 1;
        } else if (!_this.reg.test(_this.criteria.cellNumber)) {
          _this.regDisabled = true;
          _this.phoneStyle = "inp-lineOn line"
          mui.alert("手机号码格式不正确!", function () {
            _this.regDisabled = false;
          })
          //_this.criteria.cellNumber = '';
          return 1;
        } else {
          _this.validateCode.phoneNum = _this.criteria.cellNumber;
          return 0;
        }

      },
      verificationCode(){
        var _this = this;
        if (_this.validatePhone() == 0) {
          if (!_this.criteria.registerCode) {
            _this.regDisabled = true;
            _this.cellNumStyle = "inp-lineOn line"
            mui.alert("请输入短信验证码!", function () {
              _this.regDisabled = false;
            })
            return 1;
          } else {
            _this.verifyCriteria.cellNumber = _this.criteria.cellNumber
            _this.verifyCriteria.code = _this.criteria.registerCode;
            return 0;
          }
        } else {
          return 1;
        }
      },
      getValidate() {
        var _this = this;
        if (!_this.criteria.registerCode) {
          _this.regDisabled = true;
          _this.cellNumStyle = "inp-lineOn line"
          mui.alert("请输入短信验证码!", function () {
            _this.regDisabled = false;
          })
          return 1;
        } else if (!_this.criteria.pwd) {
          _this.regDisabled = true;
          _this.criteria.pwd = '';
          _this.pwdStyle = "inp-lineOn line"
          mui.alert("请输入密码!", function () {
            _this.regDisabled = false;
          })
          return 1;
        } else if (!_this.pwdReg.test(_this.criteria.pwd)) {
          _this.regDisabled = true;
          _this.criteria.pwd = '';
          _this.pwdStyle = "inp-lineOn line"
          mui.alert("密码设置6-20位，支持字母+数字，或字母+数字+符号，符号建议使用~!@#$%^&*_-", function () {
            _this.regDisabled = false;
          })
          return 1;
        }
      },
      timer() {
        if (this.time > 0) {
          this.time--;
          this.btnText = this.time + 's后重新获取';
          this.disabled = true;
          setTimeout(this.timer, 1000);
        } else {
          this.disabled = false;
          this.btnText = '获取验证码';
        }
      },
      //发送手机验证码
      getValidateCode() {
        if(this.disabled){
          return
        }
        event.preventdefault;   
				event.stopPropagation(); 
        let codeMsg = this.validatePhone();
        if (codeMsg != 1) {
          registerUserPhoneNumValidate(
            this.validateCode, (res) => {
              if (res.isValidated == false) {
                // this.criteria.cellNumber = '';
                mui.alert(res.errorMsg);
              } else {
                this.time = 60;
                this.disabled = true;
                this.timer();
                sendUserRegisterCode(
                  this.criteria.cellNumber, (res) => {
                    mui.alert('发送成功');
                  },
                  (error) => {
                    mui.alert(error.message)
                  }
                )
              }
            }
          )
        }
      },
      setCacheAccounts (account) {
          let set = new Set()
          let accounts = window.localStorage.getItem('accountList')
          if (accounts === 'null' || accounts === null || typeof accounts === 'undefined') {
            accounts = []
          } else {
            accounts = JSON.parse(window.localStorage.getItem('accountList'))
          }
          // 去重，并将优选级提升到队列最后，然后反转
          accounts.map((one, i) => {
            if (one.username === account.username) {
              accounts.splice(i, 1); 
            }
          })
          accounts.push({
            username: account.username,
            password: account.password
          })
          accounts.reverse()
          console.log(JSON.stringify(accounts, null, 2))
          // 去重
          window.localStorage.setItem('accountList', JSON.stringify([...new Set(accounts)]));
      },
      //注册
      resgister() {
        if (this.verificationCode() == 0) {
          validateUserRegisterCode(
            this.verifyCriteria, (res) => {
              if (res) {
                let message = this.getValidate();
                if (message != 1) {
                  this.regDisabled = true;
                  registerUser(
                    this.criteria, (res) => {
                      if (!res.description) {
                        mui.alert('注册成功');
                        login( {
                            username: this.criteria.cellNumber,
                            password: this.criteria.pwd
                          }, 
                          async (res) => {
                            this.setCacheAccounts({
                            username: this.criteria.cellNumber,
                            password: this.criteria.pwd
                          })
                            await loadUserInfo('upd');
                            window.legalUser=true;
                            this.$router.push({
                              name: "home"
                            });
                        });
                      }
                    },
                    (error) => {
                      // mui.alert(error.response.data.description);
                    }
                  )
                }
              } else {
                this.cellNumStyle = "inp-lineOn line"
                mui.alert('验证码错误');
                return;
              }
            }
          )
        }

      }
    }
  }
</script>

<style lang="scss" scoped="">
span.code.xd-regist-codeOn.fade{
  background:#ccc;
}
  .mui-btn {
      height: 44px;
      border-radius: 100px;
      -webkit-border-radius: 100px;
      border: none;
      width: torem(314);
      font-size: torem(16);
      line-height: torem(16);
      color: #fff;
  }
	.xd-regist {
		position: absolute;
		top: 0;
		bottom: 0;
		width: 100%;
		background: url(~@/public/asset/img/bg/bj-pic.png) repeat-x;
		background-size: 100% torem(238);
		display: table-cell;
    background-color: #fff;
	}
  .protocol{
    font-size: 14px;
    color:#ffa713;
  }
	.eye{
		color: #ccc;
		font-size: torem(24);
		position: absolute!important;
		right: torem(60)!important;
		top: torem(16)!important;
	}
</style>
