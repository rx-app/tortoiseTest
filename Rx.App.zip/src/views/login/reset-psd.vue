﻿<template>
	<div class="xd-resetPsd">
		<h3 class="xd-regist-title">重置密码</h3>
		<p class="xd-regist-inp inp-margin">
			<img :src="resetFlag?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')" alt="" class="xd-regist-icon" />
			<input :type="inpTypeAgin" placeholder="设置登录密码" v-model="parameter.newPwd" @click="toggleResetPsd()" />
			<i class="iconfont eye" :class="iconStatusAgin" @click="toggleInpType('Agin')"></i>
			<i class="line" :class="resetFlag?'inp-lineOn':'inp-lineOff'"></i>
			<i class="iconfont icon-error" v-show="parameter.newPwd" @click="delText(1)"></i>
		</p>
		<p class="xd-regist-inp">
			<img :src="aginFlag?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')" alt="" class="xd-regist-icon" />
			<input :type="inpTypeReset" placeholder="重复登录密码" v-model="aginResetPsd" @click="toggleAginPsd()" />
			<i class="iconfont eye" :class="iconStatusReset" @click="toggleInpType('Reset')"></i>
			<i class="line" :class="aginFlag?'inp-lineOn':'inp-lineOff'"></i>
			<i class="iconfont icon-error" v-show="aginResetPsd" @click="delText(2)"></i>
		</p>
		<button type="button" class="mui-btn mui-btn-block xd-regist-btn" :class="parameter.newPwd&&aginResetPsd?'xd-regist-btnOn':'xd-regist-btnOff'" :disabled="parameter.newPwd&&aginResetPsd?false:true" @click="resetPsdAgain()">
			完成
		</button>
		<p class="xd-resgist-link">
			<router-link class="xd-resgist-link" to="reset-mess" tag="span">返回上一步</router-link>
		</p>
	</div>
</template>

<script>
	import { resetUserPwd } from '@/api/user/user-api';
	function resize2() {//*12*点击输入框时，小键盘挡住了输入框
		if (document.activeElement.tagName == 'INPUT' || document.activeElement.tagName == 'TEXTAREA') {
			window.setTimeout(function () {
				document.activeElement.scrollIntoViewIfNeeded();
			}, 0);
		}
	}
	export default {
		data() {
			return {
				resetFlag: false,
				/*控制设置密码框是否被焦点*/
				aginFlag: false,
				/*控制重新输入密码框是否被焦点*/
				aginResetPsd: "",
				/*监测重新输入密码框*/
				parameter: {
					"cellNumber": this.$route.params.verPhone,
					"newPwd": "",
					/*监测设置密码输入密码框*/
					"resetPwdCode": this.$route.params.phoneCode
				},
				inpTypeReset: 'password',
				iconStatusReset: 'icon-close-eyes',
				inpTypeAgin: 'password',
				iconStatusAgin: 'icon-close-eyes',
			}
		},
		methods: {
			toggleInpType(kind) {
				switch(kind) {
					case 'Agin':
						if(this.inpTypeAgin == 'text') {
							this.inpTypeAgin = 'password';
							this.iconStatusAgin = 'icon-close-eyes'
						} else {
							this.inpTypeAgin = 'text';
							this.iconStatusAgin = 'icon-eyes'
						}
						break;
					case 'Reset':
						if(this.inpTypeReset == 'text') {
							this.inpTypeReset = 'password';
							this.iconStatusReset = 'icon-close-eyes'
						} else {
							this.inpTypeReset = 'text';
							this.iconStatusReset = 'icon-eyes'
						}
						break;
				}
			},
			async resetPsdAgain() {
				var _this = this;
				if(!this.parameter.newPwd) {
					mui.alert("请设置登录密码!")
				} else if(!this.aginResetPsd) {
					mui.alert("请重复设置登录密码!")
				} else if(this.parameter.newPwd != this.aginResetPsd) {
					mui.alert("两次密码输入不相同!")
				} else if(!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z\+\^\!=:\:@！￥#$~%^&_'\?\(\)\-\*\～\.\(\)\[\]\【\】\（\）\/\|\\\&]{6,20}$/.test(this.parameter.newPwd)) {
					mui.alert("密码设置6-20位，支持字母+数字，或字母+数字+符号，符号建议使用~!@#$%^&*_-")
				} else {
					resetUserPwd(this.parameter, (res) => {
						this.$router.push({
							name: "login"
						})
					})
				}

			},
			toggleResetPsd() {
				this.resetFlag = true;
				this.aginFlag = false;
			},
			toggleAginPsd() {
				this.resetFlag = false;
				this.aginFlag = true;
			},
			delText(num) {
				switch(num) {
					case 1:
						this.parameter.newPwd = '';
						break;
					case 2:
						this.aginResetPsd = '';
						break;
				}
			}
		},
		created () {
			if (/Android/gi.test(navigator.userAgent)) {
			window.addEventListener('resize', resize2)
			}
		},
		destroyed(){
			if (/Android/gi.test(navigator.userAgent)) {
				window.removeEventListener('resize', resize2)
			}
		},
		beforeRouteEnter(to, from, next) {
			document.body.style.background = '#fff';
			next();
		},
		beforeRouteLeave(to, from, next) {
			document.body.style.background = '#efeff4';
			next();
		},
		mounted: function() {
			console.log(this.$route)
		}
	}
</script>

<style lang="scss" scoped>
	.mui-btn {
		height: 44px;
		border-radius: 100px;
		-webkit-border-radius: 100px;
		border: none;
		width: torem(314);
		font-size: torem(16);
		line-height: torem(16);
		color: #fff;
	}
	
	.xd-resetPsd {
		width: 100%;
		background: url(~@/public/asset/img/bg/bj-pic.png) repeat-x;
		background-size: 100% torem(238);
		background-color: #fff;
	}
	
	#v_container {
		width: torem(91);
		height: torem(30);
		position: absolute;
		top: 0;
		left: torem(234);
		bottom: 0;
		right: 0;
		margin: auto 0;
	}
	
	.eye {
		color: #ccc;
		font-size: torem(24);
		position: absolute!important;
		right: torem(60)!important;
		top: torem(16)!important;
	}
</style>