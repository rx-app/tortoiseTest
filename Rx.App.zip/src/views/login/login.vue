﻿<template>
  <div class="xd-login">
    <h3 class="xd-regist-title">登录</h3>
    <div id="slider" class="mui-slider" data-slider="4">
      <div
        id="sliderSegmentedControl"
        class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted"
      >
      <!-- <button @click="clearCache">点击</button> -->
        <a class="mui-control-item mui-active nth_child" href="#item1mobile">账号登录</a>
        <a class="mui-control-item" href="#item2mobile">验证码登录</a>
      </div>
      <div id="item1mobile" class="mui-slider-item mui-control-content mui-active">
        <div id="scroll1" class="mui-scroll-wrapper" data-scroll="1">
          <div class="mui-scroll" style="transform: translate3d(0px, 0px, 0px) translateZ(0px);">
            <div class="befor_psd">
              <div class="xd-regist-inp">
                <img
                  :src="crUser?require('@/public/asset/img/user/phone-on.png'):require('@/public/asset/img/user/phone-off.png')"
                  alt
                  class="xd-regist-icon"
                />
                <input
                  ref="refPhone"
                  style="color:#999"
                  type="tel"
                  placeholder="输入手机号码"
                  v-model="criteria.username"
                  @click="toggleCrUser()"
                  @focus="isShowInputSelect(criteria.username, 'isshow')"
                  @blur="hideInput('isshow')"
                />

                <i class="line" :class="crUser?'inp-lineOn':'inp-lineOff'"></i>
                <i class="iconfont icon-error" v-show="criteria.username" @click="delText(1)"></i>
                <div class="input-associate" v-show="isshow">
                  <ul>
                    <li
                      v-for="(item, i) in selectAccounts"
                      :key="i"
                      @click="setInputUserName('criteria', item, 'isshow')"
                    >{{item.username}}</li>
                  </ul>
                </div>
              </div>
              <p class="xd-regist-inp">
                <img
                  :src="crPsd?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
                  alt
                  class="xd-regist-icon"
                />
                <input
                  :type="inpType"
                  placeholder="输入登录密码"
                  v-model="criteria.password"

                  @click="toggleCrPsd()"
                />
                <i class="iconfont eye" :class="iconStatus" @click="toggleInpType()"></i>
                <i class="line" :class="crPsd?'inp-lineOn':'inp-lineOff'"></i>
                <i class="iconfont icon-error" v-show="criteria.password" @click="delText(2)"></i>
              </p>
              <!-- <p class="xd-regist-inp">
                
                <input
                  type="input"
                  placeholder="验证码"
                  v-model="validCode"
                  @click="changeCode()"
                />
                <i class="line" :class="crPsd?'inp-lineOn':'inp-lineOff'"></i>
              </p> -->
              
              <!-- <button @click="valid=false">点击</button> -->
              <div v-show="showValid" style="margin:0 0 20px 0;padding:0 40px;">
                <!-- <SliderVerificationCode v-model="slideCheck" /> -->
                <va v-if="reset" @success="passValid=true" ></va>
                <!-- <va v-if="reset" @success="passValid=true" :confirm="passValid"></va> -->
              </div>
              
              <button
                type="button"
                class="mui-btn mui-btn-block xd-regist-btn"
                :disabled="criteria.username && criteria.password?false:true"
                :class="[criteria.username && criteria.password? 'xd-regist-btnOn':'xd-regist-btnOff',showValid?'showValid':'']"
                @click="userLogin()"
              >登录</button>
              <router-link tag="p" :to="{name:'register'}" class="forget">立即注册</router-link>
              <p class="xd-resgist-link">
                <span class="xd-resgist-link" @click="forgetPsd()" tag="span">忘记密码?</span>
              </p>
            </div>
          </div>
          
          <div class="mui-scrollbar mui-scrollbar-vertical">
            <div
              class="mui-scrollbar-indicator"
              style="transition-duration: 0ms; display: block; height: 52px; transform: translate3d(0px, 0px, 0px) translateZ(0px);"
            ></div>
          </div>
        </div>
      </div>
      <div id="item2mobile" class="mui-slider-item mui-control-content">
        
        <div id="scroll2" class="mui-scroll-wrapper" data-scroll="2">
          <div
            class="mui-scroll"
            style="transform: translate3d(0px, 0px, 0px) translateZ(0px); transition-duration: 0ms;"
          >
            <div class="after_psd">
              <div class="xd-regist-inp">
                <img
                  :src="vrUser?require('@/public/asset/img/user/phone-on.png'):require('@/public/asset/img/user/phone-off.png')"
                  alt
                  class="xd-regist-icon"
                />
                <input
                  type="tel"
                  placeholder="输入手机号码"
                  style="color:#999"
                  v-model="vercriteria.username"
                  @click="toggleVrUser()"
                  @focus="isShowInputSelect(vercriteria.username, 'isVercriteriaShow')"
                  @blur="hideInput('isVercriteriaShow')"
                />
                <i class="line" :class="vrUser?'inp-lineOn':'inp-lineOff'"></i>
                <i class="iconfont icon-error" v-show="vercriteria.username" @click="delText(3)"></i>
                <div class="input-associate" v-show="isVercriteriaShow">
                  <ul>
                    <li
                      v-for="(item, i) in selectAccounts"
                      :key="i"
                      @click="setInputUserName('vercriteria', item, 'isVercriteriaShow')"
                    >{{item.username}}</li>
                  </ul>
                </div>
              </div>
              
              <p class="xd-regist-inp">
                <img
                  :src="vrPsd?require('@/public/asset/img/user/code-on.png'):require('@/public/asset/img/user/code-off.png')"
                  alt
                  class="xd-regist-icon"
                />
                <input
                  type="text"
                  style="width:60vw"
                  placeholder="输入手机验证码"
                  v-model="vercriteria.password"
                  @click="toggleVrPsd()"
                />
                <span
                  class="mui-btn code"
                  :class="[vercriteria.username?'xd-regist-codeOn':'xd-regist-codeOff',dis?'fade':'']"
                  @click="phoneVersion(vercriteria)"
                  :disabled="vercriteria.username&&!dis?false:true"
                >{{btnCon}}</span>
                <i class="line" :class="vrPsd?'inp-lineOn':'inp-lineOff'"></i>
                <i
                  class="iconfont icon-error icon-right"
                  v-show="vercriteria.password"
                  @click="delText(4)"
                ></i>
              </p>
              
              <div
                type="button"
                class="mui-btn mui-btn-block xd-regist-btn"
                :disabled="vercriteria.username && vercriteria.password?false:true"
                :class="vercriteria.username && vercriteria.password? 'xd-regist-btnOn':'xd-regist-btnOff'"
                @click="versionLogin()"
              >登录</div>
              <p class="xd-resgist-link">
                <router-link class="xd-resgist-link" to="register" tag="span">立即注册</router-link>
              </p>
            </div>
          </div>
          
          <div class="mui-scrollbar mui-scrollbar-vertical">
            <div
              class="mui-scrollbar-indicator"
              style="transition-duration: 0ms; display: block; height: 207px; transform: translate3d(0px, 0px, 0px) translateZ(0px);"
            ></div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import { login } from "@/api/ids/ids-api";
import { loadUserInfo } from "@/api/common/common-api";
import { sendLogOnCode } from "@/api/user/user-api";
import { CACHE_KEYS } from "@/constants";
import { Toast } from "mint-ui";
import {currentLoginUser} from '@/public/util/util.question'
import va from './partial/va'
function resize2() {
  //*12*点击输入框时，小键盘挡住了输入框
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
export default {
  data() {
    return {
      test:'testaaa',
      reset:true,
      showValid:true,
      passValid:false,
      slideCheck:false,
      valid:false,
      count: 60,
      inpType: "password",
      iconStatus: "icon-close-eyes",
      dis: false,
      btnCon: "获取验证码",
      crUser: false /*普通登录 手机号输入框触发*/,
      crPsd: false /*普通登录 密码输入框触发*/,
      vrUser: false /*验证码登录 手机号输入框触发*/,
      vrPsd: false /*验证码登录 验证码输入框触发*/,
      phoneReg: /^\d{11}$/,
      uuid: "",
      criteria: {
        username: window.updatePsdUser ? window.updatePsdUser : undefined,
        password: undefined,
        ...m2.util.getDevice()
      },

      vercriteria: {
        username: undefined,
        signInType: 1,
        password: undefined,
        ...m2.util.getDevice()
      },
      accountList: [],
      selectAccounts: [],
      isshow: false,
      isVercriteriaShow: false
    };
  },
  components: {va},
  beforeCreate(){
    mui.plusReady(function () {
      plus.webview.currentWebview().setStyle({'softinputMode':'nothing'});
    });
  },
  created() {
    
    window.userInfoErrorAlert = false;
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
  },
  destroyed() {
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
    mui.plusReady(function () {
      plus.webview.currentWebview().setStyle({'softinputMode':'nothing'});
    });
  },
  activated() {
    window.userInfoErrorAlert = false;
    this.init();
  },
  mounted() {
    this.$nextTick( ()=>{
      this.showValid = false
      this.passValid = false
      this.isNeedSlideCheck();
    })
    
    this.init();
    
    
    //this.checkTokenMsg();
  },
  // beforeRouteLeave(to,from,next){
  //   // mui.alert('aaa'+this.test)
  //   this.reset=false;
  //   this.$nextTick( ()=>{
  //     this.reset=true;
  //     // mui.alert('bbb'+this.test)
  //   })
  //   next()
  // },
  watch: {
    "criteria.username": function(val, oldVal) {
      this.isShowInputSelect(val, "isshow");
    },
    "vercriteria.username": function(val, oldVal) {
      this.isShowInputSelect(val, "isVercriteriaShow");
    }
  },
  methods: {
    clearCache(){
      m2.cache.set('invalid','');
      this.passValid = false;
      this.isNeedSlideCheck();
    },
    isNeedSlideCheck(){
      let validRecords = m2.cache.get('invalid');
      if(validRecords.length>4){
        let v1 = ( new Date().getTime() - Number(validRecords[0]) )/3600000;
        if( ( new Date().getTime() - Number(validRecords[0]) )/3600000 < 1 ){
          this.showValid = true;
          return
        }
      }
      this.showValid = false;
    },
    // checkTokenMsg(){
    //   if(window.lostToken){
    //     mui.alert('用户身份信息有误，请重新登录(一个账号只能同时登录在一台移动设备上)')
    //     window.lostToken=false;
    //   }
    // },
    createCode(length) {
        var code = "";
        var codeLength = parseInt(length); 
        var codeChars = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
        'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); 
        for (var i = 0; i < codeLength; i++)
        {
            var charNum = Math.floor(Math.random() * 62);
            code += codeChars[charNum];
        }
        this.code = code;
    },
    init() {
      this.accountList = this.getCacheAccounts();
      if (this.accountList.length) {
        this.criteria.username = this.accountList[0].username;
        // this.criteria.password = this.accountList[0].password
        this.vercriteria.username = this.accountList[0].username;
      }
      mui.plusReady(function() {
        plus.device.getInfo({
          success: function(e) {
            if (criteria && criteria.deviceType) {
              criteria.deviceType.deviceInfo = e.uuid;
            }
          },
          fail: function(e) {}
        });
      });
    },
    isShowInputSelect(val, showName) {
      if (typeof val === "undefined" || val.length == 0) {
        this[showName] = true;
        this.selectAccounts = this.accountList;
      } else {
        if (this.phoneReg.test(val)) {
          this[showName] = false;
        } else {
          this[showName] = true;
          let arr = [];
          this.accountList.forEach((item, index) => {
            if (item.username.indexOf(val) >= 0) {
              arr.unshift(item);
            }
          });
          this.selectAccounts = arr;
        }
      }
    },
    hideInput(showName) {
      setTimeout(() => {
        this[showName] = false;
      }, 100);
      
    },
    setInputUserName(typeCriteria, val, showName) {
      this[typeCriteria].username = val.username;
      this[showName] = false;
    },
    getCacheAccounts() {
      let accounts = window.localStorage.getItem("accountList");
      if (
        accounts === "null" ||
        accounts === null ||
        typeof accounts === "undefined"
      ) {
        return [];
      } else {
        return JSON.parse(accounts);
      }
    },
    setCacheAccounts(account) {
      let set = new Set();
      let accounts = window.localStorage.getItem("accountList");
      if (
        accounts === "null" ||
        accounts === null ||
        typeof accounts === "undefined"
      ) {
        accounts = [];
      } else {
        accounts = JSON.parse(window.localStorage.getItem("accountList"));
      }
      // 去重，并将优选级提升到队列最后，然后反转
      accounts.map((one, i) => {
        if (one.username === account.username) {
          accounts.splice(i, 1);
        }
      });
      accounts.push({
        username: account.username,
        password: account.password
      });
      accounts.reverse();
      console.log(JSON.stringify(accounts, null, 2));
      // 去重
      window.localStorage.setItem(
        "accountList",
        JSON.stringify([...new Set(accounts)])
      );
    },
    userLogin() {
      xdapp.util.aiUtil.seting(this.criteria.username);
      console.log(this.criteria.username, 1);
      /*普通登录*/
      if(this.showValid && !this.passValid){
        mui.alert('本次登录需要滑动验证')
        return false
      }
      login(this.criteria, async res => {
        m2.cache.set('invalid','');
        this.isNeedSlideCheck();
        this.reset=false;
        this.$nextTick( ()=>{
          this.reset=true;
          // mui.alert('bbb'+this.test)
        })
        this.setCacheAccounts(this.criteria);
        await loadUserInfo("upd");
        xdapp.util.aiUtil.seting();
        console.log("login", 2);
        window.legalUser = true;
        currentLoginUser();
        if (m2.cache.get("rx-current-user") !== null) {
          if (!m2.cache.get("rx-current-user").children.length) {
            this.$store.commit("changeFooterTab", "limited");
            this.$router.push("home-limit");
            return;
          } else {
            this.$store.commit("changeFooterTab", "normal");
            this.$router.push("home");
          }
        }
      },e=>{
        let invalidRecords = m2.cache.get('invalid')
        let err = new Date().getTime();
        if(invalidRecords){
          if(invalidRecords.length>4){
            invalidRecords.shift()
          }
          invalidRecords.push(err)
        }else{
          invalidRecords=[err]
        }
        m2.cache.set('invalid',invalidRecords)
        this.isNeedSlideCheck()
        if(this.showValid){
          this.reset=false;
          this.$nextTick( ()=>{
            this.reset=true;
            this.passValid = false;
          })
        }
        // console.log(e)
      });
    },
    versionLogin() {
      // debugger
      // if(!this.vercriteria.username || !this.vercriteria.password){
      //   return
      // }
      /*手机验证码登陆*/
      login(this.vercriteria, async res => {
        this.vercriteria.password = undefined;
        this.setCacheAccounts(this.vercriteria);
        await loadUserInfo("upd");
        if (m2.cache.get("rx-current-user") !== null) {
          if (!m2.cache.get("rx-current-user").children.length) {
            this.$store.commit("changeFooterTab", "limited");
            this.$router.push("home-limit");
            return;
          } else {
            this.$store.commit("changeFooterTab", "normal");
            this.$router.push("home");
          }
        }
      });
    },
    async forgetPsd() {
      /*点忘记密码进入重置密码界面*/
      this.$router.push({
        name: "reset-mess"
      });
    },
    async phoneVersion(vercriteria) {
      if (!vercriteria.username || this.dis) {
        return;
      }
      /*获取手机验证码*/
      event.preventdefault;
      event.stopPropagation();
      var _this = this;
      if (!this.vercriteria.username) {
        mui.alert("请输入手机号!");
      } else if (!this.phoneReg.test(this.vercriteria.username)) {
        mui.alert("输入手机号码格式有误!");
      } else {
        this.dis = true;

        sendLogOnCode(this.vercriteria.username, res => {
          Toast({ message: "发送成功", duration: 3000, type: "div" });
          var timer = setInterval(function() {
            _this.count--;
            if (_this.count == 0) {
              clearInterval(timer);
              _this.dis = false;
              _this.count = 60;
              _this.btnCon = "获取验证码";
              return;
            }
            _this.btnCon = _this.count + "s后重新获取";
          }, 1000);
        }).catch(r => {
          _this.dis = false;
        });
      }
    },
    toggleInpType() {
      if (this.inpType == "text") {
        this.inpType = "password";
        this.iconStatus = "icon-close-eyes";
      } else {
        this.inpType = "text";
        this.iconStatus = "icon-eyes";
      }
    },
    toggleCrUser() {
      this.crUser = true;
      this.crPsd = false;
    },
    toggleCrPsd() {
      this.crUser = false;
      this.crPsd = true;
    },
    toggleVrUser() {
      this.vrUser = true;
      this.vrPsd = false;
    },
    toggleVrPsd() {
      this.vrUser = false;
      this.vrPsd = true;
    },
    delText(num) {
      if (num == 1) {
        this.$refs.refPhone.focus();
      }
      switch (num) {
        case 1:
          this.criteria.username = "";
          break;
        case 2:
          this.criteria.password = "";
          break;
        case 3:
          this.vercriteria.username = "";
          break;
        case 4:
          this.vercriteria.password = "";
          break;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.showValid{
  margin-top: 0px;
}
.code.fade {
  background: #ccc;
}
.mui-btn {
  height: 44px;
  border-radius: 100px;
  -webkit-border-radius: 100px;
  border: none;
  width: torem(314);
  font-size: torem(16);
  line-height: torem(16);
  color: #fff;
}

.xd-login {
  position: absolute;
  width: 100%;
  height: 100%;
  background: url(~@/public/asset/img/bg/bj-pic.png) repeat-x;
  background-size: 100% torem(238);
  display: table-cell;
  background-color: #fff;
}

#slider {
  margin-top: torem(140);
}

.mui-control-item {
  color: #666 !important;
}

.mui-active {
  color: #ffa713 !important;
}

#item1mobile,
#item2mobile {
  height: torem(285);
  margin-top: 30px;
}

.forget {
  text-align: right;
  font-size: torem(16);
  padding-left: 34px;
  display: inline-block;
  color: #ffa713;
}

.xd-home-error {
  position: absolute;
  top: 0;
  bottom: 0;
  right: torem(20);
  margin: auto 0;
  border-radius: 100%;
  width: torem(16);
  height: torem(16);
  text-align: center;
  line-height: torem(16);
  background: orange;
}
.eye {
  color: #ccc;
  font-size: torem(24);
  position: absolute !important;
  right: torem(60) !important;
  top: torem(16) !important;
}
.xd-regist-inp {
  // border-bottom: 1px solid #eee;
}
.input-associate {
  position: absolute;
  background: #fff;
  z-index: 999;
  margin-left: torem(65);
  margin-top: -12px;
  width: calc(100% - 95px);
  line-height: torem(35);
  box-sizing: border-box;
}
.input-associate li {
  width: 100%;
  color: #000;
  padding: 0 torem(15);
  border-bottom: 1px solid rgb(238, 241, 245);
}
</style>
