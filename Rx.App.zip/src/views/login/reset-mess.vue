﻿<template>
  <div class="xd-resetMess">
    <h3 class="xd-regist-title">忘记密码？</h3>
    <p class="xd-regist-inp inp-margin">
      <img :src="PhoneFlag?require('@/public/asset/img/user/phone-on.png'):require('@/public/asset/img/user/phone-off.png')" alt="" class="xd-regist-icon" />
      <input type="tel" placeholder="输入手机号码" v-model="verPhone" @click="togglePhone()" />
      <i class="line" :class="PhoneFlag?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error" v-show="verPhone" @click="delText(1)"></i>
    </p>
    <p class="xd-regist-inp">
      <img :src="PicCodeFlag?require('@/public/asset/img/user/code-on.png'):require('@/public/asset/img/user/code-off.png')" alt="" class="xd-regist-icon" />
      <input type="text" placeholder="输入验证码" v-model="pictureCode" @click="togglePicCode()" />
      <span id="v_container" @click="getCode()"></span>
      <i class="line" :class="PicCodeFlag?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error icon-right" v-show="pictureCode" @click="delText(2)"></i>
    </p>
    <p class="xd-regist-inp">
      <img :src="CodeFlag?require('@/public/asset/img/user/code-on.png'):require('@/public/asset/img/user/code-off.png')" alt="" class="xd-regist-icon" />
      <input type="text" style="width:55vw" placeholder="输入手机验证码" v-model="phoneCode" @click="toggleCode()" />
      <button class="mui-btn code " :class="verPhone?'xd-regist-codeOn':'xd-regist-codeOff'" @click="getphoneCode()" :disabled="verPhone&&!dis?false:true">
        {{btnCon}}
      </button>
      <i class="line" :class="CodeFlag?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error icon-right" v-show="phoneCode" @click="delText(3)"></i>
    </p>
    <button type="button" class="mui-btn  mui-btn-block xd-regist-btn" :class="verPhone && phoneCode && pictureCode?'xd-regist-btnOn':'xd-regist-btnOff'" :disabled="verPhone && phoneCode && pictureCode?false:true" @click="resetPsd()">
      下一步</button>
    <p class="xd-resgist-link">
      <router-link class="xd-resgist-link" to="/login" tag="span">立即登录</router-link>
    </p>
  </div>
</template>
<script>
import "@/public/asset/js/verify-code/gVerify"; /*图形验证码插件*/
import {
  sendUserResetPwdCode,
  validateUserResetPwdCode
} from "@/api/user/user-api";
function resize2() {//*12*点击输入框时，小键盘挡住了输入框
  if (document.activeElement.tagName == 'INPUT' || document.activeElement.tagName == 'TEXTAREA') {
    window.setTimeout(function () {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
export default {
  data() {
    return {
      verifyCode: "",
      res: "",
      verPhone: "",
      /*监测输入手机号码*/
      phoneCode: "",
      /*监测输入手机验证码*/
      pictureCode: "",
      /*监测输入图片验证码*/
      PhoneFlag: false,
      PicCodeFlag: false,
      CodeFlag: false,
      phoneReg: /^1[34578]\d{9}$/ /*判断手机号码格式正则*/,
      count: 60,
      dis: false,
      btnCon: "获取验证码"
    };
  },
  methods: {
    async getCode() {
      this.res = this.verifyCode.options.code;
    },
    async getphoneCode() {
      event.preventdefault;   
      event.stopPropagation(); 
      /*触发获取手机验证码*/
      var _this = this;
      if (!this.verPhone) {
        mui.alert("请输入手机号码!");
      } else if (!this.phoneReg.test(this.verPhone)) {
        mui.alert("输入手机号码格式有误!");
      } else {
        sendUserResetPwdCode(this.verPhone, res => {
          this.dis = true;
          var timer = setInterval(function() {
            _this.count--;
            if (_this.count == 0) {
              clearInterval(timer);
              _this.dis = false;
              _this.count = 60;
              _this.btnCon = "获取手机验证码";
              return;
            }
            _this.btnCon = _this.count + "s后重新获取";
          }, 1000);
          mui.alert("发送成功");
        });
      }
    },
    async resetPsd() {
      var _this = this;
      if (!this.verPhone || !this.phoneCode || !this.pictureCode) {
        mui.alert("请输入用户相关信息!");
      } else if (!this.phoneReg.test(this.verPhone)) {
        mui.alert("输入手机号码格式有误!");
      } else if (
        this.pictureCode.toLocaleLowerCase() != this.res.toLocaleLowerCase()
      ) {
        mui.alert("输入图片验证码有误!");
      } else {
        /*验证重置密码的手机验证码*/
        validateUserResetPwdCode(
          {
            cellNumber: this.verPhone,
            code: this.phoneCode
          },
          res => {
            if (res) {
              this.$router.push({
                name: "reset-psd",
                params: {
                  verPhone: this.verPhone,
                  phoneCode: this.phoneCode
                }
              });
            } else {
              mui.alert("手机验证码输入有误！");
            }
          }
        );
      }
    },
    togglePhone() {
      this.PhoneFlag = true;
      this.PicCodeFlag = false;
      this.CodeFlag = false;
    },
    togglePicCode() {
      this.PhoneFlag = false;
      this.PicCodeFlag = true;
      this.CodeFlag = false;
    },
    toggleCode() {
      this.PhoneFlag = false;
      this.PicCodeFlag = false;
      this.CodeFlag = true;
    },
    delText(num) {
      switch (num) {
        case 1:
          this.verPhone = "";
          break;
        case 2:
          this.pictureCode = "";
          break;
        case 3:
          this.phoneCode = "";
          break;
      }
    }
  },
  created () {
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener('resize', resize2)
    }
  },
  destroyed(){
    if (/Android/gi.test(navigator.userAgent)) {
        window.removeEventListener('resize', resize2)
    }
  },
  mounted: function() {
    var _this = this;
    setTimeout(function() {
      _this.verifyCode = new GVerify("v_container");
      _this.res = _this.verifyCode.options.code;
    }, 1000);
  }
};
</script>

<style lang="scss" scoped>
.mui-btn {
  height: 44px;
  border-radius: 100px;
  -webkit-border-radius: 100px;
  border: none;
  width: torem(314);
  font-size: torem(16);
  line-height: torem(16);
  color: #fff;
}
.xd-resetMess {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 100%;
  background: url(~@/public/asset/img/bg/bj-pic.png) repeat-x;
  background-size: 100% torem(238);
  display: table-cell;
  background-color: #fff;
}

.xd-resetMess-title {
  @include letterStyle(32, #fff, 0, 45);
  margin-left: torem(21);
  margin-top: torem(70);
}

#v_container {
  width: torem(91);
  height: torem(30);
  position: absolute;
  top: 0;
  right: torem(35);
  bottom: 0;
  margin: auto 0;
}
</style>
