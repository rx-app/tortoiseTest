﻿<template>
  <div class="wrap">
    <course-header></course-header>
    <div class="xdapp-scorelist-container">
      <scroll
        :data="scoreList"
        :listen-scroll="listenScroll"
        :probe-type="probeType"
        :pullup="pullup"
        :refreshDelay="40"
        @scrollToEnd="searchMore"
        class="scroll-container"
        ref="list-view">
        <div class="score-list">
          <ul class="list-group">
            <li class="mui-table-view-cell item" v-for="(item,index) in scoreList">
              <a class="mui-navigate-right tit"  @tap="showInfo(index,item)" :class="item.isShow? 'up' : ''"> 
                <span class="left" v-if="item.studyYear"> {{item.studyYear | studyYear}} {{item.studyTerm | studyTerm}}</span>
                <span class="right" v-if="item.scoreType">{{item.scoreType | scoreType}}</span>
              </a>
              <div class="info" v-show="item.isShow">
                <div class="score" v-for="(scoreItem,index) in item.scoreItems" v-if="scoreItem.subject!=60">
                  <div class="left" v-if="scoreItem.subject">科目：{{scoreItem.subject | examSubject}}
                    <div class="right"><span>{{scoreItem.realScore}}分</span>/{{scoreItem.paperScore}}</div>
                  </div>
                  <div class="left">教师：{{scoreItem.teacherName}}
                    <div class="center" v-if="scoreItem.parentSatisficing && scoreItem.teacherName">家长满意度:
                      <i
                        style="text-indent:5px;font-size:20px" :class="{'iconfont icon-satisfaction_2':scoreItem.parentSatisficing>=5, 'iconfont icon-satisfaction_1':scoreItem.parentSatisficing<=4}"></i><span>{{scoreItem.parentSatisficing}}分</span>
                    </div>
                    <div class="center" v-if="!scoreItem.teacherName || scoreItem.teacherName==''">
                      <a v-if="scoreItem.isSiginUp" class="enroll" v-role @click="getSubjectReport(scoreItem.subject,scoreItem.itemID)"><i class="iconfont icon-report"></i>报名</a>
                      <div v-else>已报名</div>
                    </div>
                    <div class="center" v-role v-if="!scoreItem.parentSatisficing && scoreItem.teacherName">
                      家长满意度:
                      
                      <a @click="dafen(scoreItem.itemID,scoreItem)"><i v-role class="iconfont icon-evaluate"></i>打分</a>
                      <!-- <router-link :to="{name:'edit-score',query:{itemID:scoreItem.itemID}}">打分</router-link> -->
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <!-- <li style="height:30vh"></li> -->
            <loading v-show="hasMore" title=""></loading>
          </ul>
        </div>
      </scroll>
    </div>
    <tip v-if="!hasData">
      <span>暂无成绩记录</span>
    </tip>
    <div class="mask" v-if='isEditScore'>
      <div class="mask-box">
        <div class="close">        
          <i class="iconfont icon-error" @click="maskDis()"></i>
        </div>
        <div class="msg-box">
          <h5>点击色块为辅导结果打分：<span class="number">{{val}}</span> 分</h5>
          <div class="range-bar">
            <div class="range-item" v-for="item in 10" :class="item<=val?'on':'off'" :key="item" @click="setValue(item)"></div>
          </div>
           <button
            type="button"
            class="send"
            :disabled="val > 0 ? false : true"
            @click="submit()">
            打分
          </button>
        </div>
      </div>
		</div>
  </div>
</template>
<script>
  import {ACTION_TYPES, RX_TEXT} from '@/constants';
  import {pager, orderBy, defaultPageSize} from '@/public/constant';
  import {loadUserInfo, getCurrentChild} from '@/api/common/common-api';
  import {getAllScores, subjectReport} from '@/api/score/customerscore-api';
  import courseHeader from '../partials/course-header.vue';
  import Scroll from '@/components/scroll/index';
  import Loading from '@/components/loading/index';
  import Tip from '@/components/tip';
  import {modifyParentalSatisfaction} from '@/api/score/customerscore-api';
  // import white from "@/public/lib/white";

export default {
  // mixins: [white],
    data() {
      return {
        currentItem:null,
        isEditScore: false,
        probeType: 3,
        listenScroll: true,
        pullup: true,
        hasMore: false,
        hasData: false,
        scoreList: [],
        scoreItemList: [],
        subjectInfo: {
          subject: '',
          scoreItemID: '',
        },
        val: 0,
        scoreItem: {
          scoreItemID: '',
          satisfaction: 0
        }
      }
    },
    created(){
      this.initData();
      this.getScoreList();
      this.switchChild();
      
			
    },
    mounted(){
      document.body.style.background='#fff';
    },
		destroyed() {
			document.body.style.background='#efeff4';		
		},
    methods: {
      showInfo (index, item) {
        this.scoreList.map((one, i)=>{
          if (i !== index) {
            one.isShow = false
          }
        })
        this.scoreList[index].isShow = !this.scoreList[index].isShow 
        this.$set(this.scoreList, index, item)
        // 确认打开
        // if (item.isShow) {
        //   // 计算高度
        //   item.scoreItems.length
        // }
      },
      async getScoreList(){
        await loadUserInfo();
        getAllScores(this.params, res => {
          if (!res || !res.queryResult || !res.queryResult.totalCount) {
            this.hasData = false;
            return;
          }
            this.hasData = true;

          this.scoreList = this.scoreList.concat(res.queryResult.pagedData);
          this.scoreList.map(one=>{
            if (typeof one.isShow === 'undefined') {
              one.isShow = false
            }
          })
          // console.log(JSON.stringify(this.scoreList, null, 2))
          this._checkMore(res.queryResult.totalCount);
        });
      },
      getSubjectReport: function (subject, scoreItemID) {
        var _this = this;
        this.subjectInfo.subject = subject;
        this.subjectInfo.scoreItemID = scoreItemID;
        if (this.subjectInfo.subject) {
          mui.confirm('确认要报名?', '提示', ['取消', '确认'], function (e) {
            if (e.index != 0) {
              
              subjectReport(_this.subjectInfo, (res) => {
                  mui.alert(RX_TEXT.SIGNUP_TIP);
                  _this.scoreList.forEach(item => {
                    item.scoreItems.forEach(i => {
                      if (i.itemID == scoreItemID)
                        i.isSiginUp = false;
                    })
                  })
                  //item.isSiginUp = false;
                },
                (error) => {
                }
              )
            }
          })
        }
      },
      getScoreListForSwitchChild(){
        this.initData();
        this.getScoreList();
      },
      initData(){
        this.scoreList = [];
        this.scoreItemList = [];
        this.params = {
          ...pager({pageSize: defaultPageSize}),
          ...orderBy({dataField: 'customerScores.modifyTime'})
        };
        // this.hasData = true;
      },
      searchMore(){
        if (!this.hasMore)
          return;
      
        this.params.pageParams.pageIndex++;
        this.getScoreList();
      },
      switchChild(){
        xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getScoreListForSwitchChild);
      },
      _checkMore(totalCount){
        if (this.params.pageParams.pageIndex * this.params.pageParams.pageSize >= totalCount) {
          // setTimeout (()=>{
            this.hasMore = false;
          // }, 2000)
        } else {
          // setTimeout (()=>{
          this.hasMore = true;
          // }, 2000)
        }
      },
      setValue(item){
        console.log(item)
        this.val=item;
      },
      dafen (id,item) {
        this.currentItem=item;
        this.isEditScore = true;
        this.scoreItem.scoreItemID = id;
      
      },
      maskDis(){
        this.isEditScore = false;
        this.scoreItem.scoreItemID = ''
        this.scoreItem.satisfaction = 0
        this.val = 0
      },
      submit(){
        var _this=this;
        this.scoreItem.satisfaction = this.val;
        this.isEditScore = false
        mui.confirm('设定后不能修改，是否确认提交', '提示', ['取消', '确认'], function (e) {
          _this.isEditScore = true
          if (e.index != 0) {
            modifyParentalSatisfaction(_this.scoreItem, () => {
              _this.scoreList.forEach(item => {
                item.scoreItems.forEach(i => {
                  if (i.itemID == _this.scoreItem.scoreItemID)
                    i.parentSatisficing = _this.val;
                })
              })
              _this.maskDis();
              // this.isEditScore = false;
              // _this.getScoreListForSwitchChild();
            
            });
          }
        })
      }
    },
    components: {
      courseHeader,
      Scroll,
      Loading,
      Tip
    }
  }
</script>
<style lang="scss" scoped>
  .xdapp-scorelist-container {
    position: fixed;
    width: 100%;
    top: calc(75px + 2rem);
    bottom: 50px;
    .mui-table-view-cell>.mui-navigate-right:after {
      content: '\e581';
    }
     .mui-table-view-cell>.up.mui-navigate-right:after {
      content: '\e580';
    }
    .scroll-container {
      height: 100%;
      /*overflow: hidden;*/
      .score-list {
        .list-group {
          background-color: #fff;
          .mui-table-view-cell:after {
            background-color: #eee;
          }
         
          .item {
            align-items: center;
            //  .mui-navigate-right:after {
            //   // top:
            //   transform: rotate(90deg)
            // }
            .enroll{
                  display: block;
                  margin-top: -20px;
                  padding-top: 10px;
                  margin-bottom: -20px;
                  padding-bottom: 10px;
                  padding-right: 0;
                  transform: translateY(10px);
                  width: 70px;
                  float: right;
            }
            .tit {
              display: flex;
              padding-bottom: 15px;
              font-size: torem(13);
              // :after{
              //   transform: rotate(45deg)
              // }
              .left {
                flex: 1;
                align-items: center;
              }
              .right {
                flex: 1;
                text-align: right;
                align-items: center;
                padding-right: torem(18);
              }
            }
            .info {
              /*background-color: #c3d94c0f;*/
              padding: torem(8) torem(15) 0 torem(15);
              .score {
                border-bottom: 1px dashed #eee;
                padding: 5px;
                .left {
                  flex: 1;
                  display: flex;
                  align-items: flex-start;
                  color: #666;
                  padding-left: torem(12);
                  font-size: torem(12);
                  .right {
                    flex: 1;
                    text-align: right;
                    padding-right: torem(12);
                    span {
                      color: #ff4700;
                    }
                  }
                  .center {
                    flex: 1;
                    text-align: right;
                    padding-right: torem(12);
                    i {
                      display: inline-block;
                      // background: url('~@/public/asset/img/course/level3.png');
                      background-size: 100%;
                      height: 20px;
                      width: 20px;
                      margin: 0 5px;
                      vertical-align: bottom;
                      color:#007aff;
                      &.lv1 {
                        // background: url('~@/public/asset/img/course/level1.png');
                        background-size: 100%;
                      }
                      &.lv3 {
                        // background: url('~@/public/asset/img/course/level3.png');
                        background-size: 100%;
                      }
                      &.edit {
                        // background: url('~@/public/asset/img/course/edit.png');
                        background-size: 100%;
                      }
                      &.report {
                        // background: url('~@/public/asset/img/course/book.png');
                        background-size: 100%;
                      }
                    }
                    div {
                      font-color: #bbbbbb;
                    }
                    span {
                      display: inline-block;
                      width: 0.82rem;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
</style>

<style lang="scss" scoped>
	.mask {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		background-color: rgba(0, 0, 0, 0.2);
    z-index: 9999;
    .mask-box{
      width: torem(300);
      margin: torem(200) auto torem(40) auto;
      .close{
        text-align: right;
        margin-bottom: -3px;
      }
      .iconfont{
        display: inline-block;
        color: #fff;
        font-size: torem(26);
        margin-right: -18px;
        
      }
    }
		// text-align: center;
		.msg-box {
      position: relative;
			width: 100%;
			// height: torem(200);
			background-color: #fff;
			border-radius: torem(15);
			padding: torem(50) torem(15) torem(10);
      position: relative;
      text-align: center;
			.msg-text {
				padding: torem(10);
				width: 100%;
				height: torem(200);
				border: none;
				border-radius: torem(15);
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-bottom: 5px;
			}
    }
    textarea::-webkit-input-placeholder {
      @include letterStyle(12, #CACFD9, 0, 16);
    }

    .send{
      width: 60%;
      margin: torem(40) auto torem(10);
      background: rgb(255,130,1);
      color:#fff;
      display: block;
      border-radius:30px;
      border:none;
    }
	}
h5{line-height: 24px;}
.number{
  color:red;
  font-size: 24px;
}
  .range-bar{
    display: flex;
    height: 30px;
    .range-item{
      &.off{background: #ccc;}
      flex:1;
      background: #F35D13;
      &:nth-of-type(1){opacity: 0.1;}
      &:nth-of-type(2){opacity: 0.2;}
      &:nth-of-type(3){opacity: 0.3;}
      &:nth-of-type(4){opacity: 0.4;}
      &:nth-of-type(5){opacity: 0.5;}
      &:nth-of-type(6){opacity: 0.6;}
      &:nth-of-type(7){opacity: 0.7;}
      &:nth-of-type(8){opacity: 0.8;}
      &:nth-of-type(9){opacity: 0.9;}
      &:nth-of-type(10){opacity: 1;}
    }
  }
  .rx-row-wrap {
    display: flex;
    .num {
      width: 30px;
      line-height: 50px;
      font-size: 13px;
      color: #F5A623;
    }
    .bar {
      flex: 1;
      height: 40px;
    }
  }

  .mui-input-range input[type='range'] {
    position: relative;

    width: 100%;
    height: 18px;
    margin: 17px 0;
    padding: 0;

    cursor: pointer;

    border: 0;
    border-radius: 3px;
    outline: none;
    background: linear-gradient(-90deg, #ffa713 0%, #ffdd61 100%) no-repeat, #999;

    -webkit-appearance: none !important;
  }

  .mui-input-range input[type='range']::-webkit-slider-thumb {
    width: 14px;
    height: 14px;

    border-color: #0062cc;
    border-radius: 50%;
    background-color: #007aff;
    background-clip: padding-box;

    -webkit-appearance: none !important;
  }

  h4 {
    padding: 10px 15px;
  }
</style>
