<template>
  <div class="wrap">
    <h5>请为孩子辅导后的成绩满意度打分：<span class="number">{{val}}</span> 分</h5>
    <!-- <div class="mui-input-row mui-input-range field-contain rx-row-wrap"> -->

      <!-- <div class="bar">
        <input type="range" id="field-range" :style="{backgroundSize:val+'% 100%'}" v-model="val" @input="setVal"
               value="60" min="0" max="100" data-input-slider="2">
      </div> -->
      <!-- <mt-range
  v-model="val"
  :step="10"
  :bar-height="5">
</mt-range> -->
  <div class="range-bar">
    <div class="range-item" v-for="item in 10" :class="item<=val?'on':'off'" :key="item" @click="setValue(item)"></div>
  </div>
      <!-- <div class="num">
        {{val}}分
      </div> -->
    <!-- </div> -->
  </div>
</template>

<script>
  import {ACTION_TYPES} from '@/constants';
  import {modifyParentalSatisfaction} from '@/api/score/customerscore-api';
  export default{
    data () {
      return {
        val: 0,
        scoreItem: {
          scoreItemID: '',
          satisfaction: 0
        }
      }
    },
    created(){
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_SCORE_COMMIT, this.submit);
    },
    watch: {
      val: {
        handler: (val) => {
          xdapp.util.vue.commitActionStatus(val > 0)
        },
        deep: true
      }
    },
    methods: {
      setValue(item){
        console.log(item)
        this.val=item;
      },
      // setVal(){
      //   this.val = Math.floor(this.val / 10) * 10;
      // },
      submit(){
        var _this=this;
        this.scoreItem.scoreItemID = this.itemID;
        this.scoreItem.satisfaction = this.val;
        mui.confirm('设定后不能修改，是否确认提交', '提示', ['取消', '确认'], function (e) {
          if (e.index != 0) {
            modifyParentalSatisfaction(_this.scoreItem, () => {
              _this.$router.push({name: "score"});
            });
          }
        })
      },
    },
    computed: {
      itemID() {
        return this.$route.query.itemID;
      }
    }
  }
</script>

<style lang="scss" scoped>
h5{line-height: 24px;}
.number{
  color:red;
  font-size: 24px;
}
  .range-bar{
    display: flex;
    height: 30px;
    .range-item{
      &.off{background: #ccc;}
      flex:1;
      background: #F35D13;
      &:nth-of-type(1){opacity: 0.1;}
      &:nth-of-type(2){opacity: 0.2;}
      &:nth-of-type(3){opacity: 0.3;}
      &:nth-of-type(4){opacity: 0.4;}
      &:nth-of-type(5){opacity: 0.5;}
      &:nth-of-type(6){opacity: 0.6;}
      &:nth-of-type(7){opacity: 0.7;}
      &:nth-of-type(8){opacity: 0.8;}
      &:nth-of-type(9){opacity: 0.9;}
      &:nth-of-type(10){opacity: 1;}
    }
  }
  .rx-row-wrap {
    display: flex;
    .num {
      width: 30px;
      line-height: 50px;
      font-size: 13px;
      color: #F5A623;
    }
    .bar {
      flex: 1;
      height: 40px;
    }
  }

  .mui-input-range input[type='range'] {
    position: relative;

    width: 100%;
    height: 18px;
    margin: 17px 0;
    padding: 0;

    cursor: pointer;

    border: 0;
    border-radius: 3px;
    outline: none;
    background: linear-gradient(-90deg, #ffa713 0%, #ffdd61 100%) no-repeat, #999;

    -webkit-appearance: none !important;
  }

  .mui-input-range input[type='range']::-webkit-slider-thumb {
    width: 14px;
    height: 14px;

    border-color: #0062cc;
    border-radius: 50%;
    background-color: #007aff;
    background-clip: padding-box;

    -webkit-appearance: none !important;
  }

  h4 {
    padding: 10px 15px;
  }
</style>
