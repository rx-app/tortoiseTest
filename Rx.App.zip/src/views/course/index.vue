<template>
  <div class="wrap">
    <course-header></course-header>
  </div>
</template>
<script>
  import courseHeader from './partials/course-header.vue'

  export default{
    data(){
      return { }
    },
    components: {
      courseHeader
    }
  }
</script>

<style scoped>
  .mui-bar-nav ~ .mui-content {
    padding-top: 30px;
  }
</style>
