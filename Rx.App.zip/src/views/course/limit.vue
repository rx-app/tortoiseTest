﻿<template>
  <div class="limit">
    
    <div class="box">
      <img  :src="require(`@/public/asset/img/tip.png`)" alt="">
      <p>您名下暂无在学大上课的孩子</p>
      <p>无法获取相关信息</p>
    </div>
    <div style="display:none">{{this.$route.name +Math.random()}}</div>
      
  </div>
</template>
<script>
import { loadUserInfo, getCurrentChild } from "@/api/common/common-api";

export default {
  async created() {
    await loadUserInfo('upd')
    if(!m2.cache.get('rx-current-user').children.length){
      this.$store.commit('changeFooterTab','limited')
    }else{
      this.$store.commit('changeFooterTab','normal')
    }
    
  },
  async updated() {
    await loadUserInfo('upd')
    if(!m2.cache.get('rx-current-user').children.length){
      this.$store.commit('changeFooterTab','limited')
    }else{
      this.$store.commit('changeFooterTab','normal')
    }
    
  },
}
</script>

<style lang="scss" scoped>
  .limit{
    .box{
      background: #fff;
      padding: 40px;
      text-align: center;
      p{
        font-size: 14px;
      }
    }
  }
</style>
