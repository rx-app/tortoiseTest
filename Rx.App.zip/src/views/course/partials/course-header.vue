﻿<template>
	<div class="rx-course-list-nav">
		<router-link v-for="(item,index) in items" :to="{name:item.pathname}" :key="index" class="item" tag="div">
			<img :src="($route.name==item.pathname)?item.icon_active:item.icon" alt="" class="icon" />
			<span class="txt">{{item.title}}</span>
		</router-link>
	</div>
</template>
<script>
	import { COURSE_INDEX } from "@/constants";
	import { loadUserInfo } from '@/api/common/common-api';
	export default {
		async created() {
			await loadUserInfo("upd");
		},
		computed: {
			items() {
				if($vue.$store.state.currentChild.relation == 1) {
					return COURSE_INDEX
				} else {
					return [{
							title: "上课记录",
							pathname: "course",
							icon_active: require("@/public/asset/img/course/course.png"),
							icon: require("@/public/asset/img/course/courseoff.png"),
							active: true
						},
						{
							title: "成绩管理",
							pathname: "score",
							icon_active: require("@/public/asset/img/course/score.png"),
							icon: require("@/public/asset/img/course/scoreoff.png"),
							active: false
						}
					];
				}
			}
		}
	};
</script>
<style lang="scss" scoped>
	.rx-course-list-nav {
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-around;
		height: torem(75);
		padding: 0 torem(20);
		text-align: center;
		background: #f1f1f1;
		z-index: 9;
		// opacity: 0.95;
		filter: alpha(opacify=90);
		.item {
			display: inline-block;
			.icon {
				width: torem(28);
				height: torem(28);
			}
			.txt {
				display: block;
				line-height: torem(12);
				font-size: torem(13);
				color: rgb(102, 102, 102);
			}
		}
	}
</style>