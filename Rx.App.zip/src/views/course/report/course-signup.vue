﻿<template>
	<div class="wrap ">
		<course-header></course-header>
		<div class="xdapp-courselist-container">
			<scroll :data="productList" :listen-scroll="listenScroll" :probe-type="probeType" :pullup="pullup" @scrollToEnd="searchMore" class="scroll-container" ref="list-view">
				
				<div class="course-list">
					<p v-show="productList.length" style="padding:0 16px;color:#000;font-size:12px;font-weight:bold;" class="tips">
						温馨提示：点击“我要报名”，学管师会收到报名通知，与家长沟通后再决定是否订购，系统不会自动扣钱订购。
					</p>
					<!-- <p v-show="visible" class="msg">暂无推荐课程！</p> -->
					<div  v-for="(item,index) in productList" :key="index">
						<div v-if="item.isSiginUp"  class="item">
							<div class="img-wrap">
								<p class="box">
									<img class="img-left" :src="!!item.imgContent?item.imgContent:require('@/public/asset/img/course/signup0'+(index%4+1)+'.png')" alt="">
								</p>
								<div class="gap"></div>
								<p class="box2">
									<img   @click="report(item.productID)" class="img-right" :src="require(`@/public/asset/img/course/signup-on.png`)" alt="">
									<!-- <img  v-else class="img-right" :src="require(`@/public/asset/img/course/signup-off.png`)" alt=""> -->
								</p>
							</div>
							<div class="desc">
								<div class="course"> {{item.productName}}</div>
								<div class="teacher"> <span> 课程售价：</span>{{item.productPrice}} 元</div>
								<div class="count"> <span> 课程课次：</span> {{item.categoryType==3?1:item.lessonCount}} 次</div>
								<div class="detail"><span>课程简介：</span>{{item.productMemo}}</div>
								<!-- <div v-if="item.isSiginUp" class="book" @click="report(item.productID)">立即报名</div>
								<div v-else class="book2">已经报名</div> -->
							</div>
						</div>
					</div>
				</div>
			</scroll>
		</div>
		<tip v-if="!productList.length && loaded">
			<span>暂无推荐课程</span>
		</tip>
	</div>
</template>

<script>
	import courseHeader from '../partials/course-header'
	import { ACTION_TYPES } from '@/constants';
	import { loadUserInfo, getCurrentChild } from '@/api/common/common-api';
	import { pager, orderBy, defaultPageSize } from '@/public/constant';
	import { RX_TEXT } from '@/constants';
	import { getSalePagedProducts, addClassReport } from '@/api/order/order-api'
	import Scroll from '@/components/scroll/index';
    import Tip from '@/components/tip';
	import Loading from '@/components/loading/index';
	export default {
		data() {
			return {
				loaded:false,
				productList: [],
				product: {
					productIDs: '',
					customerID: getCurrentChild().id
				},
				classReport: {
					productID: '',
					customerID: getCurrentChild().id
				},
				params: {
					customerID: getCurrentChild().id,
					...pager({
						pageSize: 10
					}),
					...orderBy({
						dataField: 'createTime'
					})
				},
				probeType: 3,
				listenScroll: true,
				pullup: true,
				hasMore: false,
				visible: true,
				onFech: false
			}
		},
		updated () {
			if($vue.$store.state.currentChild.relation != 1){
				this.$router.push({name:'home'})
			}
		},
		created() {
			
			if($vue.$store.state.currentChild.relation != 1){
				this.$router.push({name:'home'})
			}
			this.initData();
			this.showProducts();
			this.switchChild();
			// document.body.style.background='#fff';
		},
		mounted(){
			document.body.style.background='#fff';
		},
		destroyed() {
			document.body.style.background='#efeff4';		
		},
    // beforeRouteEnter(to,from,next){
    //   document.body.style.background='#fff';
    //   next();
    // },
    // beforeRouteLeave(to,from,next){
    //   document.body.style.background='#efeff4';
    //   next();
    // },
		methods: {
			async showProducts() {
				if (this.onFech) {
					return
				}
				this.onFech = true
				await loadUserInfo();
				getSalePagedProducts(this.params, (res) => {
					this.loaded=true;
					if(res.totalCount == 0) {
						this.visible = true;
					}
					// console.log(res)
					res=res.filter(r=>r.isSiginUp)
					this.productList = this.productList.concat(res);//this.productList.concat(res.pagedData);
					this.onFech = false
				//	this._checkMore(res.totalCount);
				})
				
			},
			report: function(productId) {
				var _this = this;
				this.product.productIDs = productId;
				if(this.product.productIDs) {
					mui.confirm('确认要报名?', '提示', ['取消', '确认'], function(e) {
						if(e.index != 0) {
							addClassReport(_this.product, (res) => {
									console.log('res:' + res)
									mui.alert(RX_TEXT.SIGNUP_TIP);
									let item = {}
									let index = 0
									_this.productList.map((one, i) => {
										if (one.productID == productId) {
											one.isSiginUp = false;
											index = i
											item = one
										}
									})
									_this.$set( _this.productList, index, item)
								    // let index = _this.productList.findIndex(item => item.productID == productId);

									
									// _this.$set(
									// 	()=>{
									// 		// let item = _this.productList.find(item => item.productID == productId);
									// 		// _this.$set( item, 'isSiginUp', false)

									// 		//_this.productList[index].isSiginUp = false;

									// 		_this.$set( productList[index], 'isSiginUp', false)
									// 	}
									// )
								},
								(error) => {}
							)
						}
					})

				}
			},
			getCourseListForSwitchChild() {
				this.initData();
				this.showProducts();
			},
			initData() {
				this.productList = [];
				this.params = {
					customerID: getCurrentChild().id,
					...pager({
						pageSize:10// defaultPageSize
					}),
					...orderBy({
						dataField: 'createTime'
					})
				};
				this.visible = false;
			},
			searchMore() {
				if(!this.hasMore)
					return;
				this.params.pageParams.pageIndex++;
				this.showProducts();
			},
			switchChild() {
				xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getCourseListForSwitchChild);
			},
			_checkMore(totalCount) {
				if(this.params.pageParams.pageIndex * this.params.pageParams.pageSize > totalCount)
					this.hasMore = false;
				else
					this.hasMore = true;
			},
		},
		components: {
			courseHeader,
			Scroll,
			Tip,
			Loading
		}
	}
</script>

<style lang="scss" scoped>
	.xdapp-courselist-container {
		position: fixed;
		width: 100%;
    	top: calc(75px + 2rem);
		bottom: 50px;
		.scroll-container {
			height: 100%;
			/*overflow: hidden;*/
			.course-list {
				.msg {
					text-align: center;
				}
				.item {
					padding: 0 16px;
					background: #fff;
          .img-wrap {
			  
            display: flex;
			p{margin-bottom: 0}
            .box {
              flex: 1;
			  height: torem(104);
              img {
				// transform:scale(0.8);
                width: 100%;
                height: 100%;
              }
            }
			.gap{width:20px}
            .box2 {
              width: torem(100);
			  height: torem(104);
			  text-align: center;
              img {
				  max-width: 100%;
				 max-height: 100%;
                // width: 100%;
                // height: 100%;
              }
            }
          }
					.desc {
						position: relative;
						//padding: 12px 16px 22px 16px;
						background: #fff;
						margin-bottom: 25px;
						color: #757575;
						span {
							color: #757575;
							font-size: 13px;
							font-weight: 600;
						}
						div {
							margin: 2px 0;
							font-size: torem(13);
						}
						.course span {
							font-size: 14px;
							color: #f2d3d1;
						}
						.course {
							color: #757575;
							font-size: 13px;
							font-weight: 600;
						}
					}
				}
			}
		}
	}
</style>
