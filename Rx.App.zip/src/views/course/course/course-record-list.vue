<template>
	<div class="wrap">
		<course-header></course-header>
		<course-items></course-items>
	</div>
</template>
<script>
	import courseHeader from '../partials/course-header'
	import courseItems from './partials/course-items'
	import white from "@/public/lib/white";

	export default {
		// mixins: [white],
		components: {
			courseHeader,
			courseItems
		},
		created(){
			document.body.style.background='#fff';
		},
		destroyed() {
			document.body.style.background='#efeff4';		
		},

	}
</script>