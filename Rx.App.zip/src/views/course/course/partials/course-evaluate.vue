﻿<template>
  <div class="bottom">
    <div class="tit">{{evaluateConfig.title}}</div>
    <template v-if="!courseInfo.evaluateStatus">
      <ul>
        <li v-for="item in this.items">
          <span class="title">{{item.title}}</span>
          <i
            class="star"
            v-for="score in evaluateConfig.scoreConfig"
            :class="{on: score.value <= item.score}"
            @click="evaluateHandle(item.key, score.value, score.desc)"
          ></i>
          <span class="tip">{{item.desc}}</span>
        </li>
      </ul>
      <div class="comment">
        <div class="tit">其它评论</div>
        <textarea v-model="evaluate.content" class="other-comment" @focus="fnFocus" @blur="fnBlur"></textarea>
      </div>
    </template>
    <template v-if="courseInfo.evaluateStatus">
      <ul>
        <li v-for="item in this.items">
          <span class="title">{{item.title}}</span>
          <i
            class="star"
            v-for="score in evaluateConfig.scoreConfig"
            :class="{on: score.value <= item.score}"
          ></i>
          <span class="tip">{{item.desc}}</span>
        </li>
      </ul>
      <div class="comment">
        <div class="tit">其它评论</div>
        <div class="other-comment other"  @focus="fnFocus" @blur="fnBlur" style="border:none">{{evaluate.content}}</div>
      </div>
    </template>
  </div>
</template>
<script>
import { ASSIGN_STATUS as assignStatus } from "@/constants";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
    //这行本来是解决--消除小键盘和输入框之间的间隙的
    //但是，这个页面加这行代码会造成顶部会出现白条
    //去掉之后，反而不会有bug，原因不明

    //顶部白边问题的产生原因是focus和blur事件没有加上，上面有4处textarea
    //better-scroll要加在父组件上
    //底部黑边是better-scroll产生的,如果better-scroll不放在最外层，就会有底部黑边,这个黑色是通过css可以修改，并非app的背景色
    //如果页面高度太小，页会产生底部黑边，可padding-bottom: 400px;解决
    //absolute元素可以覆盖在黑边上面，达到消除黑边的作用，给wrap容器设置一个postion：absolute；可以消除底部黑边
    //主页面在点击输入框之后上移是因为页面里用了position:absolute
  }
}
function resize2() {
  //*12*点击输入框时，小键盘挡住了输入框
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
export default {
  data() {
    return {};
  },
  created(){
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
    document.querySelector('.xd-header').style.position='fixed'
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
    // document.body.style.overflow = "scroll";
    // document.querySelector("html").style.overflow = "scroll";
  },
  props: ["courseInfo", "evaluateConfig", "evaluate", "items"],
  methods: {
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "765px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
        //mui.alert('---tttt----')
        //mui('header')[0].style.transform='translateY(-10px)'
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    evaluateHandle(key, value, desc) {
      let item = this.items.find(item => item.key == key);
      item.score = value;
      item.desc = desc;
    }
  }
};
</script>
<style lang="scss" scoped>
@function torem($px) {
  @return $px/37.5 + rem;
}

i.star {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/star.png) no-repeat;
  background-size: 100%;
  width: torem(20);
  height: torem(20);
  margin-right: torem(5);
}

i.star.on {
  display: inline-block;
  vertical-align: middle;
  background: url(~@/public/asset/img/course/staron.png) no-repeat;
  background-size: 100%;
  width: torem(20);
  height: torem(20);
  margin-right: torem(5);
}

.bottom {
  .tit {
    font-size: torem(14);
    color: #666;
    padding-top: torem(15);
  }
  ul {
    font-size: torem(13);
    color: #666;
    padding: 0 torem(10);
    li {
      margin-top: torem(15);
      span.title {
        width: 25%;
        display: inline-flex;
      }
      span.tip {
        padding-left: torem(18.75);
      }
    }
  }
  .comment {
    .tit {
      font-size: torem(13);
      color: #666;
      margin: torem(10) 0;
      padding: 0 torem(10);
    }
    .other-comment {
      width: torem(272);
      height: torem(95);
      margin: 0 torem(10);
      color: #666;
      border: 1px solid #eee;
    }
    .other {
      padding: 0 torem(10);
      word-break: break-all;
    }
  }
}
</style>
