<template>
  <div class="top">
    <!--<img src="~@/public/asset/img/course/c.png" alt="">-->
    <div class="subject-container">
      <span class="subject-img">
        <img v-if="imgSrc" :src="imgSrc" />
        <img
          v-else-if="!imgSrc && userGender==1"
          src="~@/public/asset/img/user/teacher-man.png"
          alt
        />
        <img
          v-else-if="!imgSrc && userGender==2"
          src="~@/public/asset/img/user/teacher-woman.png"
          alt
        />
      </span>
    </div>
    <div class="right">
      <div class="name">
        <span
          class="mui-badge mui-badge-warning"
          v-if="courseInfo.gradeName"
        >{{courseInfo.gradeName}}</span>
        <span
          class="mui-badge mui-badge-purple"
          v-if="courseInfo.subjectName"
        >{{courseInfo.subjectName}}</span>
        <!-- <span
          class="mui-badge mui-badge-danger"
          v-if="courseInfo.businessType==2 && courseInfo.assignStatus==1 && courseInfo.isConfirmed"
        >已点名</span> -->
        <span
          class="mui-badge mui-badge-success"
          v-if="courseInfo.assignStatusName"
        >{{courseInfo.assignStatusName}}</span>
        <span
          class="mui-badge mui-badge-blue course-time"
          v-if="courseInfo.amount"
        >{{courseInfo.amount}}课时</span>
      </div>
      <div class="teachar">
        <b>{{courseInfo.teacherName}}</b>
        <span>老师</span>
      </div>
      <div
        class="time"
      >{{courseInfo.startTime | dateFormat({locale: 'zh-CN'})}} {{courseInfo.startTime | timeRange(courseInfo.endTime, {locale: 'zh-CN'})}}</div>
    </div>
  </div>
</template>
<script>
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import store from "@/store";
import * as types from "@/store/mutation-types";
export default {
  data() {
    return {
      userGender: 0,
      imgSrc: ""
    };
  },
  props: ["courseInfo", "teacherInfoImg", "teacherID"],
  methods: {
    getUserIcons() {
      var userIcons = this.$store.state.headList.slice() || [];
      var curIcon = null;
      var _this = this;
      curIcon = userIcons.find(i => i.userID === this.teacherID);
      console.log(this.teacherInfoImg);
      if (curIcon) {
        this.imgSrc = curIcon.imgData;
      } else if (
        this.teacherInfoImg &&
        this.teacherInfoImg[0] &&
        this.teacherInfoImg[0].iconID
      ) {
        getHead(
          {
            iconID: this.teacherInfoImg[0].iconID
          },
          result => {
            let obj = {
              userID: _this.customerID,
              imgData: result
            };
            userIcons.push(obj);

            this.imgSrc = result;
            store.commit(types.HEADLIST_ARR, userIcons);
          }
        );
      } else if (
        this.teacherInfoImg &&
        this.teacherInfoImg[0] &&
        this.teacherInfoImg[0].gender
      ) {
        this.userGender = this.teacherInfoImg[0].gender;
      }
    }
  },
  watch: {
    courseInfo() {
      this.getUserIcons();
    }
  }
};
</script>
<style lang="scss" scoped>
@function torem($px) {
  @return $px/37.5 + rem;
}

.top {
  display: flex;
  align-items: center;
  padding: torem(15) 0;
  border-bottom: 1px dashed #ddd;
  .subject-container {
    .subject-img {
      width: torem(20);
      height: torem(20);
    }
    .subject-img > img {
      max-width: 100%;
      max-height: 100%;
      border-radius: 50%;
    }
    display: inline-block;
    width: torem(60);
    height: torem(60);
    margin-right: torem(15);
    border-radius: 50%;
    text-align: center;
    color: #fff;
    font-size: torem(16);
    .subject-name {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100%;
      .other {
        font-size: torem(14);
      }
    }
  }
  .right {
    vertical-align: top;
    display: inline-block;
    .name {
      margin-bottom: torem(10);
      font-size: torem(16);
      color: #666666;
    }
    .teachar {
      margin-bottom: torem(10);
      font-size: torem(16);
      color: #666666;
      b {
        padding-right: torem(5);
      }
      span {
        font-size: torem(12);
        color: #2a2a2a;
      }
    }
    .time {
      font-size: torem(13);
      color: #666666;
    }
  }
}
</style>
