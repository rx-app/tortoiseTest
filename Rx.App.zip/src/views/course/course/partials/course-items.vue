﻿<template>
<div>
  <div class="xdapp-courselist-container">
    <scroll
      :data="courseList"
      :listen-scroll="listenScroll"
      :probe-type="probeType"
      :pullup="pullup"
      @scrollToEnd="searchMore"
      class="scroll-container"
      ref="list-view">
     <div class="course-list">
        <ul class="list-group mui-table-view-chevron">
        <li v-for="(course,index) in courseList"
        @tap="goDetail(course)"
                     
                      :key="index"
                      class="item"
                      tag="li">
          <div class="subject-container" :class="(!course.subject || course.subject>7) ? 'subject' :'subject'+course.subject">
            <span class="subject-name" v-if="course.subject" :style="course.subjectName.length<=4 ? 'font-size:14px' : 'font-size:12px'"><strong>{{course.subjectName}}</strong></span>
            <span class="subject-name other" v-else>
                  <strong>不限科目</strong>
                </span>
          </div>
          <div class="desc">
            <div class="name">{{course.subjectName}}</div>
            <div class="teacher">教师：{{course.teacherName}}</div>
          </div>
          <div class="time">
            {{course.startTime | dateFormat}} {{course.startTime | timeFormat}}-{{course.endTime | timeFormat}}
          </div>
          <div class="type">
            <span class="mui-badge course-time">{{course.amount}}课时</span>
            <span class="rate go" v-role v-if="!course.evaluate">待评价</span>
          </div>
        </li>
        <loading v-show="hasMore" title=""></loading>
      </ul>
      </div>
      
    </scroll>
  </div>
  <tip v-show="!hasData">
    <span>暂无上课记录</span>
  </tip>
  </div>
</template>
<script>
  import {ASSIGN_STATUS, ACTION_TYPES} from '@/constants';
  import {pager, orderBy, defaultPageSize} from '@/public/constant';
  import {getStudentCourses} from '@/api/course/course-api';
  import {loadUserInfo, getCurrentChild} from '@/api/common/common-api';
  import Scroll from '@/components/scroll/index';
  import Loading from '@/components/loading/index';
  import Tip from '@/components/tip';

  export default {
    data(){
      return {
        probeType: 3,
        listenScroll: true,
        pullup: true,
        hasMore: false,
        hasData: false,
        courseList: [],
      }
    },
    created(){
      this.initData();
      this.getCourseList();
      this.switchChild();
      
    },
    mounted(){
      document.body.style.background='#fff'
    },
    destroyed() {
      // document.body.style.background='#efeff4';	
      //这里不恢复页面的背景色，能跳转的页面只有各导航栏的首页和课表内的页面，不恢复也不影响，恢复了跳转至成绩管理时会变灰色
		},
    methods: {
      async getCourseList(){
        await loadUserInfo();

        if (this.isloading) return;
        this.isloading = true;
        getStudentCourses(this.params, res => {
          if (!res || !res.queryResult || !res.queryResult.totalCount) {
            this.hasData = false;
            return;
          }
            this.hasData = true;

          this.courseList = this.courseList.concat(res.queryResult.pagedData);
          this._checkMore(res.queryResult.totalCount);
          this.isloading = false;
        });
      },



      goDetail(course){
         if(m2.cache.get('rx-current-child').relation!=1){
           this.$router.push({name:'course-detail',query:{assignID:course.assignID,teacherID:course.teacherID,type:course.evaluate?'1':'0'}});
         }else{
           this.$router.push({name:!course.evaluate?'course-evaluate':'course-detail',query:{assignID:course.assignID,teacherID:course.teacherID,type:'1'}})
         }
      },
      getCourseListForSwitchChild(){
        this.initData();
        this.getCourseList();
      },
      initData(){
        this.courseList = [];
        this.params = {
          studentID: getCurrentChild().id,
          assignStatus: [ASSIGN_STATUS.Confirmed],
          ...pager({pageSize: defaultPageSize}),
          ...orderBy({dataField: 'StartTime'})
        };
        //this.hasData = true;
        this.isloading = false;
      },
      searchMore(){
        if (!this.hasMore)
          return;

        this.params.pageParams.pageIndex++;
        this.getCourseList();
      },
      switchChild(){
        xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getCourseListForSwitchChild);
      },
      _checkMore(totalCount){
        if (this.params.pageParams.pageIndex * this.params.pageParams.pageSize > totalCount)
          this.hasMore = false;
        else
          this.hasMore = true;
      },

    },
    computed: {
      subjectClassName(){
      }
    },
    components: {
      Scroll,
      Loading,
      Tip
    }
  }
</script>

<style lang="scss" scoped>
.course-time{
  border:1px solid #ccc;
  background: #fff;
}
  .xdapp-courselist-container {
    position: fixed;
    width: 100%;
    top: calc(75px + 2rem);
    bottom: 50px;
    .scroll-container {
      height: 100%;
      /*overflow: hidden;*/
      .course-list {
        .list-group {
          background: #fff;
          .item {
            position: relative;
            display: flex;
            align-items: center;
            height: 70px;
            border-bottom: 1px dashed #eee;
            padding: 0 torem(15);
          }
        }
      }
    }
		.subject-container {
			display: inline-block;
			width: torem(40);
			height: torem(40);
			margin-right: torem(15);
			border-radius: 50%;
			text-align: center;
			color: #fff;
			font-size: torem(16);
			.subject-name {
				display: flex;
				justify-content: center;
				align-items: center;
				height: 100%;
				.other {
					font-size: torem(14);
				}
			}
		}
		.item {
			position: relative;
			height: 70px;
			border-bottom: 1px dashed #eee;
			padding: 15px 0 0 20px;
			img {
				width: 40px;
				height: 40px;
				margin-right: 14px;
				vertical-align: middle;
			}
			.desc {
				display: inline-block;
				vertical-align: middle;
				.name {
					font-size: 14px;
					color: #1f2d3d;
					line-height: 20px;
				}
				.teacher {
					font-size: 12px;
					color: #888;
					line-height: 16px;
					margin-top: 5px;
				}
			}
			.time {
				position: absolute;
				right: 16px;
				top: 15px;
				font-size: 12px;
				color: #999999;
			}
			.type {
				line-height: 20px!important;
				position: absolute;
				right: 16px;
				bottom: 10px;
				font-size: 14px;
        .rate {
          background-color: #fff;
          font-size: torem(12);
          line-height: 1;
          display: inline-block;
          padding: 3px 6px;
          border-radius: 100px;
        }
        .go {
          color: #fd9106;
          border: 1px solid #fd9106;
        }
			}
		}
	}
</style>