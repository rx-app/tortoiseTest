﻿<template>
  <div>
    <div class="pop-box">
      <div class="main">
        <course-info :courseInfo="courseInfo" :teacherInfoImg="teacherInfoImg" :teacherID="teacherID"></course-info>
        <course-evaluate v-show="this.$route.query.type==1" v-if="showEvaluate"
                         :courseInfo="courseInfo"
                         :evaluateConfig="evaluateConfig"
                         :evaluate="evaluate"
                         :items="items">
        </course-evaluate>
      </div>
    </div>
  </div>
</template>
<script>
  import courseInfo from './partials/course-info';
  import courseEvaluate from './partials/course-evaluate';
  import {ACTION_TYPES, ASSIGN_STATUS as assignStatus, COURSE_EVALUATE_SCORE_CONFIG as scoreConfig} from '@/constants';
  import {getLessonInfo, postLessonEvaluation} from '@/api/course/course-api';

  export default {
    data() {
      return {
        courseInfo: {},
        evaluate: {},
        teacherInfoImg:[],
        evaluateConfig: {
          title: '课堂评价',
          scoreConfig: scoreConfig
        },
        items: []
      }
    },
    created(){
      this.getCourseDetail(this.assignID);
    },
    // mounted () {

    // },
    // beforeRouteEnter(to,from,next){
    //   document.body.style.background='#fff';
    //   next();
    // },
    // beforeRouteLeave(to,from,next){
    //   document.body.style.background='#efeff4';
    //   next();
    // },
    mounted(){
			document.body.style.background='#fff';
		},
		destroyed() {
			document.body.style.background='#efeff4';		
		},
    methods: {
      submit(){
        this.items.forEach(item => this.evaluate[item.key] = item.score);
        postLessonEvaluation(this.evaluate, () => {
          this.$router.push({name: "course"});
        });
      },
      getCourseDetail(assignID) {
        getLessonInfo({'assignID': assignID}, (res) => {
          // 查询教师头像
          /*  let tInfo = res.teacherInfos
            let teacherAva = ''
            tInfo.map(two => {
              if (res.lessonInfo.teacherID === two.teacherID) {
                if (two.iconID !== null && two.iconID !== ''){
                  // 取头像
                  getHead({
                      iconID: two.iconID
                    }, (res => {
                      teacherAva = res.replace(/\'/g, '');
                  }))
                } else {
                  if (two.gender == 1) {
                   teacherAva = require('@/public/asset/img/user/teacher-man.png');
                  } else if (two.gender == 2){
                    teacherAva = require('@/public/asset/img/user/teacher-woman.png')
                  }else{
                    teacherAva = require('@/public/asset/img/home/head.png');
                  }
                }
              }
            })
          res.lessonInfo.teacherAva = teacherAva*/
         this.teacherInfoImg=res.teacherInfos;
          this.callback(res)
        });
      },
      // getCourseDetail(assignID) {
      //   getLessonInfo({'assignID': assignID}, (res) => this.callback(res));
      // },
      callback(res){
        this.courseInfo = res.lessonInfo;
        this.evaluate = res.lessonInfo.evaluate;
        this.items = this.getCourseItems(this.evaluate);
        // 订阅右上角提交课后评价事件
        if (this.courseInfo.assignStatus == assignStatus.Confirmed && !this.courseInfo.evaluateStatus)
          xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
      },
      getCourseItems(evaluate) {
        return [
          {
            key: 'goal',
            title: '辅导目标',
            score: this.evaluate.goal || 0,
            desc: this.getScoreDesc(this.evaluate.goal)
          },
          {
            key: 'attitude',
            title: '授课态度',
            score: this.evaluate.attitude || 0,
            desc: this.getScoreDesc(this.evaluate.attitude)
          },
          {
            key: 'atmosphere',
            title: '课堂氛围',
            score: this.evaluate.atmosphere || 0,
            desc: this.getScoreDesc(this.evaluate.atmosphere)
          },
          {
            key: 'logic',
            title: '逻辑严谨',
            score: this.evaluate.logic || 0,
            desc: this.getScoreDesc(this.evaluate.logic)
          },
          {
            key: 'style',
            title: '形式新颖',
            score: this.evaluate.style || 0,
            desc: this.getScoreDesc(this.evaluate.style)
          }];
      },
      getScoreDesc(val){
        let config = scoreConfig.find(item => item.value == val);
        if (!config) return undefined;
        return config.desc;
      }
    },
    watch: {
      items: {
        handler: function (val) {
          xdapp.util.vue.commitActionStatus(val.every(item => item.score) && !this.courseInfo.evaluateStatus);
        },
        deep: true
      }
    },
    computed: {
      assignID() {
        return this.$route.query.assignID;
      },
      showEvaluate(){
        return this.courseInfo.assignStatus == assignStatus.Confirmed;
      },
      teacherID() {
				return this.$route.query.teacherID;
			},
    },
    components: {
      courseInfo,
      courseEvaluate
    }
  }
</script>
<style lang="scss" scoped>
  .pop-box {
    width: 100%;
    background: #fff;
    .main {
      padding: 0 torem(20) torem(20) torem(20);
    }
  }
</style>
