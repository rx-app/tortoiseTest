<template>
	<div class="mui-content" id="home">
		<ul class="mui-table-view kb-nav">
			<router-link v-for="(item,index) in accountList" tag="li" :to="{name:'accountStatement',query:{id:item.accountID,code:item.accountCode}}" :key="index" class="mui-table-view-cell">
				<a class="mui-navigate-right" href="javascript:void(0)">
					<span class="mui-icon iconfont icon-adduser"></span>
					<span class="rx-kb-nav">账户{{item.accountCode}}</span>
				</a>
			</router-link>
			
		</ul>
	</div>
	
</template>

<script>
	import {mapGetters} from 'vuex';
	import {GET_ACCOUNT_LIST} from '@/api/customer/customer-api'
	export default{
		data(){
			return{
				accountList:[]
			}
			
		},
		computed: {
			...mapGetters(['currentChild'])	
		},
		mounted () {
			this.getAccountList()
		},
		watch: {
			currentChild(){
				this.accountList=[];
				this.getAccountList();
			}	
		},
		methods: {
			getAccountList(){
				GET_ACCOUNT_LIST(
					{customerID:this.currentChild.id},
					(res)=>{
						this.accountList=res.accounts
					}
				)
			}
		}
	}
</script>

<style scoped>

</style>