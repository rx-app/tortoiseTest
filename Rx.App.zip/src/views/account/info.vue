﻿<template>
  <div style="padding-bottom:55px;">
    <div class="rx-cinfo">
      <div class="top">
        <img :src="currentChildImg" alt>
      </div>
      <div class="bottom">
        <div class="child-name">学员
          <span class="mui-badge mui-badge-warning">{{this.currentChild.name}}</span>
        </div>编号
        <span class="mui-badge mui-badge-purple">{{this.currentChild.code}}</span>
      </div>
    </div>
    <div v-show="accountList.length!=0 && role" class="rx-account-item">
      <div class="account-code">
        当前账户
        <span class="mui-badge mui-badge-success">{{item.accountCode}}</span>
        <button
          class="btn btn-default btn-xs shiny fr"
          v-show="accountList.length>1"
          id="showUserPicker"
        >
          <i class="mui-icon iconfont icon-exchange" style="font-size:12px"></i>
          <span class="action">切换账户</span>
        </button>
      </div>
      <div class="info">
        <div class="box-left">
          <div>账户价值</div>
          <div>
            <span class="number">{{item.accountValue}}</span>元
          </div>
        </div>
        <div class="box-right">
          <div>可用金额</div>
          <div>
            <span class="number">{{item.accountMoney}}</span>元
          </div>
        </div>
      </div>
      <div class="info">
        <div class="box-left">
          <div>订购余额</div>
          <div>
            <span class="number">{{item.assetMoney}}</span>元
          </div>
        </div>
        <div class="box-right">
          <div>剩余排定课时</div>
          <div>
            <span class="number">{{item.remainedAssignedAmount}}</span>个
          </div>
        </div>
      </div>
      <div class="bottom">
        <router-link
          tag="div"
          :to="{name:'accountStatement',query:{id:item.accountID,code:item.accountCode}}"
        >
          <i class="iconfont icon-accountAtate"></i> 查看对账单
        </router-link>
        <router-link
          tag="div"
          :to="{name:'orderList',query:{id:item.accountID,code:item.accountCode}}"
        >
          <i class="iconfont icon-shop"></i> 查看订购单
        </router-link>
      </div>
    </div>
    <div v-show="!role" class="rx-account-item noright-tip">您不是该孩子的主要监护人，不能查看账户信息</div>
    <div class="mask" v-show="showBox"></div>
    <div class="pop-box" v-show="showBox">
      <div class="close" @click="showBox=false"></div>
      <div class="line"></div>
      <div class="main">
        <div class="alist">
          <div
            @click="itemIndex=index"
            v-for="(item,index) in accountList"
            :key="index"
          >{{item.accountCode}}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import "@/public/asset/js/mui/mui.pick";
import "@/public/asset/css/mui/mui.pick.css";

import { mapGetters } from "vuex";
import { CACHE_KEYS, ACTION_TYPES } from "@/constants";
import { GET_ACCOUNT_LIST } from "@/api/customer/customer-api";
import { loadUserInfo, getCurrentChild } from "@/api/common/common-api";
var userPicker = null;

export default {
  data() {
    return {
      accountList: [
        // {id:1,name:'韩程璐',account:'账户AC1704335346',token:'f32df3243'},
        // {id:2,name:'韩程璐2',account:'账户AC1704335342',token:'f32df3243'}
      ],
      showBox: false,
      itemIndex: 0,
      currentChildImg: "",
      customerID: getCurrentChild().id
    };
  },
  beforeDestroy() {
    console.log(11);
    function removeElementsByClass(className) {
      var elements = document.getElementsByClassName(className);
      while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
      }
    }
    removeElementsByClass("mui-poppicker");
  },
  computed: {
    code() {
      return m2.cache.get("rx-current-child").code;
    },
    item() {
      return this.accountList[this.itemIndex]
        ? this.accountList[this.itemIndex]
        : {};
    },
    ...mapGetters(["currentChild"]),
    role() {
      return $vue.$store.state.currentChild.relation == 1;
    },
    currentUser() {
      return (
        this.$store.getters.currentModiHead ||
        m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD)
      );
    }
  },
  async created() {
    await loadUserInfo("upd");
    this.getIcon();
  },
  mounted() {
    userPicker = new mui.PopPicker();
    this.getAccountList();
    this.switchChild();
  },
  watch: {
    accountList() {
      this.pickerInit(this.accountList);
    },
    currentUser: {
      handler: function() {
        this.getIcon();
      },
      deep: true
    }
  },
  methods: {
    getIcon() {
      if (m2.cache.get("rx-current-user")) {
        var userIcons = this.currentUser;
        var currentChildId = m2.cache.get("rx-current-child").id;
        let curIcon = null;
        if (userIcons && userIcons.length) {
          curIcon = userIcons.find(i => i.userID === currentChildId);
        }
        if (curIcon && curIcon.imgData) {
          this.currentChildImg = curIcon.imgData;
        } else if (curIcon && curIcon.gender) {
          let img = curIcon.gender == 1 ? "boy.png" : "girl.png";
          this.currentChildImg = require(`@/public/asset/img/user/${img}`);
        }
      }
    },
    switchChild() {
      xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getAccountList);
    },
    dataInit(list) {
      list = list.map((v, i) => {
        return {
          text: v.accountCode,
          value: v.accountID
        };
      });
      userPicker.setData(list);
    },
    pickerInit(list) {
      list = list.map((v, i) => {
        return {
          text: v.accountCode,
          value: v.accountID
        };
      });
      var that = this;
      (function($, doc) {
        $.init();
        $.ready(function() {
          //普通示例
          //	userPicker = new $.PopPicker();
          userPicker.setData(list);
          var showUserPickerButton = doc.getElementById("showUserPicker");

          showUserPickerButton &&
            showUserPickerButton.addEventListener(
              "tap",
              function(event) {
                userPicker.show(function(items) {
                  that.accountList.forEach((v, i) => {
                    if (v.accountCode == items[0].text) that.itemIndex = i;
                  });
                  //	userResult.innerText = JSON.stringify(items[0]);
                  //返回 false 可以阻止选择框的关闭
                  //return false;
                });
              },
              false
            );
        });
      })(mui, document);
    },
    async getAccountList() {
      await loadUserInfo();
      this.getIcon();
      if (!Object.keys(this.currentChild).length) {
        return;
      }
      GET_ACCOUNT_LIST(
        //rx.api.customer.getAccountList,
        {
          customerID: this.currentChild.id
        },
        res => {
          this.accountList = res.accounts;
          this.dataInit(res.accounts);
        }
      );
    }
  }
};
</script>

<style lang="scss" scoped>
.mui-btn {
  width: 46px !important;
}

.noright-tip {
  color: #aaa;
  font-size: 15px;
  text-align: center;
}

.mask {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  background: rgba($color: #000000, $alpha: 0.6);
  z-index: 50;
}

.pop-box {
  .close {
    width: torem(30);
    height: torem(30);
    background: #fff;
    position: absolute;
    right: torem(5);
    top: torem(-50);
  }
  .line {
    height: torem(20);
    width: 1px;
    background: #f0f4f8;
    z-index: 99;
    position: absolute;
    right: torem(20);
    bottom: 100%;
  }
  position: fixed;
  z-index: 100;
  top: torem(144);
  left: torem(28);
  width: torem(320);
  background: #fff;
  border-radius: torem(5);
  .main {
    padding: torem(26) torem(23) torem(34);
    .alist {
      div {
        height: 30px;
        line-height: 30px;
        font-size: 20px;
        text-align: center;
        color: #f3e418;
      }
    }
  }
}

.rx-cinfo {
  position: relative;
  height: torem(200);
  width: torem(345);
  margin: 0 torem(15);
  padding-bottom: 55px;
  .top {
    position: absolute;
    width: torem(90);
    height: torem(90);
    top: torem(30);
    border-radius: 50%;
    margin: auto;
    left: 0;
    right: 0;
    overflow: hidden;
    img {
      width: 100%;
      height: 100%;
    }
    z-index: 10;
  }
  .bottom {
    background: rgba(255, 255, 255, 0.89);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    border-radius: 12px 12px 0 0;
    padding-top: torem(60);
    height: torem(120);
    position: absolute;
    bottom: 0;
    width: 100%;
    text-align: center;
    color: #999;
    .child-name {
      margin-bottom: torem(5);
    }
  }
}

.line {
  background: #fff;
  height: torem(4);
  margin: 0 torem(15);
  box-shadow: 0 0 10px #999;
}

.rx-account-item {
  margin: 0 torem(15) 0;
  background: rgba(255, 255, 255, 0.89);
  box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
  border-radius: 0 0 12px 12px;
  padding: torem(10) torem(10);
  .account-code {
    padding-bottom: torem(10);
    line-height: torem(22);
    border-bottom: 1px dashed #ccc;
    color: #999;
    .mui-icon {
      margin-right: torem(5);
      color: #999;
    }
    .action {
      display: inline-block;
      vertical-align: top;
    }
  }
  .info {
    overflow: hidden;
    .box-left,
    .box-right {
      width: torem(162);
      padding: torem(22) 0;
      text-align: center;
      float: left;
      div {
        @include letterStyle(13, #999, 1, 22);
        margin-bottom: 5px;
        span.number {
          @include letterStyle(18, #e03229, 0, 22);
          margin-right: 5px;
        }
      }
    }
    .box-left {
      border-right: 1px dashed #ccc;
    }
    .box-right {
      margin-left: -1px !important;
    }
  }
  .bottom {
    padding: torem(15) 0;
    overflow: hidden;
    text-align: center;
    div {
      width: 50%;
      height: torem(35);
      line-height: torem(35);
      float: left;
      color: #666;
      vertical-align: bottom;
      text-align: center;
      i {
        vertical-align: bottom;
        width: torem(35);
        height: torem(35);
        border: 1px solid #a7b4bf;
        color: #a7b4bf;
        border-radius: 100%;
        display: inline-block;
        margin-right: torem(8);
        font-size: torem(19);
      }
    }
  }
}

.fc {
  color: #8f8f94 !important;
}

.name {
  margin-right: 30px;
  font-size: 18px;
  color: #1ce05d;
  letter-spacing: 2px;
}

.info {
  border-bottom: 1px dashed #ccc;
}

.info .num {
  font-weight: 500;
  color: rgb(32, 145, 32);
  margin-right: 5px;
  letter-spacing: 1px;
}

label.item {
  color: #717175;
}
</style>