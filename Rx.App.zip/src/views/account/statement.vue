﻿<template>
  <div class="container rx-account-statement" style="padding: 10px 0px;">
    <div class="rx-account-statement-header">
      <tab on="right"></tab>
      <p class="user">
        <span class="account">当前账户
          <span class="mui-badge mui-badge-success">{{accountCode}}</span>
        </span>
        <span id="openPopover" @click="showBox" v-show="!isshow" class="classify fr">
          <i class="mui-icon iconfont icon-filter"></i>
          <span
            class="mui-badge mui-badge-purple filter-type filter-category"
          >{{typeName | substr()}}</span>
          <span class="mui-badge mui-badge-purple filter-type" v-if="time">{{time}}</span>
        </span>
        <span class="confirm fr" v-show="isshow" @click="confirm()">
          <i class="mui-icon iconfont icon-check-mark"></i>确认
        </span>
      </p>
    </div>

    <ul
      class="rx-account-statement-main"
      v-infinite-scroll="loadMore"
      infinite-scroll-disabled="loading"
      infinite-scroll-distance="10"
    >
      <li v-for="(item,index) in accountList" :key="index" class>
        <p class="info">
          <span class="info-txt">
            <span class="action">{{item.recordTypeName}}</span>
            <br>
            <span class="time">{{item.sourceOPTime | dateFormat}} {{item.sourceOPTime | timeFormat}}</span>
          </span>
          <span class="cash-box">
            <span class="cash">+{{item.settledAmount}}</span>元
            <div>成功</div>
          </span>
        </p>
      </li>
    </ul>
    <div id="popover" ref="popover" v-show="isshow" style="height:auto" class="classifies">
      <div class="triangle"></div>
      <div class="input-group input-group-sm">
        <span class="input-group-addon" :class="time.split('-').length>=3?'day-checked':''">历史月份</span>
        <input
          readonly
          type="text"
          class="form-control time-picker"
          placeholder="选择历史月份"
          data-options="{&quot;type&quot;:&quot;month&quot;}"
          v-model="time"
        >
        <span
          class="input-group-addon"
          style="margin-left:10px;"
          @click="toChangeToday()"
          :class="time.split('-').length>=3?'':'day-checked'"
        >今天</span>
      </div>
      <button
        @click="addType(item.key,item.value)"
        class="btn btn-default shiny"
        v-for="(item,index) in typeList"
        :class="{'btn-checked':item.key ==currentIndex }"
        :key="index"
      >{{item.value}}</button>
    </div>
  </div>
</template>

<script>
import "@/public/asset/js/jquery/jquery-1.8.0";
import "@/public/asset/js/mui/mui.pick";
import "@/public/asset/css/mui/mui.pick.css";

import { mapGetters } from "vuex";
import { QUERY_ACCOUNT_FLOW_LIST } from "@/api/customer/customer-api";
import { loadUserInfo, getCurrentChild } from "@/api/common/common-api";
import { GET_ACCOUNT_LIST } from "@/api/customer/customer-api";
import tab from "./partials/account-tab";
import { Toast } from "mint-ui";
export default {
  data() {
    return {
      pageIndex: 1,
      //currentChild: getCurrentChild(),
      customerID: getCurrentChild().id,
      accountList: [],
      typeList: [],
      isshow: false,
      typeName: "全部",
      recordType: [],
      total: 0,
      currentIndex: 0,
      isall: false, //判断筛选条件是全部的情况
      time: m2.date.normalizeShort(new Date()),
      accountCode: this.$route.query.code,
      accountID: this.$route.query.id,
      loading: false
    };
  },
  async mounted() {
    this.pickerInit();
  },
  computed: {
    ...mapGetters(["currentChild"])
  },
  watch: {
    async currentChild(a, b) {
      if (this.currentChild.relation != 1) {
        this.$router.push({
          name: "account"
        });
        return;
      }
      await GET_ACCOUNT_LIST(
        {
          customerID: this.currentChild.id
        },
        res => {
          this.accountCode = res.accounts[0].accountCode;
          this.accountID = res.accounts[0].accountID;
          this.getAccountList();
        }
      );
      this.accountList = [];
      this.pageIndex = 1;
    }
  },
  methods: {
    loadMore() {
      this.loading = true;
      this.getAccountList();
    },
    pickerInit() {
      var that = this;
      (function($) {
        $.init();
        var btns = $(".time-picker");
        btns.each(function(i, btn) {
          btn.addEventListener(
            "tap",
            function() {
              var optionsJson = this.getAttribute("data-options") || "{}";
              var options = JSON.parse(optionsJson);

              var picker = new $.DtPicker(options);
              picker.show(function(rs) {
                that.time = rs.text;
                picker.dispose();
              });
            },
            false
          );
        });
      })(mui);
    },
    toChangeToday() {
      this.time = m2.date.normalizeShort(new Date());
    },
    showBox() {
      this.isshow = !this.isshow;
      //this.recordType = [];
    },
    getmore() {
      if (this.recordType == 0) {
        this.getAccountList();
      } else {
        this.getAccountListByType(1);
      }
    },
    getAccountList() {
      QUERY_ACCOUNT_FLOW_LIST(
        {
          customerID: this.currentChild.id,
          AccountID: this.accountID,
          QueryDateType: this.time.split("-").length >= 3 ? 1 : 2, //this.time ? 2 : 1,
          month: this.time,
          //data: '2018-04-25',
          pageParams: {
            pageIndex: this.pageIndex,
            pageSize: 10
          },
          orderby: [
            {
              DataField: "BillTime",
              SortDirection: 0
            }
          ],
          recordTypes: this.recordType
        },
        res => {
          this.accountList = [
            ...this.accountList,
            ...res.queryResult.pagedData
          ];
          this.typeList = [
            {
              key: 0,
              value: "全部"
            },
            ...res.dictionaries.RecordTypes
          ];
          this.pageIndex++;
          this.total = res.queryResult.totalCount;
          if (this.accountList.length < res.queryResult.totalCount) {
            this.loading = false;
          } else {
            if (this.accountList.length == 0) {
              Toast("当前条件下无账单信息...");
            } else {
              Toast({
                message: "全部账单已加载完毕...",
                position: "bottom"
              });
            }
          }
        }
      );
    },
    confirm() {
      this.pageIndex = 1;
      this.accountList = [];
      this.isshow = false;
      this.getAccountList();
    },
    addType(type, name) {
      this.currentIndex = type;
      this.recordType = type == 0 ? [] : [type];
      this.typeName = name;
      if (type == 0) {
        this.isall = true;
      }
    }
  },
  beforeDestroy() {
    function removeElementsByClass(className) {
      var elements = document.getElementsByClassName(className);
      while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
      }
    }
    removeElementsByClass("mui-dtpicker");
  },
  components: {
    tab
  }
};
</script>

<style lang="scss" scoped>
.rx-account-statement {
  .rx-account-statement-main {
    background: #fff;
    margin-top: 114px;
    li {
      padding: 12px 0 0;
      margin: 0 15px;
      background: #fff;
      &::after {
        margin-top: 12px;
        content: "";
        background: #c8c7cc;
        height: 1px;
        display: block;
        transform: scaleY(0.5);
      }
    }
  }
  .rx-account-statement-header {
    position: fixed;
    background: #fff;
    z-index: 990;
    width: 100%;
    p {
      padding: 13px 15px;
      line-height: 18px;
      margin-bottom: 0;
    }
    &::after {
      content: "";
      background: #c8c7cc;
      height: 1px;
      display: block;
      transform: scaleY(0.5);
    }
  }
  .mui-pull {
    bottom: 0px;
  }
  .mui-pull-bottom-pocket {
    bottom: -30px;
  }
  .classify i {
    font-size: 14px;
  }
  .classify i,
  .confirm i {
    color: #999;
    margin-right: 2px;
  }
  .filter-type {
    margin-left: 2px;
  }
  .classifies {
    max-height: 55%;
    overflow: auto;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    position: fixed;
    top: torem(170);
    left: 0 !important;
    right: 0 !important;
    z-index: 990;
    width: 79%;
    margin-left: 18%;
    background: #eee;
    -webkit-box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    border-radius: 8px;
    padding-top: 10px;

    .input-group span.day-checked {
      color: #000;
      background-color: #ccc !important;
      border-color: #ccc !important;
    }
    p {
      margin-left: 10px;
    }
    .input-group {
      display: flex;
      width: 100%;
      margin: 0 torem(5) torem(10);
      .input-group-addon {
        width: auto;
        border-color: #5db2ff !important;
        background-color: #5db2ff !important;
        background-image: none;
        color: #fff;
      }
    }
  }
  .triangle {
    width: 0px;
    height: 0px;
    border-width: 8px;
    border-style: solid;
    border-color: transparent transparent #eee transparent;
    position: absolute;
    top: -16px;
    right: 8px;
  }
  .classifies .btn {
    margin: 6px;
    flex: 1;
    color: #666;
    font-size: 12px;
    border-color: #eee;
  }
  .fc {
    color: #8f8f94 !important;
  }
  .name {
    margin-right: 30px;
    font-size: 18px;
    color: #1ce05d;
    letter-spacing: 2px;
  }
  .info .num {
    font-weight: 500;
    color: rgb(32, 145, 32);
    margin-right: 5px;
    letter-spacing: 1px;
  }
  label.item {
    color: #717175;
  }
  .info {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  i.icon {
    display: inline-block;
    margin-right: 8px;
    /*vertical-align: top;使用flex可以避免对不齐的问题*/
    width: 50px;
    height: 50px;
    line-height: 50px;
    text-align: center;
    font-style: normal;
    color: #fff;
    font-weight: 600;
    border-radius: 50%;
    -webkit-box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    box-shadow: 0 2px 10px 1px rgba(148, 148, 148, 0.25);
    background-image: -webkit-gradient(
      linear,
      left top,
      right top,
      from(#00b3ed),
      to(#2badce)
    );
    background-image: linear-gradient(90deg, #00b3ed 0%, #2badce 100%);
  }
  span.action {
    color: #666;
    line-height: 22px;
    font-size: 16px;
  }
  span.time {
    color: #999;
    line-height: 16px;
    font-size: 12px;
  }
  .info-txt {
    display: inline-block;
    width: 80px;
    flex: 1;
  }
  .cash-box {
    width: 100px;
    height: 14px;
    display: block;
    text-align: right;
    line-height: 14px;
    color: #333;
    transform: translateY(-12px);
    .cash {
      color: #e03229;
    }
    div {
      font-size: 12px;
      color: #999;
      margin-top: 10px;
    }
  }
}

.mui-pull {
  bottom: 0;
}

.mui-pull-caption {
  font-size: 12px;
  /* line-height: 24px; */
  font-weight: normal;
}

.btn-checked {
  background: #5db2ff;
  border-color: #5db2ff !important;
  color: #fff !important;
}

.trangles {
  width: 0px;
  height: 0px;
  border-color: transparent dodgerblue dodgerblue transparent;
  border-width: 8px;
  border-style: solid;
  position: absolute;
  bottom: torem(-1);
  right: torem(-1);
}

@media only screen and (max-width: 320px) {
  .rx-account-statement .classifies {
    display: block;
  }
  .rx-account-statement .rx-account-statement-main {
    //margin-top: torem(210) !important;
  }
  span.mui-badge.mui-badge-purple.filter-type.filter-category {
    max-width: 40px;
    height: 18px;
    line-height: 12px;
    overflow: hidden;
    line-height: 14px;
    padding-top: 2px;
  }

  .rx-account-statement .classifies .input-group {
    display: block;
    padding: 0 0.13333rem 0.26667rem;
    margin: 0;
    font-size: 0;
  }
  .rx-account-statement .classifies .input-group .form-control {
    float: none;
    display: inline-block;
    width: 169px;
  }
  .rx-account-statement .classifies .input-group .input-group-addon {
    display: inline-block;
    vertical-align: top;
  }

  .btn {
    width: calc(50% - 12px);
    min-width: 64px;
    box-sizing: border-box;
  }
  .rx-account-statement .classifies {
    top: torem(215) !important;
    width: 95% !important;
    margin-left: 2% !important;
  }
  .rx-account-statement .triangle {
    top: torem(-25) !important;
  }
}

@media only screen and (min-width: 321px) and (max-width: 384px) {
  .rx-account-statement .classifies {
    top: torem(190) !important;
  }
}
</style>