<template>
	<div class="rx-order-list">
		<div class="rx-account-order-header">
			<tab on="left"></tab>
		</div>
		<div id="stu-main-content" class="main-content" :style="{'-webkit-overflow-scrolling': scrollMode}">
			<mt-loadmore class="loadMore" :bottom-method="loadBottom" :auto-fill="false" :bottom-all-loaded="allLoaded" :bottom-distance=-70 ref="loadmore">
				<ul class="mui-table-view" v-if="orderList.length">
					<li class="mui-table-view-cell mui-collapse rx-order-item" v-for="(item,index) in orderList" :key="index">
						<a class="mui-navigate-right fc" href="#">订购单: {{item.itemNo}} <span> {{item.orderTime | dateTimeFormat}}</span></a>
						<div class="mui-collapse-content info">
							<p class="product"><label class="item" for="">产品名称:</label> <span class="num worth">{{item.productName}}</span></p>
							<p><label class="item" for="">产品类型:</label> <span class="num available">{{item.categoryTypeName}}</span></p>
							<p><label class="item" for="">订购折扣:</label> <span class="num balance">{{item.discountRate}}</span></p>
							<p><label class="item" for="">订购金额:</label> <span class="num rest "><span
                class="pay"> {{item.paidMoney}}</span>元</span>
							</p>
							<p><label class="item" for="">订购数量:</label> <span class="num rest">{{item.orderAmount}}</span></p>
							<p><label class="item" for="">赠送数量:</label> <span class="num rest">{{item.presentAmount}}</span></p>
							<p><label class="item" for="">已排数量:</label> <span class="num rest">{{item.assignedAmount}}</span></p>
							<p><label class="item" for="">已上数量:</label> <span class="num rest">{{item.confirmedAmount}}</span></p>
							<p><label class="item" for="">已退数量:</label> <span class="num rest">{{item.debookedAmount}}</span></p>
							<p><label class="item" for="">换出数量:</label> <span class="num rest">{{item.exchangedAmount}}</span></p>
							<p><label class="item" for="">剩余数量:</label> <span class="num rest">{{item.amount}}</span></p>
						</div>
					</li>
				</ul>
				<tip v-if="!orderList.length">
					<span>没有查询到订购单</span>
				</tip>
	</mt-loadmore>
		</div>
	</div>
</template>

<script>
	import { mapGetters } from 'vuex'
	import { GET_ORDER_LIST } from '@/api/customer/customer-api'
	import { loadUserInfo, getCurrentChild } from '@/api/common/common-api';
	import tab from './partials/account-tab'
	import tip from '@/components/tip';
	export default {
		data() {
			return {
				pageIndex: 1,
				pageSize: 10,
				orderList: [],
				totalCount: 0,
				allLoaded: false,
				scrollMode: "auto"
			}

		},
		computed: {
			...mapGetters(['currentChild']),
		
		},
		watch: {
			currentChild(now, old) {
				this.pageIndex = 1;
				this.orderList = []
				this.getOrderList();
			}
		},
		async mounted() {
			await loadUserInfo()
		},
		methods: {
			loadBottom() {
				this.$refs.loadmore.onBottomLoaded(); //加载完重新定位
				this.getOrderList();
			},
			getOrdertType(i) {
				return ['常规订购', '插班订购', '买赠订购', '补差兑换', '不补差兑换'][i]
			},
			getOrderList() {
				if(this.currentChild.relation !=1){
					this.$router.push({
						name:'account'
					})
					return;
				};
				if(!Object.keys(this.currentChild).length) {
					return
				}
				GET_ORDER_LIST({
						customerID: this.currentChild.id,
						pageParams: {
							pageIndex: this.pageIndex,
							pageSize: this.pageSize
						}
					},
					(res) => {
						if(res.queryResult.pagedData.length > 0) {
							this.orderList = [...this.orderList, ...res.queryResult.pagedData]
						}
						if(this.pageSize * this.pageIndex >= res.queryResult.totalCount) {
							this.allLoaded = true;
						} else {
							this.allLoaded = false;
						}
						this.pageIndex++;
					}
				)
			}
		},
		components: {
			tab,
			tip
		}
	}
</script>

<style lang="scss">
	.main-content {
		overflow: auto;
		margin-top: torem(70);
	}
	
	.rx-order-list {
		.mui-scroll {
			margin-top: 117px;
		}
		.rx-account-order-header {
			position: fixed;
			z-index: 990;
			width: 100%;
			background: #fff;
		}
		.worth {
			font-weight: 600
		}
		.rx-order-item {
			a {
				span {
					color: #999;
					font-size: 12px;
				}
			}
			div {
				padding: 2px 0;
				overflow: hidden;
				p {
					border-bottom: 1px solid #ddd;
					padding: 12px 0;
					margin: 0;
					font-size: 14px;
					color: #666;
					line-height: 20px;
					width: 50%;
					float: left;
					span {
						color: #151515;
					}
					.pay {
						color: rgb(231, 48, 48)
					}
					&.product {
						width: 100%;
						padding-left: 0 !important
					}
				}
				p:nth-of-type(odd) {
					padding-left: 10%;
				}
			}
		}
		.mui-pull-bottom-pocket {
			bottom: -30px;
		}
	}
</style>