<template>
	<div class="mui-content" id="home">
		<ul class="mui-table-view kb-nav">
			<router-link tag="li" :to="{name:'accountInfo'}" class="mui-table-view-cell">
				<a class="mui-navigate-right" href="javascript:void(0)">
					<span class="mui-icon iconfont icon-adduser"></span>
					<span class="rx-kb-nav">账户信息</span>
				</a>
			</router-link>
			<router-link tag="li" :to="{name:'chooseAccount'}" class="mui-table-view-cell">
				<a class="mui-navigate-right" href="javascript:void(0)">
					<span class="mui-icon iconfont icon-adduser"></span>
					<span class="rx-kb-nav">对账单</span>
				</a>
			</router-link>
		</ul>
	</div>
</template>

<script>
	export default{
		data(){
			return{

			}

		}
	}
</script>

<style lang="scss" scoped>
#home{
	margin-top: 20px;
}
</style>
