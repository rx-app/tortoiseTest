<template>
  <div>
    <div class="wrap" v-if="questionList && questionList.length && !submitIsSuccess">
      <div class="wrap-sub">
        <div class="wrap-cover">
          <h4>学大教育学管师服务满意度调查问卷</h4>
          <h5>尊敬的家长，您好！</h5>
          <h5>感谢您一直以来对学大教育的支持和信任！为了更好地为孩子的成长保驾护航，烦请您抽3-5分钟完成此调查问卷。谢谢！</h5>
          <ul v-for="(item,index) in questionList" :key="index">
            <li
              class="tit"
              v-if="item.question.questionType == 2"
            >{{item.question.sort}}、{{item.question.questionText}} (可多选)</li>
            <li class="tit" v-else>{{item.question.sort}}、{{item.question.questionText}}</li>
            <li class="list" v-if="item.question.questionType == 1">
              <div
                class="mui-input-row mui-radio"
                v-for="(list,ind) in item.questionOptionsList"
                :key="ind"
                @click="selRadio(list)"
              >
                <label data-v-0fc735d5>{{list.option}}、{{list.optionValue}}</label>
                <input data-v-0fc735d5 :id="list.optionID" :name="list.questionID" type="radio" />
              </div>
            </li>
            <li class="list" v-if="item.question.questionType == 2">
              <div
                class="mui-input-row mui-checkbox"
                v-for="(list,ind) in item.questionOptionsList"
                :key="ind"
                @click="selCheckbox($event,list)"
              >
                <label data-v-0fc735d5>{{list.option}}、{{list.optionValue}}</label>
                <input data-v-0fc735d5 :id="list.optionID" name="checkbox" type="checkbox" />
              </div>
            </li>
            <textarea
              name
              id
              cols="30"
              rows="10"
              v-if="item.question.questionType == 3"
              @input="changeSubmit(item.question)"
              v-model="textVal" @focus="fnFocus" @blur="fnBlur"
            ></textarea>
          </ul>
          <h5>再次感谢您的支持和配合！</h5>
          <button id="btn" @click="submit()">提交</button>
        </div>
      </div>
    </div>
    <div class="tip" v-if="submitIsSuccess">
      <span class="mark">√</span>
      <h5>提交成功！</h5>
      <h5>感谢您的支持，祝您生活顺遂！</h5>
      <span>温馨提示：点击左上角返回首页。</span>
    </div>
  </div>
</template>
<script>
mui.plusReady(function () {
  plus.webview.currentWebview().setStyle({'softinputMode':'adjustResize'});
  plus.webview.currentWebview().setStyle({ 'background': '#fff' });
});
// 2019-11-11 16:14  GuoTidan
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
function resize2() {
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
import {
  loadQuestionnaire,
  submitQuestionnaire
} from "@/api/questionnaire/questionnaire-api";
import {storageQuestionFun} from "@/public/util/util.question";
export default {
  data() {
    return {
      questionList: [],
      selQuestionListResult: [],
      selQuestionListArea: [], //存储填写完成的问题ID
      noneQuestionArr: [],
      textVal: "",
      isSubmit: true,
      submitIsSuccess: false
    };
  },
  created() {
    loadQuestionnaire("", res => {
      if (!res.questionnaire && !res.questionList) {
        mui.alert(
          "已完成调查问卷!",
          "提示",
          () => {
            storageQuestionFun("isComplete");
            this.$router.push({ name: "home" });
          },
          "",
          "div"
        );
      }
      this.questionList = res.questionList;
    });
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
    document.querySelector('.xd-header').style.position='fixed'
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
    // document.body.style.overflow = "scroll";
    // document.querySelector("html").style.overflow = "scroll";
  },
  methods: {
    setPosition() {
      console.log(1);
      var ua = navigator.userAgent.toLowerCase();
      // setTimeout(()=>{
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "415px";
        // setTimeout(() => {
        wv.setStyle({ top: "0px" });
        // wv.setStyle({'height':'100%'});
        wv.setStyle({ bottom });
        setTimeout(() => {
          // mui.toast(window.innerHeight)
        }, 1000);

        // document.querySelector('.msg-input').style.transform='translateY(10px)'
        // }, 400);
      }
      // },200)
    },
    setPosition2() {
      console.log(1);
      var ua = navigator.userAgent.toLowerCase();
      // setTimeout(()=>{
      if (/iphone|ipad|ipod/.test(ua)) {
        // alert(window.pageYOffset)
        var header = document.getElementsByTagName("header")[0];
        header.setAttribute("style", "position:fixed;top:" + 0 + "px;left:0");
        var wv = plus.webview.currentWebview();

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
        setTimeout(() => {
          // mui.toast(window.innerHeight)
        }, 1000);
      }
      // },200)
    },
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "765px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
        //mui.alert('---tttt----')
        //mui('header')[0].style.transform='translateY(-10px)'
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    //问题--单选
    selRadio(content) {
      if (this.selQuestionListResult.length) {
        this.selQuestionListResult.forEach((currentVal, index) => {
          if (currentVal.questionID == content.questionID) {
            this.selQuestionListResult.splice(index, 1, content);
          } else {
            this.selQuestionListResult.push(content);
          }
        });
      } else {
        this.selQuestionListResult.push(content);
      }
      this._delectReact();
    },
    //问题--多选
    selCheckbox(e, content) {
      if (e.srcElement.checked) {
        if (this.selQuestionListResult.indexOf(content) == -1) {
          this.selQuestionListResult.push(content);
        }
      } else {
        var currentIndex = this.selQuestionListResult.indexOf(content);
        this.selQuestionListResult.splice(currentIndex, 1);
      }
      console.log(this.selQuestionListResult);
    },
    //问题--文字
    changeSubmit(content) {
      this.textVal = this.textVal.replace(/\s*/g, "");
      if (this.textVal == "") return;
      if (this.textVal.replace(/\s*/g, "").length > 1000) {
        this.textVal = this.textVal.replace(/\s*/g, "").slice(0, 1000);
        mui.alert("最多允许输入1000个字!", "提示", "", "", "div");
        return;
      }
      if (this.selQuestionListResult.length) {
        this.selQuestionListResult.forEach((item, index) => {
          if (
            content.questionID == item.questionID &&
            content.questionType == 3
          ) {
            item.answerInput = this.textVal;
          } else if (content.questionType == 3) {
            content.answerInput = this.textVal;
            this.selQuestionListResult.push(content);
          }
        });
      } else {
        content.answerInput = this.textVal;
        this.selQuestionListResult.push(content);
      }
      this._delectReact();
    },
    submit() {
      this.noneQuestionArr = this._getArrDifference(
        this.selQuestionListArea,
        this.questionListAreas
      );
      if (this.noneQuestionArr.length) {
        this.findQuestionFun(this.noneQuestionArr);
      } else {
        submitQuestionnaire(this.selQuestionListResult, res => {
          mui.alert(
            "提交成功!",
            "提示",
            () => {
              storageQuestionFun("isComplete");
              this.submitIsSuccess = true;
            },
            "",
            "div"
          );
        });
      }
    },
    _getArrDifference(arr1, arr2) {
      return arr1.concat(arr2).filter(function(v, i, arr) {
        return arr.indexOf(v) === arr.lastIndexOf(v);
      });
    },
    _delectReact() {
      this.selQuestionListResult = this.selQuestionListResult.filter(
        (item, index, self) => {
          return self.indexOf(item) == index;
        }
      );
      console.log(this.selQuestionListResult);
    },
    findQuestionFun(idArr) {
      this.titArr = [];
      idArr.forEach(i => {
        this.questionList.forEach(item => {
          if (item.question.questionID == i) {
            this.titArr.push(
              item.question.sort + "." + item.question.questionText + "\r"
            );
          }
        });
      });
      mui.alert(
        "请填写完整以下题目：\n" + this.titArr.join(),
        "提示",
        "",
        "",
        "div"
      );
    }
  },
  computed: {
    questionListAreas() {
      this.questionListArea = [];
      this.questionList.forEach(item => {
        this.questionListArea.push(item.question.questionID);
      });
      return this.questionListArea;
    }
  },
  watch: {
    selQuestionListResult(val) {
      this.selQuestionListArea = [];
      if (val.length) {
        this.selQuestionListResult.forEach(item => {
          this.selQuestionListArea.push(item.questionID);
        });
      }
    }
  }
};
</script>  
<style lang="scss">
#xd-header {
  position: fixed !important;
}
body{
  background: #fff !important;
}
</style>
<style lang="scss" scoped>
.mui-popup {
  position: fixed !important;
}
.wrap {
  width: 100%;
  height: calc(100vh - 65px);
  overflow: scroll;
  // margin-top: 65px;
  position: fixed;
  padding-top: torem(55) !important;
  background: url(~@/public/asset/img/bg/question-bg.jpg) no-repeat;
  background-size: contain;
  .wrap-sub {
    width: 100%;
    // height: 100%;
    background: url(~@/public/asset/img/bg/question-line.jpg);
    .wrap-cover {
      width: 90%;
      // height: 100%;
      margin: -20px 0 0 5%;
      background: #fff;
      padding: torem(20) torem(10);
      h4 {
        text-align: center;
        margin: torem(18) 0;
        font-weight: bold;
      }
      h5 {
        line-height: torem(25);
        text-indent: 0.8rem;
        color: #333;
      }
      ul {
        margin-top: torem(15);
        font-size: torem(14);
      }
      .tit {
        margin-top: torem(15);
      }
      .list {
        display: flex;
        flex-wrap: wrap;
        margin-top: torem(10);
        div {
          width: 100%;
        }
      }
      .mui-radio input[type="radio"] {
        top: torem(10);
        right: torem(48);
      }
      .mui-checkbox input[type="checkbox"] {
        top: torem(10);
        right: torem(48);
      }
      .mui-radio label {
        line-height: torem(25);
        padding-right: torem(80);
      }
      .mui-checkbox label {
        line-height: torem(25);
        padding-right: torem(80);
      }
      textarea {
        margin-top: torem(15);
        border: 1px solid skyblue;
        border-radius: 5px;
        padding: torem(10);
      }
      #btn {
        margin-top: torem(20);
        width: 60%;
        background: skyblue;
        color: #fff;
        text-align: center;
        margin-left: 20%;
        border: none;
        margin-bottom: 20px;
      }
    }
  }
}
.tip {
  width: 100%;
  height: 100%;
  text-align: center;
  margin-top: torem(50);
  letter-spacing: torem(2);
  .mark {
    color: orange;
    font-size: torem(65);
  }
  h5 {
    line-height: torem(30);
    font-size: torem(18);
    color: #333;
  }
  span {
    display: inline-block;
    margin-top: torem(20);
    color: #999;
  }
}
</style>