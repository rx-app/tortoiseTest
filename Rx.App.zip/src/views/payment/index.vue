<template>
  <div class="wrap">
    <mt-navbar v-model="selected" @click="selectTab()">
      <mt-tab-item id="1" @click.stop.prevent="switchTabs('1')" class="paymentRemind">待缴费</mt-tab-item>
      <mt-tab-item id="2" @click.stop.prevent="switchTabs('2')" class="paymentAlreay">已缴费</mt-tab-item>
    </mt-navbar>
    <mt-tab-container v-model="selected">
      <mt-tab-container-item id="1">
        <div class="payment-list listLeft" v-if="noPaymentList">
          <div class="list-con">
            <!-- v-for="(item,index) in noPaymentList" :key="index" -->
            <!-- <h5>支付码仅限当天有效，请尽快完成支付。</h5> -->
            <ul>
              <li v-if="noPaymentList.submitTime">
                <span>缴费时间 :</span>
                <span>{{noPaymentList.submitTime | dateFormat}}</span>
              </li>
              <li v-if="noPaymentList.chargeMoney">
                <span>缴费金额 :</span>
                <span>{{noPaymentList.chargeMoney.toString() | numberToMoney}}</span>
              </li>
              <!-- <li v-if="noPaymentList.submitterJobName">
                <span>提交岗位 :</span>
                <span>{{noPaymentList.submitterJobName}}</span>
              </li>-->
              <li v-if="noPaymentList.submitterName">
                <span>制单人 :</span>
                <span>{{noPaymentList.submitterName}}</span>
              </li>
            </ul>
            <div class="paymentBtn" v-if="noPaymentList.submitTime">
              <button @click="goPayment()">{{btnText}}</button>
            </div>
            <payment-dialog
              v-if="noPaymentList"
              :maskShow="isShowPaymentDialog"
              :paymentAmount="noPaymentList.chargeMoney"
              :remindPaymentId="noPaymentList.applyID"
              @changeBtnText="changeBtnTextFun($event)"
              @isSurePayBtn="isSurePayBtnFun($event)"
              @changeDialogShow="changeDialogShowFun($event)"
              @tabSelected="tabSelectedFun($event)"
              @isUnionPayError="isUnionPayErrorFun($event)"
            ></payment-dialog>
          </div>
        </div>
        <tip v-else>
          <span>暂无待缴费账单</span>
        </tip>
      </mt-tab-container-item>
      <mt-tab-container-item id="2">
        <tip v-if="!alearyPaymentList.length">
          <span>暂无已缴费账单</span>
        </tip>
        <div class="payment-list">
          <div
            id="stu-main-content"
            class="main-content"
            :style="{'-webkit-overflow-scrolling': scrollMode}"
          >
            <mt-loadmore
              v-if="alearyPaymentList.length"
              class="loadMore"
              :bottom-all-loaded="allLoaded"
              :auto-fill="false"
              :bottom-method="loadBottom"
              :bottom-distance="-70"
              ref="loadmore"
            >
              <div class="list-con" v-for="(item,index) in alearyPaymentList" :key="index">
                <h5>
                  缴费凭证 :
                  <span>{{item.merOrderID}}</span>
                </h5>
                <ul>
                  <li>
                    <span>缴费时间 :</span>
                    <span>{{item.payTime | dateFormat}}</span>
                  </li>
                  <li>
                    <span>缴费金额 :</span>
                    <span>{{item.chargeMoney.toString() | numberToMoney}}</span>
                  </li>
                  <!-- <li>
                    <span>提交岗位 :</span>
                    <span>{{item.submitterJobName}}</span>
                  </li>-->
                  <li>
                    <span>制单人 :</span>
                    <span>{{item.submitterName}}</span>
                  </li>
                  <li>
                    <span>缴费方式 :</span>
                    <span>{{item.msgType | msgType}}</span>
                  </li>
                </ul>
              </div>
            </mt-loadmore>
          </div>
        </div>
      </mt-tab-container-item>
    </mt-tab-container>
  </div>
</template>
<script>
import Tip from "@/components/tip";
import PaymentDialog from "@/components/payment-dialog";
import { loadUserInfo } from "@/api/common/common-api";
import {
  queryChargeApplyList,
  getUnionPay,
  getUnionPayOrderMessage
} from "@/api/account/account-api";
import { ACTION_TYPES, APPPayOrderStatus } from "@/constants";
export default {
  data() {
    return {
      allLoaded: false,
      scrollMode: "auto",
      btnText: "确认付款",
      selected: "1",
      isShowPaymentDialog: false,
      noPaymentList: null,
      alearyPaymentList: [],
      isSurePayBtn: true,
      isReloadBtn: false,
      btnStatusFlag: false,
      //resumePhoneFLag: false, //避免IOS后台切换到前台事件执行两次
      params: {
        customerID: "",
        pageParams: {
          pageIndex: 1,
          pageSize: 10
        }
      }
    };
  },
  mounted() {
    this.setHeight();
  },
  async created() {
    await loadUserInfo("upd");
    if(this.$route.query.type == 2){
       this.selected = this.$route.query.type;
    }else{
      this.getNoPaymentList();
    }    
    // 订阅切换孩子事件
    xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.isPermission);
    this.bindResumeCallback();
  },
  destroyed() {
    document.removeEventListener("resume", this.resumeCallback, false);
  },
  methods: {
    isPermission() {
      this.params.pageParams.pageIndex = 1;
      if (this.$store.state.currentChild.relation !== 1) {
        this.$router.push({ name: "home" });
      } else if (this.selected == 1) {
        this.getNoPaymentList();
      } else {
        this.alearyPaymentList = [];
        this.getPaymentList();
      }
    },
    bindResumeCallback() {
      mui.plusReady(() => {
        document.addEventListener("resume", this.resumeCallback, false);
      });
    },
    resumeCallback() {
      if (window.xdapp.goOut == "remind") {
        //由于页面切回来 home走完会执行到这块 就重复执行了
        return;
      }
      this.getUnionPayOrderMessageFun();
    },
    getUnionPayOrderMessageFun() {
      this.getNoPaymentList();
      if (
        m2.cache.get("isExistPaymentObj") &&
        !window.xdapp.aliPayError 
        // &&!this.resumePhoneFLag
      ) {
        mui.showLoading("付款中...", "div");
        //this.resumePhoneFLag = true;
        //检测订单交易状态
        getUnionPayOrderMessage(m2.cache.get("isExistPaymentObj"), {
          success: () => {
            m2.cache.set("isExistPaymentObj", null);
          },
          failure: res => {
            switch (res.msgStatus) {
              case APPPayOrderStatus.Invalid:
                mui.hideLoading();
                mui.alert("订单已失效!", "提示", "", "", "div");
                this.initBtnStatus();
                break;
              case APPPayOrderStatus.WaitingForPaying:
                if (this.btnStatusFlag) {
                  mui.alert(
                    "账单未完成支付，可点击确认付款再次发起支付!",
                    "提示",
                    "",
                    "",
                    "div"
                  );
                  this.btnStatusFlag = false;
                  this.btnText = "确认付款";
                  this.isSurePayBtn = true;
                  this.isReloadBtn = false;
                  //this.resumePhoneFLag = false;
                  m2.cache.set("isExistPaymentObj", null);
                } else {
                  mui.alert(
                    "账单还在支付状态,可点击按钮刷新获取最新结果!",
                    "提示",
                    "",
                    "",
                    "div"
                  );
                  this.btnStatusFlag = true;
                  this.btnText = "刷新获取最新结果";
                  this.isSurePayBtn = false;
                  this.isReloadBtn = true;
                 // this.resumePhoneFLag = false;
                }

                break;
              case APPPayOrderStatus.Paid:
                mui.hideLoading();
                mui.alert(
                  "支付成功!\n 支付凭证请联系" +
                    this.noPaymentList.submitterName +
                    "老师",
                  "提示",
                  "",
                  "",
                  "div"
                );
                this.selected = "2";
                this.btnText = "确认付款";
                this.isSurePayBtn = true;
                //this.resumePhoneFLag = false;
                m2.cache.set("isExistPaymentObj", null);
                break;
              case APPPayOrderStatus.Closed:
                mui.hideLoading();
                mui.alert("订单关闭!", "提示", "", "", "div");
                this.initBtnStatus();
                break;
              case APPPayOrderStatus.Refunded:
                mui.hideLoading();
                mui.alert("已退款!", "提示", "", "", "div");
                this.initBtnStatus();
                break;
              default:
                mui.hideLoading();
                mui.alert("订单异常!", "提示", "", "", "div");
                this.initBtnStatus();
            }
          }
        });
      }
    },
    initBtnStatus(){
       this.btnText = "确认付款";
       this.isSurePayBtn = true;
       this.isReloadBtn = false;
    },
    goPayment() {
      if (this.isSurePayBtn && !this.isReloadBtn) {
        this.isShowPaymentDialog = true;
      } else {
        this.getUnionPayOrderMessageFun();
      }
      window.xdapp.goOut = "payment"; //点击付款的页面 进行标识
    },
    //控制“确认付款”按钮是否可以点击
    isSurePayBtnFun(msg) {
      this.isSurePayBtn = msg;
    },
    //控制付款方式弹框的显示与隐藏
    changeDialogShowFun(msg) {
      this.isShowPaymentDialog = msg;
    },
    //控制“确认付款”按钮文字提示的变化
    changeBtnTextFun(msg) {
      if (msg) {
        this.btnText = "付款中，请等待...";
      }else{
        this.btnText = "确认付款";
        this.isReloadBtn = false;
      }
    },
    //下单失败重新获取缴费单
    isUnionPayErrorFun(msg) {
      if (msg) {
        this.$nextTick(function() {
          this.getNoPaymentList();
        });
      }
    },
    getNoPaymentList() {
      this.params.customerID = m2.cache.get("rx-current-child").id;
      this.noPayParams = { ...this.params, payStatus: 0 };
      this.noPaymentList = [];
      queryChargeApplyList(this.noPayParams, res => {
        this.noPaymentList = res.queryResult.pagedData[0];
      });
    },
    getPaymentList() {
      this.params.customerID = m2.cache.get("rx-current-child").id;
      this.alearyPayParams = { ...this.params, payStatus: 1 };
      queryChargeApplyList(this.alearyPayParams, res => {
        if (
          this.params.pageParams.pageSize * this.params.pageParams.pageIndex >=
          res.queryResult.totalCount
        ) {
          this.allLoaded = true;
        } else {
          this.allLoaded = false;
        }
        this.alearyPaymentList = this.alearyPaymentList.concat(
          res.queryResult.pagedData
        );
      });
    },
    loadBottom() {
      this.params.pageParams.pageIndex++;
      this.getPaymentList();
      this.$refs.loadmore.onBottomLoaded();
    },
    setHeight() {
      let content = document.querySelector("#stu-main-content");
      if (content !== null && typeof content !== "undefined") {
        let windowHeight = window.innerHeight;
        let jHight = windowHeight - 65 - 48 - 45;
        content.style.height = "calc(" + jHight + "px - 0.4rem)";
      }
    }
  },
  watch: {
    selected(type) {
      this.params.pageParams.pageIndex = 1;
      if (type == 1) {
        this.getNoPaymentList();
      } else {
        this.alearyPaymentList = [];
        this.getPaymentList();
      }
    }
  },
  components: {
    Tip,
    PaymentDialog
  }
};
</script>
<style lang="scss" scoped>
// .listLeft {
//   height: torem(150);
//   overflow: scroll;
// }
.container {
  padding-top: torem(85) !important;
}
.main-content {
  overflow: auto;
}
.wrap {
  .mint-tab-container {
    overflow: visible;
  }
  .paymentRemind {
    border-radius: 6px 0 0 6px;
  }
  .paymentAlreay {
    border-radius: 0 6px 6px 0;
  }
  .payment-list {
    .list-con {
      border-top: 10px solid #fff;
      h5 {
        height: torem(40);
        line-height: torem(40);
        font-size: 16px;
        color: #333;
        border-bottom: 1px solid #ddd;
        padding-left: torem(34);
        font-weight: bold;
      }
      ul {
        display: flex;
        flex-wrap: wrap;
        li {
          width: 50%;
          height: torem(45);
          padding-left: torem(34);
          line-height: torem(45);
          font-size: torem(16);
          span:nth-child(2) {
            font-size: torem(13);
          }
        }
      }
      .paymentBtn {
        text-align: center;
        margin-top: torem(15);
        button {
          border: none;
          width: torem(200);
          height: torem(30);
          background-color: skyblue;
          color: #fff;
          border-radius: 8px;
        }
      }
    }
    .list-con:nth-child(1) {
      border-top: 0 solid #fff;
    }
  }
}
</style>
