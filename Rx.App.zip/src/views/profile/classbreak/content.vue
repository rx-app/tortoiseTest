<template>
  <div class="mui-content rx-big-font" id="home">
      <div class="rx-break-content">
        <div class="time">{{con.createTime | dateFormat}}</div>
        <div class="text">{{con.content}}</div>
      </div>
  </div>
</template>
<script>
  import ListItems from '@/components/list-items/'
  import {loadByID} from '@/api/relax/relax-api';


  export default{
    data () {
      return {
        con:null,
      }
    },
    created(){

      this.load()
    },
    computed: {
      
    },
    methods:{
      load(){
        loadByID({id:this.$route.query.id},r=>{
          console.log(r)
          this.con=r;
        })
      }
    },
  }
</script>
<style lang="scss" scoped>
.rx-break-content{
    padding: 20px ;
    .text{color:#888}
}
</style>