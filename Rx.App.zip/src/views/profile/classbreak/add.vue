<template>
  <div class="xdapp-feedback-container">
    <scroll
      @tap.native="fnTap"
      :data="[]"
      :listen-scroll="true"
      :probe-type="3"
      :pulldown="true"
      class="scroll-container"
      ref="listview"
    >
      <div class="rx-share-add rx-big-font">
        <div class="top">生活很平凡，但我们不平凡。把激励你的话分享给大家吧!</div>
        <div class="suggest">
          <textarea
            name
            @input="setNum"
            @focus="fnFocus"
            @blur="fnBlur"
            class="txt"
            placeholder="请输入不少于10个字的分享"
            id
            cols="30"
            rows="10"
          ></textarea>
          <span class="count">
            <span class="num">{{num}}</span>/200
          </span>
          <!-- <textarea name="suggestion" v-model="criteria.content"
          placeholder=""></textarea>-->
        </div>
        <!-- <textarea name="" class="con" v-model="con" placeholder="请输入不少于10个字"></textarea> -->
        <div class="bottom">您的分享被录用后，会在掌上学大首页显示，请注意文明发言。分享不限风格，转载自创均可，最好能引发共鸣，激人上进。我们的孩子也能看到哦！</div>
      </div>
    </scroll>
  </div>
</template>
<script>
import { send } from "@/api/relax/relax-api";
import Scroll from "@/components/scroll/index";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({
      bottom: "-1px"
    });
  }
}
function resize2() {
  //*12*点击输入框时，小键盘挡住了输入框
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
export default {
  data() {
    return {
      con: "",
      num: 0
    };
  },
  methods: {
    fnTap(e) {
      if (!mui.os.ios) {
        if (e.target.tagName == "TEXTAREA" || e.target.tagName == "INPUT") {
          return;
        }
        if (
          document.activeElement.tagName == "TEXTAREA" ||
          document.activeElement.tagName == "INPUT"
        ) {
          document.activeElement.blur();
        }
      }
    },
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    },
    setNum(e) {
      this.num = this.calcLength(e.target.value);
      if (this.num > 200) {
        e.target.value = this.con;
        this.num = 200;
      } else {
        this.con = e.target.value;
      }
    },
    calcLength(str) {
      return str.length;
      //-Math.floor(str.length/2);
    },
    send() {
      send({ content: this.con }, r => {
        this.con = "";
        mui.toast("提交成功");
        this.$router.go(-1);
      });
    }
  },
  created() {
    this.con = "";
    this.num = 0;
    xdapp.util.vue.on("sendShare", this.send);
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
    document.querySelector(".xd-header").style.position = "fixed";
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
  },
  mounted() {
    this.con = "";
    this.num = 0;
  },
  activated() {
    this.con = "";
    this.num = 0;
  },
  components: {
    Scroll
  },
  watch: {
    con: {
      handler: function(val) {
        xdapp.util.vue.commitActionStatus(val.length >= 10);
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.xd-header {
  position: fixed;
  top: 0;
  left: 0;
}
.xdapp-feedback-container {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: hidden;
 
  }
}
.con {
  height: 120px;
}
.top {
  padding: 10px 18px;
}
.bottom {
  padding: 0 18px;
}
.suggest {
  margin: 10px 18px;
  display: block;
  text-align: right;
  box-sizing: border-box;
  background: #fff;
  border-radius: 5px;
  textarea {
    margin: 0;
    border: 0px;
    height: 100px;
    // font-size: 14px;
    border: none;
    border-radius: 5px;
    font-size: torem(14);
  }
  > span {
    display: block;
    padding: 0 15px 5px;
  }
}
</style>

