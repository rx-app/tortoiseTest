<template>
  <div class="mui-content rx-big-font" id="home">
    <div class="bar-top"></div>
    <div class="share">
      <router-link class="btn" tag="div" :to="{name:'break-add'}">我要分享</router-link>
    </div>
    <div class="share-list">
      <div class="tit">
        我的分享：
      </div>
    </div>
    <scroll :data="shareList" :listen-scroll="listenScroll" :probe-type="probeType" :pulldown="pulldown" @scroll="scroll" @scrollToStart1="refreshMore" @scrollToEnd="refreshMore" class="scroll-container" ref="listview">
      <!-- <ul class="mui-table-view rx-list-items">
        <router-link v-for="(item, index) in shareList" :to="{name:'break-content',query:{id:item.id}}" :key="index" tag="li" class="item link-item">

          <div class="name">
            <div class="break-time">{{item.createTime | dateFormat}}</div>
            <div class="break-content ell">{{item.content}}</div>
          </div>
          <span class="value"></span>

        </router-link>
        <tip v-if="!shareList.length">
          <span>您还没有分享，点击我要分享快去分享吧</span>
        </tip>
      </ul> -->
      <!-- {{shareList}} -->
      <div class="students-list xd-mail-list">
            <tip v-if="!shareList.length">
              <span>暂无家长分享</span>
            </tip>
            <ul class='list'>
              <li v-for='(item,index) in shareList' :class="[{activeLi:item.show}]" @click="changeLi(index,item)">
									<h6>{{item.createTime | dateFormat({locale: 'zh-CN'})}}</h6>
									<p class="perContent">{{item.content}}</p>
								</li>
            </ul>
          </div>
    </scroll>

  </div>
  
</template>
<script>
import ListItems from "@/components/list-items/";
import { load } from "@/api/relax/relax-api";
import Tip from "@/components/tip";
import Scroll from "@/components/scroll/index";
import Loading from "@/components/loading/index";

import { courseDetail } from "@/api/course/course-api";
import { loadUserInfo, getCurrentChild } from "@/api/common/common-api";
import white from "@/public/lib/white";

export default {
  mixins: [white],
  data() {
    return {
      shareList: [],
      count: 10, //一次读取的数量
      timePoint: null,
      hasData: true,
      hasMore: false,
      probeType: 3,
      listenScroll: true,
      pulldown: true,
      selected: null,
      myList: []
    };
  },
  async created() {
    await loadUserInfo();
    this.timePoint = m2.date.addDays(m2.date.now() ,1);
    this.loadList();
    this.probeType = 3;
    this.listenScroll = true;
    this.pulldown = true;
  },
  computed: {},
  methods: {
    changeLi(index, item) {
        this.shareList[index].show = !this.shareList[index].show
        this.$set(this.shareList, index, item)
			},
    loadList() {
      load({ createTime: this.timePoint, count: this.count, sort: 1 }, res => {
        this.shareList = [...this.shareList, ...res];
        this.shareList.map(one => {
          one.show = false
        })
        console.log(res);
        if (!res || !res.length) {
          this.hasMore = false;
        } else {
          this.hasMore = true;
          this.timePoint = res[0].createTime;
        }
        if (!this.shareList || !this.shareList.length) {
          this.hasData = false;
        }
      });
    },
    refreshMore() {
      if (!this.hasMore) return;
      this.loadList();
    },
    scroll(pos) {
      this.scrollY = pos.y;
    }
  },
  components: {
    ListItems,
    Scroll,
    Loading,
    Tip
  }
};
</script>
<style lang="scss" scoped>
.scroll-container {
  overflow: hidden;
  height: calc(100vh - 190px);
}
.ell {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
}
.break-time {
  color: #666;
}
.share-list {
  .tit {
    height: 40px;
    line-height: 40px;
    background: #eee;
    padding-left: 10px;
  }
}
.share {
  height: 60px;
  padding: 10px;
  background: #fff;
  text-align: center;

  .btn {
    height: 36px;
    line-height: 36px;
    font-size: 16px;
    background: #ffa713;
    display: inline-block;
    width: 140px;
    border-radius: 5px;
  }
}
.bar-top {
  height: 20px;
  background: #eee;
}
.rx-list-items {
  .item {
    display: flex !important;
    justify-content: center;
    align-items: center;
    padding: torem(10);
    border-bottom: 1px solid #eee;
    margin: 0 torem(5);
  }
  .link-item:after {
    content: "\E583";
    font-family: Muiicons;
    color: #bbb;
    -webkit-font-smoothing: antialiased;
    margin-left: 5px;
  }
  .name {
    color: #777;
    max-width: 90%;
  }
  .value {
    display: block;
    text-align: right;
    flex: 1;
    color: #aaa;

    .img-header {
      width: 1.70667rem;
      height: 1.70667rem;
    }
  }
  .no-arrow {
    margin-right: 17px;
  }
}
</style>
<style lang='scss' scoped>
	.main-content {
		overflow: auto;
	}
	
	.xd-mail-list {
		h5 {
			height: torem(40);
			line-height: torem(40);
			float: right;
			margin-right: torem(15);
			i {
				color: #ddd;
			}
		}
		.list {
			.activeLi {
				height: auto;
				.perContent {
					overflow: auto;
					white-space: normal;
				}
			}
			li {
				border-bottom: 1px solid #eee;
				padding: torem(10) torem(20);
				position: relative;
				.perContent {
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
					margin-bottom: 0;
					margin-right: torem(16);
					width: 100%;
          word-wrap: break-word;
				}
				b {
					margin-left: torem(15);
					font-size: torem(14);
					font-weight: bold;
				}
			}
		}
	}
	
	.btn-box {
		background: #ff9966;
		color: #fff;
		border: none;
		width: 90%;
		height: torem(35);
		line-height: torem(35);
		text-align: center;
		margin: 10px auto;
		border-radius: 10px;
	}
	
	.list {
		padding-left: torem(10);
		padding-right: torem(10);
	}
</style>
