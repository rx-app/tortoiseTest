﻿<template>
	<div class="mui-content rx-cname-name">
		<list-items :items="items" :userID="childId" :type="2"></list-items>
	</div>
</template>

<script>
	import { mapState, mapGetters } from 'vuex';
	import ListItems from '@/components/list-item/';
	import { loadUserInfo } from '@/api/common/common-api';
	import { getConfirmPassword } from '@/api/customer/customer-api';
	import { getHead } from "@/api/user/user-api";

	export default {
		data() {
			return {
				conPwd: '',
			}
		},
		created() {
			loadUserInfo();
			getConfirmPassword({
				customerID: this.childId
			}, res => {
				this.conPwd = res.password;
			})
		},
		methods: {
			getAvatar() {
				if(this.childInfo.iconID !== null) {
					getHead({
							iconID: this.childInfo.iconID
						},
						(res => {
							return res;
						})
					);
				} else {
					return this.childInfo.gender == 1 ? require('@/public/asset/img/user/boy.png') : require('@/public/asset/img/user/girl.png')
				}
			}
		},
		computed: {
			childId() {
				return this.$route.params.id;
			},
			childInfo() {
				return this.$store.getters.getChild(this.childId) || {
					name: ''
				};
			},
			items() {
				if(this.childInfo.relation != 1) {
					return [{
							title: '头像',
							/* pathname: { name: 'childAvatar',query: {
							   iconId: this.childInfo.iconID !== null ? this.childInfo.iconID : 0,
							   gender:this.childInfo.gender
							   }},*/
							img: true,
						},
						{
							title: '姓名',
							value: this.childInfo.name
						},
						{
							title: '签约学员编号',
							value: this.childInfo.code
						},
						{
							title: '家长联系方式',
							value: this.childInfo.parentPhone
						},
						{
							title: '课时确认密码<span style="color:red">(请勿泄露给他人)<span>',
							value: this.conPwd
						},
						// {title: '签到密码', pathname: 'profile-children-sign-password'},
						{
							title: '更多',
							routerLink: true,
							pathname: {
								name: 'profile-children-more',
								query: {
									id: this.$route.params.id
								}
							}
						}
					]
				}
				return [{
						title: '头像',
						/* pathname: { name: 'childAvatar',query: {
						   iconId: this.childInfo.iconID !== null ? this.childInfo.iconID : 0,
						   gender:this.childInfo.gender
						   }},*/
						img: true,
						routerLink: true
					},
					{
						title: '姓名',
						routerLink: true,
						pathname: {
							name: 'profile-children-edit-name',
							params: {
								id: this.childId,
								childName: this.childInfo.name
							}
						},
						value: this.childInfo.name
					},
					{
						title: '签约学员编号',
						value: this.childInfo.code
					},
					{
						title: '家长联系方式',
						routerLink: true,
						pathname: {
							name: 'profile-children-parent-phone',
							params: {
								id: this.childId,
								childName: this.childInfo.name
							}
						},
						value: this.childInfo.parentPhone
					},
					{
						title: '课时确认密码<span style="color:red">(请勿泄露给他人)<span>',
						routerLink: true,
						pathname: {
							name: 'editConPwd',
							query: {
								cid: this.childId,
								childName: this.childInfo.name
							}
						},
						value: this.conPwd
					},
					// {title: '签到密码', pathname: 'profile-children-sign-password'},
					{
						title: '更多',
						routerLink: true,
						pathname: {
							name: 'profile-children-more',
							query: {
								id: this.$route.params.id
							}
						}
					}
				];
			}
		},
		components: {
			ListItems
		}
	}
</script>
<style>
	.rx-cname-name .name {
		font-size: 16px;
	}
</style>