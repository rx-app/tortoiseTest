<template>
  <div class="mui-content rx-big-font" id="home">
    <list-items :items="list"></list-items>
  </div>
</template>

<script>
  import {mapState, mapGetters} from 'vuex';
  import ListItems from '@/components/list-items/';
  import {loadUserInfo} from '@/api/common/common-api';
  import {getCustomer} from '@/api/customer/customer-api';

  export default{
    created(){
      //loadUserInfo();
      this.getCustomerInfo();
    },
    data () {
      return {
        list:[]
      }
    },
    computed: {
      items(){
        return [
          {title: '性别', value: '男'},
          {title: '关系', value: '母子'},
          {title: '校区', value: '北京·三元桥'},
          {title: '当前', value: '高中一年级'},
          {title: '入学大年级', value: '高中一年级'}];
      }
    },
    methods: {
      getCustomerInfo(){
        getCustomer({customerID:this.$route.query.id},(res)=>{
          let a= res.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE.filter((item)=>{
            return item.key=='6'
          })
          // console.log(res.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE)
          // console.log(a)
          this.list=[
            {title: '性别', value: res.dictionaries.C_CODE_ABBR_GENDER[ res.customer.gender -1].value},
            {title: '关系',  value:this.getRelation(res.customer.userCustomerRelation, res.customer.customerRoleName)},
            {title: '校区',  value:res.customer.campusName },
            {title: '当前',  value: res.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE.filter((item)=>{
              return item.key==res.customer.grade
            })[0].value},
            {title: '入学大年级',  value: res.dictionaries.C_CODE_ABBR_CUSTOMER_GRADE.filter((item)=>{
              return item.key==res.customer.entranceGrade
            })[0].value},
          ]
          console.log(res)
        })
      },
      getRelation(type,name){
        if(type==1){
          return (name=='儿子'||name=='女儿')?'亲子':'亲属'
        }else{
          return type==2?'自己':'亲属'
        }
      }
    },
    components: {
      ListItems
    }
  }
</script>

<style scoped>

</style>
