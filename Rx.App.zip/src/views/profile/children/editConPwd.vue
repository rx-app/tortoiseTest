<template>
 <scroll :data="messages" :listen-scroll="true" :probe-type="3" :pulldown="true"  class="scroll-container" ref="listview">
	<div class="user-edit-conpwd">
		<div class="user-edit-box xd-login user-edit-conpwd" style="margin-top:12px">
			<!-- <div class="form-input">
				<input :type="inpTypeAgin" v-model="con.pwd" class="mui-input-clear" placeholder="输入新的6位数字课时确认密码" data-input-clear="5"><span class="mui-icon mui-icon-clear " @click="con.pwd=''" :style="con.pwd.length ? '' : 'display:none'"></span>
				<i class="iconfont eye" :class="iconStatusAgin" @click="toggleInpTypeAgin()"></i>
				<input :type="inpTypeReset" v-model="con.pwd2" class="mui-input-clear" placeholder="再次输入新的课时确认密码" data-input-clear="5"><span class="mui-icon mui-icon-clear " @click="con.pwd2=''" :style="con.pwd2.length ? '' : 'display:none'"></span>
				<i class="iconfont eyes" :class="iconStatusReset" @click="toggleInpTypeReset()"></i>
			</div> -->

			<p class="xd-regist-inp">
					<img
					:src="con.pwd?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
					alt="" class="xd-regist-icon"/>
					<input :type="inpType" placeholder="输入新的6位数字课时确认密码" v-model="con.pwd" />
					<i class="iconfont eye" :class="iconStatus" @click="toggleInpType()"></i>
					<!-- <i class="line" :class="crPsd?'inp-lineOn':'inp-lineOff'"></i> -->
					<i class="iconfont icon-error" v-show="con.pwd" @click="con.pwd=''"></i>
				</p>
				<p class="xd-regist-inp">
					<img
					:src="con.pwd2?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
					alt="" class="xd-regist-icon"/>
					<input :type="inpType2" placeholder="再次输入新的课时确认密码" v-model="con.pwd2" />
					<i class="iconfont eye" :class="iconStatus2" @click="toggleInpType2()"></i>
					<!-- <i class="line" :class="crPsd?'inp-lineOn':'inp-lineOff'"></i> -->
					<i class="iconfont icon-error" v-show="con.pwd2" @click="con.pwd2=''"></i>
				</p>

		</div>
	</div>
 </scroll>
</template>
<script>
	import { mapState } from 'vuex';
	import { loadUserInfo } from '@/api/common/common-api';
	import { modifyConfirmPassword } from '@/api/customer/customer-api';
	import { ACTION_TYPES, ASSIGN_STATUS as assignStatus, COURSE_EVALUATE_SCORE_CONFIG as scoreConfig } from '@/constants';
	import Scroll from '@/components/scroll/index';
	function resize() {
			if(mui.os.ios){
				plus.webview.currentWebview().setStyle({
					'bottom': '-1px'
				})
			}
	}

	export default {
		data() {
			return {
				count: 60,
				inpType:'password',
				inpType2:'password',
				iconStatus:'icon-close-eyes',
				iconStatus2:'icon-close-eyes',
				dis: false,
				btnCon: "获取验证码",
				crUser: false, /*普通登录 手机号输入框触发*/
				crPsd: false, /*普通登录 密码输入框触发*/
				vrUser: false, /*验证码登录 手机号输入框触发*/
				vrPsd: false, /*验证码登录 验证码输入框触发*/
				phoneReg: /^1[34578]\d{9}$/,
				criteria: {
					username: undefined,
					password: undefined
				},
				vercriteria: {
					username: undefined,
					signInType: 1,
					password: undefined
				},
				con: {
					pwd: '',
					pwd2: ''
				},
				inpTypeReset: 'password',
				iconStatusReset: 'icon-close-eyes',
				inpTypeAgin: 'password',
				iconStatusAgin: 'icon-close-eyes',
			}
		},
		computed: {
			...mapState({
				userInfo: state => state
			})
		},
		watch: {
			con: {
				handler: function(val) {
					xdapp.util.vue.commitActionStatus(!!val.pwd && !!val.pwd2);
				},
				deep: true
			},
		},
		created() {
			xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
		},
		methods: {
			toggleInpType() {
				if(this.inpType == 'input') {
					this.inpType = 'password';
					this.iconStatus = 'icon-close-eyes'
				} else {
					this.inpType = 'input';
					this.iconStatus = 'icon-eyes'
				}
			},
			toggleInpType2() {
				if(this.inpType2 == 'input') {
					this.inpType2 = 'password';
					this.iconStatus2 = 'icon-close-eyes'
				} else {
					this.inpType2 = 'input';
					this.iconStatus2 = 'icon-eyes'
				}
			},
			submit() {
				if(!/^\d{6}$/.test(this.con.pwd) || !/^\d{6}$/.test(this.con.pwd2)) {
					mui.alert('密码输入有误，密码必须是6位数字')
					this.con.pwd = '';
					this.con.pwd2 = '';
					return false;
				}
				if(this.con.pwd != this.con.pwd2) {
					mui.alert('两次输入的密码不一样，请重新输入')
					return
				}
				modifyConfirmPassword({
					customerID: $vue.$route.query.cid,
					newPassword: this.con.pwd
				}, res => {
					mui.alert('密码修改成功')
					setTimeout(() => {
						$vue.$router.go(-1);
					}, 1000)
				})
			},
			toggleInpTypeAgin() {
				if(this.inpTypeAgin == 'text') {
					this.inpTypeAgin = 'password';
					this.iconStatusAgin = 'icon-close-eyes'
				} else {
					this.inpTypeAgin = 'text';
					this.iconStatusAgin = 'icon-eyes'

				}

			},
			toggleInpTypeReset() {
				if(this.inpTypeReset == 'text') {
					this.inpTypeReset = 'password';
					this.iconStatusReset = 'icon-close-eyes'
				} else {
					this.inpTypeReset = 'text';
					this.iconStatusReset = 'icon-eyes'

				}

			},
		},
		components: {
			Scroll,
		},
	}
</script>
<style>
html,body{
  height: 100%;
  overflow: hidden;
}
</style>

<style scoped lang='scss'>
	.scroll-container {
		height: 100%;
		overflow: hidden;
		position:absolute;
		background: rgba(239,239,244,1);
		width: 100%;
		z-index: 19;
		// padding: 0 10px;
	}
	input{line-height:21px;width:100%;height:40px;margin-bottom:15px;padding:10px 15px;-webkit-user-select:text;border:1px solid rgba(0,0,0,.2);border-radius:3px;outline:0;background-color:#fff;-webkit-appearance:none}

	.sex {
		padding: 5px 10px;
		background: #fff;
		margin: 5px;
		color: #888;
	}
	.icon-error{
		right: torem(15)!important;
	}
	
	.sex.on {
		color: rgb(216, 203, 21)
	}
	
	.sex.on::after {
		content: '√';
		position: absolute;
		right: 10px;
		transform: scaleX(1.6);
		color: rgb(56, 199, 127)
	}
	
	.eye {
		color: #ccc;
		font-size: torem(24);
		position: absolute!important;
		right: torem(45)!important;
		top: torem(10)!important;
	}
	
	.eyes {
		color: #ccc;
		font-size: torem(24);
		position: absolute!important;
		right: torem(60)!important;
		top: torem(69)!important;
	}
</style>
<style>
	.user-edit-box .mui-icon {
		position: absolute;
		/* right: 2%;
		top: 10%;
		transform: translateY(10%); */
	}
	
	.user-edit-box .form-input {
		position: relative;
	}
	html,body{
		height: 100%;
  		overflow: hidden;
	}
	.user-edit-conpwd{
		position: absolute;
		width: 100%;
		z-index: 19;
		/* background: #fff; */
		height: 100%;
		overflow: hidden;
		/* padding-bottom: 1000px; */
	}
</style>