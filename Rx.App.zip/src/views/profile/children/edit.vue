<template>
    <scroll @tap.native='fnTap' :data="messages" :listen-scroll="true" :probe-type="3" :pulldown="true"  class="scroll-container" ref="listview">
      <div  class="child-edit-box">
        <p v-html="txt01"></p>
        <div>
          <textarea  name="" @input="setNum" class="txt" @focus="fnFocus" @blur="fnBlur"  :placeholder="placeholder" id="" cols="30" rows="10"></textarea>
          <span class="count"><span class="num">{{num}}</span>/200</span>
        </div>
        <p v-html="txt02"></p>
      </div>
    </scroll>
</template>
<script>
  import {loadUserInfo} from '@/api/common/common-api';
  import {changeNameApply, changeParentPhoneApply} from '@/api/user/user-api';
  import {ACTION_TYPES, ASSIGN_STATUS as assignStatus, COURSE_EVALUATE_SCORE_CONFIG as scoreConfig} from '@/constants';
  import Scroll from '@/components/scroll/index';
  function resize() {
		if(mui.os.ios){
			plus.webview.currentWebview().setStyle({
				'bottom': '-1px'
			})
		}
  }
  
	export default{
		data(){
			return{
        txt01: '',
        txt02: '',
        msg: '',
        num: 0,
        placeholder: '',
        onSubmit: false
			}
    },
    watch: {
      'msg': {
        handler: function (val) {
          xdapp.util.vue.commitActionStatus(val.length >= 10);
        },
        deep: true
      }
    },
    created () {
      this.init()
      if(window.innerHeight<500){
				this.iosType='4s'
      }
      window.addEventListener('resize',resize)
    },
    destroyed(){
			window.removeEventListener('resize',resize)
		},
    methods:{
      fnTap(e){
        if(!mui.os.ios){
          if( e.target.tagName=='TEXTAREA' ||  e.target.tagName=='INPUT' ){
            return
          }
          if( document.activeElement.tagName=='TEXTAREA' ||  document.activeElement.tagName=='INPUT' ){
            document.activeElement.blur();
          }
        }
      },
      fnFocus(){
        var ua = navigator.userAgent.toLowerCase();
        if(/iphone|ipad|ipod/.test(ua)) {
          var wv=plus.webview.currentWebview();
          let bottom=this.iosType=='4s'?'315px':'655px'
          
          wv.setStyle({'top':'0px'});
          wv.setStyle({bottom});
          plus.webview.currentWebview().setStyle({'background':'#fff'});
        }
      },
      fnBlur(){
        var ua = navigator.userAgent.toLowerCase();
        if(/iphone|ipad|ipod/.test(ua)) {
          // mui.toast(window.innerHeight)

          var wv=plus.webview.currentWebview();
          wv.setStyle({'top':'0px'});
          wv.setStyle({'bottom':'0px'});
        }
      },
      init () {
        if (this.$route.name === 'profile-children-edit-name') {
          this.txt01 = '如果孩子姓名不正确，可以留言给学管师:'
          this.txt02 = '姓名非常重要，若学管师回复不及时，请直接电话联系。'
          this.placeholder = '请输入不少于10个字的描述，例如，老师您好，孩子的姓名已经变更为某某某,请帮忙更新，谢谢！'
        } else {
          this.txt01 = '如果家长联系方式不正确，可以留言给学管师:'
          this.txt02 = '联系方式非常重要，若学管师回复不及时，请直接电话联系。'
          this.placeholder = '请输入不少于10个字的描述，例如，老师您好，我是韩程璐的家长，我的手机号已变更为18812344321,请帮忙更新，谢谢！'
        }
        xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
      },
      setNum(e){
          this.num=this.calcLength(e.target.value);
          if(this.num > 200) {
              e.target.value = this.msg;
              this.num = 200;
          } else {
            this.msg = e.target.value; 
          }
      },
      calcLength(str){
        return str.length;
      },
      submit () {
        xdapp.util.vue.commitActionStatus(false);
        let sendData = {
          msg: this.msg,
          sid: this.$route.params.id,
          customerName: this.$route.params.childName
        }
        // 姓名变更申请
        if (this.$route.name === 'profile-children-edit-name') {
          changeNameApply(sendData, () => {
            mui.toast("申请成功");
            setTimeout(() => {
              this.$router.push({
                name: 'profile-children-child-info', 
                params: { id: this.$route.params.id }
              });
            }, 3000)
          });
        } else {
          // 家长联系方式变更申请
          changeParentPhoneApply(sendData, () => {
            mui.toast("申请成功");
            setTimeout(() => {
              this.$router.push({
                name: 'profile-children-child-info', 
                params: { id: this.$route.params.id }
              });
             }, 3000)
          });
        }
      },
      clear(){ 
        this.msg =''
      },
    },
    components: {
			Scroll,
		},
	}
</script>
<style>
html,body{
  height: 100%;
  overflow: hidden;
}
.child-edit-box p{
  margin-top: 10px;
}
.child-edit-box > div {
  position: relative;
  border: 1px solid rgba(0,0,0,.2);
  background: #fff;
  border-radius: 3px;
}
.child-edit-box > div .count{
  display: block;
  text-align: right;
  box-sizing: border-box;
  padding: 0 15px 5px;
}
.child-edit-box textarea {
  border: none;
  border-radius: none;
}
</style>
<style lang="scss" scoped>
.scroll-container {
			height: 100%;
			overflow: hidden;
			position:absolute;
      background: #fff;
      width: 100%;
      z-index: 9;
      padding: 0 10px;
		}
.container{
  // padding-top: 0px!important;
  // margin-top:65px;
}
</style>
