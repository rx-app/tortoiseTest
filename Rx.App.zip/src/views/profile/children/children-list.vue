<template>
  <div style="overflow:scroll;height:100vh;">
    <div v-if="children.length" class="mui-content rx-cname-name" id="home">
      <list-items :items="children"></list-items>
    </div>
    <div v-if="!children.length" class="limit">
      <div class="box">
        <img  :src="require(`@/public/asset/img/tip.png`)" alt="">
        <p>您名下暂无在学大上课的孩子</p>
        <p>无法获取相关信息</p>
      </div>
    </div>
  </div>
</template>
<script>
  import ListItems from '@/components/list-items/'

  import {courseDetail} from '@/api/course/course-api';
  import {loadUserInfo, getCurrentChild} from '@/api/common/common-api';

  export default{
    created(){
      loadUserInfo();
    },
    computed: {
      children() {
        let items = [];
        // console.log(this.$store.state)
        this.$store.state.children.forEach(item =>
          items.push({title: `${item.name}(${item.code.substr(-4)})`, pathname: {name: 'profile-children-child-info', params: {id: item.id}}})
        );
        return items;
      }
    },
    components: {
      ListItems
    }
  }
</script>
<style>
.rx-cname-name .name{
  font-size: 16px;
}
</style>

<style lang="scss" scoped>
  .limit{
    .box{
      background: #fff;
      padding: 40px;
      text-align: center;
      p{
        font-size: 14px;
      }
    }
  }
</style>
