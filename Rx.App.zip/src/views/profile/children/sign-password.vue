<template>
	<div class="wrap">
		<div class="after_psd">
			<p class="inp">
				<span class="mui-icon iconfont icon-home"></span>
				<input type="text" placeholder="输入原签到密码" />
			</p>
			<p class="inp">
				<span class="mui-icon iconfont icon-home"></span>
				<input type="text" placeholder="设置新签到密码（6位数字）" />
			</p>
			<p class="inp phone_id">
				<span class="mui-icon iconfont icon-home"></span>
				<input type="text" placeholder="输入手机验证码" /><button id="btn">获取手机验证码</button>
			</p>
		</div>
	</div>

</template>

<script>
</script>

<style scoped>
	.after_psd{
		margin-top: 20px;
		
	}
	.inp {
		position: relative;
		width: 90%;
		margin-left: 5%;
		border-radius: 5%;
	}
	
	.inp input {
		height: 50px;
		padding-left: 40px;
	}
	
	.mui-icon {
		position: absolute;
		left: 10px;
		top: 9px;
	}
	
	.phone_id {
		display: flex;
	}
	
	#btn {
		height: 50px;
		background-color: #ccc;
	}
</style>