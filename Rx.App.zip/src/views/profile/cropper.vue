﻿<template>
	<div class="mui-content" id="home">
		<div id="cropper-example-1" class="">
			<img class="crossOrigin" id="imgIcon" alt="Picture" />
		</div>
		<div class="divbut">
			<div>
				<p id="cancle" class="iconfont icon-cancle" @click="cancle()">取消</p>
			</div>
			<div>
				<p id="sure" class="iconfont icon-sure" @click="sure()">确认</p>
			</div>
		</div>
	</div>

</template>

<script>
	import { modifyHead } from "@/api/user/user-api";
	import { modifyHeadCus } from "@/api/customer/customer-api";
	import { CACHE_KEYS } from "@/constants";
	import * as types from '@/store/mutation-types';
	import store from '@/store';

	import '@/public/asset/js/jquery/jquery-1.8.0';
	import '@/public/asset/js/cropper/cropper.min.css';
	import '@/public/asset/js/cropper/cropper.min.js';
	export default {
		data() {
			return {}
		},
		methods: {
			cancle() {
				$vue.$router.go(-1);
			},
			sure() {
				this._processPic()
			},
			upDateImg(path) {
				var _this = this;
				plus.nativeUI.showWaiting('头像上传中...');
				var stream = this._dataURLtoBlob(path);
				var data = new FormData();
				data.append("headupload", stream, Date.parse(new Date()) + ".jpg");
				if(this.$route.query.type == 2) {
					data.append("customerid", this.$route.query.userID);
				}
				var request = new XMLHttpRequest();
				if(this.$route.query.type == 1) {
					request.open("POST", modifyHead);
				} else {
					request.open("POST", modifyHeadCus);
				}
				request.setRequestHeader(
					"x-session-token",
					m2.cache.get('rx-session-token')
				);
				request.setRequestHeader(
					"CurrentChildID",
					m2.cache.get('rx-current-child').id
				);
				request.send(data);
				request.onload = function(oEvent) {
					if(request.status == 200) {
						window.xdapp[_this.$route.query.userID] = true;
						window.xdapp.childID = _this.$route.query.userID;
						plus.nativeUI.closeWaiting();
						var currentIcon = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
						currentIcon.forEach(item => {
							if(item.userID == _this.$route.query.userID) {
								item.iconID = JSON.parse(request.responseText);
							}
						})
						// 保存当前用户头像ID
						m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, currentIcon);
						var objs = currentIcon.slice();
						store.commit(types.CURRENT_MODI_HEAD, objs);

						mui.toast("头像上传成功!");
						if(_this.$route.query.type == 1) {
							_this.$router.push({
								name: 'profile-user-userInfo'
							});
						} else {
							_this.$router.go(-1)
						}

					} else {
						mui.toast("上传失败,请稍后重试!");
					}
				};
			},
			/*将裁剪完图片处理为base64*/
			_processPic() {
				var _this = this;
				var cropperImg = $('#cropper-example-1 > img').cropper('getCroppedCanvas');
				var base64Img = cropperImg.toDataURL("image/jpeg", 0.5);
				_this.upDateImg(base64Img);
			},
			/*将 base 64 转为 blob*/
			_dataURLtoBlob(dataurl) {
				var arr = dataurl.split(','),
					mime = arr[0].match(/:(.*?);/)[1],
					bstr = atob(arr[1]),
					n = bstr.length,
					u8arr = new Uint8Array(n);
				while(n--) {
					u8arr[n] = bstr.charCodeAt(n);
				}
				return new Blob([u8arr], {
					type: mime
				});
			},
			/*裁剪初始化*/
			_init() {
				$('#cropper-example-1 > img').on("load", () => {
					$('#cropper-example-1 > img').cropper({
						aspectRatio: 1 / 1,
						autoCropArea: 0.6,
						strict: false,
						viewMode: 1,
						background: false,
						guides: false,
						highlight: false,
						dragCrop: true,
						resizable: false,
					});
				});
				var wrapMove = document.getElementById('cropper-example-1');
				wrapMove.addEventListener('touchmove', function(e) {
					e.preventDefault();
				}, false);
			},
			_imgInit() {
				var _this = this;
				plus.nativeUI.showWaiting('加载中...');
				const fileReader = new plus.io.FileReader();
				fileReader.readAsDataURL(this.$route.query.urlData, 'utf-8');
				fileReader.onloadend = function(evt) {
					var imgIcon = document.getElementById("imgIcon");
					imgIcon.src = evt.target.result;
					_this._init();
					plus.nativeUI.closeWaiting();
				}
			}
		},
		mounted() {
			this._imgInit();
		},
	}
</script>

<style lang="scss" scoped>
	.mui-content {
		position: fixed;
		top: 0;
		bottom: 0;
		width: 100%;
		height: 100%;
		background-color: #000000;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	
	#cropper-example-1 {
		height: auto;
		width: auto;
		background-color: #000000;
		position: absolute;
		margin: auto 0;
		#imgIcon {
			height: 100%;
			width: 100%;
			margin: auto 0;
		}
	}
	
	#cancle,
	#sure {
		font-size: 16px;
	}
	
	.divbut {
		width: 100%;
		text-align: center;
		position: fixed;
		z-index: 2;
		top: 0;
		background-color: #000000;
		padding-top: torem(40);
		line-height: 25px;
	}
	
	.divbut>div:first-child {
		float: left;
		width: 20%;
	}
	
	.divbut>div:last-child {
		float: right;
		width: 20%;
	}
	
	@media only screen and (max-width: 320px) {
		#cropper-example-1 {
			height: torem(300);
			width: auto;
			background-color: #000000;
			position: absolute;
			margin: torem(-100) 0;
			#imgIcon {
				height: 100%;
				width: 100%;
				margin: torem(10) 0;
			}
		}
	}
</style>