﻿<template>
  <div class="mui-content rx-profile">
    <div class="mui-table-view header">
      <router-link
        :to="{name:'profile-user-userInfo'}"
        class="mui-table-view-cell mui-media header-link"
        tag="a"
      >
        <p id="head-img">
          <img v-if="avatar" :src="avatar" />
          <img v-else-if="curGender==2" src="~@/public/asset/img/user/mother.png" alt />
          <img
            v-else-if="curGender==1 || curGender==0 || curGender==null "
            src="~@/public/asset/img/user/father.png"
            alt
          />
        </p>
        <div class="mui-media-body">
          <p>
            <span class="name">{{displayName}}</span>
            <span class="mui-ellipsis">
              账号:
              <span class="account">{{logOnName}}{{relation}}</span>
            </span>
          </p>
          <a class="iconfont icon-turn-right"></a>
        </div>
      </router-link>
    </div>
    <list-items :items="items"></list-items>
    <!-- <p
      @click="startEnglishActivity('conversation')"
      style="align-items: center;padding: 0.26667rem;border-bottom: 1px solid #eee;background:#fff"
    >去小英学英语</p> -->
  </div>
</template>
<script>
import { mapState } from "vuex";
import store from "@/store";
import * as types from "@/store/mutation-types";
import ListItems from "@/components/list-items/";
import { PROFILE_INDEX, CACHE_KEYS } from "@/constants";
import { loadUserInfo } from "@/api/common/common-api";
import { getHead } from "@/api/user/user-api";
//import { microsoftEnglishGetToken } from "@/api/microsoft-english/microsoft-english-api";
import "@/public/asset/js/xiaoying/EnglishWebViewFeature.js";

export default {
  data() {
    return {
      items: PROFILE_INDEX,
      curGender: -1,
      avatar: ""
    };
  },
  async created() {
    await loadUserInfo("upd");
    this.getAvatar();
    /*    let oldId=m2.cache.get("rx-current-user").iconID; 
			      if(oldId!=m2.cache.get("rx-current-user").iconID){
			        this.getAvatar();
			      }*/
  },
  computed: {
    ...mapState({
      displayName: state => state.alias,
      logOnName: state => state.logOnName,
      relation: state => state.relation
    })
  },
  components: {
    ListItems
  },
  methods: {
    // startEnglishActivity(key) {
    //   mui.plusReady(() => {
    //     alert(plus.EnglishWebView.startEnglishWebView);
    //     var startUrl = xdapp.config.englishActivitiesConfig.activities[key];
    //     //判读机型
    //     if (mui.os.android) {
    //       startUrl = startUrl + "?origin=android-xinfangxiang";
    //     }
    //     microsoftEnglishGetToken({}, res => {
    //       var { access_token } = res;
    //       var data = {'access_token':access_token};
    //       plus.EnglishWebView.startEnglishWebView(startUrl, data);
    //     });
    //   });
    // },
    getAvatar() {
      var currentIcon = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
      var currentLogon = m2.cache.get(CACHE_KEYS.CURRENT_USER).userId;
      if (currentIcon) {
        currentIcon.forEach(item => {
          if (item.userID == currentLogon) {
            if (item.imgData) {
              this.avatar = item.imgData;
            } else if (item.iconID) {
              getHead(
                {
                  iconID: item.iconID
                },
                res => {
                  this.avatar = res;
                  item.imgData = res;
                  m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, currentIcon);
                }
              );
            } else {
              this.curGender = item.gender;
            }
          }
        });
      }
    }
  }
};
</script>
<style>
.rx-profile .link-item .name {
  font-size: 16px;
}
</style>

<style lang="scss" scoped>
a,
a:hover,
a:active,
a:visited,
a:link,
a:focus {
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  -webkit-tap-highlight-color: transparent;
  outline: none;
  background: none;
  text-decoration: none;
}

.rx-profile {
  padding-top: 0 !important;
  background: transparent !important;
  > .rx-list-items {
    margin-top: 15px;
  }
  .header {
    display: flex;
    align-items: center;
    margin-top: 0;
    height: 149px;
    color: #fff;
    background: url(~@/public/asset/img/bg/home-bg.png) repeat-x;
    background-size: 100% 260px;
    .header-link {
      width: 100%;
      #head-img {
        width: torem(64);
        height: torem(64);
        img {
          width: 100%;
          height: 100%;
          border-radius: 100%;
        }
      }
      .mui-media-body {
        display: flex;
        flex: 1;
        align-items: center;
        justify-content: space-between;
        color: #fff;
        margin-left: 15px;
        .icon-turn-right {
          font-size: torem(18);
        }
        p {
          display: flex;
          flex-direction: column;
          span {
            color: #fff;
          }
          .name {
            font-size: torem(17);
          }
          .mui-ellipsis {
            font-size: torem(14);
          }
        }
      }
    }
    .mui-media {
      display: flex;
    }
  }
}
</style>