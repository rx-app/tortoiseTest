<template>
  <div class="xdapp-msg-wrapper">
    <router-link :to="{name:'feedbackEdit',query:{feedid:$route.query.feedid}}" class="send-btn" >留言</router-link>
    <div class="wrapper" ref="wrapper">
      <div>
        <!--<div class="top-tip">-->
          <!--<span class="refresh-hook">下拉刷新</span>-->
        <!--</div>-->
        <mt-loadmore :top-method="loadTop"  ref="loadmore">


        <ul class="msg-content">
          <li v-for="(item,index) in messages" class="msg-list-hook">
            <span class="msg-time mui-badge">{{item.createTime | normalize }}</span>
            <div :class="{'msg-item':item.poster==1,'msg-item-right':item.poster==2 }">
              <div v-if="item.poster==1">
                <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/home/head.png">
              </div>
              <dd class="reply" v-html="item.replyContent"></dd>
              <div v-if="item.poster==2">
                <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/04@3x.png">
              </div>
            </div>
          </li>
        </ul>
        </mt-loadmore>
      </div>
    </div>
    
  </div>
</template>

<script>
  import BScroll from 'better-scroll';
  import Tip from '@/components/tip';
  import {ReplyType, PreOrLast, Poster} from '@/constants';
  import {defaultPageSize} from '@/public/constant';
  import {getUserFeedbackTopic} from '@/api/settings/setting-api';
  import {pager, orderBy} from '@/public/constant';
  import {loadUserInfo} from '@/api/common/common-api';

  export default {
    data() {
      return {
        messages: [],
        scrollY: 0,
        pageIndex:1,
        total:0,
        loading:false,
      }
    },
    created(){
      this.setPageTitle();
      this.getCustomerReply();
    },
    mounted () {
      this.$route.meta.title=this.getTitle( this.$route.query.type )
    },
    methods: {
      getTitle(type){
        type=parseInt(type)
        return ['功能异常','意见建议','其它问题'][type]
      },
      getCustomerReply(){
        this.getData(m2.date.now(),1);
      },
      loadTop(){
        this.getData(this.firstMessageCreateTime);
      },
      setPageTitle(){
        this.$route.meta.title = this.pageTitle;
      },
      async getData(replyTime,isFirst){
        //await loadUserInfo();

        let params = {
          feedID: this.$route.query.feedid,
          ...pager({pageSize: 20}),
          ...orderBy({dataField: 'createTime'})
        };

        getUserFeedbackTopic(params, res => {
          this.messages = [...res, ...this.messages];
          this.pageIndex++;
          this.total = res.queryResult.totalCount;
          if( this.list.length < res.queryResult.totalCount ){
              this.loading = false;
          }else{
              if(this.list.length==0){
                  Toast('当前条件下无账单信息...')
              }else{
                  Toast({message: '全部账单已加载完毕...',position:'bottom'})
              }
              
          }
          this.$refs.loadmore.onTopLoaded();
          
          this.$nextTick(() => {
            this._initScroll();
            isFirst && this._scrollToBottom();
          });
        });
      },
      _initScroll(){
        let wrapper = this.$refs.wrapper;
        wrapper.style.height = (window.screen.height - 125) + 'px';

        this.scroll = this.scroll ? this.scroll.refresh() : new BScroll(wrapper, {
          probeType: 3
        });

        this.scroll.on('scroll', (pos) => {
          this.scrollY = Math.abs(Math.round(pos.y));
        });
      },
      _scrollToBottom(){
        let msgList = this.$refs.wrapper.getElementsByClassName('msg-list-hook');
        let height = 0;
        for (let i = 0; i < msgList.length; i++) {
          height += msgList[i].clientHeight;
        }

        let el = msgList[msgList.length - 1];
        this.scroll.scrollToElement(el);
      }
    },
    computed: {
      replyType(){
        return this.$route.query.replyType;
      },
      pageTitle(){
        return this.$route.query.title;
      },
      replierID(){
        return this.$route.query.staffId;
      }
      
    }
  }
</script>

<style lang="scss" scoped>
.send-btn{
  position: fixed;
  top:27px;
  right:15px;
  color:#fff;
  font-size: 15px;
  z-index:1000;
}
  .xdapp-msg-wrapper {
    position: absolute;
    top: 0px;
    bottom: 46px;
    width: 100%;
    .wrapper {
      background: #eee;
      ul.msg-content {
        li {
          padding-bottom: 15px;
        }
        .msg-time {
          text-align: center;
          display: block;
          margin-top: 14px;
          font-size: 12px;
          margin-left: 40%;
          width: 70px;
          color: #fff;
        }
        .msg-item {
          z-index: 1;
          position: relative;
          padding: 10px 18px 0;
          display: flex;
          img {
            width: 40px;
            height: 40px;
            margin-right: 11px;
          }
          .reply {
            margin-left: 0;
            padding: 8px 15px;
            width: torem(222);
            font-size: 16px;
            color: #333;
            border: 1px solid #ccc;
            background-color: #F9F9FB;
            .tit {
              font-size: 20px;
              color: #000;
              line-height: 28px;
            }
          }
          &:after {
            content: '';
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-right: 7px solid #ccc;
            position: absolute;
            left: 56px;
            top: 27px;
            z-index: 10;
          }
          &:before {
            content: '';
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-right: 7px solid #fff;
            position: absolute;
            left: 58px;
            top: 27px;
            z-index: 20;
          }
        }
        .msg-item-right {
          z-index: 1;
          position: relative;
          padding: 14px 18px 0;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          img {
            width: 40px;
            height: 40px;
            margin-left: 11px;
          }
          .reply {
            font-size: 16px;
            color: #333;
            padding: 8px 15px;
            margin-left: torem(57);
            background: #ffe3b6;
            border-radius: 5px;
            .tit {
              font-size: 20px;
              color: #000;
              line-height: 28px;
            }
          }
          &:after {
            content: '';
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-left: 7px solid #ccc;
            position: absolute;
            right: 56px;
            top: 27px;
            z-index: 10;
          }
          &:before {
            content: '';
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-left: 7px solid #ffe3b6;
            position: absolute;
            right: 58px;
            top: 27px;
            z-index: 20;
          }
        }
      }
    }
    .msg-input {
      position: fixed;
      width: 100%;
      height: 50px;
      min-height: 50px;
      border-top: solid 1px #bbb;
      left: 0px;
      bottom: 0px;
      overflow: hidden;
      padding: 0px 90px 0px 10px;
      background-color: #fafafa;
      .msg-left {
        height: 100%;
        padding: 5px 0px;
        [class*=input] {
          width: 100%;
          height: 100%;
          border-radius: 5px;
        }
        .input-text {
          background: #fff;
          border: solid 1px #ddd;
          padding: 10px !important;
          font-size: 16px !important;
          line-height: 18px !important;
          font-family: verdana !important;
          overflow: hidden;
        }
      }
      .msg-right {
        position: absolute;
        width: 100px;
        height: 50px;
        right: 0px;
        bottom: 0px;
        text-align: center;
        vertical-align: middle;
        line-height: 100%;
        padding: 5px 0px;
        display: inline-block;
        .btn-send {
          width: 70px;
          height: 100%;
          border: none;
          text-align: center;
          line-height: torem(-0.04);
          font-size: torem(14)
        }
        .btn-on {
          background: skyblue;
          color: #fff;
        }
        .btn-off {
          background: #ccc;
        }
      }

    }
  }
</style>
