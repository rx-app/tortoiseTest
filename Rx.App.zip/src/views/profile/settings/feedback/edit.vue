<template>
  <div class="wrap feedback">
    <div class="mui-page-content">

      <div class="row mui-input-row center" >
        <textarea id="question" class="mui-input-clear question " placeholder="请输入不少于10个字的描述"
                  v-model="content"></textarea>
      </div>
      <p>请提供相关问题的截图或照片</p>
      <div v-for="(item,index) in imgList" class="image-item" :key="index">
        <img :src="item" alt="">
        <div class="image-close"  @click="delImg(index)">X</div>
      </div>
      <div v-show="max>0" class="image-item space " href="#popover" id="openPopover" @click="galleryImg">
       <!-- <img :src="require('@/public/asset/img/profile/iconfont-tianjia.png')" alt="">-->
        <div class="image-close" @click="delImg(index)">X</div>
      </div>

      <!-- <div class="image-item space "><div class="image-close">X</div><input type="file" accept="image/*" id="image-1"></div></div> -->
      <!-- 删除了<input type="file" accept="image/*" id="image-1"> -->
      <div id="popover" ref='popover' class="mui-popover popover classifies mui-active" :class="{move:on}">
        <my-text txt="拍照"></my-text>
        <my-text txt="从手机相册中选择"></my-text>
        <my-text txt="保存图片"></my-text>
        <my-text txt="取消" @click.native="on=false"></my-text>
      </div>
      <div class="mui-backdrop mui-active" style="" v-show="on"></div>
      <button id="submit" type="button" class="mui-btn mui-btn-green" @click="save">提交</button>
    </div>
  </div>
</template>

<script>
  import myText from '@/components/myText';
  import {getUserFeedback} from '@/api/common/common-api';
  import {getUserTypeFeedback,savePostFeedback} from '@/api/settings/setting-api';

  export default {
    data() {
      return {
        others: false,
        flag: true,
        on: false,
        content: "测试数据",
        feedbackTypes: [],
        feedbackRadios: 0,
        //imgs:[require('@/public/asset/img/profile/iconfont-tianjia.png'),require('@/public/asset/img/profile/avatar.png'),],
        // max:4,
      }
    },
    computed: {
      imgList(){
        return this.imgs.slice(0,5)
      },
      max(){
        return 4-this.imgs.length
      }
    },
    components: {
      myText
    },
    mounted () {
      
    },
    created() {
      this.getData();
      //this.getType();
    },
    methods: {
      delImg(i){

        this.imgs.splice(i,1);
      },
      galleryImg(){  
        alert('开始选择图片')
        // 从相册中选择图片 
        var _this= this; 
        plus.gallery.pick( function(e){  
          console.log(e.files)
          // this.imgs = e.files.map((v,i)=>{
          //   alert('v:'+v);
          //   return require(v)
          // })
          // this.imgs=e.files;
            for(var i in e.files){  
                var fileSrc = e.files[i]  
                console.log(e.files[i])
                alert(e.files[i])
                _this.imgs.push(e.files[i])
                // setHtml(fileSrc);  
            }  
        }, function ( e ) {  
            console.log( "取消选择图片" );  
        },{  
            filter: "image",  
            multiple: true,  
            maximum: _this.max,  
            system: false,  
            onmaxed: function() {  
                plus.nativeUI.alert('最多还可选择'+_this.max+'张图片');  
            }  
        });  
      },
      async save() { /*手机验证码登陆*/
        const criteria = {
          feedback: {
            content: this.content,
            feedType: this.feedbackRadios
          }

        }

        // debugger;
        savePostFeedback(criteria, (res) => {
          // debugger;
          // this.$router.push({
          //   name: "home"
          // });
        });
      },
      getData() {

        // getUserFeedback(res => {

        //   // this.feedbackTypes = res.dictionaries.App_Settings_FeedbackType;
        //   var ary_RoleType = [];
        //   var typeObj = res.dictionaries.App_Settings_FeedbackType;
        //   for (var j = 0; j < typeObj.length; j++) {
        //     this.feedbackTypes.push({
        //       'index': typeObj[j].key,
        //       'item': typeObj[j].value,
        //     });
        //   }
        // });
      }
    }
  }
</script>

<style lang="scss" scoped>
  .content{
    margin:0 0 53px 0; 
  }
  .center {
    width: 90%;
    // margin-left: 5%
  }

  .feedback body {
    background-color: #EFEFF4;
  }

  .feedback input,
  .feedback textarea {
    border: none !important;
  }

  .feedback textarea {
    height: 100px;
    margin-bottom: 0 !important;
    padding-bottom: 0 !important;
  }

  .feedback .row {
    width: 100%;
    background-color: #fff;
  }

  .feedback p {
    padding: 10px 15px 0 0;
  }

  .feedback button {
    width: 90%;
    height: 46px;
    left: 50%;
    -webkit-transform: translate(-50%);
  }

  .feedback .hidden {
    display: none;
  }

  .feedback .image-list {
    width: 100%;
    height: 85px;
    background-size: cover;
    padding: 10px 10px;
    overflow: hidden;
  }

  .feedback .image-item {
    width: 65px;
    height: 65px;
    /* background-image: url(~@/public/asset/img/profile/iconfont-tianjia.png); */
    background-size: 100% 100%;
    display: inline-block;
    position: relative;
    border-radius: 5px;
    margin-right: 10px;
    margin-bottom: 10px;
    border: solid 1px #e8e8e8;
    img{
      width:65px;
      height: 65px;
    }
  }

  .feedback .image-item input[type="file"] {
    position: absolute;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
    z-index: 0;
  }

  .feedback .image-item.space {
    border: none;
  }

  .feedback .image-item .image-close {
    position: absolute;
    display: inline-block;
    right: -6px;
    top: -6px;
    width: 20px;
    height: 20px;
    text-align: center;
    line-height: 20px;
    border-radius: 12px;
    background-color: #FF5053;
    color: #f3f3f3;
    border: solid 1px #FF5053;
    font-size: 9px;
    font-weight: 200;
    z-index: 1;
  }

  .feedback .image-item.space .image-close {
    display: none;
  }

  .feedback{
      padding: 10px;
      margin-top: 15px;
  }

  #openPopover {
    // margin-left: 5%;
  }

  .popover {
    margin-left: 6%;
    position: fixed;
    bottom: 0;
    border-radius: 0;
    transition: 0.5s;
    transform: translate3d(0, 100%, 0)
  }

  .move {
    transform: translate3d(0, 0, 0);
  }

  #submit {
    position: fixed;
    bottom: 0;
  }
</style>
