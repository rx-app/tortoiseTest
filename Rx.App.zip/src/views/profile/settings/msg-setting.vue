<template>
  <div class="wrap rx-big-font">
    <ul class="mui-table-view">
      <li v-for="(item,index) in list" :key="index" class="mui-table-view-cell">
        <span>{{item.name}}</span>
        <div class="mui-switch" @click="change(item)" :class="{'mui-active':item.isBind}" data-switch="1">
          <!-- <div class="mui-switch" @click="change(item)" data-switch="1"> -->
          <div class="mui-switch-handle"></div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { fingerPsdStatus, loadUserInfo } from "@/api/common/common-api";
import { setSendMsgSwitch, setSendGenNotifySwitch } from "@/api/user/user-api";
import { CACHE_KEYS } from "@/constants";
import { FINGERPSDSTATUS } from "@/store/mutation-types";

export default {
  data() {
    return {
      list: []
    };
  },
  async created() {
    await loadUserInfo("upd");
    let user = m2.cache.get("rx-current-user");
    this.$nextTick(()=>{
      this.list = [
        {
          name: "接收课业通知消息",
          isBind: user.sendGenNotify,
          type: 1
        },
        {
          name: "接收手机短信",
          isBind: user.sendMsg,
          type: 2
        }
      ];
    })
    
  },
  methods: {
    change(item) {
      // mui.confirm("确定关闭此功能？", "提示", ["取消", "确定"], function(e) {
      //   if (e.index != 0) {
          if (item.type == 1) {
            setSendGenNotifySwitch(!item.isBind, () => {
              item.isBind = !item.isBind;
            });
          } else {
            setSendMsgSwitch(!item.isBind, () => {            
              item.isBind = !item.isBind;
            });
          }
        // }
      // });
    }
  }
};
</script>

<style scoped>
/* * {
  touch-action: none;
} */
</style>