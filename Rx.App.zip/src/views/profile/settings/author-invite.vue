﻿<template>
  <div class="xd-login xd-author">
    <p class="xd-regist-inp">
      <img
        :src="focus==1?require('@/public/asset/img/icons/profile-on.png'):require('@/public/asset/img/icons/profile-off.png')"
        alt="" class="xd-regist-icon"/>
      <input type="text" placeholder="被授权人姓名" v-model="container.name" @click="focus=1"/>
      <i class="line" :class="focus==1?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error" v-show="container.name" @click="container.name=''"></i>
    </p>
    <p class="xd-regist-inp">
      <img
        :src="focus==2?require('@/public/asset/img/user/phone-on.png'):require('@/public/asset/img/user/phone-off.png')"
        alt="" class="xd-regist-icon"/>
      <input type="text" placeholder="被授权人手机号码" v-model="container.phone" @click="focus=2"/>
      <i class="line" :class="focus==2?'inp-lineOn':'inp-lineOff'"></i>
      <i class="iconfont icon-error" v-show="container.phone" @click="container.phone=''"></i>
    </p>
    <div class="children-tit" v-if="children.length">选择对方可查看的孩子：</div>
    <template v-for="(child,index) in children">
      <a class="mint-cell" @click="tapHandler($event,index)">
        <div class="mint-cell-left"></div>
        <div class="mint-cell-wrapper" :class="cur==index?'radio-on':''" >
          <div class="mint-cell-title">
            <label class="mint-radiolist-label">
							<span class="mint-radio is-right">
								<input  type="checkbox" class="mint-radio-input my"
                       v-model="container.selectedChildren"
                       :value="child.id">
								<span class="mint-radio-core my"></span>
							</span>
              <span class="mint-radio-label my"><img src="~@/public/asset/img/home/head.png" alt="">{{child.name}}</span>
            </label>
          </div>
          <div class="mint-cell-value">
            <span></span>
          </div>
        </div>
        <div class="mint-cell-right"></div>
      </a>
      <mt-radio :name="child.id" v-show="cur==index" align="right" @change="changeRelation2($event,child.id,index)" title="该孩子与被授权人关系" @click.native="changeRelation(e,$event,child.id,index,children.relation)" :value="getValue(child.id)"
                :options="relationTypes">
      </mt-radio>
    </template>
  </div>
</template>

<script>
  import {ACTION_TYPES} from "@/constants";
  import {getChild, secondGuardianAuthority, getSecondGuardianAuthorityByCellNumber} from "@/api/user/user-api";

  export default {
    data() {
      return {
        container: {
          name: "",
          phone: "",
          relation: "",
          selectedChildren: []
        },
        cur: -1,
        focus: {},
        children: [],
        relationList:{},
        authority: [],
        params:null,
        relationTypes: [{label: '次要监护人', value: '3'}, {label: '学员', value: '2'}]
      };
    },
    created() {
      this.getAuthorit();
      this._getChild();
      xdapp.util.vue.on(ACTION_TYPES.Author_Invite, this.submit);
    },
    methods: {
      tapHandler(e,index){
        this.cur=index;
        let previous =this.container.selectedChildren.length;
        console.log(e)
        this.$nextTick(()=>{
          if(this.container.selectedChildren.length<previous){
            e.srcElement.parentElement.offsetParent.nextElementSibling.style.display='none'
          }else{
            e.srcElement.parentElement.offsetParent.nextElementSibling.style.display='block'
          }
          // console.l
        })
      },
      getAuthorit(){
        if (!this.$route.query.phone)
          return;
        let params = {cellNumber: this.$route.query.phone};
        getSecondGuardianAuthorityByCellNumber(
          params,
          res => {
            if (res.length) {

              this.authority = res;

              this.container.name = res[0].secName;
              this.container.phone = res[0].secUserCellPhone;

              this.authority.forEach(item => {
                this.container.selectedChildren.push(item.sid);
                this.relationList[item.sid]=item.relation;
              });
            }
          }
        );
      },
      getParams(){
        return this.container.selectedChildren.map((v, i) => {
          
          return {
            secUserCellPhone: this.container.phone,
            relation: this.relationList[v] || '3',
            sid: v,
            sname:this.getName(v),
            secName: this.container.name
          };
        });
      },
      getName(sid){
        let name='';
        this.children.forEach(v=>{
          if(v.id==sid){
            name=v.name;
          }
        })
        return name;
      },
      changeRelation2(e,id,index){
        // debugger
        let i = this.container.selectedChildren.indexOf(id);
        this.relationList[id]= e.toString();
      },
      changeRelation(e1,e,id,index,relation){
        // alert(123)
        // debugger
        // console.log(e.srcElement.previousElementSibling)
        // console.log(e.srcElement.nextElementSibling.attributes[0])
        // debugger
        let ele = '';
        if(e.srcElement.parentElement.offsetParent.previousElementSibling && e.srcElement.parentElement.offsetParent.previousElementSibling.className=='mint-cell'){
          ele = e.srcElement.parentElement.offsetParent.previousElementSibling
        }else{
          ele = e.srcElement.parentElement.offsetParent.nextElementSibling
        }
        // console.log(e.srcElement.parentElement.offsetParent.previousElementSibling.className)
        // console.log(e.srcElement.parentElement.offsetParent.nextElementSibling.className)
        // debugger
        // console.log(ele)
        // console.log(ele.querySelector('.mint-radio-input'))
        // alert(ele.style.display)
        // ele.style.display='none'
        // let tEle =ele.querySelector('.mint-radio-input');
        ele.querySelector('.mint-radio-input').checked=false
        // tEle.style.display='none'
        // console.log(e)
        let i = this.container.selectedChildren.indexOf(id);
        // this.relationList[id]=relation //e.toString();
        // console.log(e.srcElement)
        this.relationList[id]=e.srcElement.value;
      },
      _getChild() {
        return getChild(res => {
          console.log(res)
          res.forEach((v,i)=>{
            v.relation=v.relation.toString();
          })
          this.children = res;
          
        });
      },
      submit() {
        this.params=this.getParams();
        if(this.params[0].secUserCellPhone == m2.cache.get('rx-current-user').cellNumber){
          mui.alert('授权失败！不能对自己进行授权')
          return false
        }
        let n = 0;
        this.params.forEach(v=>{
          v.relation==2?n++:''

        })
        if(n>1){
          mui.alert('授权失败！请检查授权关系，一个手机号只能授权一个学员')
          // return flase
          return false
        }
//        console.log(this.params);
//        console.log(this.container.selectedChildren);
        secondGuardianAuthority(this.params, res => {
          mui.alert("授权成功");
          this.$router.push({name: "profile-settings-author-manage"});
        });
      },
      getValue(sid){
        // return '3';
        
        let result = this.authority.find(item => item.sid == sid && item.relation != 1);
        if (result) {
          // alert(result.relation.toString())
          return result.relation.toString();
        }else{
          return '3';
        }
        if(this.$route.query.type=='add'){
          // alert(3)
          return '3';
        }
      }
    },
    computed: {
      
    },
    watch: {
      container: {
        handler(now,old) {
          // console.log(now);
          // console.log(old);
          xdapp.util.vue.commitActionStatus(
            now.phone && now.selectedChildren.length
          );
          
        },
        deep: true
      }
    },
  };
</script>
<style>
  .mint-radiolist-title{
	text-indent: 1.5em
}
.xd-author .mint-radio input:checked + .mint-radio-core {
  background-color: #ffa713 !important;
  border-color: #ffa713 !important;
}

.radio-on{
  background: #eee;
}
.my.mint-radio-core {
    display: inline-block;
    background-color: #fff;
    border-radius: 100%;
    border: 1px solid #ccc;
    position: relative;
    width: 20px;
    height: 20px;
    vertical-align: middle;
    transform: scale(1.6)
}
.my.mint-radio-input:checked + .mint-radio-core::after {
    border-color: #fff;
    -webkit-transform: rotate(45deg) scale(1);
    transform: rotate(45deg) scale(1);
}
.my.mint-radio-core::after{border-radius: 0!important}
.my.mint-radio-input:checked + .mint-radio-core::after {
    background-color: #ffa713;
}
.my.mint-radio-core::after{

    border: 2px solid transparent;
    border-left: 0;
    border-top: 0;
    content: " ";
    top: 3px;
    left: 6px;
    position: absolute;
    width: 4px;
    height: 8px;
    -webkit-transform: rotate(45deg) scale(0);
    transform: rotate(45deg) scale(0);
    -webkit-transition: -webkit-transform .2s;
    transition: -webkit-transform .2s;
    transition: transform .2s;
    transition: transform .2s, -webkit-transform .2s;
}
</style>

<style lang="scss" scoped>
  .mint-radio-label {
    img {
      height: 20px;
      width: 20px;
      vertical-align: top;
      margin-right: 5px;
    }
  }

  .children-tit {
    padding-left: 0.8rem;
    font-size: 14px;
    color: #888;
  }

  .mui-btn {
    height: 44px;
    border-radius: 100px;
    -webkit-border-radius: 100px;
    border: none;
    width: torem(314);
    font-size: torem(16);
    line-height: torem(16);
    color: #fff;
  }

  .xd-login {
    position: absolute;
    width: 100%;
    background-size: 100% torem(238);
    display: table-cell;
    background-color: #fff;
    .xd-regist-icon {
      height: 18px;
      width: 18px;
    }
  }

  #slider {
    margin-top: torem(140);
  }

  .mui-control-item {
    color: #666 !important;
  }

  .mui-active {
    color: #ffa713 !important;
  }

  #item1mobile,
  #item2mobile {
    height: torem(285);
    margin-top: 30px;
  }

  .forget {
    text-align: right;
    font-size: torem(16);
    padding-left: 34px;
    display: inline-block;
    color: #ffa713;
  }

  .xd-home-error {
    position: absolute;
    top: 0;
    bottom: 0;
    right: torem(20);
    margin: auto 0;
    border-radius: 100%;
    width: torem(16);
    height: torem(16);
    text-align: center;
    line-height: torem(16);
    background: orange;
  }

  .rx-teacher-list {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    .item {
      width: 25%;
      text-align: center;
      img {
        width: torem(50);
        height: torem(50);
        border-radius: 50%;
        overflow: hidden;
        text-align: center;
        margin-top: torem(15);
      }
    }
    .t-sub {
      height: 20px;
      line-height: 20px;
      font-size: 14px;
      color: #999;
    }
    .t-name {
      line-height: 22px;
      font-size: 16px;
      color: #888;
    }
    .input-wrap {
      padding-top: 2px;
      height: 40px;
      input[type="checkbox"] {
        position: static;
        &:before {
          color: #ffa300;
        }
        &:checked:after {
          color: #ffa300 !important;
        }
      }
    }
  }
</style>
