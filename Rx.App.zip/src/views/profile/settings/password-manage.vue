<template>
  <div class="wrap">
    <list-items :items="items"></list-items>
  </div>
</template>

<script>
  import ListItems from '@/components/list-items/';
  import {PROFILE_PASSWORD_MANAGE} from '@/constants';

  export default {
    data() {
      return {
        items: PROFILE_PASSWORD_MANAGE
      }
    },
    components: {
      ListItems
    }
  }
</script>

<style>
</style>
