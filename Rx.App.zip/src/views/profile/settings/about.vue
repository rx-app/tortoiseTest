<template>
  <div class="wrap">
    <ul class="mui-table-view rx-list-items">
      <li @click="goUrl(item)" v-for="(item, index) in items" :key="index" class="item" :class="{'link-item':item.pathname}">
        <span v-if="item.icon" class="mui-icon iconfont" :class="item.icon"></span>
        <span class="name">{{item.title}}</span>
        <span class="value" :class="{'no-arrow':!item.pathname.name}">{{item.value}}
          <img v-if="item.img" :src="item.img" class="img-header" /></span>
      </li>
    </ul>
    <p class="hid" @click="showVersion"></p>
    <p class="hid2" @click="getVersion"></p>
    <p class="con">版权信息</p>
  </div>
</template>
<script>
import ListItems from "@/components/list-items/";
import axios from "@/public/api/axios";
import { PROFILE_RX_ABOUT } from "@/constants";

export default {
  data() {
    return {
      items: PROFILE_RX_ABOUT
    };
  },
  components: {
    ListItems
  },
  methods: {
    showVersion() {
      let res = confirm();
      if (res) {
        axios.get(xdapp.api.config.getFullConfig).then(r => {
          var version = r.versionConfig.version;
          if (window.version && window.version != version) {
            mui.alert("有新版本，需要重新加载");
            plus.runtime.restart();
          }else{
            mui.alert('无需更新')
          }
          window.version = version;
        });
      }
    },
    getVersion() {
      axios.get(xdapp.api.config.getFullConfig).then(r => {
        var version = r.versionConfig.version;
        mui.alert("服务器版本:" + version);
        mui.alert("当前版本:" + window.version);

        if (window.version != version) {
          mui.alert("版本不一致");
          //plus.runtime.restart();
        } else {
          mui.alert("版本一致");
        }
      });
    },
    goUrl(item) {
      if (item.isGoUrl) {
        let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
        if (reg.test(item.pathname)) {
          plus.runtime.openURL(item.pathname);
          return false;
        } else {
          mui.toast("评分地址不正确");
        }
      } else {
        this.$router.push({
          name: item.pathname
        });
      }
    }
  }
};
</script>
<style scoped>
.hid,
.hid2 {
  position: absolute;
  bottom: 100px;
  height: 100px;
  width: 100px;
}
.hid2 {
  right: 0;
}
.con {
  text-align: center;
  position: absolute;
  bottom: 20px;
  width: 100%;
}
</style>
<style lang="scss" scoped>
.rx-list-items {
  .item {
    display: flex !important;
    justify-content: center;
    align-items: center;
    padding: torem(10);
    border-bottom: 1px solid #eee;
    margin: 0 torem(5);
  }
  .link-item:after {
    content: "\E583";
    font-family: Muiicons;
    color: #bbb;
    -webkit-font-smoothing: antialiased;
    margin-left: 5px;
  }
  .name {
    color: #777;
    font-size: torem(14);
  }
  .value {
    display: block;
    text-align: right;
    flex: 1;
    color: #aaa;

    .img-header {
      width: 1.70667rem;
      height: 1.70667rem;
    }
  }
  .no-arrow {
    margin-right: 3px;
  }
}
.mui-content > .mui-table-view:first-child {
  margin-top: 0;
}
</style>
