<template>
	<div class="wrap">
		<div id="slider" class="mui-slider" data-slider="4">
			<div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<a class="mui-control-item mui-active nth_child" href="#item1mobile">
					原密码修改
				</a>
				<a class="mui-control-item" href="#item2mobile">
					手机验证码修改
				</a>
			</div>
			<!--<div id="sliderProgressBar" class="mui-slider-progress-bar mui-col-xs-6" style="transform: translate3d(50%, 0px, 0px) translateZ(0px);"></div>-->
			<div id="item1mobile" class="mui-slider-item mui-control-content mui-active">
				<div id="scroll1" class="mui-scroll-wrapper" data-scroll="1">
					<div class="mui-scroll" style="transform: translate3d(0px, 0px, 0px) translateZ(0px);">
						<div class="befor_psd">
							<p class="xd-regist-inp">
								<img
								:src="pwd?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
								alt="" class="xd-regist-icon"/>
								<input :type="inpTypeSo" placeholder="请输入原密码" v-model="pwd" />
								<i class="iconfont eye" :class="iconStatusSo" @click="toggleInpType('So')"></i>
								<i class="iconfont icon-error" v-show="pwd" @click="pwd=''"></i>
							</p>
							<p class="xd-regist-inp">
								<img
								:src="newPwd?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
								alt="" class="xd-regist-icon"/>
								<input :type="inpTypeNew" placeholder="请输入新密码（6到20位）" v-model="newPwd" />
								<i class="iconfont eye" :class="iconStatusNew" @click="toggleInpType('New')"></i>
								<i class="iconfont icon-error" v-show="newPwd" @click="newPwd=''"></i>
							</p>
							<p class="xd-regist-inp">
								<img
								:src="newPwd2?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
								alt="" class="xd-regist-icon"/>
								<input :type="inpTypeAgin" placeholder="再次输入新密码" v-model="newPwd2" />
								<i class="iconfont eye" :class="iconStatusAgin" @click="toggleInpType('Agin')"></i>
								<i class="iconfont icon-error" v-show="newPwd2" @click="newPwd2=''"></i>
							</p>
							<!-- <p class="inp">
								<span class="mui-icon iconfont icon-home"></span>
								<input v-model="pwd" :type="inpTypeSo" placeholder="请输入原密码" />
								<i class="iconfont eye" :class="iconStatusSo" @click="toggleInpType('So')"></i>
							</p>
							<p class="inp">
								<span class="mui-icon iconfont icon-home"></span>
								<input v-model="newPwd" :type="inpTypeNew" placeholder="请输入新密码（6到12位）" />
								<i class="iconfont eye" :class="iconStatusNew" @click="toggleInpType('New')"></i>
							</p>
							<p class="inp">
								<span class="mui-icon iconfont icon-home"></span>
								<input v-model="newPwd2" :type="inpTypeAgin" placeholder="再次输入新密码" />
								<i class="iconfont eye" :class="iconStatusAgin" @click="toggleInpType('Agin')"></i>
							</p> -->
							<div class="inp">
								<div style="float:right" class="submit mui-btn" @click="reset">确定</div>
							</div>
						</div>
					</div>
					<div class="mui-scrollbar mui-scrollbar-vertical">
						<div class="mui-scrollbar-indicator" style="transition-duration: 0ms; display: block; height: 52px; transform: translate3d(0px, 0px, 0px) translateZ(0px);"></div>
					</div>
				</div>
			</div>
			<div id="item2mobile" class="mui-slider-item mui-control-content ">
				<div id="scroll2" class="mui-scroll-wrapper" data-scroll="2">
					<div class="mui-scroll" style="transform: translate3d(0px, 0px, 0px) translateZ(0px); transition-duration: 0ms;">
						<div class="after_psd">
							<p class="xd-regist-inp">
								<img
								:src="newPwd3?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
								alt="" class="xd-regist-icon"/>
								<input :type="inpTypeNewPsd" placeholder="设置新登录密码（6到20位）" v-model="newPwd3" />
								<i class="iconfont eye" :class="iconStatusNewPsd" @click="toggleInpType('NewPsd')"></i>
								<i class="iconfont icon-error" v-show="newPwd3" @click="newPwd3=''"></i>
							</p>
							<p class="xd-regist-inp">
								<img
								:src="newPwd4?require('@/public/asset/img/user/psd-on.png'):require('@/public/asset/img/user/psd-off.png')"
								alt="" class="xd-regist-icon"/>
								<input :type="inpTypeAginPsd" placeholder="重复新登录密码" v-model="newPwd4" />
								<i class="iconfont eye" :class="iconStatusAginPsd" @click="toggleInpType('AginPsd')"></i>
								<i class="iconfont icon-error" v-show="newPwd4" @click="newPwd4=''"></i>
							</p>
							<!-- <p class="inp">
								<span class="mui-icon iconfont icon-home"></span>
								<input v-model="newPwd3" :type="inpTypeNewPsd" placeholder="设置新登录密码" />
								<i class="iconfont eye" :class="iconStatusNewPsd" @click="toggleInpType('NewPsd')"></i>
							</p>
							<p class="inp">
								<span class="mui-icon iconfont icon-home"></span>
								<input v-model="newPwd4" :type="inpTypeAginPsd" placeholder="重复新登录密码（6到20位字符）" />
								<i class="iconfont eye" :class="iconStatusAginPsd" @click="toggleInpType('AginPsd')"></i>
							</p> -->
							<p class="xd-regist-inp">
								<img
								:src="valid?require('@/public/asset/img/user/code-on.png'):require('@/public/asset/img/user/code-off.png')"
								alt="" class="xd-regist-icon"/>
								<input type="text" placeholder="输入手机验证码" v-model="valid" />
								<span class="mui-btn code" :class="'xd-regist-codeOn'"
									v-show="ifshow"	@click="getValidCode()" >获取手机验证码
								</span>
								<span class="mui-btn fade code" :class="'xd-regist-codeOn'"
										v-show="!ifshow">{{num}}秒
								</span>
								<i class="iconfont icon-error icon-right" v-show="valid" @click="valid=''"></i>
							</p>
							<!-- <p class="inp phone_id">
								<span class="mui-icon iconfont icon-home"></span>
								<input v-model="valid" type="text" placeholder="输入手机验证码" />
								<button v-show="ifshow" @click="getValidCode" id="btn">获取手机验证码</button>
								<button class="rest-num" v-show="!ifshow">{{num}}秒</button>
							</p> -->
							<div class="inp">
								<div style="float:right" class="submit mui-btn" @click="phoneReset">确定</div>
							</div>
						</div>
					</div>
					<div class="mui-scrollbar mui-scrollbar-vertical">
						<div class="mui-scrollbar-indicator" style="transition-duration: 0ms; display: block; height: 207px; transform: translate3d(0px, 0px, 0px) translateZ(0px);"></div>
					</div>
				</div>

			</div>

		</div>
	</div>
</template>

<script>
	import { logOff } from '@/api/ids/ids-api';

	import { updateUserPwd, sendUserResetPwdCode, validateUserResetPwdCode, resetUserPwd } from '@/api/user/user-api';
	export default {
		data() {
			return {
				pwd: '',
				newPwd: '',
				newPwd2: '',
				newPwd3: '',
				newPwd4: '',
				valid: '',
				num: 60,
				ifshow: true,
				inpTypeSo: 'password',
				iconStatusSo: 'icon-close-eyes',
				inpTypeNew: 'password',
				iconStatusNew: 'icon-close-eyes',
				inpTypeAgin: 'password',
				iconStatusAgin: 'icon-close-eyes',
				inpTypeNewPsd: 'password',
				iconStatusNewPsd: 'icon-close-eyes',
				inpTypeAginPsd: 'password',
				iconStatusAginPsd: 'icon-close-eyes',
			}
		},
		methods: {
			toggleInpType(kind) {
				switch(kind) {
					case 'So':
						if(this.inpTypeSo == 'text') {
							this.inpTypeSo = 'password';
							this.iconStatusSo = 'icon-close-eyes'
						} else {
							this.inpTypeSo = 'text';
							this.iconStatusSo = 'icon-eyes'
						}break;
					case 'New':
						if(this.inpTypeNew == 'text') {
							this.inpTypeNew = 'password';
							this.iconStatusNew = 'icon-close-eyes'
						} else {
							this.inpTypeNew = 'text';
							this.iconStatusNew = 'icon-eyes'
						}break;
					case 'Agin':
						if(this.inpTypeAgin == 'text') {
							this.inpTypeAgin = 'password';
							this.iconStatusAgin = 'icon-close-eyes'
						} else {
							this.inpTypeAgin = 'text';
							this.iconStatusAgin = 'icon-eyes'
						}break;
					case 'NewPsd':
						if(this.inpTypeNewPsd == 'text') {
							this.inpTypeNewPsd = 'password';
							this.iconStatusNewPsd = 'icon-close-eyes'
						} else {
							this.inpTypeNewPsd = 'text';
							this.iconStatusNewPsd = 'icon-eyes'
						}break;
					case 'AginPsd':
						if(this.inpTypeAginPsd == 'text') {
							this.inpTypeAginPsd = 'password';
							this.iconStatusAginPsd = 'icon-close-eyes'
						} else {
							this.inpTypeAginPsd = 'text';
							this.iconStatusAginPsd = 'icon-eyes'
						}break;
				}
			},
			reset() {
				if (this.pwd === '') {
					mui.alert('请输入原密码')
					return
				}
				if (this.newPwd === '') {
					mui.alert('请输入新密码')
					return
				}
				if (this.newPwd2 === '') {
					mui.alert('请再次输入新密码')
					return
				}
				var reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z\+\^\!=:\:@！￥#$~%^&_'\?\(\)\-\*\～\.\(\)\[\]\【\】\（\）\/\|\\\&]{6,20}$/;
				if(this.newPwd !== this.newPwd2) {
					mui.alert('两次输入的新密码不一致，请重新输入')
					return
				}
			
				if( !reg.test(this.pwd) || !reg.test(this.newPwd) || !reg.test(this.newPwd2)) {
					mui.alert('密码设置6-20位，支持字母+数字，或字母+数字+符号，符号建议使用~!@#$%^&*_-')
					return
				}
				updateUserPwd({
					oldPwd: this.pwd,
					newPwd: this.newPwd
				}, () => {
					mui.alert('密码修改成功');
					/*保存当前修改密码用户的账号*/
					window.updatePsdUser=m2.cache.get('rx-current-user').logOnName;
					this.logOff()
				})
			},
			logOff() {
				logOff(res => {
					let fingerpwd = window.localStorage.getItem('passwordxx');
					m2.cache.clear();
					fingerpwd && window.localStorage.setItem('passwordxx', fingerpwd);
					this.$router.push({
						name: 'login'
					})
				})
			},
			getValidCode() {
				event.preventdefault;   
				event.stopPropagation(); 
				sendUserResetPwdCode(m2.cache.get('rx-current-user').cellNumber, () => {
					mui.alert('验证码已发送')
					this.ifshow = false;
					var timer = setInterval(() => {
						this.num--;
						if(this.num == 0) {
							this.ifshow = true;
							//timer = null
							clearInterval(timer)
							this.num = 60;
						}
					}, 1000)
				})
			},
			phoneReset() {
				if (this.newPwd3 === '') {
					mui.alert('请输入新密码')
					return
				}
				if (this.newPwd4 === '') {
					mui.alert('请再次输入新密码')
					return
				}
				if(this.newPwd3 != this.newPwd4) {
					mui.alert('两次输入的新密码不一致，请重新输入')
					return
				}
				var reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z\+\^\!=:\:@！￥#$~%^&_'\?\(\)\-\*\～\.\(\)\[\]\【\】\（\）\/\|\\\&]{6,20}$/;
				if(!reg.test(this.newPwd3) || !reg.test(this.newPwd4)) {
					mui.alert('密码设置6-20位，支持字母+数字，或字母+数字+符号，符号建议使用~!@#$%^&*_-')
					return
				}
				if(!this.valid) {
					mui.alert('请输入手机验证码')
					return
				}
				resetUserPwd({
					cellNumber: m2.cache.get('rx-current-user').cellNumber,
					newPwd: this.newPwd3,
					resetPwdCode: this.valid
				}, (res) => {
                   /*保存当前修改密码用户的账号*/
					window.updatePsdUser=m2.cache.get('rx-current-user').logOnName;
					mui.alert('密码修改成功')
					this.logOff();

				})
			}

		}
	}
</script>

<style lang='scss' scoped>
span.mui-btn.code.xd-regist-codeOn.fade{
	background: #ccc;
}
	.submit {
		height: 40px;
		width: 100%;
		border-radius: 20px;
		background: #ffa713;
		color: #fff;
		line-height: 28px;
	}
	
	.rest-num {
		height: 50px;
		background-color: #ccc!important;
	}
	
	.mui-slider-indicator.mui-segmented-control {
		height: 60px;
	}
	
	.mui-slider-indicator.mui-segmented-control a {
		line-height: 60px;
	}
	
	#item1mobile,
	#item2mobile {
		height: 400px;
	}
	
	.inp {
		position: relative;
		width: 90%;
		margin-left: 5%;
		border-radius: 5%;
	}
	
	.inp input {
		height: 50px;
		padding-left: 40px;
	}
	
	.mui-icon {
		position: absolute;
		left: 10px;
		top: 9px;
	}
	
	.phone_id {
		display: flex;
	}
	
	#btn,
	.rest-num {
		width: 240px;
		height: 50px;
		background-color: #ffa713;
	}
	.eye {
		color: #ccc;
		font-size: torem(24);
		position: absolute!important;
		right: torem(60)!important;
		top: torem(16)!important;
		margin-top: -4px;
		margin-right: -12px;
	}
	.icon-error{
		margin-top: -2px;
		margin-right:-8px;
		right:torem(20)!important;
	}
</style>