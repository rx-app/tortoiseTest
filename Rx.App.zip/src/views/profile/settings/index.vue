<template>
  <div class="wrap rx-big-font">
    <list-items :items="items1"></list-items>
    <button type="button" class="mui-btn mui-btn-block btn btn-signout" @click="sign_out()">退出登录</button>
    <div class="mui-popup-backdrop mui-active" v-if="flag">
      <div class="inner" v-if="flag">
        <div class="title">退出登录后不会删除历史记录，下次登录依然可以使用本账号。</div>
        <div class="buttons">
          <p class="sign btn" @click="logOff">确认退出</p>
          <p class="cancel btn" @click="cancel()">取消</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { logOff } from "@/api/ids/ids-api";
import ListItems from "@/components/list-items/";
import { PROFILE_SETTING } from "@/constants";
import { fingerPsdStatus } from "@/api/common/common-api";
import { CACHE_KEYS } from "@/constants";
import { FINGERPSDSTATUS } from "@/store/mutation-types";
import * as types from "@/store/mutation-types";
import store from "@/store";

export default {
  data() {
    return {
      userInfo: {},
      flag: false,
      items1: PROFILE_SETTING
    };
  },
  beforeRouteEnter(to, from, next) {
    if (from.name == "login") {
      next(false);
    } else {
      next();
    }
  },
  methods: {
    sign_out: function() {
      this.flag = true;
    },
    cancel: function() {
      this.flag = false;
    },
    logOff() {
      logOff(res => {
        // 清除ai监控
        xdapp.util.aiUtil.seting("loginOut");
        console.log("loginOut", 4);
        let loginStatus = fingerPsdStatus();
        console.log("loginStatus:" + loginStatus);
        // if (loginStatus && typeof loginStatus !== 'undefiend') {
        //   m2.cache.clear();
        //   $vue.$router.push({
        //     name: 'unlock'
        //   })
        // } else {
        //   m2.cache.clear();
        //   this.$router.push({name:'login'})
        // }
        // let fingerpwd = m2.cache.get('passwordxx');
        let accountList = m2.cache.get("accountList");
        let userIcons = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
        let questionMess = m2.cache.get(CACHE_KEYS.QUESTIONMESS);
        let quesOpenTime = m2.cache.get(CACHE_KEYS.QUESOPENTIME);
        m2.cache.clear();
        m2.cache.set("accountList", accountList);
        m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, userIcons);
        m2.cache.set(CACHE_KEYS.QUESTIONMESS, questionMess);
        m2.cache.set(CACHE_KEYS.QUESOPENTIME, quesOpenTime);
        store.commit(types.CURRENT_MODI_HEAD, []);
        //fingerpwd && window.localStorage.setItem('passwordxx', fingerpwd);
        this.$router.push({
          name: "login"
        });
      });
    }
  },
  components: {
    ListItems
  }
};
</script>

<style scoped>
.btn {
  width: 100%;
  display: block;
  margin-top: 20px;
  text-align: center;
  color: #fff;
  background: rgb(226, 85, 85);
  border-radius: 25px;
}

.cancel,
.sign {
  background: rgb(226, 85, 85);
  line-height: 50px;
}

.cancel {
  background: #ccc;
}

.inner {
  position: fixed;
  bottom: 0;
  width: 100%;
  background-color: #fff;
  padding: 15px 10px;
}

.btn-signout {
  position: fixed;
  bottom: 0;
  width: 90%;
  left: 5%;
  border-radius: 25px;
  margin-top: 0;
}
</style>