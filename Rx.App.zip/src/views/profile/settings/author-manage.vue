<template>
  <div class="mui-content rx-big-font" id="home">
    <ul class="mui-table-view">
      <router-link tag="div" :to="{name:'profile-settings-author-invite',query:{type:'add'}}" class="addChild">+ 授权邀请</router-link>
      <li v-for="(item,index) in authorList" :key="index" class="mui-table-view-cell">
        <router-link :to="{name:'profile-settings-author-invite',query:{phone:item.cellNumber}}" tag="span"
                     v-if="item.name">{{item.name}}(手机号：{{item.cellNumber}})
        </router-link>
        <router-link :to="{name:'profile-settings-author-invite',query:{phone:item.cellNumber}}" tag="span" v-else>
          {{item.cellNumber}}
        </router-link>
        <div class="mui-switch" @click="change(item)" :class="{'mui-active':true}" data-switch="1">
          <div class="mui-switch-handle"></div>
        </div>
      </li>
    </ul>
  </div>

</template>

<script>
  import {getSeconedGuardianInfo, removeSecondGuardianAuthority} from '@/api/user/user-api';

  export default{
    data(){
      return {
        authorList: []
      }
    },
    created () {
      this.getAuthorList();
    },
    methods: {
      removeAuthor(){
        removeSecondGuardianAuthority({}, res => {
        });
      },
      getAuthorList(){
        getSeconedGuardianInfo(res => {
          this.authorList = res;
          console.log(res);
        })
      },
      change(item){
        var _this = this;
        mui.confirm('解除授权后，对方将看不到你名下孩子信息。是否确认解除授权？', '提示', ['取消', '确定'], function (e) {
          if (e.index != 0) {
            removeSecondGuardianAuthority({secUserCellPhone: item.cellNumber}, res => {
              mui.alert('取消授权成功');
              _this.authorList.splice(_this.authorList.findIndex(v => v.cellNumber == item.cellNumber), 1)
            })
          }
        })


      }
    }
  }
</script>

<style scoped>
  .addChild {
    padding: 18px;
    color: #fff;
    font-weight: 600;
    background: rgb(120, 149, 228);
  }
</style>
