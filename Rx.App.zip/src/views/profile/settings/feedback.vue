﻿<template>
	<div class="wrap">
		<div style="padding-bottom:100px" class="mess_content" >

			<span class="rx-msg-time">2017年12月1日 下午5:45</span>
			<dl v-for="(item,index) in msgList" :key="index" :class="item.type? 'rx-msg-item' : 'rx-msg-item-re'">
				<dt v-if="item.type">
					<img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/04@3x.png">
				</dt>
				<dd v-html="item.content">

				</dd>
				<dt v-if="!item.type">
						<img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/04@3x.png">
				</dt>
			</dl>

		</div>
		<div class="rx-msg-input">
			<input v-model="con" type="text">
            <button class="addpic On" id="openPopover" @click="initBtn">图片</button>
            <div id="popove" ref='popover' class="mui-popover classifies mui-active" v-show="on">
                <my-text txt="拍照"></my-text>
                <my-text txt="从手机相册中选择"></my-text>
                <my-text txt="保存图片"></my-text>
                <my-text txt="取消" @click.native="on=false"></my-text>
            </div>
            <div class="mui-backdrop mui-active" style="" v-show="on"></div>
			<button :disabled="con?false:true" class="sendBtn" :class="con?'On':'Off'" @click="send">发送</button>
		</div>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				con: '',
				msgList: [{
						type: 1,
						content: '家长，您好！你的孩子xxx有一条补录课时产生，<a href="/">点击查看</a>'
					},
					{
						type: 1,
						content: '[记录]家长，您好！你的孩子xxx有一条补录课时产生，上课时间为2017年8月4日，科目为数学，请确认。'
					},
					{
						type: 0,
						content: '收到'
					},
					{
						type: 1,
						content: '[记录]家长，您好！你的孩子xxx有一条补录课时产生，上课时间为2017年8月4日，科目为数学，请确认。'
					},
					{
						type: 0,
						content: '收到'
					},
					{
						type: 1,
						content: '[记录]家长，您好！你的孩子xxx有一条补录课时产生，上课时间为2017年8月4日，科目为数学，请确认。'
					},
					{
						type: 0,
						content: '收到'
					},
					{
						type: 1,
						content: '家长，您好！你的孩子xxx有一条补录课时产生，<a href="/">点击查看</a>'
					},
				]
			}
		},
		methods: {
			send() {
				this.msgList.push({
					type: 0,
					content: this.con
				});
				this.con = '';
            },
            initBtn(){
                plus.nativeUI.actionSheet({cancel:"取消",buttons:[
                    {title:"拍照"},
                    {title:"从相册中选择"}
                ]}, (e)=>{//1 是拍照  2 从相册中选择
                    switch(e.index){
                        case 1:this.appendByCamera();break;
                        case 2:this.appendByGallery();break;
                    }
                });
            },
            appendByCamera(){
            	var that=this;
                plus.camera.getCamera().captureImage(function(e){
                    console.log("e is" +  e);
                    plus.io.resolveLocalFileSystemURL(e, function(entry) {
                        var path = entry.toLocalURL();
                        m2.cache.set('temp-img',path)
                        that.upload();
                        //document.querySelector('.avatar').src = path;

                    
                        //cutImage(path)

                    }, function(e) {
                        mui.toast("读取拍照文件错误：" + e.message);
                    });

                });
            },
            appendByGallery(){
                var that=this;
                plus.gallery.pick((path)=>{
                    //document.querySelector('.avatar').src = path;
                    //cutImage(path)
                    m2.cache.set('temp-img',path)
                    that.upload();
                });
            },
            upload(){
                //服务端接口路径
                var server = "http://10.1.55.88/PPTSApp/Rx.Api/api/Test/Upload";
                //获取图片元素
                //var files = document.querySelector('.avatar');
                var wt=plus.nativeUI.showWaiting();
                var task;
                this.task=task;
                task=plus.uploader.createUpload(server,
                    {method:"POST"},
                    function(t,status){ //上传完成
                        if(status==200){
                            alert("上传成功："+t.responseText);
                            wt.close(); //关闭等待提示按钮
                        }else{
                            alert("上传失败："+status);
                            wt.close();//关闭等待提示按钮
                        }
                    }
                );
                //添加其他参数
                task.addData("name","test");
                task.addFile(m2.cache.get('temp-img'),{key:"dddd"});
                // 设置自定义数据头
	            task.setRequestHeader("x-session-token",m2.cache.get('x-session-token'));
                task.start();
            },
            
        }
        
	}
</script>

<style lang="scss" scoped>
.mess_content{background: #eee;}
	.rx-msg-input {
		display: flex;
		position: fixed;
		z-index: 100;
		bottom: torem(0);
		background: #fff;
		width: 100%;
		padding: 8px 10px;
		border-top: 1px solid #ccc;
		div {
			width: 30px;
			margin-right: 8px;
			margin-top: 3px;
			line-height: 30px;
			text-align: center
		}
		input {
			margin-right: 8px;
			flex: 1;
			border-radius: 4px;
			height: torem(36);
			margin-bottom: 0;
		}
		.sendBtn,.addpic {
			width: torem(80);
			height: torem(36);
			border: none;
			text-align: center;
			line-height: torem(-0.04);
			font-size: torem(14)
		}
        .addpic{margin-right: 10px;}
		.On {
			background: skyblue;
			color: #fff;
		}
		.Off {
			background: #ccc;
		}
	}
	
	.rx-msg-time {
		text-align: center;
		display: block;
		margin-top: 14px;
		color: #999;
		font-size: 12px;
	}
	
	.rx-msg-item {
		z-index: 1;
		position: relative;
		padding: 14px 18px 0;
		display: flex;
		img {
			width: 40px;
			height: 40px;
			margin-right: 11px;
		}
		dd {
			font-size: 16px;
			color: #333;
			width: torem(222);
			padding: 8px 15px;
			background: #fff;
			border: 1px solid #ccc;
			margin-left: 0;
			.tit {
				font-size: 20px;
				color: #000;
				line-height: 28px;
			}
		}
		&:after {
			content: '';
			width: 0;
			height: 0;
			border: 7px solid transparent;
			border-right: 7px solid #ccc;
			position: absolute;
			left: 56px;
			top: 27px;
			z-index: 10;
		}
		&:before {
			content: '';
			width: 0;
			height: 0;
			border: 7px solid transparent;
			border-right: 7px solid #fff;
			position: absolute;
			left: 58px;
			top: 27px;
			z-index: 20;
		}
	}
	
	.rx-msg-item-re {
		z-index: 1;
		position: relative;
		padding: 14px 18px 0;
		display: flex;
		align-items: center;
		justify-content: flex-end;
		img {
			width: 40px;
			height: 40px;
			margin-left: 11px;
		}
		dd {
			font-size: 16px;
			color: #333;
			padding: 8px 15px;
			margin-left: torem(57);
			background: #ffe3b6;
			border: 1px solid #ccc;
			.tit {
				font-size: 20px;
				color: #000;
				line-height: 28px;
			}
		}
		&:after {
			content: '';
			width: 0;
			height: 0;
			border: 7px solid transparent;
			border-left: 7px solid #ccc;
			position: absolute;
			right: 56px;
			top: 27px;
			z-index: 10;
		}
		&:before {
			content: '';
			width: 0;
			height: 0;
			border: 7px solid transparent;
			border-left: 7px solid #ffe3b6;
			position: absolute;
			right: 58px;
			top: 27px;
			z-index: 20;
		}
	}
</style>