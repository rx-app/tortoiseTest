<template>
	<div class="wrap">
		<ul class="mui-table-view mui-table-view-radio">
			<li class="mui-table-view-cell mui-selected">
				<a class="mui-navigate-right">
					满意
				</a>
			</li>
			<li class="mui-table-view-cell">
				<a class="mui-navigate-right">
					不满意
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
</script>

<style>
</style>