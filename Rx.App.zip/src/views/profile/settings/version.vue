﻿<template>
  <div class="wrap">
    <div class="img">
      <img src="~@/public/asset/img/profile/icon.png" alt />
    </div>
    <div id="list" v-if="versionList.length">
      <p v-for="(item,index) in versionList" :key="index">{{item}}</p>
    </div>
    <div id="tip" v-else>掌上学大&nbsp;&nbsp;{{version}}</div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      versionInfo: {
        "1.0.3": [
          "掌上学大  v1.0.3",
          "1、扫码确认课时",
          "2、课后评价",
          "3、成绩满意度打分",
          "4、家校互动",
          "5、孩子管理",
          "6、消息管理",
          "7、学大资讯"
        ],
        "1.1.3": [
          "掌上学大  v1.1.3",
          "1、扫码确认课时",
          "2、在线缴费",
          "3、查看课表",
          "4、课后评价",
          "5、成绩满意度打分",
          "6、家校互动留言、群聊",
          "7、孩子管理",
          "8、消息管理",
          "9、学大资讯"
        ]
      },
      version: "",
      versionList: []
    };
  },
  mounted() {
    mui.plusReady(() => {
      this.version = plus.runtime.version;
      for (var item in this.versionInfo) {
        if (plus.runtime.version == item) {
          this.versionList = this.versionInfo[item];
        }else{
          //匹配第一版没版本号的
          this.versionList = this.versionInfo["1.0.3"];
        }
      }
    });
  }
};
</script>

<style lang="scss" scoped>
.wrap {
  padding-top: torem(105) !important;
  line-height: torem(32);
  .img {
    text-align: center;
  }
  #list {
    margin-left: 35%;
  }
  #tip {
    text-align: center;
  }
}
</style>