<template>
  <div class="edition-wrap">
    <!-- <tip v-if="!introduction.length">
			<span>暂无功能介绍</span>
    </tip>-->
    <div class="wrap rx-edition" v-if="this.$route.query.time==20180726">
      <div class="txt-large">功能模块在页面下方即可查看：</div>
      <div class="img-box">
        <img :src="require('@/public/asset/img/version/20180726/1.jpg')" alt />
        <div class="txt-small">图1 功能模块</div>
      </div>
      <div class="txt-large">主要功能入口分别如下：</div>
      <div class="txt-large">一、首页确认课时</div>
      <img :src="require('@/public/asset/img/version/20180726/2.jpg')" alt />
      <div class="txt-small">图2 可确认课表二维码</div>
      <div class="txt-large">开课前90分钟到课后90分钟之间，该节课会显示二维码，出示二维码给老师，扫码确认课时。</div>
      <div class="txt-large">
        孩子忘带手机，或没有手机，可以在“我的孩子信息”中查看密码，让孩子通过输入密码确认课时。
        <span
          class="red"
        >切记：该密码只能孩子及家长知道，不要告知他人，也不要让老师代为输入。</span>
      </div>
      <img :src="require('@/public/asset/img/version/20180726/3.jpg')" alt />
      <div class="txt-small">图3 课时确认密码</div>
      <div class="txt-large">二、课后评价</div>
      <img :src="require('@/public/asset/img/version/20180726/4.jpg')" alt />
      <div class="txt-small">图4 课后评价</div>
      <div class="txt-large">上完课，就可以通过打分和补充说明的方式，对授课老师做出评价。授课教师无权查看此评价。</div>
      <div class="txt-large">三、辅导结果打分</div>
      <img :src="require('@/public/asset/img/version/20180726/5.jpg')" alt />
      <div class="txt-small">图5 为成绩结果打分</div>
      <div class="txt-large">在成绩管理中，在学大辅导过的科目，可以通过点击色块的方式为辅导结果打分。</div>
      <div class="txt-large">四、家校互动</div>
      <img :src="require('@/public/asset/img/version/20180726/6.jpg')" alt />
      <div class="txt-small">图6 家校互动留言</div>
      <div class="txt-large">家校互动下可与归属咨询师、学管师，以及专职授课教师进行留言互动。</div>
    </div>
    <div class="wrap rx-edition" v-if="this.$route.query.time==20190326">
      <div class="txt-large">新增讨论组功能：</div>
      <div class="txt-large">
        <span class="red">功能说明：</span>学管师可将学员相关老师添加至一个讨论组中，对学员近期情况进行分享、分析，讨论解决方案。
        <span class="red">
          <br />功能位置：
        </span>消息——家校互动——学员讨论组。
      </div>
      <div class="txt-large">
        <span class="red">界面示意图：</span>
      </div>
      <img :src="require('@/public/asset/img/version/20190326/1.jpg')" alt />
      <div class="txt-small">图1 消息-家校互动-XX学员讨论组</div>
      <img :src="require('@/public/asset/img/version/20190326/2.jpg')" alt />
      <div class="txt-small">图2 讨论组会话界面</div>
    </div>
    <div class="wrap rx-edition" v-if="this.$route.query.time==20191126">
      <div class="txt-large">新增主要功能：在线支付</div>
      <div class="txt-large">
        <span class="red">功能说明：</span>咨询师、学管师可以在学大业务系统发起“在线支付”，家长会在掌上学大APP上收到付款通知，家长通过链接进行付款即可。
        <span class="red">
          <br />功能位置：
        </span>缴费——待缴费——已缴费。
      </div>
      <div class="txt-large">
        <span class="red">界面示意图：</span>
      </div>
      <img :src="require('@/public/asset/img/version/20190910/1.jpg')" alt />
      <div class="txt-small">图1 缴费——待缴费</div>
      <img :src="require('@/public/asset/img/version/20190910/2.jpg')" alt />
      <div class="txt-small">图2 缴费——已缴费</div>
      <img :src="require('@/public/asset/img/version/20190910/3.jpg')" alt />
      <div class="txt-small">图3 缴费付款页面</div>
      <div class="txt-large">
        <span class="red">注意:</span>
        <div class="txt-large">1.咨询师或学管师在学大业务系统中操作了转在线支付的缴费单后，家长会在掌上学大APP首页收到待缴费提醒，点击付款链接进行支付即可；</div>
        <div class="txt-large">2.付款成功后，已缴费界面会立即显示该条缴费记录；如因网络问题支付失败，只需稍后重新支付即可。</div>
      </div>
    </div>
  </div>
</template>

<script>
import { getAppInfo } from "@/api/common/common-api";
import { getAppInfoByQuery } from "@/api/course/course-api";

import white from "@/public/lib/white";
import Tip from "@/components/tip";

export default {
  mixins: [white],
  components: {
    Tip
  },
  data() {
    return {
      introduction: "",
      contents: { 20180726: `` }
    };
  },
  created() {},
  mounted() {},
  methods: {}
};
</script>

<style lang="scss">
.edition-wrap {
  overflow: auto;
  height: 100vh;
}
.rx-edition {
  padding: 10vw;
  font-size: 12pt;
  // line-height: 24pt;
  font-family: "微软雅黑", sans-serif;
  color: rgb(143, 143, 148);
  .txt-large {
    margin-bottom: 10px;
    .red {
      color: red;
    }
  }
  .txt-small {
    font-size: 14px;
    text-align: center;
    margin-bottom: 10px;
    margin-top: 5px;
  }
  img {
    width: 100%;
  }
}
</style>
