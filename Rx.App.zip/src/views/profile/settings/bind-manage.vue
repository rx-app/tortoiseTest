<template>
  <div class="mui-content" id="home">
    <ul class="mui-table-view">
      <div class="addChild">+ 添加孩子</div>
      <li v-for="(item,index) in childList" :key="index" class="mui-table-view-cell">
        <span>{{item.name}}</span>
        <div class="mui-switch" @click="change(item)" :class="{'mui-active':item.isBind}" data-switch="1">
          <div class="mui-switch-handle"></div>
        </div>
      </li>
    </ul>
  </div>

</template>

<script>
  export default{
    data(){
      return {
        childList: [
          {name: '韩程璐', isBind: true},
          {name: '韩程璐2', isBind: false},
          {name: '韩程璐3', isBind: true},
          {name: '韩程璐4', isBind: true},
        ]
      }

    },
    methods: {
      change(item){
        if (item.isBind) {
          mui.confirm('解除绑定后，将不能关注该生信息。是否确认解除绑定？', '提示', ['取消', '确定'], function (e) {
            if (e.index != 0) {
              item.isBind = !item.isBind;
            }
          })
        } else {
          item.isBind = !item.isBind;
        }


      }
    }
  }
</script>

<style scoped>
  .addChild {
    padding: 18px;
    color: #fff;
    font-weight: 600;
    background: rgb(120, 149, 228);
  }
</style>
