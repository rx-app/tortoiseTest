<template>
  <div class="mui-content" id="home">
    <div id="cropper-example-1" class="">
      <img id="im" alt="Picture"/>
    </div>

    <div class="divbut">
      <div>
        <p id="quxiao" class="iconfont icon-quxiao">取消</p>
      </div>
      <div>
        <p id="xuanqu" class="iconfont icon-queding">确认</p>
      </div>
    </div>
    <!-- <img src="" alt="" class="mui-hidden" id="im_exif" /> -->
  </div>

</template>

<script>
  import { modifyHeadCus } from "@/api/customer/customer-api";
  import { CACHE_KEYS } from "@/constants";
  import '@/public/asset/js/cropper/cropper.min.css';

  import '@/public/asset/js/jquery/jquery-1.8.0';
  

  import '@/public/asset/js/cropper/cropper.min';

  //import myLi from '@/components/myLi'
  export default {
    data() {
      return {
        example2: {
          img: 'http://ofyaji162.bkt.clouddn.com/bg1.jpg',
          info: true,
          size: 1,
          outputType: 'jpeg',
          canScale: false,
          autoCrop: true,
          // 只有自动截图开启 宽度高度才生效
          autoCropWidth: 300,
          autoCropHeight: 250,
          // 开启宽度和高度比例
          fixed: true,
          fixedNumber: [4, 3]
        }

      }

    },
    components: {
      //myLi
    },
    mounted () {
      var _this = this;
      (function (c) {
        var Cro = function () {
        }
        c.extend(Cro.prototype, {
          orientation: null,
          urldata: null,
          view: null,
          num: 0,
          sbx: null,
          sby: null,
          n: 0,
          onReady: function () {
            var that = this;
            mui.init();
            that.bindEvent();
           // that.view = plus.webview.currentWebview();
            // alert(_this.$route.query.path)
            var img = document.getElementById("im");
            
            img.src =window.$mysrc; // _this.$route.query.path;
            that.cropperImg();

            // img.addEventListener("load", function() {
            //     //exif调整图片的横竖
            //     EXIF.getData(this, function() {
            //         var orientation = EXIF.getAllTags(this).Orientation;
            //         $("#im").attr("src", that.loadcopyImg(img, orientation));
            //         document.getElementById("cropper-example-1").classList.remove("mui-hidden"); //显示裁剪区域
            //     });
            // })
          },
          cropperImg: function () {
            var that = this;
            $('#cropper-example-1 > img').cropper({
              aspectRatio: 1 / 1,
              autoCropArea: 1,
              strict: true,
              viewMode:2,
              background: false,
              guides: false,
              highlight: false,
              dragCrop: false,
              movable: false,
              resizable: false,
              crop: function (data) {
                // that.urldata = that.base64(data);
              }
            });
          },
          loadcopyImg: function (img, opt) {
            var that = this;
            var canvas = document.createElement("canvas");
            var square = 500;
            var imageWidth, imageHeight;
            if (img.width > img.height) {
              imageHeight = square;
              imageWidth = Math.round(square * img.width / img.height);
            } else {
              imageHeight = square; //this.width;
              imageWidth = Math.round(square * img.width / img.height);
            }
            canvas.height = imageHeight;
            canvas.width = imageWidth;
            if (opt == 6) {
              that.num = 90;
            } else if (opt == 3) {
              that.num = 180;
            } else if (opt == 8) {
              that.num = 270;
            }
            if (that.num == 360) {
              that.num = 0;
            }

            var ctx = canvas.getContext("2d");
            ctx.translate(imageWidth / 2, imageHeight / 2);
            ctx.rotate(that.num * Math.PI / 180);
            ctx.translate(-imageWidth / 2, -imageHeight / 2);
            ctx.drawImage(img, 0, 0, imageWidth, imageHeight);
            var dataURL = canvas.toDataURL("image/jpeg", 1);
            return dataURL;
          },
          bindEvent: function () {
            var that = this;
            document.getElementById("quxiao").addEventListener("tap", function () {
             // mui.back();            //取消就直接返回
              $vue.$router.go(-1)
            });
            document.getElementById("xuanqu").addEventListener("tap", function () {
              // var preView = plus.webview.getWebviewById('plus/headinfo.html');
              //  //触发上一个页面刷新图片事件
              // mui.fire(preView,'updateHeadImg',{
              //     img_path:that.urldata
              //   });
              // mui.back();
              var mimeType = "jpg";
              function dataURLtoBlob(dataurl) {
                var arr = dataurl.split(","),
                  mime = arr[0].match(/:(.*?);/)[1],
                  bstr = atob(arr[1]),
                  n = bstr.length,
                  u8arr = new Uint8Array(n);
                while (n--) {
                  u8arr[n] = bstr.charCodeAt(n);
                }
                mimeType = mime;
                return new Blob([u8arr], { type: mime });
              }
              var data = $('#cropper-example-1 > img').cropper('getCroppedCanvas');
              var base64img = data.toDataURL("image/jpeg", 1);
              var stream = dataURLtoBlob ( base64img );
              var server = modifyHead//"http://10.1.55.88/RxApp/Rx.Api/api/User/ModifyHead";

              var formData = new FormData();
              formData.append("headupload", stream, Date.parse(new Date()) + ".jpg");

              var request = new XMLHttpRequest();
              request.open("POST", server);
              request.setRequestHeader(
                "x-session-token",
                m2.cache.get(CACHE_KEYS.SESSION_TOKEN)
              );

              request.send(formData);

              request.onload = function(oEvent) {
                if (request.status == 200) {
                  m2.cache.set("rx-user-head", request.responseText);
                  let user = m2.cache.get('rx-current-user');
                  window.xdapp.uavatar[m2.cache.get("rx-current-user").userId]=base64img;
        
                  user.iconID = request.responseText;
                  m2.cache.set('rx-current-user',user);
                  mui.alert("上传成功" );
                  $vue.$router.push({name:'profile'})
                  // wt.close(); //关闭等待提示按钮
                } else {
                  mui.alert("上次失败" + request.responseText);
                  // wt.close(); //关闭等待提示按钮
                }
              };
              // if(_this.$route.query.type=="child"){
              //   localStorage.setItem('cimg', data.toDataURL("image/jpeg", 0.1));
              //   _this.$router.push({name: 'childAvatar', query: {done: 1}})
              // }else{
              //   localStorage.setItem('img', data.toDataURL("image/jpeg", 0.1));
              //   _this.$router.push({name: 'profile-edit-avatar', query: {done: 1}})
              // }
            });
          },
          base64: function (data) {
            var that = this;
            var img = document.getElementById("im");

            var canvas = document.createElement("canvas");
            //像素
            canvas.height = 500;
            canvas.width = 500;
            var bx = data.x;
            var by = data.y;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, bx, by, data.width, data.height, 0, 0, 500, 500);
            var dataURL = canvas.toDataURL("image/jpeg", 1.0);            //第二个参数是质量
            return dataURL;
          }
        });

        var cro = new Cro();

        //c.plusReady(function () {
          cro.onReady();
       // })
      })(mui)


    }
  }
</script>

<style scoped>
  body {
    background-color: #000000;
  }

  #cropper-example-1 {
    background-color: #000000;
    height: 100%;
    width: 100%;
    position: absolute;
  }

  #quxiao,
  #xuanzhuan,
  #xuanqu {
    font-size: 16px;
  }

  .divbut {
    width: 100%;
    text-align: center;
    position: fixed;
    z-index: 2;
    top: 0px;
    background-color: #000000;
    /* height: 7.5%; */
    padding-top: 30px;
    line-height: 25px;
  }

  .divbut > div:first-child {
    float: left;
    width: 20%;
  }

  .divbut > div:last-child {
    float: right;
    width: 20%;
  }

  img#im {
    height: 100%;
    width: 100%;
  }
</style>
