<template>
  <div class="xdapp-feedback-container">
    <scroll
      @tap.native="fnTap"
      :data="[]"
      :listen-scroll="true"
      :probe-type="3"
      :pulldown="true"
      class="scroll-container"
      ref="listview"
    >
      <div class="user-edit-box">
        <div v-if="canEdit('profile-user-edit-name')" class="form-input">
          <input
            @focus="fnFocus"
            @blur="fnBlur"
            type="text"
            v-model="form.alias"
            class="mui-input-clear"
            placeholder="输入昵称不能超过15个字"
            data-input-clear="5"
          >
          <span
            class="mui-icon mui-icon-clear"
            @click="clear"
            :style="form.alias.length ? '' : 'display:none'"
          ></span>
        </div>
        <div v-if="canEdit('profile-user-edit-sex')">
          <ul class="mui-table-view mui-table-view-radio">
            <li
              v-for="(item,index) in sexList"
              class="mui-table-view-cell"
              @click="selectedSex(item)"
              :class="form.gender === item.key ? 'mui-selected' : ''"
              :key="index"
            >
              <a class="mui-navigate-right">{{item.value}}</a>
            </li>
          </ul>
        </div>
        <div v-if="canEdit('profile-user-edit-area')">
          <v-distpicker
            type="mobile"
            @selected="getArea"
            :province="userInfo.provinceName"
            :city="userInfo.cityName"
            :area="userInfo.countyName"
          ></v-distpicker>
        </div>
      </div>
    </scroll>
  </div>
</template>
<script>
import { mapState } from "vuex";
import { loadUserInfo } from "@/api/common/common-api";
import { updateUserInfo } from "@/api/user/user-api";
import VDistpicker from "v-distpicker";
import Scroll from "@/components/scroll/index";
import {
  ACTION_TYPES,
  ASSIGN_STATUS as assignStatus,
  COURSE_EVALUATE_SCORE_CONFIG as scoreConfig
} from "@/constants";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({
      bottom: "-1px"
    });
  }
}
function resize2() {
  //*12*点击输入框时，小键盘挡住了输入框
  if (
    document.activeElement.tagName == "INPUT" ||
    document.activeElement.tagName == "TEXTAREA"
  ) {
    window.setTimeout(function() {
      document.activeElement.scrollIntoViewIfNeeded();
    }, 0);
  }
}
export default {
  computed: {
    ...mapState({
      userInfo: state => state
    })
  },
  watch: {
    "form.alias": {
      handler: function(val) {
        this.validateForm("profile-user-edit-name", val);
      },
      deep: true
    },
    "form.gender": {
      handler: function(val) {
        this.validateForm("profile-user-edit-sex", val);
      },
      deep: true
    }
  },
  created() {
    this.getUserInfo();
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.addEventListener("resize", resize2);
    }
    document.querySelector(".xd-header").style.position = "fixed";
  },
  destroyed() {
    window.removeEventListener("resize", resize);
    if (/Android/gi.test(navigator.userAgent)) {
      window.removeEventListener("resize", resize2);
    }
  },
  data() {
    return {
      form: {
        alias: "",
        gender: "",
        provinceCode: "",
        cityCode: "",
        countyCode: ""
      },
      sexList: [
        {
          key: 1,
          value: "男"
        },
        {
          key: 2,
          value: "女"
        }
      ]
    };
  },
  methods: {
    selectedSex(item) {
      this.form.gender = item.key;
    },
    getArea(area) {
      this.form.provinceCode = area.province.code;
      this.form.cityCode = area.city.code;
      this.form.countyCode = area.area.code;
      xdapp.util.vue.commitActionStatus(true);
    },
    validateForm(editName, val) {
      if (this.canEdit(editName)) {
        xdapp.util.vue.commitActionStatus(val !== "" && val !== null);
      }
    },
    clear() {
      this.form.alias = "";
    },
    canEdit(editName) {
      if (this.$route.name === editName) {
        return true;
      }
      return false;
    },
    getUserInfo() {
      loadUserInfo();
      this.form.alias = this.userInfo.alias;
      this.form.gender = this.userInfo.gender;
      this.form.provinceCode = this.userInfo.provinceCode;
      this.form.cityCode = this.userInfo.cityCode;
      this.form.countyCode = this.userInfo.countyCode;
      xdapp.util.vue.on(ACTION_TYPES.SUBMIT_COMMET, this.submit);
    },
    submit() {
      if (this.canEdit("profile-user-edit-name")) {
        if (this.form.alias.length > 15) {
          mui.alert("昵称不能超过15个字，请重新输入！");
          return;
        }
      }
      xdapp.util.vue.commitActionStatus(false);
      updateUserInfo(this.form, () => {
        loadUserInfo("upd");
        mui.toast("修改成功");
        setTimeout(() => {
          this.$router.push({ name: "profile-user-userInfo" });
        }, 3000);
      });
    },
    fnTap(e) {
      if (!mui.os.ios) {
        if (e.target.tagName == "TEXTAREA" || e.target.tagName == "INPUT") {
          return;
        }
        if (
          document.activeElement.tagName == "TEXTAREA" ||
          document.activeElement.tagName == "INPUT"
        ) {
          document.activeElement.blur();
        }
      }
    },
    fnFocus() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "655px";

        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom });
        plus.webview.currentWebview().setStyle({ background: "#fff" });
      }
    },
    fnBlur() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // mui.toast(window.innerHeight)

        var wv = plus.webview.currentWebview();
        wv.setStyle({ top: "0px" });
        wv.setStyle({ bottom: "0px" });
      }
    }
  },
  components: {
    VDistpicker,
    Scroll
  }
};
</script>

<style lang="scss" scoped>
.xd-header {
  position: fixed;
  top: 0;
  left: 0;
}
.xdapp-feedback-container {
  position: fixed;
  width: 100%;
  height: 100%;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    background: #fff;
  }
}
.sex {
  padding: 5px 10px;
  background: #fff;
  margin: 5px;
  color: #888;
}

.sex.on {
  color: rgb(216, 203, 21);
}

.sex.on::after {
  content: "√";
  position: absolute;
  right: 10px;
  transform: scaleX(1.6);
  color: rgb(56, 199, 127);
}
</style>
<style>
.user-edit-box .mui-icon {
  position: absolute;
  right: 2%;
  top: 10%;
  transform: translateY(10%);
}
.user-edit-box .form-input {
  position: relative;
}
</style>
