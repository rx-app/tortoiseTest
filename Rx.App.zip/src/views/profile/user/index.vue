﻿<template>
	<div class="mui-content rx-user-info" id="home">
		<list-items :items="items" :userID="userID" :type="1"></list-items>
	</div>
</template>
<script>
	import { mapState } from "vuex";
	import { loadUserInfo } from "@/api/common/common-api";
	import { getHead } from "@/api/user/user-api";
	import ListItems from "@/components/list-item/";

	export default {
		data() {
			return {
				userInfo: {},
				userID:'',
				avatar: ""
			};
		},

		async created() {
			await loadUserInfo();
			this.userID=m2.cache.get("rx-current-user").userId;
			//this.getAvatar();
			//alert(' m2.cache.get("rx-user-head") '+ m2.cache.get("rx-user-head") )
		},
		computed: {
			...mapState({
				userId: state => state.userId,
				userName: state => state.alias,
				loginAccount: state => state.loginAccount,
				gender: state => state.gender,
				relation: state => state.relation,
				area: state =>
					state.provinceName + " " + state.cityName + " " + state.countyName
			}),
			items() {
				return [{
						title: "头像",
						routerLink: true,
						pathname: {
							//name: "profile-edit-avatar",
							params: {
								id: this.userId
							}
						},
						img: true
					},
					{
						title: "昵称",
						routerLink: true,
						pathname: "profile-user-edit-name",
						value: !!this.userName ? this.userName : '请设置'
					},
					{
						title: "掌上学大账号",
						value: this.loginAccount + this.relation
					},
					{
						title: "性别",
						routerLink: true,
						pathname: "profile-user-edit-sex",
						value: this.setGender(this.gender)
					},
					{
						title: "地区",
						routerLink: true,
						pathname: "profile-user-edit-area",
						value: this.area == 'null null null' ? '请选择' : this.area
					}
				];
			}
		},
		methods: {
			setGender(sex) {
				sex = parseInt(sex)
				if(sex == 1) {
					return '男'
				} else if(sex == 2) {
					return '女'
				} else {
					return '请选择'
				}
			},
			/*    getAvatar() {
			      if ( m2.cache.get("rx-current-user").iconID) {
			          getHead(
			            {
			              iconID: m2.cache.get("rx-current-user").iconID
			            },
			            (res => {
			              this.avatar = res;
			              window.xdapp.uavatar={};
			              window.xdapp.uavatar[m2.cache.get("rx-current-user").userId]=res;
			            })
			          );
			        } else {
			          if(m2.cache.get('rx-current-user').gender==1){
			            this.avatar = require('@/public/asset/img/user/father.png');
			          }else if(m2.cache.get('rx-current-user').gender==2){
			            this.avatar = require('@/public/asset/img/user/mother.png')
			          }else{
			            this.avatar = require('@/public/asset/img/home/head.png');
			          }
			          
			          // this.avatar = m2.cache.get('rx-current-user').gender==1? require('@/public/asset/img/user/father.png') : require('@/public/asset/img/user/mother.png')
			          return
			        }
			      
			    }*/
		},
		components: {
			ListItems
		}
	};
</script>

<style>
	.rx-user-info img {
		border-radius: 50%;
	}
</style>