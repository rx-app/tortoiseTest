<template>
  <div class="xdapp-msg-wrapper">
    <loading v-show="loading"></loading>
    <scroll
      @tap.native="fnTap"
      :data="messages"
      :listen-scroll="listenScroll"
      :probe-type="probeType"
      :pulldown="pulldown"
      :pullup="true"
      @scrollToEnd="searchMore"
      @scrollToStart="refreshMore"
      class="scroll-container"
      ref="listview"
    >
      <div class="msg-list">
        <ul class="list-group">
          <li class="list-group-item" v-for="(item,index) in messages" ref="groupItem">
            <span class="msg-time mui-badge">{{item.speakTime | normalize}}</span>
            <div
              :class="{'msg-item':item.userID!=curUserId,'msg-item-right':item.userID==curUserId,sysmsg:item.userType==5 }"
            >
              <!-- <div v-if="item.userID!=curUserId && item.userType!=5 "> -->
              <div v-if="item.userID!=curUserId && item.userType!=5 ">
                <span v-if="item.icons2">
                  <img
                    v-if="item.icons2.iconID && getIconImg(item.icons2.userID)"
                    :src="getIconImg(item.icons2.userID)"
                  >
                  <img
                    v-else-if="item.icons2.gender==1"
                    src="~@/public/asset/img/user/teacher-man.png"
                    alt
                  >
                  <img
                    v-else-if="item.icons2.gender==2"
                    src="~@/public/asset/img/user/teacher-woman.png"
                    alt
                  >
                  <img v-else src="~@/public/asset/img/user/teacher-man.png" alt>
                </span>
                <img v-else src="~@/public/asset/img/user/teacher-man.png" alt>
                <!-- <img v-if="icons && icons.iconID && imgSrcOption" :src="imgSrcOption">
								<img v-else-if='icons && icons.gender==2' src="~@/public/asset/img/user/teacher-woman.png" alt="" />
								<img v-else-if='icons && (icons.gender==1 || icons.gender==0 || icons.gender==null)' src="~@/public/asset/img/user/teacher-man.png" alt="" />
                <img v-else src="~@/public/asset/img/user/teacher-man.png" alt="" />-->
                <!-- <img src="~@/public/asset/img/user/teacher-man.png" alt> -->
              </div>
              <div
                v-if="item.userID!=curUserId && item.userType!=5"
                class="reply-name"
              >【{{getJobName(item.userType)}}{{item.userName}}】</div>
              <dd class="reply" v-html="item.content"></dd>
              <div v-if="item.userID==curUserId">
                <img class="mui-media-object mui-pull-left" :src="currentAvatar">
              </div>
            </div>
          </li>
        </ul>
      </div>
    </scroll>
    <div class="msg-input" v-if="isMessage">
      <div class="msg-left">
        <textarea
          type="text"
          class="input-text"
          v-model="content"
          @focus="setPosition()"
          @blur="setPosition2()"
        ></textarea>
      </div>
      <div class="msg-right">
        <button
          :disabled="content ? false : true"
          class="btn-send"
          :class="content ? 'btn-on' : 'btn-off'"
          @click="sendReply()"
        >发送</button>
      </div>
    </div>
    <div class="mask" v-if="maskShow">
      <div class="mask-box">
        <div class="close">
          <i class="iconfont icon-error" @click="maskDis()"></i>
        </div>
        <div class="msg-box">
          <textarea
            placeholder="请输入留言"
            autofocus="autofocus"
            v-model="content"
            class="msg-text"
            name
            id
            cols="30"
            rows="10"
          ></textarea>
          <button :disabled="content !== '' ? false : true" @click="sendReply()" class="send">发送</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {
  ReplyType,
  PreOrLast,
  Poster,
  ACTION_TYPES,
  CACHE_KEYS
} from "@/constants";
import { defaultPageSize } from "@/public/constant";
import {
  $getCustomerReplyByType,
  $sendCustomerReply,
  loadDiscussion,
  speakInDiscussion
} from "@/api/customer-reply/customer-reply-api";
import { loadUserInfo } from "@/api/common/common-api";
import Scroll from "@/components/scroll/index";
import Loading from "@/components/loading/index";
import { getHead, getHeadIDsByUserIDs } from "@/api/user/user-api";
import store from "@/store";
import * as types from "@/store/mutation-types";
import Tip from "@/components/tip";
function resize() {
  if (mui.os.ios) {
    plus.webview.currentWebview().setStyle({ bottom: "-1px" });
  }
}
export default {
  data() {
    return {
      probeType: 3,
      listenScroll: true,
      pulldown: true,
      loading: false,
      uidToHid: {},
      switch: true,
      chatList: [],
      icons2: [],
      count:0,
      // teachers: [],
      params: {
        discussionGroupID: this.$route.query.did,
        speakTime: null, //m2.date.addDays(m2.date.now() ,1),
        sort: PreOrLast.Pre,
        count: defaultPageSize
      },
      imgSrcOption: "",
      messages: [],
      firstFetch: true,
      maskShow: false,
      content: "",
      iosType: "normal",
      avatar: "",
      isMessage: true,
      currentAvatar: "",
      tAvatarList: []
    };
  },
  beforeRouteEnter(to, from, next) {
    document.body.style.background = "#fff";
    next();
  },
  beforeRouteLeave(to, from, next) {
    document.body.style.background = "#efeff4";
    next();
  },
  destroyed() {
    window.removeEventListener("resize", resize);
  },
  created() {
    this.checkInit();
    mui.plusReady(function() {
      plus.webview.currentWebview().setStyle({ softinputMode: "adjustResize" });
    });

    var curRelation =
      m2.cache.get("rx-current-child").relation ||
      $vue.$store.state.currentChild.relation;
    if (curRelation !== 1) {
      //this.isMessage = false;
      this.$route.meta.actionText = "";
    } else {
      //this.isMessage = true;
      this.$route.meta.actionText = ""; // '留言'
    }
    this.setPageTitle();
    this.getCustomerReply();
    this.enableEvent();
    this.init();
    this.getTAvatar();
    if (window.innerHeight < 500) {
      this.iosType = "4s";
    }
    window.addEventListener("resize", resize);
  },
  methods: {
    getJobName(type){
      if(type==2){
        return '学管师-'
      }else if(type==3){
        return '教师-'
      }else if(type==1){
        return '咨询师-'
      }else{
        return ''
      }
    },
    searchMore(){
      this.getData(m2.date.now())
    },
    getHeadById(user) {
      let iconID = this.uidToHid[user.userID];
      // debugger;
      if (iconID) {
        getHead({ iconID }, res => {
          // this.currentAvatar = res;
          // item.imgData = res;
          // m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, userIcons);
          console.log(res);
          return "~@/public/asset/img/user/teacher-man.png";
        });
      } else {
        return '"~@/public/asset/img/user/teacher-man.png"';
      }
    },
    fnTap(e) {
      if (!mui.os.ios) {
        if (e.target.tagName == "TEXTAREA" || e.target.tagName == "INPUT") {
          return;
        }
        if (
          document.activeElement.tagName == "TEXTAREA" ||
          document.activeElement.tagName == "INPUT"
        ) {
          document.activeElement.blur();
        }
      }
    },
    setPosition() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        // // 动态改变webview的侧滑返回功能：
        var wv = plus.webview.currentWebview();
        let bottom = this.iosType == "4s" ? "315px" : "415px";
        wv.setStyle({
          top: "0px"
        });
      }
    },
    setPosition2() {
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        var header = document.getElementsByTagName("header")[0];
        header.setAttribute("style", "position:fixed;top:" + 0 + "px;left:0");
        var wv = plus.webview.currentWebview();

        wv.setStyle({
          top: "0px"
        });
        wv.setStyle({
          bottom: "0px"
        });
      }
    },
    getTAvatar() {
      var userIcons = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
      var currentLogon = m2.cache.get(CACHE_KEYS.CURRENT_USER).userId;
      userIcons.forEach(item => {
        if (item.userID == currentLogon) {
          if (item.iconID && item.imgData) {
            this.currentAvatar = item.imgData;
          } else if (item.iconID) {
            getHead(
              {
                iconID: item.iconID
              },
              res => {
                this.currentAvatar = res;
                item.imgData = res;
                m2.cache.set(CACHE_KEYS.CURRENT_MODI_HEAD, userIcons);
              }
            );
          } else if (item.gender) {
            let img = item.gender == 2 ? "mother.png" : "father.png";
            this.currentAvatar = require(`@/public/asset/img/user/${img}`);
          } else {
            this.currentAvatar = require("@/public/asset/img/user/father.png");
          }
        }
      });
    },
    init() {
      var userIcons = this.$store.state.headList.slice() || [];
      var curIcon = userIcons.find(i => i.userID === this.replierID);
      var _this = this;
      if (curIcon) {
        this.imgSrcOption = curIcon.imgData;
      } else if (this.icons && this.icons.iconID) {
        getHead(
          {
            iconID: _this.icons.iconID
          },
          res => {
            let obj = {
              userID: this.replierID,
              imgData: res
            };
            this.imgSrcOption = res;
            userIcons.push(obj);
            store.commit(types.HEADLIST_ARR, userIcons);
          }
        );
      }
    },
    getCustomerReply() {
      this.getData();
    },
    setPageTitle() {
      this.$route.meta.title = this.pageTitle;
    },
    checkInit() {
      if (
        this.replyType == ReplyType.Consultant ||
        this.replyType == ReplyType.Educator
      ) {
        if (this.pageTitle.indexOf("-") < 0) {
          if (this.replyType == ReplyType.Consultant) {
            mui.confirm(
              "该学员目前没有咨询师，请联系校区在系统中分配咨询师。",
              "提示",
              ["确定"],
              e => {
                this.$router.push({ path: "/message/customer-interact" });
                // this.$router.back()
              }
            );
          }
          if (this.replyType == ReplyType.Educator) {
            mui.confirm(
              "该学员目前没有学管师，请联系校区在系统中分配学管师。",
              "提示",
              ["确定"],
              e => {
                // this.$router.back()
                this.$router.push({ path: "/message/customer-interact" });
              }
            );
          }
        }
      }
    },
    async getData(addDate) {
      await loadUserInfo();
      if (typeof addDate !== "undefined") {
        this.params.speakTime = addDate;
      }

      loadDiscussion(this.params, res => {
        console.log("--");
        console.log(res);
        console.log("-----------");
        // res = res.map((v,i)=>{
        //   debugger
        //   if(v.userId!=this.curUserId){
        //     v.poster = 1
        //   }else{
        //     v.poster = 2
        //   }
        //   return v
        // })
        // console.log(res)

        let newList = res;

        if (typeof addDate !== "undefined") {
          this.messages = newList;
          this.content = "";
        } else {
          this.messages = newList.concat(this.messages);
        }
        if (!res || !res.length || res.length < this.params.queryNumber) {
          this.hasMore = false;
        } else {
          this.hasMore = true;
          this.params.speakTime = res[0].speakTime;
        }
        // 获取所有老师的头像参数
        let tids = [];
        newList.map(item => {
          // debugger
          if (item.userType != "5") {
            // 判断是否已经请求过该头像了
            if (this.tAvatarList.length) {
              this.tAvatarList.map(one => {
                if (item.replierID !== one.userID) {
                  tids.push({
                    type: "1",
                    userID: item.userID
                  });
                }
              });
            } else {
              tids.push({
                type: "1",
                userID: item.userID
              });
            }
          }
        });
        if (tids.length) {
          let sendIDS = Array.from(new Set([...tids]));
          console.log(sendIDS);
          getHeadIDsByUserIDs(sendIDS, res => {
            this.tAvatarList = res;
            res.forEach((v, i) => {
              this.uidToHid[v.userID] = v.iconID;
            });

            console.log(this.uidToHid);
          });
        }
        if (this.firstFetch) {
          this._scrollToBottom();
          this.firstFetch = false;
        }
        this.loading = false;
      });
    },
    refreshMore() {
      this.loading = this.hasMore ? true : false;
      if (!this.hasMore) return;

      this.getData();
    },
    enableEvent() {
      xdapp.util.vue.commitActionStatus(true);
      xdapp.util.vue.on(ACTION_TYPES.GOTO_FEEDBACK, this._gotoReply);
    },
    _gotoReply() {
      this.maskShow = true;
    },
    maskDis() {
      this.maskShow = false;
    },
    sendReply() {
      // let content = this.content;
      let params = {
        replyObject: this.replyType,
        replyContent: this.content
      };
      if (this.replyType == ReplyType.Teacher) {
        params = {
          teacherID: this.replierID,
          ...params
        };
      }
      speakInDiscussion(
        {
          DiscussionGroupID: this.$route.query.did,
          content: this.content
        },
        res => {
          this.content = "";
          this.getData(m2.date.now());
          console.log("tt");
        }
      );
      // $sendCustomerReply(params, res => {
      //   this.firstFetch = true;
      //   this.maskShow = false;
      //   this.getData(null);
      // });
    },
    // _gotoReply(){
    //   this.$router.push({
    //     name: "leaveMsg",
    //     query: {replyType: this.replyType, title: this.pageTitle, staffId: this.replierID}
    //   });
    // },
    inpFocus() {
      var _this = this;
      setTimeout(() => {
        var rectObject = _this.msgText.getBoundingClientRect();
        var moveH = _this.initObj.top - rectObject.top;

        var screenH = document.body.scrollHeight;

        if (window.isMessageTopAdd && screenH !== 480) {
          moveH += 45;
          window.isMessageTopAdd = false;
        }
        var ua = navigator.userAgent.toLowerCase();
        if (/iphone|ipad|ipod/.test(ua)) {
          this.header = document.getElementsByTagName("header")[0];
          this.msgList = document.getElementsByClassName("msg-list")[0];

          this.header
            ? this.header.setAttribute(
                "style",
                "position:absolute;top:" + moveH + "px;left:0"
              )
            : "";
          this.msgList
            ? this.msgList.setAttribute(
                "style",
                "position:relative;top:" + moveH + "px;left:0"
              )
            : "";
        }
      }, 0);
      this.bfscrolltop = document.body.scrollTop;
      this.interval = setInterval(function() {
        document.body.scrollTop = document.body.scrollHeight;
      }, 100);
      this._scrollToBottom();
    },
    inpBlur() {
      clearInterval(this.interval); //清除计时器
      var ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        //苹果手机
        this.header
          ? this.header.setAttribute("style", "position:fixed;top:0;left:0")
          : "";
        this.msgList
          ? this.msgList.setAttribute("style", "position:relative;top:0;left:0")
          : "";
      }
      document.body.scrollTop = this.bfscrolltop;
    },
    _scrollToBottom() {
      this.$nextTick(() => {
        setTimeout(() => {
          let groupItems = this.$refs.groupItem || 0;
          let el = groupItems[groupItems.length - 1];
          this.$refs.listview.scrollToElement(el, 200);
        }, 20);
      });
    },
    getIconImg(userID) {
      
      // console.log(this.icons2)
      let icon = this.icons2.find(item => item.userID === userID);
      return icon ? icon.imgData : '';
    },
    getUserIcons() {
      
				this.messages.forEach(item => {
					if(!item.icons2 || !item.icons2.iconID)
						return;

					var userIcons = this.$store.state.headList.slice() || [];
					let curIcon = null;
					if(userIcons && userIcons.length) {
						curIcon = userIcons.find(i => i.userID === item.icons2.userID);
					}
					if(curIcon) {
						this.icons2.push({
							userID: curIcon.userID,
							imgData: curIcon.imgData,
						});
					} else {
            
						getHead({
							iconID: item.icons2.iconID
						}, res => {
							let obj = {
								userID: item.icons2.userID,
								imgData: res,
              };
              
				      // console.log(this.icons2)
							this.icons2.push(obj);
							userIcons.push(obj);
							store.commit(types.HEADLIST_ARR, userIcons);
						});
					}
				});
    },
  },
  /*mounted() {
			var msgInp = document.getElementsByClassName('msg-input')[0];
			if(msgInp) {
				this.msgText = msgInp;
				this.initObj = this.msgText.getBoundingClientRect();
			}

    },*/
  watch: {
    messages(val) {
      this.getUserIcons();
      this.chatList = [];
      if (val.length) {
        val.forEach((item, index) => {
          if (item.userID && item.userType !== 5) {
            if (item.userType == 4) {
              this.chatList.push({
                type: "3",
                userID: item.userID
              });
            } else if (item.userType !== 4) {
              this.chatList.push({
                type: "1",
                userID: item.userID
              });
            }
          }
        });
      }
    },
    chatList() {
      if (this.chatList.length) {
        // debugger
        getHeadIDsByUserIDs(this.chatList, res => {
          this.messages.forEach(item => {
            // debugger
            // console.log(this.messages)
            // console.log(res)
            // console.log(this.count++)
            res.forEach(sel => {
              if (item.userID == sel.userID) {
                
                this.$set(item, "icons2", sel);
                // this.$nextTick(() => {
                //   this.getUserIcons();
                // });
              }
            });
          });
          console.log('--msg-')
          console.log(this.messages)


        });
      }
    }
  },
  computed: {
    replyType() {
      return this.$route.query.replyType;
    },
    pageTitle() {
      return this.$route.query.title;
    },
    replierID() {
      return this.$route.query.staffId;
    },
    icons() {
      return this.$route.query.icons;
    },
    curUserId() {
      return m2.cache.get("rx-current-user").userId;
    }
  },
  components: {
    Scroll,
    Loading,
    Tip
  }
};
</script>

<style lang="scss" scoped>
.reply-name {
  position: absolute;
  transform: translate(45px);
  color: #aaa;
}
.mask {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.2);
  z-index: 99999;
  .mask-box {
    width: torem(300);
    margin: torem(200) auto torem(40) auto;
    .close {
      text-align: right;
      margin-bottom: -3px;
    }
    .iconfont {
      display: inline-block;
      color: #fff;
      font-size: torem(26);
      margin-right: -18px;
    }
  }
  // text-align: center;
  .msg-box {
    position: relative;
    width: 100%;
    // height: torem(200);
    background-color: #fff;
    border-radius: torem(15);
    padding: torem(15) torem(15) torem(10);
    position: relative;
    text-align: center;
    .msg-text {
      padding: torem(10);
      width: 100%;
      height: torem(200);
      border: none;
      border-radius: torem(15);
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-bottom: 5px;
    }
  }
  textarea::-webkit-input-placeholder {
    @include letterStyle(13, #cacfd9, 0, 16);
  }
  .send {
    width: 60%;
    margin: 0 auto;
    background: rgb(255, 130, 1);
    color: #fff;
    display: block;
    border-radius: 30px;
    border: none;
  }
}

.xdapp-msg-wrapper {
  position: fixed;
  width: 100%;
  height: 100%;
  background: #fff;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    .msg-list {
      background: #fff;
      padding-top: 20px;
      ul.list-group {
        li {
          padding-bottom: torem(15);
          &:last-child {
            padding-bottom: torem(100);
          }
        }
        .msg-time {
          text-align: center;
          display: block;
          margin-top: 14px;
          font-size: 12px;
          margin-left: 40%;
          width: 70px;
          color: #fff;
        }
        .msg-item {
          z-index: 1;
          position: relative;
          padding: 10px 18px 0;
          display: flex;
          img {
            width: 40px;
            height: 40px;
            margin-right: 11px;
            border-radius: 50%;
            transform: translate(0, 17px);
          }
          .reply {
            margin-left: 0;
            padding: 8px 15px;
            max-width: torem(222);
            font-size: 16px;
            color: #333;
            // border: 1px solid #eee;
            border-radius: 5px;
            background-color: #eee;
            transform: translate(0, 20px);
            .tit {
              font-size: 20px;
              color: #000;
              line-height: 28px;
            }
          }
          &:after {
            content: "";
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-right: 7px solid #eee;
            position: absolute;
            left: 56px;
            top: 40px;
            z-index: 10;
          }
          &:before {
            content: "";
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-right: 7px solid #eee;
            position: absolute;
            left: 58px;
            top: 40px;
            z-index: 20;
          }
        }
        .sysmsg {
          align-items: center;
          justify-content: center;
          transform: translate(0, -15px);
          .reply {
            max-width: 90vw !important;
          }
          &::before {
            border: none !important;
          }
          &::after {
            border: none !important;
          }
        }
        .msg-item-right {
          z-index: 1;
          position: relative;
          padding: 14px 18px 0;
          display: flex;
          justify-content: flex-end;
          img {
            width: 40px;
            height: 40px;
            margin-left: 11px;
            border-radius: 50%;
          }
          .reply {
            font-size: 15px;
            color: #333;
            padding: 8px 15px;
            margin-left: torem(57);
            background: #ffe3b6;
            border-radius: 5px;
            max-width: torem(222);
            .tit {
              font-size: 20px;
              color: #000;
              line-height: 28px;
            }
          }
          &:after {
            content: "";
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-left: 7px solid #ffe3b6;
            position: absolute;
            right: 56px;
            top: 27px;
            z-index: 10;
          }
          &:before {
            content: "";
            width: 0;
            height: 0;
            border: 7px solid transparent;
            border-left: 7px solid #ffe3b6;
            position: absolute;
            right: 58px;
            top: 27px;
            z-index: 20;
          }
        }
        @media only screen and (max-width: 320px) {
          .msg-item-right {
            display: box;
            /* OLD - Android 4.4- */
            display: -webkit-box;
            /* OLD - iOS 6-, Safari 3.1-6 */
            display: -moz-box;
            /* OLD - Firefox 19- (buggy but mostly works) */
            display: -ms-flexbox;
            /* TWEENER - IE 10 */
            display: -webkit-flex;
            /* NEW - Chrome */
            display: flex;
          }
        }
      }
    }
  }
}

.msg-input {
  position: absolute;
  width: 100%;
  height: 50px;
  min-height: 50px;
  border-top: solid 1px #bbb;
  left: 0px;
  bottom: 0px;
  overflow: hidden;
  padding: 0px 90px 0px 10px;
  background-color: #fafafa;
  .msg-left {
    height: 100%;
    padding: 5px 0px;
    [class*="input"] {
      width: 100%;
      height: 100%;
      border-radius: 5px;
    }
    .input-text {
      background: #fff;
      border: solid 1px #ddd;
      padding: 10px !important;
      font-size: 16px !important;
      line-height: 18px !important;
      font-family: verdana !important;
      overflow: hidden;
    }
  }
  .msg-right {
    position: absolute;
    width: 100px;
    height: 50px;
    right: 0px;
    bottom: 0px;
    text-align: center;
    vertical-align: middle;
    line-height: 100%;
    padding: 5px 0px;
    display: inline-block;
    .btn-send {
      width: 70px;
      height: 100%;
      border: none;
      text-align: center;
      line-height: torem(-0.04);
      font-size: torem(14);
    }
    .btn-on {
      background: skyblue;
      color: #fff;
    }
    .btn-off {
      background: #ccc;
    }
  }
}
</style>