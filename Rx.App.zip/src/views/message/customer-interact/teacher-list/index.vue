<template>
	<div class="wrap">
		<div class="rx-teacher-list">
			<div v-for="(item,index) in teachers" :key="index" class="item">
				<div class="img-wrap">
					<span v-if="item.icons">
						<img v-if="item.icons.iconID && getIconImg(item.icons.userID)" :src="getIconImg(item.icons.userID)">	
					  <img v-else-if='item.icons.gender==1' src="~@/public/asset/img/user/teacher-man.png" alt="" />
					  <img v-else-if='item.icons.gender==2' src="~@/public/asset/img/user/teacher-woman.png" alt="" />
					  <img v-else  src="~@/public/asset/img/user/teacher-man.png" alt="" />
					</span>
					<img v-else src="~@/public/asset/img/user/teacher-man.png" alt="" />
				</div>
				<div class="t-sub">{{item.subiects}}</div>
				<div class="t-name">{{item.teacherName}}</div>
				<div class="mui-input-row mui-radio input-wrap">
					<input type="radio" name="teacher" v-model="currentTeacher" :value="{teacherID:item.teacherID,teacherName:item.teacherName,icons:item.icons}">
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { ACTION_TYPES, ReplyType } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api';
	import { $getTeacherList } from '@/api/customer-reply/customer-reply-api';
	import { getHead, getHeadIDsByUserIDs } from "@/api/user/user-api";
	import store from '@/store';
	import * as types from '@/store/mutation-types';

	export default {
		data() {
			return {
				teachers: [],
				switch: true,
				parentIDs: [],
				icons: [],
				currentTeacher: {}
			}
		},
		created() {
			this.getTeacherList();
			xdapp.util.vue.on(ACTION_TYPES.SELECT_TEACHER, this.submit);
		},
		methods: {
			async getTeacherList() {
				await loadUserInfo();

				$getTeacherList(res => {
					this.teachers = res;
				});
			},
			submit() {
				this.$router.push({
					name: 'message-customer-reply',
					query: {
						teacherID: this.currentTeacher.teacherID,
						icons: this.currentTeacher.icons,
						staffId: this.currentTeacher.teacherID,
						replyType: ReplyType.Teacher,
						title: this.currentTeacher.teacherName
					}
				});
			},
			getIconImg(userID) {
				let icon = this.icons.find(item => item.userID === userID);
				return icon ? icon.imgData : '';
			},
			getUserIcons() {
				this.teachers.forEach(item => {
					if(!item.icons || !item.icons.iconID)
						return;

					var userIcons = this.$store.state.headList.slice() || [];
					let curIcon = null;
					if(userIcons && userIcons.length) {
						curIcon = userIcons.find(i => i.userID === item.icons.userID);
					}
					if(curIcon) {
						this.icons.push({
							userID: curIcon.userID,
							imgData: curIcon.imgData,
						});
					} else {
						getHead({
							iconID: item.icons.iconID
						}, res => {
							let obj = {
								userID: item.icons.userID,
								imgData: res,
							};
							this.icons.push(obj);
							userIcons.push(obj);
							store.commit(types.HEADLIST_ARR, userIcons);
						});
					}
				});
			},
		},
		watch: {
			currentTeacher: {
				handler: function(value) {
					xdapp.util.vue.commitActionStatus(!!value);
				},
				deep: true
			},
			teachers: {
				handler: function() {
					if(this.teachers.length && this.switch) {
						this.switch = false;
						this.teachers.forEach((item, index) => {
							if(item.teacherID) {
								this.parentIDs.push({
									type: '1',
									userID: item.teacherID
								});
							}

						})
					}
				},
				deep: true
			},
			parentIDs() {
				if(this.parentIDs.length) {
					getHeadIDsByUserIDs(this.parentIDs, res => {
						this.teachers.forEach(item => {
							res.forEach(sel => {
								if(item.teacherID == sel.userID) {
									this.$set(item, 'icons', sel);
									this.$nextTick(() => {
										this.getUserIcons();
									})
								}
							})

						})
					})
				}

			},
		},
	}
</script>

<style lang="scss">
	.rx-teacher-list {
		display: flex;
		width: 100%;
		flex-wrap: wrap;
		.item {
			width: 25%;
			text-align: center;
			img {
				width: torem(50);
				height: torem(50);
				border-radius: 50%;
				overflow: hidden;
				text-align: center;
				margin-top: torem(15);
			}
		}
		.t-sub {
			height: 20px;
			line-height: 20px;
			font-size: 14px;
			color: #999;
		}
		.t-name {
			line-height: 22px;
			font-size: 16px;
			color: #121212;
		}
		.input-wrap {
			padding-top: 12px;
			height: 40px;
			input[type=radio] {
				position: static;
				&:before {
					color: #ffa300;
				}
				&:checked:after {
					color: #ffa300 !important
				}
			}
		}
	}
</style>