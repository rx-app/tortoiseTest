<template>
	<div class="wrap">
		<div class="select-teacher">
			<router-link v-show="$store.state.currentChild.relation==1" tag="div" class="add" :to="{name:'message-teacher-list'}">
				<span>+</span>联系教师
			</router-link>
		</div>
		<div class="teacher-list-wrap">
			<teacher-reply :teacherReplyList="teacherReplyList" @todoDelChat="getTeacherReplyList()"></teacher-reply>
		</div>
	</div>
</template>
<script>
	import { ACTION_TYPES } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api';
	import { getHeadIDsByUserIDs } from '@/api/user/user-api';
	import { $getTeacherReplyList } from '@/api/customer-reply/customer-reply-api';
	import TeacherReply from '../partials/teacher-reply/index';

	export default {
		data() {
			return {
				teacherReplyList: [],
				parentIDs: [],
				switch: true
			};
		},
		created() {
			xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getTeacherReplyList);
			this.getTeacherReplyList();
			document.body.style.overflow='hidden';
			document.body.style.background='#fff';
		},
		destroyed() {
			document.body.style.background='#efeff4';		
		},
		methods: {
			async getTeacherReplyList() {
				await loadUserInfo();

				$getTeacherReplyList(res => {
					
					if(res&&res.length&&res[0].lastInfo){
						
						res.forEach(v=>{
							if(v.lastInfo){
								v.lastInfo.replyContent.includes('[###voice###]')&&(v.lastInfo.replyContent='[语音消息]')
								v.lastInfo.replyContent.includes('[###img###]')&&(v.lastInfo.replyContent='[图片]')
							}
						})
					}
					this.teacherReplyList = res;
				});
			}
		},
		watch: {
			teacherReplyList() {
				if(this.teacherReplyList.length && this.switch) {
					this.switch = false;
					this.teacherReplyList.forEach((item, index) => {
						if(item.lastInfo.replierID) {
							this.parentIDs.push({
								type: '1',
								userID: item.lastInfo.replierID
							});
						}

					})
				}
			},
			parentIDs() {
				if(this.parentIDs.length) {
					getHeadIDsByUserIDs(this.parentIDs, res => {
						this.teacherReplyList.forEach(item => {
							res.forEach(sel => {
								if(item.lastInfo.replierID == sel.userID) {
									this.$set(item, 'icons', sel);
								}
							})

						})
					})
				}

			}

		},
		components: {
			TeacherReply
		}
	}
</script>
<style lang="scss" scoped>
	.teacher-list-wrap{
		overflow: auto;
		height: 80vh;
		padding-bottom: 20vh;
	}
	.wrap {
		.select-teacher {
			padding: torem(12) torem(12) torem(10) torem(12);
			background-color: #fff;
			.add {
				font-size: 14px;
				color: #b1b9ca;
				height: 45px;
				line-height: 45px;
				text-align: center;
				span {
					font-size: 16px;
					font-weight: 600;
				}
			}
		}
	}
</style>