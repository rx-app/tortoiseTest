async getData(addDate) {
    await loadUserInfo();
    if (typeof addDate !== "undefined") {
      this.params.replyTime = addDate;
    }
    if (this.replyType == ReplyType.Teacher) {
      this.params = {
        replierID: this.replierID,
        ...this.params
      };
    }

    $getCustomerReplyByType(this.params, res => {
      let newList = res;
      console.log('res---',res)
      if (typeof addDate !== "undefined") {
        this.messages = newList;
        this.content = "";
      } else {
        this.messages = newList.concat(this.messages);
      }
      this.messages.forEach((v,i)=>{
        if(v.replyContent.includes('[###img###]')){
          console.log(JSON.parse( v.replyContent.replace('[###img###]','') ).name)
        }
        if(v.replyContent.includes('[###img###]')){
          this.$nextTick( a=>{
            this.showImages(v) 
          } )
          
        }
      })
      this.$nextTick(() => {
        
        console.log(this.messages.length)
        let len = this.messages.length % 20;
        
        this.mescroll.endSuccess(30)// 结束下拉刷新,无参
        // if(len<=this.messages.length){
        //   return
        // }
        if(!this.hasMore){
          document.getElementsByClassName('list-group-item')[0].scrollIntoView();
        }else{
          if(len){
            document.getElementsByClassName('list-group-item')[len-1].scrollIntoView();
          }else{
            document.getElementsByClassName('list-group-item')[19].scrollIntoView();
          }
        }

        
      })
      
      if (!res || !res.length || res.length < this.params.queryNumber) {
        this.hasMore = false;
      } else {
        this.hasMore = true;
        this.params.replyTime = res[0].createTime;
      }
      // 获取所有老师的头像参数
      let tids = [];
      newList.map(item => {
        if (item.poster === "1") {
          // 判断是否已经请求过该头像了
          if (this.tAvatarList.length) {
            this.tAvatarList.map(one => {
              if (item.replierID !== one.userID) {
                tids.push({
                  type: "1",
                  userID: item.replierID
                });
              }
            });
          } else {
            tids.push({
              type: "1",
              userID: item.replierID
            });
          }
        }
      });
      if (tids.length) {
        let sendIDS = Array.from(new Set([...tids]));
        console.log(sendIDS);
        getHeadIDsByUserIDs(sendIDS, res => {
          this.tAvatarList = res;
        });
      }
      if (this.firstFetch) {
        this._scrollToBottom();
        this.firstFetch = false;
      }
      this.loading = false;
      this.sendingImage=false;
    });
  },