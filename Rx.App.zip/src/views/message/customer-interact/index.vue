<template>
	<div class="wrap">
		<reply-list :customerReply="customerReply" :disList="disList" @dellist="delDisList" ></reply-list>
	</div>
</template>

<script>
	import { ACTION_TYPES } from '@/constants';
	import { loadUserInfo } from '@/api/common/common-api';
	import { $getCustomerReply, customerReplyPageItem ,loadDiscussionLastCollection ,deleteDiscussion} from '@/api/customer-reply/customer-reply-api';
	import { getHeadIDsByUserIDs } from '@/api/user/user-api';
	import ReplyList from './partials/reply-list/index';

	export default {
		data() {
			return {
				customerReply: {},
				disList:[],
				parentIDs: [],
				switch: true

			};
		},
		created() {
			this.getCustomerReply();
			this.switchChild();
		},
		methods: {
			async getCustomerReply() {
				await loadUserInfo();
				$getCustomerReply(res => {
					
					if(res.educator && res.educator.lastInfo){
						res.educator.lastInfo.replyContent.includes('[###voice###]')&&(res.educator.lastInfo.replyContent='[语音消息]')
						res.educator.lastInfo.replyContent.includes('[###img###]')&&(res.educator.lastInfo.replyContent='[图片]')
					}
					if(res.consultant && res.consultant.lastInfo){
						res.consultant.lastInfo.replyContent.includes('[###voice###]')&&(res.consultant.lastInfo.replyContent='[语音消息]')
						res.consultant.lastInfo.replyContent.includes('[###img###]')&&(res.consultant.lastInfo.replyContent='[图片]')
					}
					if(res.teacher && res.teacher.lastInfo){
						res.teacher.lastInfo.replyContent.includes('[###voice###]')&&(res.teacher.lastInfo.replyContent='[语音消息]')
						res.teacher.lastInfo.replyContent.includes('[###img###]')&&(res.teacher.lastInfo.replyContent='[图片]')
					}
					if(res.educatorWeek && res.educatorWeek.lastInfo){
						res.educatorWeek.lastInfo.replyContent.includes('[###voice###]')&&(res.educatorWeek.lastInfo.replyContent='[语音消息]')
						res.educatorWeek.lastInfo.replyContent.includes('[###img###]')&&(res.educatorWeek.lastInfo.replyContent='[图片]')
					}
					this.customerReply = res;
					this.switch=true;
					this.parentIDs=[];
				});
				loadDiscussionLastCollection(res=>{
					if(res&&res.length&&res[0].lastInfo){
						res[0].lastInfo.content.includes('[###voice###]')&&(res[0].lastInfo.content='[语音消息]')
						res[0].lastInfo.content.includes('[###img###]')&&(res[0].lastInfo.content='[图片]')
					}
					this.disList= res;
					console.log(res)
				})
			},
			delDisList(){
				// this.disList=[];  
				this.getCustomerReply();
			},
			
			switchChild() {
				xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getCustomerReply);
			},
			
		},
		watch: {
			customerReply: {
				handler: function() {
					// console.log(1);
					console.log(this.customerReply);
					if(this.customerReply && this.switch) {
						this.switch = false;
						for(var item in this.customerReply) {
							var obj = this.customerReply[item];
							if(obj && obj.staffID) {
								var curParent = {
									type: '1',
									userID: obj.staffID
								};
								if(JSON.stringify(this.parentIDs).indexOf(JSON.stringify(curParent)) == -1) {
									this.parentIDs.push(curParent);
								}
							}
						}
					}
				},
				deep:true
			},
			parentIDs() {
				if(this.parentIDs.length) {
					getHeadIDsByUserIDs(this.parentIDs, res => {
						for(var item in this.customerReply) {
							var obj = this.customerReply[item];
							res.forEach(sel => {
								if(obj.staffID == sel.userID) {
									this.$set(obj, 'icons', sel);
								}
							})

						}
					})
				}
			},
		},
		components: {
			ReplyList
		}
	};
</script>