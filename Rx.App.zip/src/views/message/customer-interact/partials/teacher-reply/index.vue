<template>
	<ul class="mui-table-view rx-message-reply">
		<li v-for="(item,index) in teacherReplyList" class="mui-table-view-cell mui-transitioning">
			<div class="mui-slider-right mui-disabled">
				<a class="mui-btn mui-btn-red" @click="todoDelete($event, item)">删除</a>
			</div>
			<div class="mui-slider-handle" v-if="item.lastInfo" :ref="item.lastInfo.replierID">
				<router-link :to="todoLink(item)">
					<span v-if="item.icons">
						<img class="mui-media-object mui-pull-left" v-if="item.icons.iconID && getIconImg(item.icons.userID)" :src="getIconImg(item.icons.userID)">	
					    <img class="mui-media-object mui-pull-left" v-else-if='item.icons.gender==2' src="~@/public/asset/img/user/teacher-woman.png" alt="" />
					    <img class="mui-media-object mui-pull-left" v-else-if='item.icons.gender==1 || item.icons.gender==0 ' src="~@/public/asset/img/user/teacher-man.png" alt="" />
					</span>
					<div class="pointer" v-if="item.unReadCount"></div>
					<div class="mui-media-body">
						<p class="tit">
							<span class="tit-name">{{item.subjects}}-{{item.lastInfo.replierName}}</span>
							<span class="tit-time" v-if="item.lastInfo">{{item.lastInfo.createTime | dateTimeFormat}}</span>
						</p>
						<p class="mui-ellipsis txt">
							<span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span>
							<span v-if="item.lastInfo">{{item.lastInfo.replyContent}}</span>
						</p>
					</div>
				</router-link>
			</div>
		</li>
	</ul>
</template>
<script>
	import { ReplyType } from '@/constants';
	import { $deleteTeacherCustomerReply } from '@/api/customer-reply/customer-reply-api';
	import { getHead, getHeadIDsByUserIDs } from "@/api/user/user-api";
	import store from '@/store';
	import * as types from '@/store/mutation-types';
	export default {
		data(){
			return{
				icons:[]
			}
		},
		props: ['teacherReplyList'],
		methods: {
			todoDelete(event, item) {
				let bts = ['确认', '取消'];
				mui.confirm(`确认删除${item.lastInfo.replierName}的聊天记录吗？`, '提示', bts, (e) => {

					event.target.style.transform = 'translate(0px, 0px)';
					this.$refs[item.lastInfo.replierID][0].style.transform = 'translate(0px, 0px)';

					if(e.index == 0) {
						$deleteTeacherCustomerReply(item.lastInfo.replierID, (res) => {
							this.$emit('todoDelChat');
						});
					}
				});
			},
			getIconImg(userID) {
				let icon = this.icons.find(item => item.userID === userID);
				return icon ? icon.imgData : '';
			},
			getUserIcons() {
				this.teacherReplyList.forEach(item => {
					if(!item.icons || !item.icons.iconID)
						return;

					var userIcons = this.$store.state.headList.slice() || [];
					console.log(userIcons)
					let curIcon = null;
					if(userIcons && userIcons.length) {
						curIcon = userIcons.find(i => i.userID === item.icons.userID);
					}
					if(curIcon) {
						this.icons.push({
							userID: curIcon.userID,
							imgData: curIcon.imgData,
						});
					} else {
						getHead({
							iconID: item.icons.iconID
						}, res => {
							let obj = {
								userID: item.icons.userID,
								imgData: res,
							};
							this.icons.push(obj);
							userIcons.push(obj);
							store.commit(types.HEADLIST_ARR, userIcons);
						});
					}
				});
			},
			todoLink(item) {
				return {
					name: 'message-customer-reply',
					query: {
						staffId: item.lastInfo.replierID,
						replyType: ReplyType.Teacher,
						icons: item.icons,
						title: item.lastInfo.replierName
					}
				};
			},
		},
		watch: {
			teacherReplyList: {
				handler: function() {
					this.getUserIcons();
				},
				deep:true
			}
		},

	}
</script>
<style lang="scss" scoped>
	.mui-table-view-cell:after {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 15px;
		height: 2px;
		content: '';
		transform: scaleY(.5);
		background-color: #c8c7cc;
	}
	@media (-webkit-min-device-pixel-ratio: 3),(min-device-pixel-ratio: 3){
		.mui-table-view-cell:after {
			transform: scaleY(0.33)
		}
	}
            
	.trans {
		transform: translate(0px, 0px);

	}
	
	.rx-message-reply {
		padding: 0 12px;
		.mui-table-view-cell {
			padding: 12px 0;
			&::after {
				left: 0px
			}
		}
		.mui-btn-red {
			height: 100%;
			width: torem(100);
		}
		li {
			.pointer {
				position: absolute;
				width: torem(10);
				height: torem(10);
				border-radius: 50%;
				background: #fb150a;
				margin-left: torem(40);
				margin-top: torem(6);
			}
			a {
				img {
					width: torem(50);
					height: torem(50);
					max-width: 1000px;
					border-radius: 100%;
					/*border-radius: 5px;*/
				}
				.tit {
					display: flex;
					justify-content: space-between;
					.tit-name {
						font-size: torem(16);
						color: #121212;
						line-height: torem(22);
					}
					.tit-time {
						font-size: torem(12);
						color: #8e8e8e;
						line-height: torem(17);
					}
				}
				.txt {
					color: #999;
					font-size: torem(14);
					margin-top: torem(8);
				}
				.num {
					color: #e03229;
				}
			}
		}
	}
</style>