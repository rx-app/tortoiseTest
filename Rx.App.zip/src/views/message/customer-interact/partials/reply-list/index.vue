﻿<template>
  <div>
    <ul class="mui-table-view rx-message-reply" v-if="!customerReply">
      <li class="mui-table-view-cell mui-transitioning" v-for="(item,index) in selList" :key="index">
        <div class="mui-slider-handle">
          <a>
            <span class="img_left">
              <img
                class="mui-media-object mui-pull-left"
                src="~@/public/asset/img/user/teacher-woman.png"
                alt
              />
            </span>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{item}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <span>加载中，加载完毕可点击进入与其沟通~</span>
              </p>
            </div>
          </a>
        </div>
      </li>
    </ul>
    <ul class="mui-table-view rx-message-reply" v-if="customerReply">
      <li
        v-for="(item,key) in customerReply"
        class="mui-table-view-cell mui-transitioning"
        :key="key"
      >
        <div class="mui-slider-right mui-disabled">
          <a class="mui-btn mui-btn-red" @click="todoDelete($event, item, key)">删除</a>
        </div>
        <div class="mui-slider-handle" :ref="key">
          <router-link :to="todoLink(item)">
            <span class="img_left">
              <img
                class="mui-media-object mui-pull-left"
                v-if="item.icons && item.icons.iconID && getIconImg(item.icons.userID)"
                :src="getIconImg(item.icons.userID)"
              />
              <img
                class="mui-media-object mui-pull-left"
                v-else-if="item.icons && item.icons.gender==1"
                src="~@/public/asset/img/user/teacher-man.png"
                alt
              />
              <img
                class="mui-media-object mui-pull-left"
                v-else
                src="~@/public/asset/img/user/teacher-woman.png"
                alt
              />
            </span>
            <div class="pointer" v-if="item.unReadCount"></div>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{item.title.replace('归属','')}}</span>
                <span
                  class="tit-time"
                  v-if="item.lastInfo"
                >{{item.lastInfo.createTime | dateTimeFormat}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <span
                  v-if="item.unReadCount && item.title!='归属教师'"
                  class="num"
                >[{{item.unReadCount}}条]</span>
                <span v-if="item.lastInfo">{{item.lastInfo.replyContent}}</span>
              </p>
            </div>
          </router-link>
        </div>
      </li>
      <li v-for="(item,key) in disList" class="mui-table-view-cell mui-transitioning" :key="key">
        <div class="mui-slider-right mui-disabled">
          <a @click="todoDelete()" class="mui-btn mui-btn-red">删除</a>
        </div>
        <div class="mui-slider-handle">
          <router-link
            :to="{name:'msgDis',query:{title:item.title,did:item.lastInfo.discussionGroupID}}"
          >
            <span class="img_left">
              <img class="mui-media-object mui-pull-left" :src="getIconImg2()" alt />
            </span>
            <div class="pointer" v-if="item.unReadCount"></div>
            <div class="mui-media-body">
              <p class="tit">
                <span class="tit-name">{{item.title}}</span>
                <span class="tit-time">{{item.lastInfo.speakTime | dateTimeFormat}}</span>
              </p>
              <p class="mui-ellipsis txt">
                <span v-if="item.unReadCount" class="num">[{{item.unReadCount}}条]</span>
                <span>{{item.lastInfo.content}}</span>
              </p>
            </div>
          </router-link>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import { getHeadIDsByUserIDs, getHead } from "@/api/user/user-api";
import { CACHE_KEYS } from "@/constants";
import store from "@/store";
import * as types from "@/store/mutation-types";
import "@/public/asset/js/jquery/jquery-1.8.0";
import { ReplyType } from "@/constants";
import {
  $deleteCustomerReply,
  deleteDiscussion
} from "@/api/customer-reply/customer-reply-api";
import { setTimeout } from "timers";

export default {
  props: ["customerReply", "disList"],
  data() {
    return {
      icons: [],
	  teacherArr: [],
	  selList:["咨询师","学管师","教师","学管师周反馈"],
      childImgData: ""
    };
  },
  mounted() {},
  methods: {
    getIconImg3() {},
    getIconImg2() {
      let userID = this.$store.getters.currentChild.id;
      let icons2 = null;
      if (window.xdapp.icons) {
        icons2 = window.xdapp.icons;
      } else {
        icons2 = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD);
      }
      // let icons2 = m2.cache.get(CACHE_KEYS.CURRENT_MODI_HEAD)
      let icon = icons2.find(item => item.userID === userID);
      if (icon && icon.imgData) {
        this.childImgData = icon.imgData;
      } else if (icon && icon.gender) {
        let img = icon.gender == 1 ? "boy.png" : "girl.png";
        this.childImgData = require(`@/public/asset/img/user/${img}`);
      } else {
        this.childImgData = "";
      }
      return this.childImgData;
    },
    todoDelete(event, item, key) {
      let bts = ["确认", "取消"];
      mui.confirm(`删除后内容不会再显示，是否删除？`, "提示", bts, e => {
        if (e.index == 0) {
          deleteDiscussion(res => {
            this.$emit("dellist");
          });
        }

        // event.target.style.transform = 'translate(0px, 0px)';
        // this.$refs[key][0].style.transform = 'translate(0px, 0px)';

        // if(e.index == 0) {
        // 	$deleteCustomerReply(item.replyObject, (res) => {
        // 		this.$emit('todoDelChat');
        // 	});
        // }
      });
    },
    todoLink(item) {
      if (item.replyObject == ReplyType.Teacher)
        return {
          name: "message-teacher-chats"
        };
      else
        return {
          name: "message-customer-reply",
          query: {
            replyType: item.replyObject,
            teacherID: item.staffID,
            icons: item.icons,
            // title: item.title.replace('归属', '') + (item.lastInfo ? '-' + item.lastInfo.replierName : '')
            title:
              item.title.replace("归属", "") +
              (item.staffName ? "-" + item.staffName : "")
            // title: item.title.replace('归属', '') + (item.staffID ? '-' + item.staffID : '')
          }
        };
    },
    getIconImg(userID) {
      let icon = this.icons.find(item => item.userID === userID);
      return icon ? icon.imgData : "";
    },

    getUserIcons() {
      console.log(this.customerReply);
      for (var item in this.customerReply) {
        var obj = this.customerReply[item];
        if (
          JSON.stringify(this.teacherArr).indexOf(JSON.stringify(obj)) == -1
        ) {
          this.teacherArr.push(obj);
        }
      }
      if (this.teacherArr.length) {
        this.teacherArr.forEach(item => {
          if (!item.icons || !item.icons.iconID) return;
          var userIcons = this.$store.state.headList.slice() || [];
          let curIcon = null;
          if (userIcons && userIcons.length) {
            curIcon = userIcons.find(i => i.userID === item.icons.userID);
          }
          if (curIcon) {
            this.icons.push({
              userID: curIcon.userID,
              imgData: curIcon.imgData
            });
          } else {
            getHead(
              {
                iconID: item.icons.iconID
              },
              res => {
                let obj = {
                  userID: item.icons.userID,
                  imgData: res
                };
                this.icons.push(obj);
                userIcons.push(obj);
                store.commit(types.HEADLIST_ARR, userIcons);
              }
            );
          }
        });
      }
    }
  },
  watch: {
    customerReply: {
      handler: function(o, n) {
        this.getUserIcons();
        this.teacherArr = [];
      },
      deep: true
    }
  }
};
</script>
<style lang="scss" scoped>
.trans {
  transform: translate(0px, 0px);
}

.rx-message-reply {
  &:after {
    height: 0px !important;
  }
  .mui-table-view-cell:last-child:after,
  .mui-table-view-cell:last-child:before {
    height: 1px;
  }
  padding: 0 torem(12);
  height: calc(100vh - 65px);
  overflow: scroll;
  .mui-table-view-cell {
    padding: 11px 0;
    &::after {
      left: 0px;
    }
  }
  .mui-btn-red {
    height: 100%;
    width: torem(100);
  }
  li {
    .pointer {
      position: absolute;
      width: torem(10);
      height: torem(10);
      border-radius: 50%;
      background: #fb150a;
      margin-left: torem(40);
      margin-top: torem(6);
    }
    a {
      .img_left {
        /*display: inline-block;*/
        width: torem(50);
        height: torem(50);
        img {
          width: torem(50);
          height: torem(50);
          max-width: 1000px;
          border-radius: 100%;
        }
      }
      .tit {
        display: flex;
        justify-content: space-between;
        .tit-name {
          font-size: torem(16);
          height: torem(22);
          overflow: hidden;
          color: #121212;
          line-height: torem(22);
          max-width: torem(170);
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .tit-time {
          font-size: torem(12);
          color: #8e8e8e;
          line-height: torem(17);
        }
      }
      .txt {
        color: #999;
        font-size: torem(14);
        margin-top: torem(8);
      }
      .num {
        color: #e03229;
      }
    }
  }
}
</style>