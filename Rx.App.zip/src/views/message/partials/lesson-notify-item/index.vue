﻿<template>
  <scroll
    :data="items"
    :listen-scroll="listenScroll"
    :probe-type="probeType"
    :pulldown="pulldown"
    @scroll="scroll"
    @scrollToStart1="refreshMore"
    @scrollToEnd="refreshMore"
    class="scroll-container"
    ref="listview">
    <div class="list-group xdsef-feser">
      <ul class="msg-list">
        <li class="list-group-item" v-for="(item,index) in items" ref="groupItem">
          <div class="msg-time msg-title-base">
            <span>{{item.createTime | dateTimeFormat}}</span>
          </div>
          <div class="msg-wrapper">
            <div class="msg-title">
              <img v-if="item.msgCatalog==1" src="~@/public/asset/img/msg/04@3x.png" class="img">
              <img v-if="item.msgCatalog==99" src="~@/public/asset/img/msg/03@3x.png" class="img">
              <span class="msg-title-name">{{item.msgCatalogValue}}</span>
            </div>
            <div class="msg-content">
              <div class="msg-title-left category-wrapper">
                <span class="cg-title msg-title-base">消息类型</span>
                <span class="cg">{{item.msgCategoryValue}}</span>
              </div>
              <div class="msg-title-left title-wrapper" v-if="item.title">
                <span class="tt-title msg-title-base">消息标题</span>
                <span class="tt">{{item.title}}</span>
              </div>
              <div class="content-wrapper">
                <span class="ct-title msg-title-base">消息内容</span>
                <span class="ct rx-html-my" v-html="editContent(item.content)"></span>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </scroll>
</template>

<script>
  import Scroll from '@/components/scroll/index';
  import Loading from '@/components/loading/index';
   import "@/public/asset/js/jquery/jquery-1.8.0";

  export default {
    props: {
      items: {
        type: Array,
        default: null
      }
    },
    created(){
      this.probeType = 3;
      this.listenScroll = true;
      this.pulldown = true;
    },
    mounted(){
      $('.xdsef-feser').on('click','a',(e)=>{
        // plus.runtime.openURL(e.target.);
        // plus.runtime.openURL(e.target.attributes.href.nodeValue)
        if(e.currentTarget.href.includes('.xueda.com/')&&e.currentTarget.href.includes('/profile/settings/edition')){
          $vue.$router.push({name: 'profile-settings-about-list'})
        }else{
          plus.runtime.openURL(e.currentTarget.href)
        }
        // console.log(e.currentTarget.href)
        // console.log(e.target.attributes.href.nodeValue)
        return false
        
      })
      // $('.list-group').on('click',()=>{
      //   alert(0)
      //   return false
      // })
      // this.$nextTick(() => {
      //   let groupItems = this.$refs.groupItem;
      //   let el = groupItems[groupItems.length - 1];

      //   setTimeout(() => {
      //     this.$refs.listview.scrollToElement(el);
      //   }, 20);
      // });
    },
    methods: {
      editContent(content){
				if((/<img/).test(content.substr(0,7))){
					return '<br />'+content
				}else{
					return content
				}
			},
      searchMore(){
        console.log('searchMore');
      },
      refreshMore(){
        this.$emit('refreshMore');
      },
      scroll(pos) {
        this.scrollY = pos.y
      }
    },
    components: {
      Scroll,
      Loading
    }
  }
</script>
<style>
.rx-html-my h2{
  font-size: 14px;
}
.rx-html-my a{
				word-wrap:break-word!important;
			}
</style>


<style lang="scss" scoped>
.rx-html-my{
				word-wrap:break-word!important;
			width: 6rem;
}
  $fontColor: #999;
  .scroll-container {
    height: 100%;
    overflow: hidden;
    .msg-title-base {
      color: $fontColor;
      flex: 0 0 torem(70);
    }
    .msg-title-left {
      display: flex;
      height: torem(30);
      line-height: torem(30);
    }
    .msg-list {
      .list-group-item {
        padding-bottom: torem(10);
        .msg-time {
          margin-top: torem(10);
          margin-bottom: torem(5);
          text-align: center;
          color: $fontColor;
        }
        .msg-wrapper {
          margin: 0 torem(20);
          background-color: #fff;
          border-radius: torem(5);
          .msg-title {
            display: flex;
            align-items: center;
            padding: torem(10);
            border-bottom: torem(1) inset;
            .msg-title-name{font-size: 14px}
            .img {
              width: torem(30);
              height: torem(30);
              margin-right: torem(5);
              border-radius: torem(30);
            }
          }
          .msg-content {
            padding: torem(10);
            font-size: 14px;
            .category-wrapper {
              .cg-title {
              }
            }
            .title-wrapper {
            }
            .content-wrapper {
              display: flex;
              .ct-title {
              }
            }
          }
        }
        &:last-child {
          padding-bottom: torem(30);
        }
      }
    }
  }
</style>
