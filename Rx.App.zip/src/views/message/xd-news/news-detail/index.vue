<template>
  <div class="mui-content xdapp-news-detail">
    <div class="mui-content-padded" style="margin:0 10px;height:80vh;overflow:scroll">
      <div class="news-content title"><h4>{{news.title}}</h4></div>
      <div class="news-content time">{{news.createTime | dateTimeFormat}}
        <span><span class="newSourse" v-if="news.originalLink">转载</span><span class="newSourse" v-else>原创</span>{{news.newSource}}</span>
        <!-- <a v-if="news.originalLink" @tap="goURL(news.originalLink)">查看原文</a> -->
      </div>
      <div  id="nn-con-box" v-html="news.content"></div>
    </div>
  </div>
</template>
<script>
  import {loadUserInfo} from '@/api/common/common-api';
  import {$getNews} from '@/api/news/news-api';

  export default {
    data(){
      return {
        news: {}
      }
    },
    mounted () {
      let windowHeight = window.innerHeight;
      let content = document.querySelector('.mui-content-padded');
      content.style.minHeight = 'calc(' + windowHeight + 'px - 65px)'

      let atag = document.querySelectorAll('#nn-con-box a')
      for(let i=0;i<atag.length;i++){
        atag[i].onclick= function(){
          ad_foucs(this.href)
          return false
        }
      }
      function ad_foucs(url){
        let reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
        if(reg.test(url)) {
          plus.runtime.openURL(url);
          return false
        } else {
          mui.toast('链接地址不正确')
        }
      }
    },
    created(){
      this.getNews();
      document.querySelector('.xd-header').style.position='fixed'
    },
    destroyed() {
			document.querySelector('.xd-header').style.position='absolute'			
		},
    updated(){
      [...document.getElementsByTagName('img')].forEach(img => {
        img.style.width = '90%';
        img.style.height = '90%';
      });
    },
    methods: {
      goURL(url) {
        let reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
        if(reg.test(url)) {
          plus.runtime.openURL(url);
          return false
        } else {
          mui.toast('原文地址不正确')
        }
      },
      async getNews(){
        await loadUserInfo();

        $getNews({newsID: this.newsId}, res => {
          console.log(JSON.stringify(res, null, 2))
          this.news = res;
        });
      }
    },
    computed: {
      newsId(){
        return this.$route.query.newsId;
      }
    }
  }
</script>
<style>

</style>

<style lang="scss" scoped>
  .xdapp-news-detail {
    background-color: #fff;
    font-size: 14px;
    color: #8f8f94;
    overflow: scroll;
    height: 100vh;
    #nn-con-box{
      padding-bottom: 40px;
    }
    .news-content {
      text-align: center;
      color: #333;
      
    }
    .title {
      padding: 10px 0;
    }
    .time {
      padding-bottom: 10px;
    }
    .newSourse{
    	margin: 0 torem(6);
    }
    /*img {*/
    /*width: 100px!important;*/
    /*}*/
  }
</style>
