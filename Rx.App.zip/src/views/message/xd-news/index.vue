﻿<template>
	<div class="mui-content xdapp-news" id="stu-main-content">
		<mt-loadmore class="loadMore" :auto-fill="false" :bottom-all-loaded="allLoaded" :bottom-method="loadBottom" :bottom-distance=-70 ref="loadmore">
			<div class="mui-table-view mm-box11" v-if="newsList.length">
				<ul v-for="(itemList,itemIndex) in newsList">
					<li class="time"><span> {{itemList[0].modifyTime | dateFormat}} </span></li>
					<li :style="setStyle(index, itemList.length)" v-if="newsList.length>0" v-for="(item,index) in itemList" :class="index === 0?'firstBox':'imgBox'" class="mui-table-view-cell mui-media" @tap="goDetail(item)">
						<p class='text' :class="index === 0?'firstText':''">
							<span>{{subStringStr(item.title)}} </span>
						</p>
						<p class='img' :class="index === 0?'firstImg':''"><img :src="item.subtitleIMGID" alt="" /></p>

					</li>

				</ul>
			</div>
		</mt-loadmore>
		<tip v-if="isShow">
			<span>暂无资讯内容</span>
		</tip>
	</div>
</template>
<script>
	import { ACTION_TYPES } from '@/constants';
	import { pager } from '@/public/constant';
	import { loadUserInfo } from '@/api/common/common-api';
	import { $getNewsList, $getNewsByDay } from '@/api/news/news-api';
	import Tip from '@/components/tip'

	export default {
		data() {
			return {
				pageIndex: 1,
				pageSize: 10,
				newsList: [],
				isShow: false,
				date: null,
				allLoaded: false,
				loading:false,
			};
		},
		mounted() {
			this.setHeight();
		},
		created() {
			let today=m2.date.now();
			this.date=new Date( today.getFullYear()+'/'+(today.getMonth()+1)+'/'+ (today.getDate()+1) )
			this.getNewsList();
			this.switchJob();
		},
		methods: {
			translateDate(date){
				return new Date( date.getFullYear()+'/'+(date.getMonth()+1)+'/'+ (date.getDate()) )
			},
			setStyle(index, length) {
				let v = 3
				if(index === 0 && length === 1) {
					return 'border-bottom: none;border-radius: ' + v + 'px'
				} else if(length > 1 && index === 0) {
					return 'border-bottom: none;border-top-left-radius: ' + v + 'px;border-top-right-radius: ' + v + 'px'
				}
				if(index === length - 1) {
					return 'border-bottom: none;border-bottom-left-radius: ' + v + 'px;border-bottom-right-radius: ' + v + 'px'
				}
				// if (index > 0 && index < length - 1) {
				// 	return 'border-bottom: 1px solid rgb(229,229,229)'
				// }
			},
			loadBottom() {
				event.preventdefault;
				event.stopPropagation();
				this.$refs.loadmore.onBottomLoaded();
				this.pageIndex++;
				this.getNewsList();
			},
			subStringStr(str) {
				// let w = window.screen.width
				// let s = str
				// if(w > 375 && str.length > 24) {
				// 	s = str.substring(0, 24) + '...'
				// } else if(w <= 375 && str.length > 16) {
				// 	s = str.substring(0, 16) + '...'
				// }
				return str
			},
			goDetail(news) {
				this.$router.push({
					name: 'message-news-detail',
					query: {
						newsId: news.newsID
					}
				})
			},
			async getNewsList() {
				if(this.loading){
					return
				}
				this.loading=true;
				await loadUserInfo();
				// console.log(this.translateDate( this.date ))
				let params = {
					date: this.translateDate( this.date )
				};
				console.log(params)
				$getNewsByDay(params, res => {
					
					// console.log(res)
					// console.log(new Date(res.result[0].modifyTime).getDate())
					var firstDay = new Date(res.result[0].modifyTime).getDate();
					var indexList = [0];
					var timeList = [res.result[0].modifyTime]
					var result = res.result;
					if(result.length == 0) {
						this.isShow = true;
						return
					} else {
						this.isShow = false;
					}
					var lastDay = result[result.length - 1].modifyTime;
					this.loading=false;
					// console.log('----------------------')
					// console.log(lastDay)
					// console.log(this.translateDate(lastDay))
					// console.log('----------------------')
					this.date = lastDay;
					result.forEach((v, i) => {

						if(new Date(v.modifyTime).getDate() != firstDay) {
							firstDay = new Date(v.modifyTime).getDate();
							indexList.push(i)
							timeList.push(v.modifyTime)
						}
					});

					let list = null;
					if(indexList.length==3){
					 list=	[result.slice(0, indexList[1]), result.slice(indexList[1], indexList[2]), result.slice(indexList[2])];
					}else if(indexList.length==2){
					 list=	[result.slice(0, indexList[1]), result.slice(indexList[1], indexList[2])];
					}else{
						list=[result.slice(0,indexList[1])]
					}
					// console.log(indexList)
					// console.log(list)
					this.newsList = this.newsList.concat(list);
					
					if(new Date(lastDay).getTime() <= new Date(res.minDate).getTime()) {
						
						this.allLoaded = true;
					} else {
						this.allLoaded = false;
					}

				});
			},
			switchJob() {
				xdapp.util.vue.on(ACTION_TYPES.SWITCH_Job, this.getNewsList);
			},
			setHeight() {
				let content = document.querySelector('#stu-main-content');
				if(content !== null && typeof content !== 'undefined') {
					let windowHeight = window.innerHeight;
					let jHight = windowHeight + 65;
					content.style.height = 'calc(' + jHight + 'px - 1.7rem)'

				}
			}
		},
		components: {
			Tip
		}
	}
</script>
<style lang="scss" scoped>
	.xdapp-news {
		overflow: auto;
		.mui-table-view {
			position: inherit;
			.mui-media-body {
				font-size: 14px;
				.mui-ellipsis {
					font-size: 12px;
				}
			}
		}
	}
</style>

<style scoped lang='scss'>
	.mui-content>.mui-table-view:first-child {
		margin-top: 0;
		padding-top: 10px;
	}
	
	.xueda-news {
		// background: #fff;
		width: 100%;
		margin-top: torem(-1);
		padding: torem(10) 0;
	}
	
	.xd-news {
		padding-top: torem(20);
		display: flex;
		padding: 10px 0 0 10px;
		justify-content: space-between;
		padding: 0 torem(23);
		align-items: center;
		height: torem(40);
		background-color: #fff;
		p {
			margin-bottom: 0;
		}
		div {
			display: flex;
			align-items: center;
		}
		.xueda-img {
			width: torem(22);
			height: torem(22);
			border-radius: 100%;
			margin-right: torem(6);
			border: 1px solid #fff;
			overflow: hidden;
			img {
				width: 100%;
				height: 100%;
			}
		}
		span {
			color: #8f8f94;
			font-size: torem(14)
		}
		span.tit {
			font-size: torem(15);
			font-weight: bold;
		}
	}
	
	.mui-table-view {
		// background: rgba(255, 255, 255, 0.89) !important;
		background-color: transparent;
		li {
			// font-size:0;
			margin: 0 torem(10);
			// background: rgba(255, 255, 255, 0.89) !important;
			border-bottom: torem(1) solid rgb(229, 229, 229) // border-bottom: 1px solid #ccc;
		}
		li.time {
			width: torem(90);
			font-size: 12px;
			text-align: center;
			background: rgba(255, 255, 255, .7);
			height: 25px;
			line-height: 25px;
			border-radius: 5px;
			margin: torem(20) auto torem(10);
		}
		li:last-child {
			border: none;
		}
		.img {
			width: torem(60);
			height: torem(43);
			margin-right: torem(15);
			img {
				width: torem(60);
				height: torem(43);
			}
		}
		.text {
			font-size: torem(15);
			margin-top: -4px;
			width: calc(100% - 60px);
			flex-basis: calc(100% - 60px);
			line-height: 1.5;
			padding: 0 5px;
			color: #666;
			span.tit01 {
				// width: 60%;
				// height: 25px;
				// overflow:hidden;
				display: block;
				line-height: 1.5;
			}
			span.time {
				font-size: torem(13);
				color: #888
			}
		}
		.firstBox {
			margin-bottom: 0;
			margin-top: 0;
			padding: 0;
			position: relative;
			.firstImg {
				width: 100%;
				height: auto;
				margin: 0;
				img {
					display: block;
				}
			}
			.firstText {
				position: absolute;
				bottom: 0;
				width: 100%;
				color: #fff;
				background: rgba(0, 0, 0, .5);
				line-height: 1.5;
				font-size: torem(16);
				overflow: hidden;
				margin-top: 0;
				// white-space: nowrap;
				// text-overflow: ellipsis;
			}
			span.time {
				font-size: torem(14);
				color: #fefefe
			}
		}
		.imgBox {
			display: flex;
			padding-left: 0;
			padding-right: 0;
			margin-bottom: 0;
			margin-top: 0;
			align-items: center;
			// margin-bottom: torem(50);
		}
		.firstImg {
			width: torem(219);
			height: torem(100);
			margin: torem(10) auto;
			img {
				width: 100%;
				height: 100%;
			}
		}
	}
	
	.mui-table-view:before,
	.mui-table-view-cell:after,
	.mui-table-view:after {
		height: 0;
	}
</style>
<style lang='scss'>
	.mm-box11 {
		background-color: transparent!important;
		ul {
			width: 95%;
			margin: 0 auto torem(30);
			border-radius: 5px;
			// padding: 0;
			// background: #fff;
			div {
				background: #fff;
				border-radius: 5px;
			}
			li {
				background: #fff;
			}
			li.item {
				width: 50%;
				margin: 0 auto;
			}
		}
	}
	
	.mui-table-view:before,
	.mui-table-view:after {
		display: none;
	}
</style>