<template>
  <div class="xdapp-message-container" ref="messageContainer">
    <loading v-show="loading" title=""></loading>
    <lesson-notify-item
      :items="lessonNotifyItems"
      :loading="loading"
      @refreshMore="refreshMore"
      v-if="lessonNotifyItems.length"/>
    <tip v-if="!hasData">
      <span>暂无课业通知</span>
    </tip>
  </div>
</template>
<script>
  import {ACTION_TYPES, NotifyCatalog, PreOrLast} from '@/constants';
  import {defaultPageSize} from '@/public/constant';
  import {loadUserInfo} from '@/api/common/common-api';
  import {$getLessonNotifyList} from '@/api/notify/notify-api';
  import LessonNotifyItem from '../partials/lesson-notify-item/index';
  import Loading from '@/components/loading/index';
  import Tip from '@/components/tip';

  export default {
    data(){
      return {
        lessonNotifyItems: [],
        params: {
          msgCatalog: NotifyCatalog.LessonNotify,
          timePoint: m2.date.now(),
          preOrLast: PreOrLast.Pre,
          queryNumber: defaultPageSize
        },
        hasData: true,
        hasMore: false,
        loading: false
      }
    },
    created(){
      this.getLessonNotifyList();
      this.switchChild();
    },
    methods: {
      async getLessonNotifyList(){
        // 判断是否切换了孩子
        if (this.$store.getters.currentChild.id !== window.swithChildOldID) {
          this.params.timePoint = m2.date.now();
          this.lessonNotifyItems = []
        }
        await loadUserInfo();

        $getLessonNotifyList(this.params, (res) => {

          this.lessonNotifyItems = this.lessonNotifyItems.concat(res.reverse());

          if (!res || !res.length || res.length < this.params.queryNumber) {
            this.hasMore = false;
          } else {
            this.hasMore = true;
            this.params.timePoint = res[0].createTime;
          }
          if (!this.lessonNotifyItems || !this.lessonNotifyItems.length) {
            this.hasData = false;
          }
          this.loading = false;
        });
      },
      switchChild(){
        xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getLessonNotifyList);
      },
      refreshMore(){
        this.loading = this.hasMore ? true : false;
        if (!this.hasMore)
          return;

        this.getLessonNotifyList();
      }
    },
    components: {
      LessonNotifyItem,
      Tip,
      Loading
    }
  }
</script>
<style lang="scss" scoped="">
  .xdapp-message-container {
    position: fixed;
    width: 100%;
    height: 100%;
  }
</style>
