<template>
  <div class="wrap">
    <ul class="mui-table-view rx-message-main">

      <!--学大资讯-->
      <router-link class="mui-table-view-cell mui-media" tag="li" :to="{name:'message-xd-news'}">
        <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/01@3x.png">
        <div class="mui-media-body">
          <p class="tit">
            <span class="tit-name">学大资讯</span>
            <span class="tit-time" v-if="XDNews">{{XDNews.createTime | dateTimeFormat}}</span>
          </p>
          <p class="mui-ellipsis txt" v-if="XDNews">{{XDNews.title}}</p>
          <p class="mui-ellipsis txt" v-show="showNews">
            <span >暂无学大资讯</span>
          </p>
        </div>
      </router-link>
      <!--系统消息-->
      <router-link class="mui-table-view-cell mui-media" tag="li" :to="{name:'message-system-notify'}">
        <img class="mui-media-object mui-pull-left" src="~@/public/asset/img/msg/03@3x.png">
        <div class="pointer" v-if="systemNotify && systemNotify.unReadedCount"></div>
        <div class="mui-media-body">
          <p class="tit">
            <span class="tit-name">系统消息</span>
            <span class="tit-time"
                  v-if="systemNotify && systemNotify.messages">{{systemNotify.messages.createTime | dateTimeFormat}}</span>
          </p>
          <p style="height:20px" class="mui-ellipsis txt" v-if="systemNotify && systemNotify.messages">
            <span class="num" v-if="systemNotify.unReadedCount">[{{systemNotify.unReadedCount}}条]</span>
            <span class="my-xd-text-s" v-html="systemNotify.messages.content"></span>
          </p>
          <p class="mui-ellipsis txt" v-else>
            <span>暂无系统消息</span>
          </p>
        </div>
      </router-link>
    </ul>
  </div>
</template>

<script>
  import {ACTION_TYPES,NotifyCatalog} from '@/constants';
  import {pager} from '@/public/constant';
  import {loadUserInfo} from '@/api/common/common-api';
  import {$getNewsList} from '@/api/news/news-api';
  import {$getLastReply} from '@/api/customer-reply/customer-reply-api';
  import {$getLastLessonNotify,$getLastSystemNotify} from '@/api/notify/notify-api';

  export default {
    data() {
      return {
        lessonNotify: {},
        customerReply: {},
        XDNews: null,
        showNews:false,
        systemNotify: {}
      }
    },
    created(){
      this.getMessageData();
      this.switchChild();
    },
    methods: {
      async getMessageData(){
        await loadUserInfo();

        let lessonNotifyParams = {msgCatalog: NotifyCatalog.LessonNotify};
        let systemNotifyParams = {msgCatalog: NotifyCatalog.SystemNotify};


        // 学大资讯
        let params = {
          newType: 2,
          pageParams:{
            pageIndex: 0,
            pageSize: 0,
            top:1,
          },
        };

        $getNewsList(params, res => {
          if (res && res.queryResult && res.queryResult.pagedData && res.queryResult.pagedData.length>0 )
            this.XDNews = res.queryResult.pagedData[0];
        });
        // 系统消息
        $getLastSystemNotify(systemNotifyParams, res => this.systemNotify = res);
      },
      switchChild(){
        xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getMessageData);
      }
    }
  }
</script>

<style lang="scss">
.my-xd-text-s *{
  font-size: torem(14);
}
</style>


<style lang="scss" scoped>
  .rx-message-main {
    padding: torem(12) torem(12) torem(10);
    li {
      margin-left: torem(-15);
      .pointer {
        position: absolute;
        width: torem(10);
        height: torem(10);
        border-radius: 50%;
        background: #fb150a;
        margin-left: torem(44);
        margin-top: torem(-4)
      }
      img {
        width: torem(50);
        height: torem(50);
        max-width: 1000px;
      }
      .tit {
        display: flex;
        justify-content: space-between;
        .tit-name {
          font-size: torem(16);
          color: #121212;
          line-height: torem(22)
        }
        .tit-time {
          font-size: torem(12);
          color: #8e8e8e;
          line-height: torem(17)
        }
      }
      .txt {
        color: #999;
        font-size: torem(14);
        margin-top: torem(8)
      }
      .num {
        color: #e03229
      }

    }
  }

</style>
