<template>
  <div class="xdapp-notify-container" ref="messageContainer">
    <lesson-notify-item
      :items="systemNotifyItems"
      :hasMore="hasMore"
      @refreshMore="refreshMore"
      v-if="systemNotifyItems.length"/>
    <tip v-if="!hasData">
      <span>暂无系统消息</span>
    </tip>
  </div>
</template>

<script>
  import {ACTION_TYPES, NotifyCatalog, PreOrLast} from '@/constants';
  import {defaultPageSize} from '@/public/constant';
  import {loadUserInfo} from '@/api/common/common-api';
  import {$getSystemNotifyList} from '@/api/notify/notify-api';
  import LessonNotifyItem from '../partials/lesson-notify-item';
  import Tip from '@/components/tip';

  export default {
    data(){
      return {
        systemNotifyItems: [],
        params: {
          msgCatalog: NotifyCatalog.SystemNotify,
          timePoint: m2.date.now(),
          preOrLast: PreOrLast.Pre,
          queryNumber: defaultPageSize
        },
        hasData: true,
        hasMore: false
      };
    },
    created(){
      this.getSystemNotifyList();
      this.switchChild();
    },
    methods: {
      async getSystemNotifyList(){
        await loadUserInfo();

        $getSystemNotifyList(this.params, (res) => {
          this.systemNotifyItems = this.systemNotifyItems.concat(res.reverse());

          if (!res || !res.length || res.length < this.params.queryNumber) {
            this.hasMore = false;
          } else {
            this.hasMore = true;
            this.params.timePoint = res[0].createTime;
          }
          if (!this.systemNotifyItems || !this.systemNotifyItems.length) {
            this.hasData = false;
          }
        });
      },
      refreshMore(){
        if (!this.hasMore)
          return;
        this.getSystemNotifyList();
      },
      switchChild(){
        xdapp.util.vue.on(ACTION_TYPES.SWITCH_CHILD, this.getSystemNotifyList);
      }
    },
    components: {
      LessonNotifyItem,
      Tip
    }
  }
</script>
<style>
.xdapp-notify-container p{color: #333;}
.xdapp-notify-container .rx-html-my img{ 
    width: calc(100% + 70px)!important;
    margin-left: -70px;
  }
</style>

<style lang="scss" scoped>
  .xdapp-notify-container {
    position: fixed;
    width: 100%;
    height: 100%;
    p{color: #333;}
  }
</style>
