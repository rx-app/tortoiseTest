﻿import Vue from 'vue';
import router from './router';
import store from './store';
import MintUI from 'mint-ui'
import 'mint-ui/lib/style.css'
import App from './App.vue'
import SignalR from './public/util/signalr.util'
import aiSDK from './public/util/ai.util'

// import VConsole from 'vconsole/dist/vconsole.min.js' //import vconsole
// let vConsole = new VConsole() // 初始化

// import SliderVerificationCode from 'slider-verification-code';
// import 'slider-verification-code/lib/slider-verification-code.css';
 
// Vue.use(SliderVerificationCode);
Vue.use(MintUI)
Vue.use(SignalR, process.env)
Vue.use(aiSDK, process.env)

window.ajaxList || (window.ajaxList=[])
router.beforeEach((to, from, next) => {
    while (window.ajaxList.length > 0) {
      window.ajaxList.shift()('cancel');
    }
    next();
})
window.$vue = new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: {App}
});
