window.onload = function () {
    var wrapBox = document.getElementsByClassName('rx-sign-code')[0];
    wrapBox.onclick = function () {
        window.xdapp.switchCode = !window.xdapp.switchCode;
        if (!window.xdapp.switchCode) {
            wrapBox.style.display = 'none'
        }
    };
    function canToImg() {
        var canvasTagImg = document.getElementById('showSizeCode').children[0].toDataURL('image/png');
        m2.util.saveHeadImgFile(Date.parse(new Date()), canvasTagImg, 80);
    }
    var downQrcode = document.getElementById('downQrcode');
    downQrcode.onclick = function (event) {
        plus.nativeUI.showWaiting('下载中...')
        canToImg();
        event.stopPropagation();
    };
}
